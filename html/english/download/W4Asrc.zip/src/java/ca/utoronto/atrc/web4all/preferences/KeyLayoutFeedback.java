/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;

import ca.utoronto.atrc.web4all.Percent2Pixels;

/**
 * Shows the sizes and spacing of keys as the user updates their width, height, and spacing via
 * some gui widget.
 *
 * @version $Id: KeyLayoutFeedback.java,v 1.4 2006/03/28 16:31:10 gus Exp $
 * @author	Joseph Scheuhammer
 *
 */
	
public class KeyLayoutFeedback extends JPanel
{
    /**
     * All the "percentages" below are even multiples of this constant.  Hence, given a multiplier
     * of "10" a percentage of "15" is actually 1.5% (10 / 15).
     */
    public final static float   PERCENT_MULTIPLIER  = 10.0f;
    /**
     * Minimum key width.  This is a percentage of the screen width.
     */
    public final static int     KEY_WIDTH_MIN       = 10;

    /**
     * Maximum key width.  This is a percentage of the screen width.
     */
    public final static int     KEY_WIDTH_MAX       = 200;

    /**
     * Default key width.  This is a percentage of the screen width.
     */
    public final static int     KEY_WIDTH_DEFAULT   = 40;

    /**
     * Minimum key height.  This is a percentage of the screen height.
     */
    public final static int     KEY_HEIGHT_MIN      = 10;
    
    /**
     * Maximum key height.  This is a percentage of the screen height.
     */
    public final static int     KEY_HEIGHT_MAX      = 150;

    /**
     * Default key height.  This is a percentage of the screen height
     */
    public final static int     KEY_HEIGHT_DEFAULT  = 30;
    
    /**
     * Minimum key spacing.  This is a percentage of the screen width.
     */
    public final static int     KEY_SPACING_MIN     = 0;

    /**
     * Maximum key spacing.  This is a percentage of the screen width.
     */
    public final static int     KEY_SPACING_MAX     = 50;

    /**
     * Default key spacing.  This is a percentage of the screen width.
     */
    public final static int     KEY_SPACING_DEFAULT = 0;
    
    /** 
     * The top left key position and size is used for all four keys.  The size is given in pixels.
     */
    private Rectangle theTopLeftKey;
    
    /**
     * Current spacing between keys, in pixels.
     */
    private int theSpacing;
	
    /** 
     * Colour of the key.
     */
    private Color theColour;
    
    /**
     * Initialize the object with an initial key size, initial spacing, and a colour.  The
     * key sizes and spacing are expressed as integer values that represent percentages of
     * the screen width or height, scaled by <code>PERCENT_MULTIPLIER</code>.  For example, 
     * if the multiplier has a value of "10", and the given spacing is "200", that equals 20%.
     * @param   inInitKeySize     The intial key size as a Dimension.
     * @param   inInitSpacing     The intial spacing between keys.
     * @see #PERCENT_MULTIPLIER
     */
    public KeyLayoutFeedback (Dimension inDimension, int inSpacing, Color inColour)
    {
        super();
        float width = ((float) inDimension.width) / PERCENT_MULTIPLIER;
        int widthI = Percent2Pixels.convert2Pixels (width / 100.0f, Percent2Pixels.WIDTH_FLAG);
        if (widthI < 0)
            widthI = KEY_WIDTH_DEFAULT;
        
        float height = ((float) inDimension.height) / PERCENT_MULTIPLIER;
        int heightI = Percent2Pixels.convert2Pixels (height / 100.0f, Percent2Pixels.HEIGHT_FLAG);
        if (heightI < 0)
            heightI = KEY_HEIGHT_DEFAULT;
        
        float spacing = ((float) inSpacing) / PERCENT_MULTIPLIER;
        int spacingI = Percent2Pixels.convert2Pixels (spacing / 100.0f, Percent2Pixels.WIDTH_FLAG);
        
        theTopLeftKey = new Rectangle (widthI, heightI);
        theSpacing = ( inSpacing < 0 ? KEY_SPACING_DEFAULT : inSpacing );
        theColour = inColour;
        
    }	// end SizeFeedback (Dimension inDimension, int inSpacing, Color inColour).

    /**
     * Initialize the object with an initial key size, and initial spacing.  The
     * key sizes and spacing are expressed as integer values that represent percentages of
     * the screen width or height, scaled by <code>PERCENT_MULTIPLIER</code>.  For example, 
     * if the multiplier has a value of "10", and the given spacing is "200", that equals 20%.
     * The colour defaults to blue.
     * @param   inInitKeySize     The intial key size as a Dimension.
     * @param   inInitSpacing     The intial spacing between keys.
     * @see #PERCENT_MULTIPLIER
     */
    public KeyLayoutFeedback (Dimension inDimension, int inSpacing)
    {
        this (inDimension, inSpacing, Color.blue);
        
    }	// end SizeFeedback (Dimension inDimension, int inSpacing).
 
    /**
     * Initialize the object with an initial key size.  The key width and height are expressed
     * as integer values that represent percentages of the screen width or height, scaled by
     * <code>PERCENT_MULTIPLIER</code>.  For example, if the multiplier has a value of "10", and
     * the given spacing is "200", that equals 20%.  The spacing will be zero, and the colour blue.
     * @param   inInitKeySize     The intial key size as a Dimension.
     * @see #PERCENT_MULTIPLIER
     */
    public KeyLayoutFeedback (Dimension inDimension)
    {
        this (inDimension, 1);
        
    }	// end SizeFeedback (Dimension inDimension).
   
    /**
     * Utility method to calculate the position of <code>theTopLeftKey</code>.  The positions of the other
     * keys are defined in terms of the top left one.  This assumes a 2x2 matrix of keys.
     */
    private void calcTopLeftPosition()
    {
        // The drawing area of the 2x2 pattern of keys is itself a rectangle whose width is the width
        // of two keys plus the spacing.  The height is the height of two keys plus the spacing.  The
        // position of the top left key is the top left of the drawing area.
        //
        int drawWidth = theTopLeftKey.width * 2 + theSpacing;
        int drawHeight = theTopLeftKey.height * 2 + theSpacing;
        
        int leftX = (int) (((float) (getWidth() - drawWidth)) / 2.0f);
        int topY = (int) (((float) (getHeight() - drawHeight)) / 2.0f);
        
        theTopLeftKey.setLocation (leftX, topY);
    
    }   // end calcTopLeftPosition()
	
	/**
	 * Override to draw a rectangle whose size is the same as the current key size.
	 * @param   ioGraphics  The Graphcis object to use for the drawing.
	 */
    public void paintComponent (Graphics ioGraphics)
    {
        super.paintComponent (ioGraphics);  // paints current background -- erases <theTopLeftKey>.
        
        // Position the keys in the centre of the drawing area.
        //
        calcTopLeftPosition();
        
        // Draw the rectangle representing the top left key.
        //
        ioGraphics.setColor (Color.blue);
        int x = theTopLeftKey.x;
        int y = theTopLeftKey.y;
        int width = theTopLeftKey.width - 1;
        int height = theTopLeftKey.height - 1;
        ioGraphics.fillRect (x, y, width, height);
        
        // Draw the top right, lower left, and bottom right keys.
        //
        x += theTopLeftKey.width + theSpacing;
        ioGraphics.fillRect (x, y, width, height);
        
        x = theTopLeftKey.x;
        y += theTopLeftKey.height + theSpacing;
        ioGraphics.fillRect (x, y, width, height);
        
        x += theTopLeftKey.width + theSpacing;
        ioGraphics.fillRect (x, y, width, height);
        
    }   // end paintComponent().

    /** 
     * Accessor to attach an anonymous ChangeListener to the given JSlider.  The slider represents changes
     * in key width.
     * @param   ioSlider   The JSlider that represents key width.
     */
    public void addWidthListener (JSlider ioSlider)
    {
        ioSlider.addChangeListener ( new ChangeListener() {
            public void stateChanged (ChangeEvent inChange) {
                JSlider widthSlider = (JSlider) inChange.getSource();
                float perCent = ((float) (widthSlider.getValue())) / (PERCENT_MULTIPLIER * 100.0f);
                int newWidth = Percent2Pixels.convert2Pixels (perCent, Percent2Pixels.WIDTH_FLAG);
                Dimension newSize =  new Dimension (newWidth, theTopLeftKey.height);
                updateSize (newSize);
            }
        });
                
    }   // addWidthListener().
    
    /** 
     * Accessor to attach an anonymous ChangeListener to the given JSlider.  The slider represents changes
     * in key height.
     * @param   ioSlider   The JSlider that represents key height.
     */
    public void addHeightListener (JSlider ioSlider)
    {
        ioSlider.addChangeListener ( new ChangeListener() {
            public void stateChanged (ChangeEvent inChange) {
                JSlider heightSlider = (JSlider) inChange.getSource();
                float perCent = ((float) (heightSlider.getValue())) /  (PERCENT_MULTIPLIER * 100.0f);
                int newHeight = Percent2Pixels.convert2Pixels (perCent, Percent2Pixels.HEIGHT_FLAG);
                Dimension newSize =  new Dimension (theTopLeftKey.width, newHeight);
                updateSize (newSize);
            }
        });
                
    }   // addHeightListener()
    
    /** 
     * Accessor to attach an anonymous ChangeListener to the given JSlider.  The slider represents changes
     * in key spacing.
     * @param   ioSlider   The JSlider that represents spacing between keys.
     */
    public void addSpacingListener (JSlider ioSlider)
    {
        ioSlider.addChangeListener ( new ChangeListener() {
            public void stateChanged (ChangeEvent inChange) {
                JSlider spacingSlider = (JSlider) inChange.getSource();
                float perCent = ((float) (spacingSlider.getValue())) / (PERCENT_MULTIPLIER * 100.0f);
                int newSpacing = Percent2Pixels.convert2Pixels (perCent, Percent2Pixels.WIDTH_FLAG);
                updateSpacing (newSpacing);
            }
        });

    }   // addSpacingListener()
    
    /**
     * Update the size of the "keys" and call repaint.  If the new size is
     * the same as the current, nothing is done.
     * @param   inNewSize   A Dimension representing the new size.
     */
    private void updateSize (Dimension inNewSize)
    {
        // Do nothing if <inNewSize> is the same as the current.
        //
        if ((inNewSize.width != theTopLeftKey.width) || (inNewSize.height != theTopLeftKey.height))
        {
            theTopLeftKey.setSize (inNewSize.width, inNewSize.height);
            repaint();
        }
    
    }   // end updateSize().

    /* 
     * Update the spacing between the "keys" and call repaint.  If the new spacing is
     * the same as the current, nothing is done.
     * @param   inNewSpacing   An int representing the new spacing between keys in pixels.
     */
    private void updateSpacing (int inNewSpacing)
    {
        // Do nothing if <inNewSpacing> is the same as the current.
        //
        if (inNewSpacing != theSpacing)
        {
            theSpacing = inNewSpacing;
            repaint();
        }
    
    }   // end updateSpacing().
        
    /**
     * A main() for testing.
     */
    public static void main (String args[])
    {
        // First, make a panel to place our slider and SizeFeedback panel into.
        //
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout (new BorderLayout());
        
        // Next, a width slider panel and JSlider to change the width of the key.
        //
        JPanel widthPanel = new JPanel();
        JSlider widthSlider = new JSlider (JSlider.HORIZONTAL, KEY_WIDTH_MIN, KEY_WIDTH_MAX, KEY_WIDTH_DEFAULT);
        JLabel widthLabel = new JLabel ("Key width");
        widthLabel.setLabelFor (widthSlider);
        widthPanel.add (widthLabel);
        widthPanel.add (widthSlider);
        
        // Next, a height slider panel and JSlider to change the width of the key.
        //
        JPanel heightPanel = new JPanel();
        JSlider heightSlider = new JSlider (JSlider.HORIZONTAL, KEY_HEIGHT_MIN, KEY_HEIGHT_MAX, KEY_HEIGHT_DEFAULT);
        JLabel heightLabel = new JLabel ("Key height");
        heightLabel.setLabelFor (heightSlider);
        heightPanel.add (heightLabel);
        heightPanel.add (heightSlider);
        
        // Next, a key spacing slider panel and JSlider to change the spacing between keys.
        //
        JPanel spacingPanel = new JPanel();
        JSlider spacingSlider = new JSlider (JSlider.HORIZONTAL, KEY_SPACING_MIN, KEY_SPACING_MAX, KEY_SPACING_DEFAULT);
        JLabel spacingLabel = new JLabel ("Key spacing");
        spacingLabel.setLabelFor (spacingSlider);
        spacingPanel.add (spacingLabel);
        spacingPanel.add (spacingSlider);
        
        // A control panel to hold all the slider panels.
        //
        JPanel controlPanel = new JPanel (new GridLayout (0,1));    // 1 column, infinite rows.
        controlPanel.add (widthPanel);
        controlPanel.add (heightPanel);
        controlPanel.add (spacingPanel);        
        
        // Create a SizeFeedback panel, and hook it up to the slider changes.
        //
        KeyLayoutFeedback aLayoutFeedback = new KeyLayoutFeedback (new Dimension (widthSlider.getValue(), heightSlider.getValue()), spacingSlider.getValue());
        aLayoutFeedback.addWidthListener (widthSlider);
        aLayoutFeedback.addHeightListener (heightSlider);
        aLayoutFeedback.addSpacingListener (spacingSlider);
        
        // Add all the pieces to the main panel.
        //
        mainPanel.add (aLayoutFeedback, BorderLayout.CENTER);
        mainPanel.add (controlPanel, BorderLayout.SOUTH);
        
        // Create a Window and show it all.
        //
        JFrame display = new JFrame ("Key Size Feedback Test");
        display.setContentPane (mainPanel);
        display.pack();
        display.setSize (480, 360);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int leftX = (screenSize.width - 480) / 2;
        int topY = (screenSize.height - 240) / 2;
        display.setLocation (leftX, topY);
        display.show();
    
    }   // end main().
   
}	// end class SizeFeedback.

