/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.net.URL;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

/**
 * Class which encapsulates the screen enhancement preferences.
 *
 * @author David Weinkauf
 * @revision $Revision: 1.14 $, $Date: 2006/03/28 16:31:10 $
 */
public class ScreenEnhancement extends PWMEditPanel 
    implements ActionListener {
  
    /**
     * The preview panel.
     */
    private JPanel textPanel;

    /**
     * The preview panel's label.
     */
    private JLabel textLabel;

    /**
     * The font type for the display text.
     */
    private String fontType;

    /**
     * The display text font size.
     */
    private int fontSize;

    /**
     * The three font face items.
     */
    private ComboBoxFontFaceItem serif, sansSerif, monospaced, cursive, fantasy;

    /**
     * Array of all the font face items.
     */
    private ComboBoxFontFaceItem[] fonts;

    /**
     * The font face combo box.
     */
    private JComboBox fontFaceBox;

    /**
     * Array of all the font sizes.
     */
    private ComboBoxItem[] fontSizes;

    /**
     * The font size combo box.
     */
    private JComboBox fontSizeComboBox;

    /**
     * The font face and size labels.
     */
    private JLabel fontFaceLabel, fontSizeLabel;

    /**
     * The border titles for the UI sections.
     */
    private TitledBorder textTitle, previewTitle;

    /**
     * The foreground color select button.
     */
    private JButton fgColourButton;

    /**
     * The background color select button.
     */
    private JButton bgColourButton;

    /**
     * The highlight color select button.
     */
    private JButton highlightColourButton;

    /**
     * The XML Document sub-tree this dialog produces in a user's preferences.
     */
    private Document document;

    /**
     * The root element of the keypad default prefs under <screen_enhance>.
     */
    private Element generic;

    /**
     * The font point suffix to display.
     */
    private static final String POINT_SUFFIX = "pt";

    /**
     * The default font size.
     */
    private static final int DEFAULT_FONT_SIZE = 19;

    /**
     * The default font size combo box.
     */
    private ComboBoxItem defaultFontSize;

    /**
     * The colour chooser dialog.
     */
    private JDialog colourChooserDialog;

    /**
     * The colour the colour chooser returns.
     */
    private Color colour;

    /**
     * The colour chooser.
     */
    private JColorChooser colourChooser;

    /**
     * Invert colour choice check box.
     */
    private JCheckBox invertColours;

    /**
     * The action listeners for the modal colour chooser.
     */
    private ActionListener okListener, cancelListener;

    /**
     * The second screen enhancement dialog.
     */
    private ScreenEnhancement2 screenEnhancement2;

    /**
     * The constructor initializes all the components in the dialog and displays them accordingly.
     * @param    pm                     the reference to the PreferenceManagaer
     * @param    root                   the root of the screen enhance XML sub-tree
     * @param    inAppType              the application type
     */
    public ScreenEnhancement(PreferenceManager pm, Element root, String inAppType) {
        super(pm, inAppType, inAppType + TITLE_SUFFIX);
    
        screenEnhancement2 = new ScreenEnhancement2(pm, this, inAppType);

        document = initDocument(root, xmlLabels.getString(SCREEN_ENHANCE), xmlLabels.getString(SE_GENERIC));
        generic = DOMUtil.getFirstChildElement(document.getDocumentElement());

        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.ScreenEnhancement", pm.language);
        ResourceBundle hashLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.HashTables", pm.language);
    
        // Setup the panel!!!

        fontType = "Sans Serif";
        fontSize = DEFAULT_FONT_SIZE;
    
        Vector fontSizeVector = new Vector();
        ComboBoxItem fontSizeItem;
        for (int i = 10; i <= 30; i++) {
            fontSizeItem = new ComboBoxItem(String.valueOf(i) + " " + POINT_SUFFIX, String.valueOf(i));
            fontSizeVector.add(fontSizeItem);

            if (i == DEFAULT_FONT_SIZE)
                defaultFontSize = fontSizeItem;
        }

        fontSizes = new ComboBoxItem[fontSizeVector.size()];
        fontSizeVector.toArray(fontSizes);

        fontSizeComboBox = new JComboBox(fontSizes);
        fontSizeComboBox.setForeground(TEXT_COLOUR);
        fontSizeComboBox.setFont(TEXT_FONT);
        fontSizeComboBox.setBackground(PANEL_BACKGROUND);		
        fontSizeComboBox.setSelectedItem(defaultFontSize);
        fontSizeComboBox.addItemListener(new FontSizeListener());

        fontSizeLabel = new JLabel(labels.getString("font.size"));
        fontSizeLabel.setForeground(TEXT_COLOUR);
        fontSizeLabel.setFont(TEXT_FONT);
        fontSizeLabel.setDisplayedMnemonic(labels.getString("font.size.mnemonic").charAt(0));
        fontSizeLabel.setLabelFor(fontSizeComboBox);
    		
        serif = new ComboBoxFontFaceItem("Serif", labels.getString("serif"), "serif");
        sansSerif = new ComboBoxFontFaceItem("Sans Serif", labels.getString("sans.serif"), "sansSerif");
        monospaced = new ComboBoxFontFaceItem("Monospaced", labels.getString("monospaced"), "monospaced");
        cursive = new ComboBoxFontFaceItem("Comic Sans MS", labels.getString("cursive"), "cursive");
        fantasy = new ComboBoxFontFaceItem("Sans Serif", labels.getString("fantasy"), "fantasy");

        ComboBoxFontFaceItem[] tempFonts = {serif, sansSerif, monospaced, cursive, fantasy};
        fonts = tempFonts;

        fontFaceBox = new JComboBox(fonts);
        fontFaceBox.setForeground(Color.black);
        fontFaceBox.setFont(TEXT_FONT);
        fontFaceBox.setBackground(PANEL_BACKGROUND);		
        fontFaceBox.setSelectedItem(sansSerif);
        fontFaceBox.addItemListener(new FontFaceItemListener());

        fontFaceLabel = new JLabel(labels.getString("font.face"));
        fontFaceLabel.setDisplayedMnemonic(labels.getString("font.face.mnemonic").charAt(0));
        fontFaceLabel.setLabelFor(fontFaceBox);
        fontFaceLabel.setFont(TEXT_FONT);
        fontFaceLabel.setForeground(TEXT_COLOUR);

        textTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("text"));
        textTitle.setTitleColor(BORDER_TITLE_COLOUR);
        textTitle.setTitleFont(BORDER_TITLE_FONT);

        fgColourButton = new JButton(labels.getString("fg"));
        fgColourButton.setIcon(new ColourIcon(Color.black));
        fgColourButton.setBackground(PANEL_BACKGROUND);
        fgColourButton.addActionListener(this);
        fgColourButton.setMnemonic(labels.getString("fg.mnemonic").charAt(0));
        fgColourButton.setHorizontalAlignment(SwingConstants.LEFT);
	
        bgColourButton = new JButton(labels.getString("bg"));
        bgColourButton.setIcon(new ColourIcon(Color.white));
        bgColourButton.setBackground(PANEL_BACKGROUND);
        bgColourButton.addActionListener(this);
        bgColourButton.setMnemonic(labels.getString("bg.mnemonic").charAt(0));
        bgColourButton.setHorizontalAlignment(SwingConstants.LEFT);

        highlightColourButton = new JButton(labels.getString("highlight"));
        highlightColourButton.setIcon(new ColourIcon(Color.red));
        highlightColourButton.setBackground(PANEL_BACKGROUND);
        highlightColourButton.addActionListener(this);
        highlightColourButton.setMnemonic(labels.getString("highlight.mnemonic").charAt(0));
        highlightColourButton.setHorizontalAlignment(SwingConstants.LEFT);

        invertColours = new JCheckBox(labels.getString("invert.colour"));
        invertColours.setMnemonic(labels.getString("invert.colour.mnemonic").charAt(0));
        invertColours.setBackground(PANEL_BACKGROUND);
        invertColours.setSelected(false);
        invertColours.addChangeListener(new InvertColourListener());
        

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel textGridPanel = new JPanel();
        textGridPanel.setBackground(PANEL_BACKGROUND);
        textGridPanel.setLayout(gridbag);

        Insets insets = new Insets(5, 5, 5, 5);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.weighty = 0.5;
        c.gridheight = 1;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        textGridPanel.add(fontSizeLabel, c);

        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0.5;
        textGridPanel.add(fontSizeComboBox, c);

        c.gridx = 0;
        c.gridy = 1;
        c.weightx = 0.0;
        textGridPanel.add(fontFaceLabel, c);

        c.gridx = 1;
        c.gridy = 1;
        c.weightx = 0.5;
        textGridPanel.add(fontFaceBox, c);

        c.gridwidth = 2;
        c.gridx = 0;
        c.gridy = 2;
        c.weightx = 0.5;
        textGridPanel.add(fgColourButton, c);

        c.gridx = 0;
        c.gridy = 3;
        c.weightx = 0.5;
        textGridPanel.add(bgColourButton, c);

        c.gridx = 0;
        c.gridy = 4;
        c.weightx = 0.5;
        textGridPanel.add(highlightColourButton, c);

        c.gridx = 0;
        c.gridy = 5;
        c.weightx = 0.5;
        textGridPanel.add(invertColours, c);

        JPanel fontPanel = new JPanel(new GridLayout(1, 1));
        fontPanel.setBorder(textTitle);
        fontPanel.setBackground(PANEL_BACKGROUND);
        fontPanel.add(textGridPanel);

        AccessibleContext ac = fontSizeLabel.getAccessibleContext();
        ac.setAccessibleParent(fontPanel);
        ac = fontSizeComboBox.getAccessibleContext();
        ac.setAccessibleParent(fontPanel);
        ac = fontFaceLabel.getAccessibleContext();
        ac.setAccessibleParent(fontPanel);
        ac = fontFaceBox.getAccessibleContext();
        ac.setAccessibleParent(fontPanel);
        ac = fgColourButton.getAccessibleContext();
        ac.setAccessibleParent(fontPanel);
        ac = bgColourButton.getAccessibleContext();
        ac.setAccessibleParent(fontPanel);
        ac = highlightColourButton.getAccessibleContext();
        ac.setAccessibleParent(fontPanel);
        ac = invertColours.getAccessibleContext();
        ac.setAccessibleParent(fontPanel);
        

        previewTitle = new TitledBorder(BORDER_TITLE_LINE,
                                        labels.getString("preview"));
        previewTitle.setTitleFont(BORDER_TITLE_FONT);
        previewTitle.setTitleColor(BORDER_TITLE_COLOUR);

        textLabel = new JLabel(labels.getString("preview.text"), JLabel.CENTER);
        textPanel = new JPanel(new BorderLayout());
        textPanel.add(textLabel, BorderLayout.CENTER);
    
        JPanel previewPanel = new JPanel(new GridLayout(1, 1));
        previewPanel.setBackground(PANEL_BACKGROUND);
        previewPanel.setBorder(previewTitle);
        previewPanel.add(textPanel);

        ac = textLabel.getAccessibleContext();
        ac.setAccessibleParent(previewPanel);

        JPanel fontAndPreviewPanel = new JPanel(new GridLayout(1, 2));
        fontAndPreviewPanel.setBackground(PANEL_BACKGROUND);
        fontAndPreviewPanel.add(fontPanel);
        fontAndPreviewPanel.add(previewPanel);

        this.add(fontAndPreviewPanel);    
        this.add(Box.createVerticalGlue());

        drawTextPanel();

        okListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    colour = colourChooser.getColor();
                    colourChooserDialog.dispose();
                }
            };

        cancelListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    colour = null;
                    colourChooserDialog.dispose();
                }
            };


    }
  
    /**
     * Set all the JPanel labels to the current PreferenceManager.language value.
     */
    protected void setNewLabels() {
        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.ScreenEnhancement", pm.language);

        fgColourButton.setMnemonic(newLabels.getString("fg.mnemonic").charAt(0));
        fgColourButton.setText(newLabels.getString("fg"));

        bgColourButton.setMnemonic(newLabels.getString("bg.mnemonic").charAt(0));
        bgColourButton.setText(newLabels.getString("bg"));

        highlightColourButton.setMnemonic(newLabels.getString("highlight.mnemonic").charAt(0));
        highlightColourButton.setText(newLabels.getString("highlight"));

        textTitle.setTitle(newLabels.getString("text"));

        fontSizeLabel.setText(newLabels.getString("font.size"));
        fontSizeLabel.setDisplayedMnemonic(newLabels.getString("font.size.mnemonic").charAt(0));

        fontFaceLabel.setText(newLabels.getString("font.face"));
        fontFaceLabel.setDisplayedMnemonic(newLabels.getString("font.face.mnemonic").charAt(0));

        textLabel.setText(newLabels.getString("preview.text"));

        serif.name = newLabels.getString("serif");
        sansSerif.name = newLabels.getString("sans.serif");
        monospaced.name = newLabels.getString("monospaced");
        cursive.name = newLabels.getString("cursive");
        fantasy.name = newLabels.getString("fantasy");

        previewTitle.setTitle(newLabels.getString("preview"));

        invertColours.setText(newLabels.getString("invert.colour"));
        invertColours.setMnemonic(newLabels.getString("invert.colour.mnemonic").charAt(0));

        setNewButtonLabels();

        drawTextPanel();
        revalidate();
        repaint();

        screenEnhancement2.setNewLabels();

    }
  
    /**
     * Draws the preview panel.
     */
    private void drawTextPanel() {
        if (invertColours.isSelected()) {
            textPanel.setBackground(((ColourIcon) fgColourButton.getIcon()).colour);		
            textLabel.setForeground(((ColourIcon) bgColourButton.getIcon()).colour);
        }
        else {
            textPanel.setBackground(((ColourIcon) bgColourButton.getIcon()).colour);		
            textLabel.setForeground(((ColourIcon) fgColourButton.getIcon()).colour);
        }

        textLabel.setFont(new Font(fontType, Font.PLAIN, fontSize));

        textPanel.repaint();

        fgColourButton.repaint();
        bgColourButton.repaint();
        highlightColourButton.repaint();
		
    }

    /**
     * Cleans up any outstanding dialogs.
     */
    protected void cleanUp() {
        if (colourChooserDialog != null)
            colourChooserDialog.dispose();
    }

    /**
     * Listens to the the colour buttons and spawns a colour chooser if activated.
     */
    public void actionPerformed(ActionEvent e) {		
        Color whichColour = ((ColourIcon) ((JButton) e.getSource()).getIcon()).colour;
        colourChooser = new JColorChooser(whichColour);
        colourChooserDialog = JColorChooser.createDialog(this, ((JButton) e.getSource()).getText(), true, colourChooser,  okListener, cancelListener);
    	   
        colourChooserDialog.show();
		
        if (colour != null) {
            ((ColourIcon) ((JButton) e.getSource()).getIcon()).colour = colour;

            drawTextPanel();
        }
        fgColourButton.repaint();
        bgColourButton.repaint();
        highlightColourButton.repaint();
    }

    /**
     * The ChangeListener for the font size slider, so that the display text size is automatically updated.
     */
    class FontSizeListener implements ItemListener {
        public void itemStateChanged(ItemEvent e) {
            ComboBoxItem item = (ComboBoxItem) e.getItem();
            fontSize = Integer.parseInt(item.value);
            drawTextPanel();
        }
    }
  
    /**
     * The ActionListener for the font face radio buttons, so the display text is automatically updated.
     */
    class FontFaceItemListener implements ItemListener {
        public void itemStateChanged(ItemEvent e) {
            ComboBoxFontFaceItem item = (ComboBoxFontFaceItem) e.getItem();
            fontType = item.font;
            drawTextPanel();
        }
    }

    /**
     * Listener to enable/disable the inversion of foreground /
     * background colours.
     */
    class InvertColourListener implements ChangeListener {
        public void stateChanged(ChangeEvent e) {

            JCheckBox box = (JCheckBox) e.getSource();
            if (box.isSelected()) {
                textPanel.setBackground(((ColourIcon) fgColourButton.getIcon()).colour);
                textLabel.setForeground(((ColourIcon) bgColourButton.getIcon()).colour);
            }
            else {
                textPanel.setBackground(((ColourIcon) bgColourButton.getIcon()).colour);
                textLabel.setForeground(((ColourIcon) fgColourButton.getIcon()).colour);
            }
            
            textPanel.repaint();
            
        }
    }
  
    /**
     * Set all the JPanel's components to their correct values corresponding to 
     * the user's XML preferences passed in through the constructor.
     */
    protected void setDomValues() {
        Element temp = DOMUtil.getFirstChildElement(generic);

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(SE_GENERIC_FONT_FACE))) {
            Element genericFace = DOMUtil.getLastChildElement(temp);
            ComboBoxFontFaceItem fontFaceItem = (ComboBoxFontFaceItem) findItem(fonts, genericFace.getAttribute(VALUE));
            fontFaceBox.setSelectedItem(fontFaceItem);
            fontType = fontFaceItem.font;
            temp = DOMUtil.getNextSiblingElement(temp);
        }
		
        if (temp != null && temp.getTagName().equals(xmlLabels.getString(SE_GENERIC_FONT_SIZE))) {
            fontSizeComboBox.setSelectedItem( findItem(fontSizes, temp.getAttribute(VALUE)) );
            temp = DOMUtil.getNextSiblingElement(temp);
        }
	
        if (temp != null && temp.getTagName().equals(xmlLabels.getString(SE_GENERIC_FG_COLOUR))) {
            String fgColourVal = temp.getAttribute(VALUE);
            ((ColourIcon) fgColourButton.getIcon()).colour = ScreenEnhancement.getACCLIPColour(fgColourVal);
            temp = DOMUtil.getNextSiblingElement(temp);				
        }
		
        if (temp != null && temp.getTagName().equals(xmlLabels.getString(SE_GENERIC_BG_COLOUR))) {
            String bgColourVal = temp.getAttribute(VALUE);
            ((ColourIcon) bgColourButton.getIcon()).colour = ScreenEnhancement.getACCLIPColour(bgColourVal);
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(SE_GENERIC_HI_COLOUR))) {
            String highlightColourVal = temp.getAttribute(VALUE);
            ((ColourIcon) highlightColourButton.getIcon()).colour = ScreenEnhancement.getACCLIPColour(highlightColourVal);

            temp = DOMUtil.getNextSiblingElement(temp);				
        }

	if (temp != null && temp.getTagName().equals(xmlLabels.getString(SE_GENERIC_INVERT_COLOURS))) {
            if (temp.getAttribute(VALUE).equals("true"))
                invertColours.setSelected(true);
            else
                invertColours.setSelected(false);

        }

        screenEnhancement2.setDomValues(temp);

        drawTextPanel();
    }

    /**
     * Construct the XML sub-tree for keyboard setup according to the user's current selections.
     *
     * @return  root element of the new XML sub-tree created
     */
    protected Element getRootElement() {
        Element temp;
    
        pm.removeAllChildren(generic);

        temp = document.createElement(xmlLabels.getString(SE_GENERIC_FONT_FACE));
        generic.appendChild(temp);

        Element genericFace = document.createElement(xmlLabels.getString(SE_GENERIC_GENERIC_FACE));
        ComboBoxFontFaceItem genericFaceItem = (ComboBoxFontFaceItem) fontFaceBox.getSelectedItem();
        genericFace.setAttribute(VALUE, genericFaceItem.value);
        temp.appendChild(genericFace);

        temp = document.createElement(xmlLabels.getString(SE_GENERIC_FONT_SIZE));
        ComboBoxItem fontSizeItem = (ComboBoxItem) fontSizeComboBox.getSelectedItem();
        temp.setAttribute(VALUE, fontSizeItem.value);
        generic.appendChild(temp);
    
        temp = document.createElement(xmlLabels.getString(SE_GENERIC_FG_COLOUR));
        temp.setAttribute(VALUE, ScreenEnhancement.getACCLIPHex(((ColourIcon) fgColourButton.getIcon()).colour));
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(SE_GENERIC_BG_COLOUR));
        temp.setAttribute(VALUE, ScreenEnhancement.getACCLIPHex(((ColourIcon) bgColourButton.getIcon()).colour));
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(SE_GENERIC_HI_COLOUR));
        temp.setAttribute(VALUE, ScreenEnhancement.getACCLIPHex(((ColourIcon) highlightColourButton.getIcon()).colour));
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(SE_GENERIC_INVERT_COLOURS));
        if (invertColours.isSelected())
            temp.setAttribute(VALUE, "true");
        else
            temp.setAttribute(VALUE, "false");
        generic.appendChild(temp);

        screenEnhancement2.addElementsTo(document);

        return document.getDocumentElement();
    }

    /**
     * Gets the Hex representation of the colour value as RGBA.
     *
     * @param  colour  the colour
     * @return  the ACCLIP hex representation as RGBA
     */
    protected static String getACCLIPHex(Color colour) {
        String hex = Integer.toHexString(colour.getRGB());
        return hex.substring(2, 8) + hex.substring(0, 2);
    }
    
    /**
     * Gets the Colour for the given ACCLIP hex.
     *
     * @param  hex  the ACCLIP hex colour
     * @return  the colour
     */
    protected static Color getACCLIPColour(String hex) {
        String red = hex.substring(0, 2);
        String green = hex.substring(2, 4);
        String blue = hex.substring(4, 6);
        String alpha = hex.substring(6, 8);

        return new Color(Integer.parseInt(red, 16),
                         Integer.parseInt(green, 16),
                         Integer.parseInt(blue, 16),
                         Integer.parseInt(alpha, 16));
        
    }


    /**
     * Sets the value of the UI to its default state.
     */
    protected void doDefault() {

        ((ColourIcon) bgColourButton.getIcon()).colour = Color.white;
        ((ColourIcon) fgColourButton.getIcon()).colour = Color.black;
        ((ColourIcon) highlightColourButton.getIcon()).colour = Color.red;

        invertColours.setSelected(false);

        drawTextPanel();
        
        fontSizeComboBox.setSelectedItem(defaultFontSize);
        
        fontFaceBox.setSelectedItem(sansSerif);
        fontType = sansSerif.font;
		
    }

    /**
     * Get the entire app type XML subtree including default 
     * preferences and third party preferences.
     *
     * @return    the screen enhance XML sub-tree.
     */
    protected Document getAppTypeDoc() {
        return document;
    }

    /**
     * Class which encapsulates a font face item.
     */
    class ComboBoxFontFaceItem extends ComboBoxItem{

        public String font;

        public ComboBoxFontFaceItem(String inFont, String inName, String inValue) {
            super(inName, inValue);
            font = inFont;
        }
		
        public String toString() {
            return name;
        }

    }

    /**
     * Shows the next dialog.
     */
    protected void doNext() {
        pm.showPanel(screenEnhancement2);
    }

    /**
     * Gets the last panel.
     */
    protected PWMEditPanel getLastPanel() {
        return screenEnhancement2.getLastPanel();
    }

    /**
     * The colour icon for the colour chooser buttons.
     */
    class ColourIcon implements Icon {

        public Color colour;
				
        public int getIconWidth() {
            return 15;
        }

        public int getIconHeight() {
            return 15;
        }

        public ColourIcon(Color inColour) {
            super();
            colour = inColour;
        }

        public void paintIcon(Component c, Graphics g, int x, int y) {
            g.setColor(Color.black);
            g.fillRect(x, y, getIconWidth(), getIconHeight());
            g.setColor(colour);
            g.fillRect(x + 2, y + 2, getIconWidth() - 4, getIconHeight() - 4);
        }

    }

}
