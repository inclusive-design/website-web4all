/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            LargeTextTheme.java
 *
 * Synopsis:        package ca.utoronto.atrc.web4all.prefschooser;
 * 
]*/

package ca.utoronto.atrc.web4all.prefschooser;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.*;
import javax.swing.plaf.basic.*;
import javax.swing.plaf.metal.*;

/**
 * Defines the large text-high contrast version of the file chooser for
 * persons with low vision.
 * @author Joseph Scheuhammer.
 * @version $Id: LargeTextTheme.java,v 1.2 2006/03/28 21:17:27 clown Exp $
 */
public class LargeTextTheme extends DefaultMetalTheme
{
    /**
     * The name of this theme.
     */
    public String getName() { return "Large Text"; }
    
    /**
     * Primary colours:  black, medium grey, and white.  Highlight is a dark
     * grey.
     */
    private final ColorUIResource primary1 =
        new ColorUIResource (0, 0, 0);
        
    private final ColorUIResource primary2 =
        new ColorUIResource (204, 204, 204);
        
    private final ColorUIResource primary3 =
        new ColorUIResource (255, 255, 255);
        
    private final ColorUIResource primaryHighlight = 
        new ColorUIResource (102,102,102);
        
    /**
     * Secondary colours:  medium grey, white, and black.  Highlight is a dark
     * grey.
     */
    private final ColorUIResource secondary2 =
        new ColorUIResource(204, 204, 204);
        
    private final ColorUIResource secondary3 =
        new ColorUIResource(255, 255, 255);
        
    private final ColorUIResource controlHighlight =
        new ColorUIResource(102,102,102);

    /**
     * Accessors for primary colours.
     */
    protected ColorUIResource getPrimary1() { return primary1; } 
    protected ColorUIResource getPrimary2() { return primary2; }
    protected ColorUIResource getPrimary3() { return primary3; }
    public ColorUIResource getPrimaryControlHighlight()
    { return primaryHighlight;}

    /**
     * Accessors for secondary colours.
     */
    protected ColorUIResource getSecondary2() { return secondary2; }
    protected ColorUIResource getSecondary3() { return secondary3; }
    public ColorUIResource getControlHighlight()
    { return super.getSecondary3(); }

    /**
     * Accessors for focus colour.
     */
    public ColorUIResource getFocusColor() { return getBlack(); }

    /**
     * Accessors for highlight colours.
     */
    public ColorUIResource getTextHighlightColor() { return getBlack(); }
    public ColorUIResource getHighlightedTextColor() { return getWhite(); }
  
    /**
     * Accessors for menu colours.
     */
    public ColorUIResource getMenuSelectedBackground() { return getBlack(); }
    public ColorUIResource getMenuSelectedForeground() { return getWhite(); }
    public ColorUIResource getAcceleratorForeground() { return getBlack(); }
    public ColorUIResource getAcceleratorSelectedForeground()
    { return getWhite(); }
    
    /**
     * Big fonts.
     */
    private final FontUIResource controlFont =
        new FontUIResource("Dialog", Font.BOLD, 24);

    private final FontUIResource systemFont =
        new FontUIResource ("Dialog", Font.PLAIN, 24);
        
    private final FontUIResource windowTitleFont =
        new FontUIResource ("Dialog", Font.BOLD, 24);
        
    private final FontUIResource userFont =
        new FontUIResource ("SansSerif", Font.PLAIN, 24);
        
    private final FontUIResource smallFont =
        new FontUIResource ("Dialog", Font.PLAIN, 20);

    /**
     * Accessors for fonts..
     */
    public FontUIResource getControlTextFont() { return controlFont;}
    public FontUIResource getSystemTextFont() { return systemFont;}
    public FontUIResource getUserTextFont() { return userFont;}
    public FontUIResource getMenuTextFont() { return controlFont;}
    public FontUIResource getWindowTitleFont() { return windowTitleFont;}
    public FontUIResource getSubTextFont() { return smallFont;}

    /**
     * Add various things to the UIDefaults lookup table.
     * @param   ioTable     The UIDefaults table to massage.
     */
    public void addCustomEntriesToTable (UIDefaults ioTable)
    {
        // Border definitions.
        //
        Border blackLineBorder = new BorderUIResource (
            new MatteBorder ( 2,2,2,2, Color.black)
        );
        Border whiteLineBorder = new BorderUIResource (
            new LineBorder (getWhite())
        );
        Border textBorder = blackLineBorder;
        
        ioTable.put ("ToolTip.border", blackLineBorder);
        ioTable.put ("TitledBorder.border", blackLineBorder);
        ioTable.put ("Table.focusCellHighlightBorder", whiteLineBorder);
        ioTable.put ("Table.focusCellForeground", getWhite());
        ioTable.put ("TextField.border", textBorder);
        ioTable.put ("PasswordField.border", textBorder);
        ioTable.put ("TextArea.border", textBorder);
        ioTable.put ("TextPane.font", textBorder);
        ioTable.put ("ScrollPane.border", blackLineBorder);
        ioTable.put ("ScrollBar.width", new Integer(25));   // big scrollbars
        
        // JInternalFrame stuff -- needed?
        //
        final int internalFrameIconSize = 30;
        ioTable.put ("InternalFrame.closeIcon", MetalIconFactory.getInternalFrameCloseIcon(internalFrameIconSize));
        ioTable.put ("InternalFrame.maximizeIcon", MetalIconFactory.getInternalFrameMaximizeIcon(internalFrameIconSize));
        ioTable.put ("InternalFrame.iconifyIcon", MetalIconFactory.getInternalFrameMinimizeIcon(internalFrameIconSize));
        ioTable.put ("InternalFrame.minimizeIcon", MetalIconFactory.getInternalFrameAltMaximizeIcon(internalFrameIconSize));
        
    }   // end addCustomEntriesToTable().

}   // end class LargeTextTheme.