/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xml.serialize.*;
import java.text.NumberFormat;
import java.net.URL;
import java.net.MalformedURLException;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

/**
 * The JPanel to edit the alternative pointing setup in a user's preferences.
 *
 * @author David Weinkauf
 * @author Joseph Scheuhammer
 * @version $Revision: 1.8 $, $Date: 2006/03/28 16:31:09 $
 */
public class AltPointing extends PWMEditPanel {

    /**
     * The pointer speed slider.
     */
    private JSlider pointerSpeedSlider;

    /**
     * The pointer acceleration slider.
     */
    private JSlider pointerAccelSlider;

    /**
     * The double click slider.
     */
    private JSlider doubleClickSlider;

    /**
     * The two radio buttons to decide the handedness value.
     */
    private JCheckBox leftHand;

    /**
     * The two bottom sliders' labels.
     */
    private JLabel pointerSpeedLabel, pointerAccelLabel;

    /**
     * The three pointerSpeedSlider labels.
     */
    private JLabel pitchLow, pitchMedium, pitchHigh;

    /**
     * The slow, medium, and fast labels.
     */
    private JLabel slow, medium, fast;

    /**
     * The two top trackball settings labels.
     */
    private TitledBorder mouseOrientation, doubleClickTitle;

    private JLabel delayLabel;

    /**
     * The two panel section titles.
     */
    private TitledBorder pointerTitle;

    /**
     * The check box to enable/disable external button assignments.
     */
    private JCheckBox buttonAssignExternal;
	
    /**
     * The text field for the external button assignment URL.
     */
    private JTextField buttonAssignExtURL;

    /**
     * The border title for external button assignment.
     */
    private TitledBorder buttonTitle;

    /**
     * Absolute pointing.
     */
    private JCheckBox absolutePointing;

    /**
     * The XML Document sub-tree this dialog produces in a user's preferences.
     */
    private Document document;

    /**
     * The root element of the trackball default prefs under <trackball>
     */
    private Element generic;

    /**
     * Initializes all the components in the dialog and displays them accordingly.
     *
     * @param  pm  the reference to the PreferenceManagaer
     * @param  root  the root of the alt pointing XML sub-tree
     */
    public AltPointing(PreferenceManager pm, Element root, String inAppType) {
        super(pm, inAppType, inAppType + TITLE_SUFFIX);
	
        document = initDocument(root, xmlLabels.getString(ALT_POINTING), xmlLabels.getString(AP_GENERIC));
        generic = DOMUtil.getFirstChildElement(document.getDocumentElement());

        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.AltPointing", pm.language);
        ResourceBundle hashLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.HashTables", pm.language);

        // Setup the panel!!!

        mouseOrientation = new TitledBorder(BORDER_TITLE_LINE, labels.getString("mouse.orientation"));
        mouseOrientation.setTitleFont(BORDER_TITLE_FONT);
        mouseOrientation.setTitleColor(BORDER_TITLE_COLOUR);
		
        leftHand = new JCheckBox(labels.getString("left.hand"));
        leftHand.setBackground(PANEL_BACKGROUND);
        leftHand.setMnemonic(labels.getString("left.hand").charAt(0));
        leftHand.setFont(TEXT_FONT);

        JPanel handedPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        handedPanel.setBackground(PANEL_BACKGROUND);
        handedPanel.setBorder(mouseOrientation);
        handedPanel.add(leftHand);

        this.add(handedPanel);
        this.add(Box.createVerticalGlue());

        Hashtable doubleClickHash = new Hashtable();
        JLabel seconds;
        NumberFormat numberFormat = NumberFormat.getInstance(pm.language);
        for (int i = 1; i <= 10; i++) {
            seconds = new JLabel(numberFormat.format( i / 10.0d ));
            seconds.setForeground(TEXT_COLOUR);
            doubleClickHash.put(new Integer(i), seconds);
        }

        doubleClickSlider = new JSlider(SwingConstants.HORIZONTAL, 1, 10, 4);
        doubleClickSlider.setPaintLabels(true);
        doubleClickSlider.setBackground(PANEL_BACKGROUND);
        doubleClickSlider.setForeground(TEXT_COLOUR);
        doubleClickSlider.setLabelTable(doubleClickHash);
        doubleClickSlider.setMajorTickSpacing(1);
        doubleClickSlider.setSnapToTicks(true);
        doubleClickSlider.setPaintTicks(true);

        delayLabel = new JLabel(labels.getString("delay"));
        delayLabel.setDisplayedMnemonic(labels.getString("delay.mnemonic").charAt(0));
        delayLabel.setLabelFor(doubleClickSlider);
        delayLabel.setFont(TEXT_FONT);
        delayLabel.setForeground(TEXT_COLOUR);

        JPanel delayPanel = new JPanel();
        delayPanel.setLayout(new BoxLayout(delayPanel, BoxLayout.X_AXIS));
        delayPanel.setBackground(PANEL_BACKGROUND);
        delayPanel.add(Box.createHorizontalStrut(INDENT_VALUE));
        delayPanel.add(delayLabel);
        delayPanel.add(Box.createHorizontalStrut(SPACING_VALUE));
        delayPanel.add(doubleClickSlider);

        doubleClickTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("double.click.delay"));
        doubleClickTitle.setTitleFont(BORDER_TITLE_FONT);
        doubleClickTitle.setTitleColor(BORDER_TITLE_COLOUR);

        JPanel doubleClickPanel = new JPanel();
        doubleClickPanel.setLayout(new BoxLayout(doubleClickPanel, BoxLayout.Y_AXIS));
        doubleClickPanel.setBorder(doubleClickTitle);
        doubleClickPanel.setBackground(Color.white);
        doubleClickPanel.add(delayPanel);

        AccessibleContext ac = delayLabel.getAccessibleContext();
        ac.setAccessibleParent(doubleClickPanel);
        ac = doubleClickSlider.getAccessibleContext();
        ac.setAccessibleParent(doubleClickPanel);        

        this.add(doubleClickPanel);
        this.add(Box.createVerticalGlue());

        ChangeListener pointingTypeListener = new ChangeListener() {
                public void stateChanged(ChangeEvent e) {
                    JCheckBox box = (JCheckBox) e.getSource();
                    if (!box.isSelected()) {
                        pointerSpeedSlider.setEnabled(true);
                        pointerSpeedLabel.setEnabled(true);
                        pointerAccelSlider.setEnabled(true);
                        pointerAccelLabel.setEnabled(true);
                    }
                    else {
                        pointerSpeedSlider.setEnabled(false);
                        pointerSpeedLabel.setEnabled(false);
                        pointerAccelSlider.setEnabled(false);
                        pointerAccelLabel.setEnabled(false);
                    }
                }
            };
					   			

        absolutePointing = new JCheckBox(labels.getString("absolute.pointing"));
        absolutePointing.setMnemonic(labels.getString("absolute.pointing.mnemonic").charAt(0));
        absolutePointing.setBackground(PANEL_BACKGROUND);
        absolutePointing.setFont(TEXT_FONT);
        absolutePointing.addChangeListener(pointingTypeListener);
		
        JPanel absolutePointingPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        absolutePointingPanel.setBackground(PANEL_BACKGROUND);
        absolutePointingPanel.add(absolutePointing);

        Hashtable pointerSpeedHash = new Hashtable();
        pitchLow = new JLabel(hashLabels.getString("low"));
        pitchLow.setForeground(TEXT_COLOUR);
        pitchMedium = new JLabel(hashLabels.getString("medium"));
        pitchMedium.setForeground(TEXT_COLOUR);
        pitchHigh = new JLabel(hashLabels.getString("high"));
        pitchHigh.setForeground(TEXT_COLOUR);
        pointerSpeedHash.put(new Integer(0), pitchLow);
        pointerSpeedHash.put(new Integer(5), pitchMedium);
        pointerSpeedHash.put(new Integer(10), pitchHigh);

        pointerSpeedSlider = new JSlider(SwingConstants.HORIZONTAL, 0, 10, 5);
        pointerSpeedSlider.setPaintLabels(true);
        pointerSpeedSlider.setBackground(PANEL_BACKGROUND);
        pointerSpeedSlider.setForeground(TEXT_COLOUR);
        pointerSpeedSlider.setLabelTable(pointerSpeedHash);
        pointerSpeedSlider.setMajorTickSpacing(5);
        pointerSpeedSlider.setMinorTickSpacing(1);
        pointerSpeedSlider.setSnapToTicks(true);
        pointerSpeedSlider.setPaintTicks(true);

        pointerSpeedLabel = new JLabel(labels.getString("pointer.speed"));
        pointerSpeedLabel.setDisplayedMnemonic(labels.getString("pointer.speed.mnemonic").charAt(0));
        pointerSpeedLabel.setLabelFor(pointerSpeedSlider);
        pointerSpeedLabel.setFont(TEXT_FONT);
        pointerSpeedLabel.setForeground(TEXT_COLOUR);

        Hashtable pointerAccelHash = new Hashtable();
        slow = new JLabel(hashLabels.getString("slow"));
        slow.setForeground(TEXT_COLOUR);
        medium = new JLabel(hashLabels.getString("medium"));
        medium.setForeground(TEXT_COLOUR);
        fast = new JLabel(hashLabels.getString("fast"));
        fast.setForeground(TEXT_COLOUR);
        pointerAccelHash.put(new Integer(0), slow);
        pointerAccelHash.put(new Integer(5), medium);
        pointerAccelHash.put(new Integer(10), fast);

        pointerAccelSlider = new JSlider(SwingConstants.HORIZONTAL, 0, 10, 5);
        pointerAccelSlider.setPaintLabels(true);
        pointerAccelSlider.setBackground(PANEL_BACKGROUND);
        pointerAccelSlider.setForeground(TEXT_COLOUR);
        pointerAccelSlider.setMajorTickSpacing(5);
        pointerAccelSlider.setMinorTickSpacing(1);
        pointerAccelSlider.setLabelTable(pointerAccelHash);
        pointerAccelSlider.setSnapToTicks(true);
        pointerAccelSlider.setPaintTicks(true);

        pointerAccelLabel = new JLabel(labels.getString("pointer.accel"));
        pointerAccelLabel.setDisplayedMnemonic(labels.getString("pointer.accel.mnemonic").charAt(0));
        pointerAccelLabel.setLabelFor(pointerAccelSlider);
        pointerAccelLabel.setFont(TEXT_FONT);
        pointerAccelLabel.setForeground(TEXT_COLOUR);

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel pointerGridPanel = new JPanel();
        pointerGridPanel.setBackground(PANEL_BACKGROUND);
        pointerGridPanel.setLayout(gridbag);

        Insets insets = new Insets(0, INDENT_VALUE, 0, INDENT_VALUE);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        pointerGridPanel.add(pointerSpeedLabel, c);

        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0.5;
        pointerGridPanel.add(pointerSpeedSlider, c);

        c.gridx = 0;
        c.gridy = 1;
        c.weightx = 0.0;
        pointerGridPanel.add(pointerAccelLabel, c);

        c.gridx = 1;
        c.gridy = 1;
        c.weightx = 0.5;
        pointerGridPanel.add(pointerAccelSlider, c);

        JPanel pointerSliderPanel = new JPanel(new GridLayout(1, 1));
        pointerSliderPanel.setBackground(PANEL_BACKGROUND);
        pointerSliderPanel.add(pointerGridPanel);

        pointerTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("pointer.title"));
        pointerTitle.setTitleColor(BORDER_TITLE_COLOUR);
        pointerTitle.setTitleFont(BORDER_TITLE_FONT);

        JPanel pointerPanel = new JPanel();
        pointerPanel.setLayout(new BoxLayout(pointerPanel, BoxLayout.Y_AXIS));
        pointerPanel.setBackground(PANEL_BACKGROUND);
        pointerPanel.setBorder(pointerTitle);
        pointerPanel.add(absolutePointingPanel);
        pointerPanel.add(pointerSliderPanel);

        ac = absolutePointing.getAccessibleContext();
        ac.setAccessibleParent(pointerSliderPanel);        
        ac = pointerSpeedLabel.getAccessibleContext();
        ac.setAccessibleParent(pointerSliderPanel);        
        ac = pointerSpeedSlider.getAccessibleContext();
        ac.setAccessibleParent(pointerSliderPanel);        
        ac = pointerAccelLabel.getAccessibleContext();
        ac.setAccessibleParent(pointerSliderPanel);        
        ac = pointerAccelSlider.getAccessibleContext();
        ac.setAccessibleParent(pointerSliderPanel);        

        this.add(pointerPanel);
        this.add(Box.createVerticalGlue());

		
        buttonAssignExternal = new JCheckBox(labels.getString("button.assign.ext"));
        buttonAssignExternal.setMnemonic(labels.getString("button.assign.ext.mnemonic").charAt(0));
        buttonAssignExternal.setFont(TEXT_FONT);
        buttonAssignExternal.setForeground(TEXT_COLOUR);
        buttonAssignExternal.setBackground(PANEL_BACKGROUND);
        buttonAssignExternal.addChangeListener(new ExtButtonAssignListener());

        buttonAssignExtURL = new JTextField("http://", 35);
	buttonAssignExtURL.getAccessibleContext().setAccessibleName(labels.getString("button.assign.ext"));
        buttonAssignExtURL.setFont(TEXT_FONT);		
        buttonAssignExtURL.setEnabled(false);

        buttonTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("button.title"));
        buttonTitle.setTitleColor(BORDER_TITLE_COLOUR);
        buttonTitle.setTitleFont(BORDER_TITLE_FONT);

        gridbag = new GridBagLayout();
        c = new GridBagConstraints();
        JPanel extButtonAssignPanel = new JPanel();
        extButtonAssignPanel.setBackground(PANEL_BACKGROUND);
        extButtonAssignPanel.setLayout(gridbag);

        insets = new Insets(0, INDENT_VALUE, 0, 0);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        extButtonAssignPanel.add(buttonAssignExternal, c);

        insets = new Insets(0, 0, 0, INDENT_VALUE);
        c.insets = insets;
        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0.5;
        extButtonAssignPanel.add(buttonAssignExtURL, c);

        JPanel buttonGridPanel = new JPanel(new GridLayout(1, 1));
        buttonGridPanel.setBackground(PANEL_BACKGROUND);
        buttonGridPanel.setBorder(buttonTitle);
        buttonGridPanel.add(extButtonAssignPanel);

        ac = buttonAssignExternal.getAccessibleContext();
        ac.setAccessibleParent(extButtonAssignPanel);
        ac = buttonAssignExtURL.getAccessibleContext();
        ac.setAccessibleParent(extButtonAssignPanel);

        this.add(buttonGridPanel);
        this.add(Box.createVerticalGlue());
		

    }

    /**
     * Listener for the external button assignment enabling.
     */
    class ExtButtonAssignListener implements ChangeListener {
        public void stateChanged(ChangeEvent e) {
            JCheckBox box = (JCheckBox) e.getSource();
            if (box.isSelected())
                buttonAssignExtURL.setEnabled(true);
            else
                buttonAssignExtURL.setEnabled(false);			
        }
    }

    /**
     * Set all the JPanel labels to the current PreferenceManager.language value.
     */
    protected void setNewLabels() {
        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.AltPointing", pm.language);
        ResourceBundle newHashLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.HashTables", pm.language);
	
        absolutePointing.setText(newLabels.getString("absolute.pointing"));
        absolutePointing.setMnemonic(newLabels.getString("absolute.pointing.mnemonic").charAt(0));
		
        doubleClickTitle.setTitle(newLabels.getString("double.click.delay"));
        mouseOrientation.setTitle(newLabels.getString("mouse.orientation"));
        leftHand.setText(newLabels.getString("left.hand"));
        leftHand.setMnemonic(newLabels.getString("left.hand.mnemonic").charAt(0));
        delayLabel.setText(newLabels.getString("delay"));
        delayLabel.setDisplayedMnemonic(newLabels.getString("delay.mnemonic").charAt(0));

        pointerSpeedLabel.setText(newLabels.getString("pointer.speed"));
        pointerSpeedLabel.setDisplayedMnemonic(newLabels.getString("pointer.speed.mnemonic").charAt(0));
        pitchLow.setText(newHashLabels.getString("low"));
        pitchMedium.setText(newHashLabels.getString("medium"));
        pitchHigh.setText(newHashLabels.getString("high"));
        pointerAccelLabel.setText(newLabels.getString("pointer.accel"));
        pointerAccelLabel.setDisplayedMnemonic(newLabels.getString("pointer.accel.mnemonic").charAt(0));
        slow.setText(newHashLabels.getString("slow"));
        medium.setText(newHashLabels.getString("medium"));
        fast.setText(newHashLabels.getString("fast"));
        pointerTitle.setTitle(newLabels.getString("pointer.title"));   

        buttonTitle.setTitle(newLabels.getString("button.title"));
        buttonAssignExternal.setText(newLabels.getString("button.assign.ext"));
        buttonAssignExternal.setMnemonic(newLabels.getString("button.assign.ext.mnemonic").charAt(0));
	buttonAssignExtURL.getAccessibleContext().setAccessibleName(newLabels.getString("button.assign.ext"));

        Hashtable doubleClickHash = new Hashtable();
        JLabel seconds;
        NumberFormat numberFormat = NumberFormat.getInstance(pm.language);
        for (int i = 1; i <= 10; i++) {
            seconds = new JLabel(numberFormat.format( i / 10.0d ));
            seconds.setForeground(TEXT_COLOUR);
            doubleClickHash.put(new Integer(i), seconds);
        }
        doubleClickSlider.setLabelTable(doubleClickHash);

        setNewButtonLabels();

        revalidate();
        repaint();
    }

    /**
     * Set all the JPanel's components to their correct values corresponding to 
     * the user's XML preferences passed in through the constructor.
     */
    protected void setDomValues() {
        Element temp = DOMUtil.getFirstChildElement(generic);

        if (temp != null && (temp.getTagName().equals(xmlLabels.getString(AP_GENERIC_REL_POINT)) || temp.getTagName().equals(xmlLabels.getString(AP_GENERIC_ABS_POINT)))) {
            if (temp.getTagName().equals(xmlLabels.getString(AP_GENERIC_REL_POINT))) {
                absolutePointing.setSelected(false);
                Element tempChild = DOMUtil.getFirstChildElement(temp);
                pointerSpeedSlider.setValue( (int) (Float.parseFloat(tempChild.getAttribute(VALUE)) * 10));
                tempChild = DOMUtil.getNextSiblingElement(tempChild);
                pointerAccelSlider.setValue( (int) (Float.parseFloat(tempChild.getAttribute(VALUE)) * 10));
            }
            else if (temp.getTagName().equals(xmlLabels.getString(AP_GENERIC_ABS_POINT))) {
                absolutePointing.setSelected(true);
                pointerSpeedSlider.setEnabled(false);
                pointerSpeedLabel.setEnabled(false);
                pointerAccelSlider.setEnabled(false);
                pointerAccelLabel.setEnabled(false);
            }

            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(AP_GENERIC_HAND))) {
            if (temp.getAttribute(VALUE).equals("left"))
                leftHand.setSelected(true);					
            else if (temp.getAttribute(VALUE).equals("right"))
                leftHand.setSelected(false);

            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(AP_GENERIC_DBLCLICK))) {
            int i = (int) (Float.parseFloat(temp.getAttribute(VALUE)) * 10);
            doubleClickSlider.setValue( (int) (Float.parseFloat(temp.getAttribute(VALUE)) * 10) );
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(AP_GENERIC_BUTTON_EXT))) {
            buttonAssignExternal.setSelected(true);
            buttonAssignExtURL.setText(temp.getAttribute(VALUE));
        }

    }
    
    /**
     * Construct the XML sub-tree for keyboard setup according to the user's current selections.
     * @return    Element    The root element of the new XML sub-tree created.
     */
    protected Element getRootElement() {
        Element temp;
	
        PreferenceManager.removeAllChildren(generic);

        if (!absolutePointing.isSelected()) {
            temp = document.createElement(xmlLabels.getString(AP_GENERIC_REL_POINT));
            generic.appendChild(temp);

            Element tempChild = document.createElement(xmlLabels.getString(AP_GENERIC_SPEED));
            tempChild.setAttribute(VALUE, String.valueOf(pointerSpeedSlider.getValue() / 10.0));
            temp.appendChild(tempChild);
			
            tempChild = document.createElement(xmlLabels.getString(AP_GENERIC_ACCEL));
            tempChild.setAttribute(VALUE, String.valueOf(pointerAccelSlider.getValue() / 10.0));
            temp.appendChild(tempChild);
        }
        else {
            temp = document.createElement(xmlLabels.getString(AP_GENERIC_ABS_POINT));
            generic.appendChild(temp);
        }

        temp = document.createElement(xmlLabels.getString(AP_GENERIC_HAND));
        generic.appendChild(temp);	
        if (leftHand.isSelected())
            temp.setAttribute(VALUE, "left");
        else 
            temp.setAttribute(VALUE, "right");
		

        temp = document.createElement(xmlLabels.getString(AP_GENERIC_DBLCLICK));
        temp.setAttribute(VALUE, String.valueOf(doubleClickSlider.getValue() / 10.0));
        generic.appendChild(temp);

        if (buttonAssignExternal.isSelected()) {
            temp = document.createElement(xmlLabels.getString(AP_GENERIC_BUTTON_EXT));
            temp.setAttribute(VALUE, buttonAssignExtURL.getText());
            generic.appendChild(temp);
        }

        return document.getDocumentElement();
    }

    protected void doNext() {

        if (buttonAssignExternal.isSelected()) {
            try {
                URL lexicon = new URL(buttonAssignExtURL.getText());
            }
            catch (MalformedURLException murle) {
                ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.AltPointing", pm.language);
                JOptionPane.showMessageDialog(this, labels.getString("malformed.url"),
                                              labels.getString("malformed.url.title"),
                                              JOptionPane.WARNING_MESSAGE);
                return;            
            }
        }

        super.doNext();
    }

    protected void doDefault() {
        absolutePointing.setSelected(false);
        pointerSpeedSlider.setValue(5);
        pointerAccelSlider.setValue(5);
        leftHand.setSelected(false);
        doubleClickSlider.setValue(4);
        buttonAssignExtURL.setText("http://");
        buttonAssignExternal.setSelected(false);
    }


    /**
     * Get the entire app type XML subtree including default preferences and third party preferences.
     * @return    The entire <trackball> XML sub-tree.
     */
    protected Document getAppTypeDoc() {
        return document;
    }

}
