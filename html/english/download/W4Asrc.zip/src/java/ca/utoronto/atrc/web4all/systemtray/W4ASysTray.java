/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            W4ASysTray.java
 *
 * Synoposis:       package ca.utoronto.atrc.web4all.systemtray;
 *
]*/

package ca.utoronto.atrc.web4all.systemtray;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*;         // Vector, Itereator, ResourceBundle, etc.

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;

import snoozesoft.systray4j.*;

import ca.utoronto.atrc.web4all.ControlHub;

/**
 * Web-4-All System Tray Representation.  This class acts as a relay between
 * the ControlHub and the Windows system tray.
 * <p>
 * This class actually does more than necessary as it it allows an arbitrary
 * set of menu item functions to be placed on the right click of the system
 * tray icon.  At the time of this writing, it is assumed that:
 * <ul>
 * <li>Web-4-All icon is displayed in the system tray.</li>
 * <li>Show/hide main window clicking on this icon.</li>
 * <li>Show/hide main window via keyboard navigation to this icon.</li>
 * </ul>
 * @author Joseph Scheuhammer
 * @author Chris Ridpath
 * @version $Id: W4ASysTray.java,v 1.2 2006/03/28 21:17:27 clown Exp $
 */
public class W4ASysTray implements SysTrayMenuListener, PropertyChangeListener
{
    /**
     * The main system tray menu invoked by clicking on the icon in the system
     * tray.
     */
    private SysTrayMenu theMainMenu;
    
    /**
     * Temporary storage of the menu items.
     */
    private volatile Vector theMenuItems;
    
    /**
     * The Web-4-All main window.
     */
    public JFrame theW4Awindow;
    
    /**
     * The ActionListener to call to actually handle menu selections.
     */
    ActionListener theRealHandler;
    
    /**
     * The icon to display in the system tray.
     */
    SysTrayMenuIcon theIcon;

    /**
     * Initialize the system tray representation of Web-4-All by creating the
     * main system tray menu, and recording the action listener that handles
     * menu choices.
     * @param   inActionListener    The ActionListener that actually handles
     *                              system tray menu item selections.
     */
    public W4ASysTray (ActionListener inActionListener)
    {
        super();
        theMenuItems = new Vector();
        theRealHandler = inActionListener;
        
        // Get the icon date, make a SysTrayMenuIcon with it, and add <this> as
        // a menu listener to it.
        //
        theIcon = new SysTrayMenuIcon (
            getClass().getResource ("web4all_logo.ico")
        );
        theIcon.addSysTrayMenuListener (this);

        // Create the main menu for now, but not items, yet.  Assign a
        // a resonable tool tip for now.
        //
        theMainMenu = new SysTrayMenu (theIcon, "Web-4-All");

    }   // end W4ASysTray().

    /**
     * Create menus/menu items for the system tray invoker.  If the
     * <code>inLabel</code> is the separator character ("-"), this creates a
     * separator item.
     * @param   inLabel     The menu/menuItem's label (String).
     * @param   inActionCmd The associated action command (String).
     */
    public void createMenuItem (String inLabel, String inActionCmd)
    {
        // Check for separator.
        //
        if (inLabel.equals ("-"))
            theMenuItems.add (0, inLabel);
        else
        {
            SysTrayMenuItem anItem = new SysTrayMenuItem (inLabel, inActionCmd);
            anItem.addSysTrayMenuListener (this);
            theMenuItems.add (0, anItem);
        }
        
    }   // end createMenuItem().
    
    /**
     * Signal indicating that all menu items are ready to be added to
     * the system tray menu.  NB:  This assumes that
     * <code>createMenuItem()</code> has been called to create the menu items
     * to add.  As a precaution against duplication of items, this will first
     * remove any and all menu items in the system tray menu.
     * @see #createMenuItem(String,String)
     */
    public void createMenu()
    {
        // Prep:  remove any items from the current menu to avoid duplication.
        //
        theMainMenu.removeAll();
        
        // Iterate through the items in <theMenuItems>, and add them.
        //
        Iterator items = theMenuItems.iterator();
        while (items.hasNext())
        {
            Object anItem = items.next();
            
            // Check for separator.
            //
            if (anItem instanceof String)
            {
                if (((String) anItem).equals ("-"))
                    theMainMenu.addSeparator();
            }
            
            // Otherwise, check for SysTrayMenuItem.  If neither,
            // don't add.
            //
            else if (anItem instanceof SysTrayMenuItem)
                theMainMenu.addItem ((SysTrayMenuItem) anItem);
        }
        
        // This next call is to insure that the tool tip is in the correct
        // language.  This method may have been called to update the language
        // of <theMainMenu>; the system tray icon tool tip should also be so
        // updated.
        //
        setIconToolTip();
        
    }   // end createMenu().
    
    /**
     * Allow "friends" to flush the menu items stored in the Vector used to
     * create the system tray menu.  
     */
    void flushMenuItemVector()
    {
        theMenuItems.removeAllElements();
    
    }   // end flushMenuItemVector()
    
    /**
     * Allow "friends" to tell us what our application window is.  Also, this
     * re-configures the window's close operation to hide the window when 
     * closed.  Use the window title, if any, as the tooltip for the system
     * tray icon.
     * @param   inWindow    The Web-4-All main window, that this system tray
     *                      icon "controls" (JFrame).
     */
    void setMainWindow (JFrame inWindow)
    {
        theW4Awindow = inWindow;
        theW4Awindow.setDefaultCloseOperation (JFrame.HIDE_ON_CLOSE);
        setIconToolTip();
    
    }   // end setMainWindow().
    
    /**
     * Set the tool tip text for the system tray menu item.
     */
    void setIconToolTip()
    {
        if (theW4Awindow != null)
        {
            String title = theW4Awindow.getTitle();
            if (title != null)
                theMainMenu.setToolTip (title);
        }
        
    }   // end setIconToolTip().
    
    /**
     * Show/hide the main Web-4-All window.
     */
    private void showHideMainWindow()
    {
        if (theW4Awindow != null)
        {
            if (theW4Awindow.isVisible())
                theW4Awindow.hide();
            else
            {
                theW4Awindow.show();
                theW4Awindow.setState (java.awt.Frame.NORMAL);
                theW4Awindow.requestFocus();
            }       
        }
    
    }   // end showHideMainWindow().
    
    /**
     * Update the UI apropos the new locale. This changes the text of the
     * tooltip on the system tray icon, which, in turn, is based on the title
     * of the main window.
     * @param   inLocale    The new Locale.
     */
    private void updateLocale (Locale inLocale)
    {
        setIconToolTip();
    
    }   // updateLocale().
    
//==================================
// SysTrayMenuListener implemenation
//==================================

    /**
     * Handle menu item selections by casting them as ActionEvent's,
     * and redireccting them to the real handler.
     * @param   e   The SysTrayMenuEvent that "called" us.
     */
    public void menuItemSelected (SysTrayMenuEvent e)
    {
        // Set up a runnable to dispatch to the AWT event queue in case the
        // current thread is not the event queue thread.
        //
        String cmd = e.getActionCommand();
        final ActionEvent action = new ActionEvent (
            this, ActionEvent.ACTION_PERFORMED, cmd
        );
        
        Runnable handleAction = new Runnable() {
            public void run() {
                theRealHandler.actionPerformed (action);
            }
        };
        SwingUtilities.invokeLater (handleAction);
    
    }   // menuItemSelected().

    /**
     * Left-click on the sytem tray icon is a no-op..
     * @param   e   The SysTrayMenuEvent that called us.
     */
    public void iconLeftClicked (SysTrayMenuEvent e)
    {
        ;
        
    }   // end iconLeftClicked().

    /**
     * Show/hide the Web-4-All main window on a left-double-click.
     * @param   e   The SysTrayMenuEvent that called us.
     */
    public void iconLeftDoubleClicked( SysTrayMenuEvent e )
    {
        showHideMainWindow();
    
    }   // end iconLeftDoubleClicked().
    
//==================================
// interface PropertyChangeListener.
//==================================

    /**
     * Handle changes in locale, and changes to Web-4-All's main window.
     *
     * @param   inEvent   The event that called us.
     */
    public void propertyChange (PropertyChangeEvent inEvent)
    {
        // Check for change in locale.
        //
        if (inEvent.getPropertyName() == ControlHub.LOCALE_PROP)
        {
            final Locale newLocale = (Locale) inEvent.getNewValue();
            Runnable rebuildMenu = new Runnable() {
                public void run() {
                    updateLocale (newLocale);
                }
            };
            SwingUtilities.invokeLater (rebuildMenu);
        }

        // Check for new W4A main window.
        //
        if  (inEvent.getPropertyName() == ControlHub.MAIN_WINDOW_PROP)
        {
            JFrame mainWindow = (JFrame) inEvent.getNewValue();
            if (mainWindow != null)
                setMainWindow (mainWindow);
        }
    
    }   // end propertyChange().

}   // end class W4ASysTray.
