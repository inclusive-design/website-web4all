/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            SpeechLog.java
 *
 * Synopsis:        package ca.utoronto.atrc.web4all.prefschooser;
 * 
]*/

package ca.utoronto.atrc.web4all.prefschooser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Displays the speech output in a window.
 *
 * @version $Id: SpeechLog.java,v 1.4 2006/03/28 21:17:27 clown Exp $
 * @author  Joseph Scheuhammer.
 *
 */
public class SpeechLog extends JPanel implements ActionListener
{
    /**
     * Feedback area to show what is being spoken.
     */
    private TextArea theFeedback;
    
    /**
     * The feedback window.
     */
    private JFrame theWindow;
    
    /**
     * Singleton instance of this class to be shared by all.
     */
    private static SpeechLog sharedInstance;
    
    /**
     * Acquire or create and acquite the single shared instance of this class.
     * @return  The global shared instance of the SpeechLog.
     */
    public static SpeechLog getSharedInstance()
    {
        if (sharedInstance == null)
            sharedInstance = new SpeechLog();

        return sharedInstance;
    
    }   // end getSharedInstance().
    
    /**
     * Constructor.
     */
    public SpeechLog()
    {
        super (new BorderLayout());
        setPreferredSize (new Dimension (300, 200));
        
        // Create the text area for displaying feedback, and scrolling it.
        //
        theFeedback = new TextArea ("Speech Log", 10, 20, TextArea.SCROLLBARS_VERTICAL_ONLY);
        
        // Create a clear button to clear the feedback area.
        //
        JButton clear = new JButton ("Clear");
        clear.addActionListener (this);
        add (clear, BorderLayout.PAGE_START);
        add (theFeedback, BorderLayout.CENTER);
        
 
        // Create a window to show the feedback.
        //
        theWindow = new JFrame ("Speech Feedback");
        theWindow.getContentPane().setLayout (new BorderLayout());
        theWindow.getContentPane().add (BorderLayout.CENTER, this);
        theFeedback.setText ("Feedback Started\n");
    
    }   // end SpeechLog().
    
    /**
     * Allow friends to show or hide the feedback window.
     */
    void showHideFeedbackWindow()
    {
        if (theWindow.isVisible())
            theWindow.hide();
        else
        {
            theWindow.pack();
            theWindow.show();
        }
        
    }   // end showHideFeedbackWindow().

    /**
     * Add new text feedback to the log.
     * @param   inSpeech    The new speech feedback to append to the log.
     */
    public void appendSpeech (String inSpeech)
    {
        theFeedback.append ("\n" + inSpeech + "\n");

    }   // end appendSpeech().
    
    /**
     * Handle the "Clear" button at the top of the display of the log.  Clear
     * the display of all text.
     * @param   inEvent     The ActionEvent that called us.
     */
    public void actionPerformed (ActionEvent inEvent)
    {
        theFeedback.setText ("Feedback Cleared\n");
        
    }   // end actionPerformed().
    
}   // end class SpeechLog.