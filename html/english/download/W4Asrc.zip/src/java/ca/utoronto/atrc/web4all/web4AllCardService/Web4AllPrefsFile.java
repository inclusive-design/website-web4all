/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 */   
package ca.utoronto.atrc.web4all.web4AllCardService;

import java.util.*;
import opencard.core.*;
import opencard.core.service.*;
import opencard.core.event.*;
import opencard.core.terminal.*;
import opencard.core.terminal.CardTerminalRegistry;
import opencard.core.util.*;
import opencard.opt.util.*;
import opencard.opt.iso.fs.*;
import com.ibm.opencard.util.*;

/**
  * A representation of the Web4All preferences file as a java object. 
*/   
public class Web4AllPrefsFile {
	static final byte[] COOKIE = {(byte)0x4a, (byte)0xc0};
	static final byte[] VERSION = {(byte)0x01};
	static final byte LEN_SIZE = 2;
	static final int HEADER_SIZE = COOKIE.length + VERSION.length + LEN_SIZE;
	static final int LEN_START_POS = COOKIE.length + VERSION.length;

	boolean initialized = false; // Have we used this file before?
	Web4AllCardService w4acs;	// Object that knows how to talk to the card.
	CardChannel theChannel;  // For sending commands to card.
	private int fileSize;	// Number of bytes in the file.
	private int version;	// Version number
	private int datalen;	// size of preference data.
	private byte[] thePrefs;	// Preferences string.
	private byte[] header = new byte[HEADER_SIZE];
	
	public Web4AllPrefsFile(Web4AllCardService cs, SelectFileResponse sfr) throws OpenCardException {
		super();
		w4acs = cs;
		fileSize = sfr.getFileSize();
		theChannel = cs.getCardChannel();
		readHeader();
		if (fileSize > HEADER_SIZE) {
			if (ByteArray.equal(COOKIE, makeBytes(header, 0, COOKIE.length))) {
				initialized = true;
			}
		}
		else {
			throw new W4ACardServiceException("Preferences File is too small");
		}
	}
	
	/*public Web4AllPrefsFile(byte[] hdr) throws W4ACardServiceException {
		super();
		if (hdr.length != HEADER_SIZE) {
			throw new W4ACardServiceException("Preference File header size is wrong");
		}
		for (int i = 0; i < HEADER_SIZE; i++) {
		    header[i] = hdr[i];
		}
	}*/
	
	public boolean isInitialized() {
		return initialized;
	}
	
	public void initialize() throws OpenCardException {
		byte[] hdr = makeHeader();
		for (int i = 0; i < header.length; i++) {
		    header[i] = hdr[i];
		}
		writeHeader();
		initialized = true;
	}
	
	public void writeData(byte[] data) throws OpenCardException {
		setHeaderVal(data.length, LEN_START_POS, LEN_SIZE);
		writeHeader();
		w4acs.writeEF(w4acs.getCardChannel(), fileSize, data, HEADER_SIZE, data.length);
	}
	
	public byte[] readData() throws OpenCardException {
		int len = getDataLength();
		if (len > 0) {
			byte[] buffer = new byte[len];
			w4acs.readEF(theChannel, fileSize, buffer, HEADER_SIZE, buffer.length);
			return buffer;
		}
		else {
			return null;
		}
	}
		
	
	public int getHeaderSize() {
		return HEADER_SIZE;
	}
	
	private void readHeader() throws OpenCardException {
		readHeader(theChannel);
	}
	
	private void readHeader(CardChannel cc) throws OpenCardException {
		w4acs.readEF(cc, fileSize, header, 0, HEADER_SIZE);
	}
	
	private void writeHeader() throws OpenCardException {
		writeHeader(theChannel);
	}
	
	private void writeHeader(CardChannel cc) throws OpenCardException {
		w4acs.writeEF(cc, fileSize, header, 0, HEADER_SIZE);
	}
		
	public int getDataLength() {
		return makeIntFromHeader(LEN_START_POS, LEN_SIZE);
	}
	
	private static byte[] makeHeader() {
		byte[] hdr = new byte[HEADER_SIZE];
		for (int i = 0; i < COOKIE.length; i++) {
			hdr[i] = COOKIE[i];
		}
		for (int i = 0; i < VERSION.length; i++) {
			hdr[i + COOKIE.length] = VERSION[i];
		}
		for (int i = 0; i < LEN_SIZE; i++) {
			hdr[i + COOKIE.length + VERSION.length] = (byte)0x00;
		}
		return hdr;
	}
	
	private static byte[] makeBytes(byte[] ba, int start, int len) {
		byte[] res = new byte[len];
		for (int i = 0; i < len; i++) {
		    res[i] = ba[i + start];
		}
		return res;
	}
	
	private int makeIntFromHeader(int start, int len) {
		int theInt = 0;
		int wki;
		int shift = 0;
		byte[] wka = makeBytes(header, start, len);
		for (int i = len - 1; i >= 0; i--) {
			wki = header[i + start] & 0x000000ff;
			theInt += wki << shift;
			shift += 8;
		}
		return theInt;
	}
	
	private void setHeaderVal(int val, int start, int len) {
		int shift = 0;
		for (int i = len -1; i >= 0; i--) {
		    header[i + start] = (byte)((val >>> shift) & 0x000000ff);
			shift += 8;
		}
	}
}
