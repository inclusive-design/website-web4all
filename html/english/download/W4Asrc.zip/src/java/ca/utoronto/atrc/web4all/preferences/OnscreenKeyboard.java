/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.net.URL;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

/**
 * The first panel to edit the onscreen keyboard setup in a user's preferences.
 *
 * @author David Weinkauf
 * @version $Revision: 1.16 $, $Date: 2006/03/28 16:31:10 $
 */
public class OnscreenKeyboard extends PWMEditPanel {
  
    /**
     * Dynamic panels for display of selection method preferences.
     */
    private JPanel selectedPanel, pointClickPanel, pointDwellPanel, 
        automaticScanningPanel, scanningPanel;
    
    /**
     * The selection method items.
     */
    private ComboBoxItem pointAndClick, pointAndDwell, automaticScanning, 
        inverseScanning, directedScanning, codeSelection;

    /**
     * The combo box for housing the selection method items.
     */ 
    private JComboBox selectionMethodComboBox;

    /**
     * Array of all selection method items.
     */
    private ComboBoxItem[] selectionMethods;

    /**
     * The keyboard layout types.
     */
    private ComboBoxItem standard, sequential, frequency;

    /**
     * The keyboard layout combo box.
     */
    private JComboBox keyArrangementComboBox;

    /**
     * Array of all the key arrangements.
     */
    private ComboBoxItem[] arrangements;

    /**
     * The bottom radio buttons' labels.
     */
    private JLabel keyArrangementLabel;

    /**
     * Check box to enable / disable key sounds.
     */
    private JCheckBox keySound;

    /**
     * The keyboard layout title label.
     */
    private TitledBorder keyTitle;

    /**
     * Action command for point and click.
     */
    private static final String POINT_AND_CLICK = "point.and.click";

    /**
     * Action command for point and dwell.
     */
    private static final String POINT_AND_DWELL = "point.and.dwell";

    /**
     * Action command for single switch.
     */
    private static final String SINGLE_SWITCH = "single.switch";

    /**
     * Action command for inverse scanning.
     */
    private static final String INVERSE_SCANNING = "inverse.scanning";

    /**
     * Repeat cycles combo box.
     */
    private JComboBox repeatCyclesComboBox;

    /**
     * The repeat cycles combo box items.
     */
    private ComboBoxItem[] repeatCyclesItems;

    /**
     * The "infinity" repeat cycles item.
     */
    private ComboBoxItem infinity;

    /**
     * The switch delay and dwell time sliders' labels.
     */
    private JLabel switchDelay, dwellTime;

    /**
     * The single switch automatic scanning option labels.
     */
    private JLabel scanSpeed, autoScanSpeed, autoScanSwitchDelay, repeatCycles, 
        initialDelay, scanSwitchDelay;

    /**
     * The title of the editing box.
     */
    private TitledBorder selectionMethodTitle;

    /**
     * The selection method label.
     */
    private JLabel selectionMethodLabel;

    /**
     * The ranged text fields.
     */
    private RangedTextField dwellTimeField, scanSpeedField, autoScanSpeedField, switchDelayField, 
        initialDelayField, scanSwitchDelayField, autoScanSwitchDelayField;

    /**
     * The reference to the second onscreen keyboard editing screen.
     */
    private OnscreenKeyboard2 onscreenKeyboardD2;

    /**
     * The XML Document sub-tree this dialog produces in a user's preferences.
     */
    private Document document;

    /**
     * The onscreen keyboard 'generic' container element.
     */
    private Element generic;

    /**
     * Sole constructor. Initializes all the components in the dialog and 
     * displays them accordingly.
     *
     * @param    pm     the reference to the PreferenceManager.
     * @param    root   the root of the onscreen keyboard preferences
     * @param    inAppType  the application type
     */
    public OnscreenKeyboard(PreferenceManager pm, Element root, 
                            String inAppType) {
        super(pm, inAppType, inAppType + TITLE_SUFFIX);

        document = initDocument(root, xmlLabels.getString(ONSCREEN_KEYBOARD), 
                                xmlLabels.getString(OK_GENERIC));
        generic = DOMUtil.getFirstChildElement(document.getDocumentElement());

        onscreenKeyboardD2 = new OnscreenKeyboard2(pm, this, inAppType, titleKey);
           
        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.OnscreenKeyboard", 
                                                         pm.language);
        ResourceBundle hashLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.HashTables", 
                                                             pm.language);

        standard = new ComboBoxItem(labels.getString("standard"), "standard");
        sequential = new ComboBoxItem(labels.getString("sequential"), "sequential");
        frequency = new ComboBoxItem(labels.getString("by.frequency"), "frequency");
        
        ComboBoxItem[] tempArrangements = { standard, sequential, frequency };
        arrangements = tempArrangements;

        keyArrangementComboBox = new JComboBox(arrangements);
        keyArrangementComboBox.setBackground(PANEL_BACKGROUND);
        
        keyArrangementLabel = new JLabel(labels.getString("key.arrange"));
        keyArrangementLabel.setDisplayedMnemonic(labels.getString(
                "key.arrange.mnemonic").charAt(0));
        keyArrangementLabel.setFont(TEXT_FONT);
        keyArrangementLabel.setForeground(TEXT_COLOUR);
        keyArrangementLabel.setLabelFor(keyArrangementComboBox);

        JPanel keyArrangementPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        keyArrangementPanel.setBackground(PANEL_BACKGROUND);
        keyArrangementPanel.add(keyArrangementLabel);
        keyArrangementPanel.add(keyArrangementComboBox);

        keySound = new JCheckBox(labels.getString("key.sound"));
        keySound.setMnemonic(labels.getString("key.sound.mnemonic").charAt(0));
        keySound.setFont(TEXT_FONT);
        keySound.setForeground(TEXT_COLOUR);
        keySound.setBackground(PANEL_BACKGROUND);
        keySound.setSelected(true);

        JPanel keySoundPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        keySoundPanel.setBackground(PANEL_BACKGROUND);
        keySoundPanel.add(keySound);

        keyTitle = new TitledBorder(BORDER_TITLE_LINE, 
                                    labels.getString("key.title"));
        keyTitle.setTitleColor(BORDER_TITLE_COLOUR);
        keyTitle.setTitleFont(BORDER_TITLE_FONT);        


        JPanel keyPanel = new JPanel();
        keyPanel.setLayout(new BoxLayout(keyPanel, BoxLayout.Y_AXIS));
        keyPanel.setBackground(PANEL_BACKGROUND);
        keyPanel.setBorder(keyTitle);
        keyPanel.add(keyArrangementPanel);
        keyPanel.add(keySoundPanel);

        AccessibleContext ac = keyArrangementLabel.getAccessibleContext();
        ac.setAccessibleParent(keyPanel);
        ac = keyArrangementComboBox.getAccessibleContext();
        ac.setAccessibleParent(keyPanel);
        ac = keySound.getAccessibleContext();
        ac.setAccessibleParent(keyPanel);

        this.add(keyPanel);
        this.add(Box.createVerticalGlue());        
   
        pointAndClick = new ComboBoxItem(labels.getString("point.click"), "pointAndClick");
        pointAndDwell = new ComboBoxItem(labels.getString("point.dwell"), "pointAndDwell");
        automaticScanning = new ComboBoxItem(labels.getString("auto.scanning"), "autoScanning");
        inverseScanning = new ComboBoxItem(labels.getString("inverse.scanning"), "inverseScanning");
        directedScanning = new ComboBoxItem(labels.getString("directed.scanning"), "directedScanning");
        codeSelection = new ComboBoxItem(labels.getString("code.selection"), "codeSelection");

        ComboBoxItem[] tempSelectionMethods = { pointAndClick, pointAndDwell, 
                                                automaticScanning, inverseScanning, 
                                                directedScanning, codeSelection };
        selectionMethods = tempSelectionMethods;

        selectionMethodComboBox = new JComboBox(selectionMethods);
        selectionMethodComboBox.setForeground(TEXT_COLOUR);
        selectionMethodComboBox.setFont(TEXT_FONT);
        selectionMethodComboBox.setBackground(PANEL_BACKGROUND);		
        selectionMethodComboBox.setSelectedItem(pointAndClick);
        selectionMethodComboBox.addItemListener(new SelectionMethodListener());
		
        selectionMethodLabel = new JLabel(labels.getString("select.method"));
        selectionMethodLabel.setDisplayedMnemonic(labels.getString("select.method.mnemonic").charAt(0));
        selectionMethodLabel.setLabelFor(selectionMethodComboBox);
        selectionMethodLabel.setFont(TEXT_FONT);
        selectionMethodLabel.setForeground(TEXT_COLOUR);

        JPanel selectionMethodPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        selectionMethodPanel.setBackground(PANEL_BACKGROUND);
        selectionMethodPanel.add(selectionMethodLabel);
        selectionMethodPanel.add(selectionMethodComboBox);

        JTextField textField = new JTextField(4);
        textField.setFont(TEXT_FONT);

        switchDelayField = new RangedTextField(new Float(0.0), new Float(30.0), textField);
        switchDelayField.setText("0.0");
        switchDelay = new JLabel(labels.getString("switch.delay"));
        switchDelay.setDisplayedMnemonic(labels.getString("switch.delay.mnemonic").charAt(0));
        switchDelay.setLabelFor(switchDelayField.textField);
        switchDelay.setFont(TEXT_FONT);
        switchDelay.setForeground(TEXT_COLOUR);

        textField = new JTextField(4);
        textField.setFont(TEXT_FONT);

        dwellTimeField = new RangedTextField(new Float(0.0), new Float(3.0), textField);
        dwellTimeField.setText("0.5");
        dwellTime = new JLabel(labels.getString("dwell.time"));
        dwellTime.setDisplayedMnemonic(labels.getString("dwell.time.mnemonic").charAt(0));
        dwellTime.setLabelFor(dwellTimeField.textField);
        dwellTime.setFont(TEXT_FONT);
        dwellTime.setForeground(TEXT_COLOUR);

        JPanel dwellTimePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        dwellTimePanel.setBackground(PANEL_BACKGROUND);
        dwellTimePanel.add(dwellTime);
        dwellTimePanel.add(dwellTimeField.textField);

        pointDwellPanel = new JPanel();
        pointDwellPanel.setBackground(PANEL_BACKGROUND);
        pointDwellPanel.setLayout(new BoxLayout(pointDwellPanel, BoxLayout.Y_AXIS));
        pointDwellPanel.add(dwellTimePanel);

        pointClickPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pointClickPanel.setBackground(PANEL_BACKGROUND);
        pointClickPanel.add(switchDelay);
        pointClickPanel.add(switchDelayField.textField);

        textField = new JTextField(4);
        textField.setFont(TEXT_FONT);

        scanSpeedField = new RangedTextField(new Float(0.1), new Float(30.0), textField);
        scanSpeedField.setText("0.1");
        scanSpeed = new JLabel(labels.getString("scan.speed"));
        scanSpeed.setDisplayedMnemonic(labels.getString("scan.speed.mnemonic").charAt(0));
        scanSpeed.setLabelFor(scanSpeedField.textField);
        scanSpeed.setFont(TEXT_FONT);
        scanSpeed.setForeground(TEXT_COLOUR);

        textField = new JTextField(4);
        textField.setFont(TEXT_FONT);

        autoScanSpeedField = new RangedTextField(new Float(0.1), new Float(30.0), textField);
        autoScanSpeedField.setText("0.1");
        autoScanSpeed = new JLabel(labels.getString("scan.speed"));
        autoScanSpeed.setDisplayedMnemonic(labels.getString("scan.speed.mnemonic").charAt(0));
        autoScanSpeed.setLabelFor(autoScanSpeedField.textField);
        autoScanSpeed.setFont(TEXT_FONT);
        autoScanSpeed.setForeground(TEXT_COLOUR);
    
        ComboBoxItem one = new ComboBoxItem("1", "1");
        ComboBoxItem two = new ComboBoxItem("2", "2");
        ComboBoxItem three = new ComboBoxItem("3", "3");
        ComboBoxItem four = new ComboBoxItem("4", "4");
        ComboBoxItem five = new ComboBoxItem("5", "5");
        infinity = new ComboBoxItem(labels.getString("infinity"), "infinity");

        ComboBoxItem[] tempItems = {one, two , three, four, five, infinity};
        repeatCyclesItems = tempItems;

        repeatCyclesComboBox = new JComboBox(repeatCyclesItems);
        repeatCyclesComboBox.setForeground(TEXT_COLOUR);
        repeatCyclesComboBox.setFont(TEXT_FONT);
        repeatCyclesComboBox.setBackground(PANEL_BACKGROUND);		
        repeatCyclesComboBox.setSelectedItem(one);
    
        repeatCycles = new JLabel(labels.getString("repeat.cycles"));
        repeatCycles.setDisplayedMnemonic(labels.getString("repeat.cycles.mnemonic").charAt(0));
        repeatCycles.setLabelFor(repeatCyclesComboBox);
        repeatCycles.setFont(TEXT_FONT);
        repeatCycles.setForeground(TEXT_COLOUR);

        textField = new JTextField(4);
        textField.setFont(TEXT_FONT);

        initialDelayField = new RangedTextField(new Float(0.0), new Float(30.0), textField);
        initialDelayField.setText("0.0");
        initialDelay = new JLabel(labels.getString("initial.delay"));
        initialDelay.setDisplayedMnemonic(labels.getString("initial.delay.mnemonic").charAt(0));
        initialDelay.setLabelFor(initialDelayField.textField);
        initialDelay.setFont(TEXT_FONT);
        initialDelay.setForeground(TEXT_COLOUR);

        textField = new JTextField(4);
        textField.setFont(TEXT_FONT);

        scanSwitchDelayField = new RangedTextField(new Float(0.0), new Float(30.0), textField);
        scanSwitchDelayField.setText("0.0");    

        scanSwitchDelay = new JLabel(labels.getString("switch.delay"));
        scanSwitchDelay.setDisplayedMnemonic(labels.getString("switch.delay.mnemonic").charAt(0));
        scanSwitchDelay.setLabelFor(scanSwitchDelayField.textField);
        scanSwitchDelay.setFont(TEXT_FONT);
        scanSwitchDelay.setForeground(TEXT_COLOUR);

        textField = new JTextField(4);
        textField.setFont(TEXT_FONT);

        autoScanSwitchDelayField = new RangedTextField(new Float(0.0), new Float(30.0), textField);
        autoScanSwitchDelayField.setText("0.0");
    
        autoScanSwitchDelay = new JLabel(labels.getString("switch.delay"));
        autoScanSwitchDelay.setDisplayedMnemonic(labels.getString("switch.delay.mnemonic").charAt(0));
        autoScanSwitchDelay.setLabelFor(autoScanSwitchDelayField.textField);
        autoScanSwitchDelay.setFont(TEXT_FONT);
        autoScanSwitchDelay.setForeground(TEXT_COLOUR);
		
        GridBagLayout gridbag2 = new GridBagLayout();
        GridBagConstraints c2 = new GridBagConstraints();
        JPanel autoScanGridPanel = new JPanel();
        autoScanGridPanel.setBackground(PANEL_BACKGROUND);
        autoScanGridPanel.setLayout(gridbag2);

        Insets insets2 = new Insets(5, INDENT_VALUE, 5, 5);

        c2.fill = GridBagConstraints.HORIZONTAL; 
        c2.anchor = GridBagConstraints.WEST;
        c2.gridheight = 1;
        c2.weighty = 0.5;
        c2.weightx = 0.0;
        c2.insets = insets2;

        c2.gridx = 0;
        c2.gridy = 0;
        autoScanGridPanel.add(autoScanSpeed, c2);

        c2.gridx = 1;
        c2.gridy = 0;
        autoScanGridPanel.add(autoScanSpeedField.textField, c2);

        c2.gridx = 2;
        c2.gridy = 0;
        c2.weightx = 0.5;
        autoScanGridPanel.add(Box.createHorizontalStrut(1), c2);

        c2.weightx = 0.0;

        c2.gridx = 0;
        c2.gridy = 1;
        autoScanGridPanel.add(repeatCycles, c2);

        c2.gridx = 1;
        c2.gridy = 1;
        autoScanGridPanel.add(repeatCyclesComboBox, c2);

        c2.gridx = 0;
        c2.gridy = 2;
        autoScanGridPanel.add(autoScanSwitchDelay, c2);

        c2.gridx = 1;
        c2.gridy = 2;
        autoScanGridPanel.add(autoScanSwitchDelayField.textField, c2);

        c2.gridx = 0;
        c2.gridy = 3;
        autoScanGridPanel.add(initialDelay, c2);

        c2.gridx = 1;
        c2.gridy = 3;
        autoScanGridPanel.add(initialDelayField.textField, c2);

        automaticScanningPanel = new JPanel(new GridLayout(1, 1));
        automaticScanningPanel.setBackground(PANEL_BACKGROUND);
        automaticScanningPanel.add(autoScanGridPanel);


        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel scanGridPanel = new JPanel();
        scanGridPanel.setBackground(PANEL_BACKGROUND);
        scanGridPanel.setLayout(gridbag);

        Insets insets = new Insets(5, INDENT_VALUE, 5, 5);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        scanGridPanel.add(scanSpeed, c);

        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0.0;
        scanGridPanel.add(scanSpeedField.textField, c);

        c.gridx = 2;
        c.gridy = 0;
        c.weightx = 0.5;
        scanGridPanel.add(Box.createHorizontalStrut(1), c);

        c.gridx = 0;
        c.gridy = 1;
        c.weightx = 0.0;
        scanGridPanel.add(scanSwitchDelay, c);

        c.gridx = 1;
        c.gridy = 1;
        c.weightx = 0.0;
        scanGridPanel.add(scanSwitchDelayField.textField, c);

        scanningPanel = new JPanel(new GridLayout(1, 1));
        scanningPanel.setBackground(PANEL_BACKGROUND);
        scanningPanel.add(scanGridPanel);		
		
        selectionMethodTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("select.method.title"));
        selectionMethodTitle.setTitleColor(BORDER_TITLE_COLOUR);
        selectionMethodTitle.setTitleFont(BORDER_TITLE_FONT);
    
        selectedPanel = new JPanel();
        selectedPanel.setLayout(new BoxLayout(selectedPanel, BoxLayout.Y_AXIS));
        selectedPanel.setBackground(PANEL_BACKGROUND);
        selectedPanel.add(pointClickPanel);

        JPanel theMethodPanel = new JPanel();
        theMethodPanel.setBorder(selectionMethodTitle);
        theMethodPanel.setLayout(new BoxLayout(theMethodPanel, BoxLayout.Y_AXIS));
        theMethodPanel.setBackground(PANEL_BACKGROUND);
        theMethodPanel.add(selectionMethodPanel);
        theMethodPanel.add(selectedPanel);
        theMethodPanel.add(Box.createVerticalGlue());
         
        ac = selectionMethodLabel.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);
        ac = selectionMethodComboBox.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);
        ac = switchDelayField.textField.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);
        ac = switchDelay.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);
        ac = dwellTimeField.textField.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);
        ac = dwellTime.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);
        ac = scanSpeedField.textField.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);
        ac = scanSpeed.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);
        ac = repeatCycles.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);
        ac = repeatCyclesComboBox.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);
        ac = autoScanSwitchDelayField.textField.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);
        ac = autoScanSwitchDelay.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);
        ac = initialDelayField.textField.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);
        ac = initialDelay.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);
        ac = autoScanSpeed.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);
        ac = autoScanSpeedField.textField.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);
        ac = scanSwitchDelay.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);
        ac = scanSwitchDelayField.textField.getAccessibleContext();
        ac.setAccessibleParent(theMethodPanel);

        this.add(theMethodPanel);    
        this.add(Box.createVerticalGlue());
    
    }

    /**
     * Sets all the JPanel labels to the current PreferenceManager.language value.
     */
    protected void setNewLabels() {
        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.OnscreenKeyboard", pm.language);
        ResourceBundle newHashLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.HashTables", pm.language);

        keyTitle.setTitle(newLabels.getString("key.title"));
        keyArrangementLabel.setText(newLabels.getString("key.arrange"));
        keyArrangementLabel.setDisplayedMnemonic(newLabels.getString("key.arrange.mnemonic").charAt(0));
        standard.name = newLabels.getString("standard");
        sequential.name = newLabels.getString("sequential");
        frequency.name = newLabels.getString("by.frequency");
        keySound.setText(newLabels.getString("key.sound"));
        keySound.setMnemonic(newLabels.getString("key.sound.mnemonic").charAt(0));

        selectionMethodTitle.setTitle(newLabels.getString("select.method.title"));
        selectionMethodLabel.setText(newLabels.getString("select.method"));
        selectionMethodLabel.setDisplayedMnemonic(newLabels.getString("select.method.mnemonic").charAt(0));

        switchDelay.setText(newLabels.getString("switch.delay"));
        switchDelay.setDisplayedMnemonic(newLabels.getString("switch.delay.mnemonic").charAt(0));
        dwellTime.setText(newLabels.getString("dwell.time"));

        pointAndDwell.name = newLabels.getString("point.dwell");
        pointAndClick.name = newLabels.getString("point.click");
        automaticScanning.name = newLabels.getString("auto.scanning");
        inverseScanning.name = newLabels.getString("inverse.scanning");
        directedScanning.name = newLabels.getString("directed.scanning");
        codeSelection.name = newLabels.getString("code.selection");
        infinity.name = newLabels.getString("infinity");

        scanSpeed.setText(newLabels.getString("scan.speed"));
        scanSpeed.setDisplayedMnemonic(newLabels.getString("scan.speed.mnemonic").charAt(0));
        autoScanSpeed.setText(newLabels.getString("scan.speed"));
        autoScanSpeed.setDisplayedMnemonic(newLabels.getString("scan.speed.mnemonic").charAt(0));
        repeatCycles.setText(newLabels.getString("repeat.cycles"));
        repeatCycles.setDisplayedMnemonic(newLabels.getString("repeat.cycles.mnemonic").charAt(0));
        initialDelay.setText(newLabels.getString("initial.delay"));
        initialDelay.setDisplayedMnemonic(newLabels.getString("initial.delay.mnemonic").charAt(0));
        scanSwitchDelay.setText(newLabels.getString("switch.delay"));
        scanSwitchDelay.setDisplayedMnemonic(newLabels.getString("switch.delay.mnemonic").charAt(0));
        autoScanSwitchDelay.setText(newLabels.getString("switch.delay"));
        autoScanSwitchDelay.setDisplayedMnemonic(newLabels.getString("switch.delay.mnemonic").charAt(0));

        dwellTimeField.reformat();
        scanSpeedField.reformat();
        autoScanSpeedField.reformat();
        switchDelayField.reformat();
        initialDelayField.reformat();
        scanSwitchDelayField.reformat();
        autoScanSwitchDelayField.reformat();

        setNewButtonLabels();
    
        revalidate();
        repaint();

        onscreenKeyboardD2.setNewLabels();
    }

    /**
     * Checks whether or not coded input is the selection method chosen.
     */
    protected boolean isUsingCodeSelection() {
        ComboBoxItem item = (ComboBoxItem) 
            selectionMethodComboBox.getSelectedItem();
        
        return (item == codeSelection);
    }

    /**
     * Shows the next dialog.
     */
    protected void doNext() {
        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.OnscreenKeyboard", pm.language);

        ComboBoxItem item = (ComboBoxItem) selectionMethodComboBox.getSelectedItem();
        onscreenKeyboardD2.setUpSwitches(item);
        pm.setUseCodedInput(false);

        if (item == pointAndClick && !switchDelayField.isInsideRange()) {
            pm.doRangeWarning(switchDelayField.getLowValue(), 
                              switchDelayField.getHighValue(), 
                              labels.getString("switch.delay"));
            return;
        }
        else if (item == pointAndDwell && !dwellTimeField.isInsideRange()) {
            pm.doRangeWarning(dwellTimeField.getLowValue(),
                              dwellTimeField.getHighValue(), 
                              labels.getString("dwell.time"));
            return;
        }
        else if (item == automaticScanning) {
            if (!autoScanSpeedField.isInsideRange()) {
                pm.doRangeWarning(autoScanSpeedField.getLowValue(),
                                  autoScanSpeedField.getHighValue(), 
                                  labels.getString("scan.speed"));
                return;
            }
            else if (!autoScanSwitchDelayField.isInsideRange()) {
                pm.doRangeWarning(autoScanSwitchDelayField.getLowValue(),
                                  autoScanSwitchDelayField.getHighValue(), 
                                  labels.getString("switch.delay"));
                return;
            }
            else if (!initialDelayField.isInsideRange()) {
                pm.doRangeWarning(initialDelayField.getLowValue(),
                                  initialDelayField.getHighValue(), 
                                  labels.getString("initial.delay"));
                return;
            }
        }
        else if (item == directedScanning || item == inverseScanning) {
            if (!scanSpeedField.isInsideRange()) {
                pm.doRangeWarning(scanSpeedField.getLowValue(), 
                                  scanSpeedField.getHighValue(), 
                                  labels.getString("scan.speed"));
                return;
            }
            else if (!scanSwitchDelayField.isInsideRange()) {
                pm.doRangeWarning(scanSwitchDelayField.getLowValue(), 
                                  scanSwitchDelayField.getHighValue(), 
                                  labels.getString("switch.delay"));
                return;
            }
        }

        if (onscreenKeyboardD2.isSwitchUsed()) {
            pm.showPanel(onscreenKeyboardD2);
        }
        else if (item == codeSelection) {
            pm.setUseCodedInput(true);
            onscreenKeyboardD2.doNext();
        }
        else
            onscreenKeyboardD2.doNext();
    }

    /**
     * Changes the UI widgets to their default implementation.
     */ 
    protected void doDefault() {
        keyArrangementComboBox.setSelectedItem(standard);
        keySound.setSelected(true);

        dwellTimeField.setText("0.5");
        switchDelayField.setText("0.0");
        scanSpeedField.setText("0.1");
        autoScanSpeedField.setText("0.1");
        initialDelayField.setText("0.0");
        scanSwitchDelayField.setText("0.0");
        autoScanSwitchDelayField.setText("0.0");
        repeatCyclesComboBox.setSelectedItem("1");

        selectionMethodComboBox.setSelectedItem(pointAndClick);
    }

    /**
     * Gets the current selection method.
     *
     * @return  the current selection method item
     */
    protected ComboBoxItem getSelectionMethod() {
        return (ComboBoxItem) selectionMethodComboBox.getSelectedItem();
    }

    /**
     * The action listener for the three radio buttons determining the 
     * selection method.
     */
    class SelectionMethodListener implements ItemListener {
        public void itemStateChanged(ItemEvent e) {
            ComboBoxItem box = (ComboBoxItem) e.getItem();
            selectedPanel.removeAll();

            if (box == pointAndClick) {
                selectedPanel.add(pointClickPanel);
            } else if  (box == pointAndDwell) {
                selectedPanel.add(pointDwellPanel);
            } else if (box == automaticScanning) {
                selectedPanel.add(automaticScanningPanel);
            } else if (box == inverseScanning || box == directedScanning) {
                selectedPanel.add(scanningPanel);
            }

            selectedPanel.revalidate();
            selectedPanel.repaint();
			
        }
    }

    /**
     * Sets all the UI components to their correct values corresponding 
     * to passed XML document.
     */
    protected void setDomValues() {
        Element temp = DOMUtil.getFirstChildElement(generic);
        Element selectionMethod = null;

        if (temp != null && 
            temp.getTagName().equals(xmlLabels.getString(ALPHA_LAYOUT_INTERNAL))) {

            keyArrangementComboBox.setSelectedItem(findItem(arrangements, temp.getAttribute(VALUE)));
            temp = DOMUtil.getNextSiblingElement(temp);
        }
        else if (temp != null && 
                 temp.getTagName().equals(xmlLabels.getString(ALPHA_LAYOUT_EXTERNAL))) {
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null) {
            selectionMethod = temp;
            if (temp.getTagName().equals(xmlLabels.getString(OK_GENERIC_POINT_CLICK))) {                
                selectionMethodComboBox.setSelectedItem(pointAndClick);
                selectedPanel.add(pointClickPanel);
                
                Element switchDelayEl = DOMUtil.getFirstChildElement(temp);
                switchDelayField.setText(switchDelayEl.getAttribute(VALUE));
            }
            else if (temp.getTagName().equals(xmlLabels.getString(OK_GENERIC_POINT_DWELL))) {
                selectionMethodComboBox.setSelectedItem(pointAndDwell);
                selectedPanel.add(pointDwellPanel);
			
                Element dwellTimeEl = DOMUtil.getFirstChildElement(temp);
                dwellTimeField.setText(dwellTimeEl.getAttribute(VALUE));
            }
            else if (temp.getTagName().equals(xmlLabels.getString(OK_GENERIC_AUTO_SCAN))) {
                selectionMethodComboBox.setSelectedItem(automaticScanning);
                Element scanSpeedEl = DOMUtil.getFirstChildElement(temp);
                autoScanSpeedField.setText(scanSpeedEl.getAttribute(VALUE));
				
                Element scanSwitchDelayEl = DOMUtil.getNextSiblingElement(scanSpeedEl);
                autoScanSwitchDelayField.setText(scanSwitchDelayEl.getAttribute(VALUE));
				
                Element switchTypeEl = DOMUtil.getNextSiblingElement(scanSwitchDelayEl);

                Element autoScanInitDelayEl = DOMUtil.getNextSiblingElement(switchTypeEl);
                initialDelayField.setText(autoScanInitDelayEl.getAttribute(VALUE));
				
                Element autoScanRepeatEl = DOMUtil.getNextSiblingElement(autoScanInitDelayEl);
				
                repeatCyclesComboBox.setSelectedItem(findItem(repeatCyclesItems, autoScanRepeatEl.getAttribute(VALUE)));
            }
            else if (temp.getTagName().equals(xmlLabels.getString(OK_GENERIC_INVERSE_SCAN)) || 
                     temp.getTagName().equals(xmlLabels.getString(OK_GENERIC_DIRECTED_SCAN))) {
                if (temp.getTagName().equals(xmlLabels.getString(OK_GENERIC_INVERSE_SCAN)))
                    selectionMethodComboBox.setSelectedItem(inverseScanning);
                else
                    selectionMethodComboBox.setSelectedItem(directedScanning);

                Element scanSpeedEl = DOMUtil.getFirstChildElement(temp);
                scanSpeedField.setText(scanSpeedEl.getAttribute(VALUE));
				
                Element scanSwitchDelayEl = DOMUtil.getNextSiblingElement(scanSpeedEl);
                scanSwitchDelayField.setText(scanSwitchDelayEl.getAttribute(VALUE));
            }
            else if (temp.getTagName().equals(xmlLabels.getString(OK_GENERIC_CODE_SELECTION))) {
                selectionMethodComboBox.setSelectedItem(codeSelection);
            }
        }

        temp = DOMUtil.getLastChildElement(generic);
        if (temp != null && temp.getTagName().equals(xmlLabels.getString(OK_GENERIC_KEY_SOUND))) {
            if (temp.getAttribute(VALUE).equals("true"))
                keySound.setSelected(true);
            else if (temp.getAttribute(VALUE).equals("false"))
                keySound.setSelected(false);			
        }

        onscreenKeyboardD2.setUpSwitches((ComboBoxItem) selectionMethodComboBox.getSelectedItem());
        onscreenKeyboardD2.setDomValues(document, selectionMethod);

    }

	

    /**
     * Gets this app type's XML document root element.
     *
     * @return  the root element for this app type's document
     */
    protected Element getRootElement() {
        pm.removeAllChildren(generic);
        Element temp;
        Element generic = DOMUtil.getFirstChildElement(document.getDocumentElement());

        Element layout = document.createElement(xmlLabels.getString(ALPHA_LAYOUT_INTERNAL));
        ComboBoxItem arrangementItem = (ComboBoxItem) keyArrangementComboBox.getSelectedItem();
        layout.setAttribute(VALUE, arrangementItem.value);
        
        generic.appendChild(layout);
        
        Element selectionMethodElement = null;
        ComboBoxItem selectionMethod = (ComboBoxItem) selectionMethodComboBox.getSelectedItem();

        if (selectionMethod == pointAndClick) {
            Element pointClick = document.createElement(xmlLabels.getString(OK_GENERIC_POINT_CLICK));
            generic.appendChild(pointClick);
            temp = document.createElement(xmlLabels.getString(OK_GENERIC_SWITCH_DELAY));
            temp.setAttribute(VALUE, switchDelayField.getValue());
            pointClick.appendChild(temp);
        }
        else if (selectionMethod == pointAndDwell) {
            Element pointDwell = document.createElement(xmlLabels.getString(OK_GENERIC_POINT_DWELL));
            generic.appendChild(pointDwell);
            temp = document.createElement(xmlLabels.getString(OK_GENERIC_DWELL_TIME));
            temp.setAttribute(VALUE, dwellTimeField.getValue());
            pointDwell.appendChild(temp);
        }
        else if (selectionMethod == automaticScanning) {
            Element autoScan = document.createElement(xmlLabels.getString(OK_GENERIC_AUTO_SCAN));
            generic.appendChild(autoScan);

            temp = document.createElement(xmlLabels.getString(OK_GENERIC_SCAN_SPEED));
            temp.setAttribute(VALUE, autoScanSpeedField.getValue());
            autoScan.appendChild(temp);
      
            temp = document.createElement(xmlLabels.getString(OK_GENERIC_SCAN_SWITCH_DELAY));
            temp.setAttribute(VALUE, autoScanSwitchDelayField.getValue());
            autoScan.appendChild(temp);
      
            temp = document.createElement(xmlLabels.getString(OK_GENERIC_AUTO_SCAN_INIT_DELAY));
            temp.setAttribute(VALUE, initialDelayField.getValue());
            autoScan.appendChild(temp);
      
            temp = document.createElement(xmlLabels.getString(OK_GENERIC_AUTO_SCAN_REPEAT));
            ComboBoxItem repeatCyclesItem = (ComboBoxItem) repeatCyclesComboBox.getSelectedItem();
            temp.setAttribute(VALUE, repeatCyclesItem.value);
            autoScan.appendChild(temp);
            selectionMethodElement = autoScan;
        }
        else if (selectionMethod == inverseScanning || selectionMethod == directedScanning) {
            Element scan = null;
            if (selectionMethod == inverseScanning)
                scan = document.createElement(xmlLabels.getString(OK_GENERIC_INVERSE_SCAN));
            else 
                scan = document.createElement(xmlLabels.getString(OK_GENERIC_DIRECTED_SCAN));

            generic.appendChild(scan);

            temp = document.createElement(xmlLabels.getString(OK_GENERIC_SCAN_SPEED));
            temp.setAttribute(VALUE, scanSpeedField.getValue());
            scan.appendChild(temp);
      
            temp = document.createElement(xmlLabels.getString(OK_GENERIC_SCAN_SWITCH_DELAY));
            temp.setAttribute(VALUE, scanSwitchDelayField.getValue());
            scan.appendChild(temp);
            selectionMethodElement = scan;
        }
        else if (selectionMethod == codeSelection) {
            Element codeSelectionEl = document.createElement(xmlLabels.getString(OK_GENERIC_CODE_SELECTION));
            generic.appendChild(codeSelectionEl);
        }

        onscreenKeyboardD2.addElementsTo(document, selectionMethodElement);

        Element sound = document.createElement(xmlLabels.getString(OK_GENERIC_KEY_SOUND));
        if (keySound.isSelected())
            sound.setAttribute(VALUE, "true");       
        else 
            sound.setAttribute(VALUE, "false");        

        generic.appendChild(sound);

        return document.getDocumentElement();

    }

    /**
     * Gets the last panel in this app types edit dialogs.
     */
    protected PWMEditPanel getLastPanel() {
        return onscreenKeyboardD2.getLastPanel();
    }

    /**
     * Shows the previous dialog.
     */
    protected void doPrev() {
            
        ComboBoxItem item = 
            (ComboBoxItem) selectionMethodComboBox.getSelectedItem();
        if (item != codeSelection)
            pm.setUseCodedInput(false);
            
        pm.doPrevAppType(appType);
    }	  

    /**
     * Get the entire app type XML subtree including default 
     * preferences and third party preferences.
     *
     * @return    The entire <mouse_alt> XML sub-tree.
     */
    protected Document getAppTypeDoc() {
        return document;
    }


}
