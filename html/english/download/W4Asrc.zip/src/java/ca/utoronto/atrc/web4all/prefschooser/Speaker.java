/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            Speaker.java
 *
 * Synopsis:        package ca.utoronto.atrc.web4all.prefschooser;
 * 
]*/

package ca.utoronto.atrc.web4all.prefschooser;

import java.util.*;
import ca.utoronto.atrc.web4all.tts.*;

/**
 * Basic class for routing speech output.
 *
 * @version $Id: Speaker.java,v 1.4 2006/03/28 21:17:27 clown Exp $
 * @author  Joseph Scheuhammer.
 *
 */
public class Speaker
{
    /**
     * The native speaker..
     */
    private static SimpleSpeech theNativeSpeaker;
    
    /**
     * Feedback area to show what is being spoken.
     */
    private SpeechLog theLog;
    
    /**
     * Scratch buffer to doing string manipulations.
     */
    private volatile StringBuffer theScratchBuffer;
    
    /**
     * Constructor:  initialize the native TTS code, and create the viewable
     * speech log.
     */
    public Speaker()
    {
        super();
        theLog = SpeechLog.getSharedInstance();
        theScratchBuffer = new StringBuffer();
        
        // Create <theNativeSpeaker> if necessary.
        //
        if (Speaker.theNativeSpeaker == null)
            Speaker.theNativeSpeaker = new SimpleSpeech();
   
    }   // end Speaker().
    
    /**
     * Constructor:  initialize the native TTS code with the given Locale, and
     * create the viewable speech log.
     * @param   inLocale    The Locale to use, initially.
     * @see #Speaker()
     * @see #setLocale()
     */
    public Speaker (Locale inLocale)
    {
        this();
        setLocale (inLocale);
        
    }   // end Speaker().
    
    /**
     * (Re)set the locale for speech.
     * @param   inLocale    The Locaale to use.
     */
    public void setLocale (Locale inLocale)
    {
        Speaker.theNativeSpeaker.setLocale (inLocale);
        
    }   // end setLocale().
    
    /**
     * Speak the given text.  For now, this only places it onto the log.
     * @param   inText  The text to speak.
     */
    public void speak (String inText)
    {
        theLog.appendSpeech (inText);
        theNativeSpeaker.speak (inText);
    
    }   // end speak().

    /**
     * Speak the given sequence of texts by appeanding each to the end of one
     * string.  For now, this only places it onto the log.
     * @param   inSpeeches  The sequence of String's to speak.
     */
    public void speak (List inSpeeches)
    {
        if (inSpeeches != null)
        {
            theScratchBuffer.delete (0, theScratchBuffer.length());
            Iterator iter = inSpeeches.iterator();
            while (iter.hasNext())
            {
                theScratchBuffer.append ((String) iter.next());
                theScratchBuffer.append (" ");
            }
            speak (theScratchBuffer.toString());
        }
    }   // end speak (List inSpeeches).
    
    /**
     * Interrupt any current speech.
     */
    public void stopSpeaking()
    {
        Speaker.theNativeSpeaker.stopSpeaking();
    
    }   // end stopSpeaking().

}   // end class Speaker.
