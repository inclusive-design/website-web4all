/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.net.URL;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

/**
 * The JPanel to edit the numeric keypad setup in a user's preferences.
 *
 * @version 1.02 01 March 20
 * @author	David Weinkauf
 * @author	Joseph Scheuhammer	Replaced "kb.defaults" with "ma.defaults".
 *
 */
public class MouseEmulation extends PWMEditPanel {

	/**
	 * The slider title labels.
	 */
	private JLabel pointerSpeedLabel, pointerAccelLabel;
	
	/**
	 * The slider value labels.
	 */
	private JLabel slow, medium, fast, pitchLow, pitchMedium, pitchHigh;

	private TitledBorder pointerTitle, deviceTitle;

	/**
	 * The pointer speed slider. 
	 */
	private JSlider pointerSpeedSlider;

	/**
	 * The pointer acceleration slider.
	 */
	private JSlider pointerAccelSlider;

	private ComboBoxItem keypad, keyboard, switchDev;

	private ComboBoxItem[] devices;

	private JComboBox deviceComboBox;

	private JLabel deviceLabel;

	/**
	 * The XML Document sub-tree this dialog produces in a user's preferences.
	 */
	private Document document;

	/**
	 * The root element of the mouseEmulation default prefs under <mouse_alt>.
	 */
	private Element generic;


	/**
	 * The constructor initializes all the components in the dialog and displays them accordingly.
	 * @param    pm    The reference to the PreferenceManagaer.
	 * @param    root  The root of the mouse alternative XML sub-tree - that is, the <mouse_alt> Element.
	 */
	public MouseEmulation (PreferenceManager pm, Element root, String inAppType) {
		super(pm, inAppType, inAppType + TITLE_SUFFIX);

		document = initDocument(root, xmlLabels.getString(MOUSE_EMULATION), xmlLabels.getString(ME_GENERIC));
		generic = DOMUtil.getFirstChildElement(document.getDocumentElement());

		ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.MouseEmulation", pm.language);
		ResourceBundle hashLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.HashTables", pm.language);

		// Setup the panel!!!

		Hashtable pointerSpeedHash = new Hashtable();
		pitchLow = new JLabel(hashLabels.getString("low"));
		pitchLow.setForeground(Color.black);
		pitchMedium = new JLabel(hashLabels.getString("medium"));
		pitchMedium.setForeground(Color.black);
		pitchHigh = new JLabel(hashLabels.getString("high"));
		pitchHigh.setForeground(Color.black);
		pointerSpeedHash.put(new Integer(0), pitchLow);
		pointerSpeedHash.put(new Integer(5), pitchMedium);
		pointerSpeedHash.put(new Integer(10), pitchHigh);

		pointerSpeedSlider = new JSlider(SwingConstants.HORIZONTAL, 0, 10, 5);
		pointerSpeedSlider.setPaintLabels(true);
		pointerSpeedSlider.setBackground(PANEL_BACKGROUND);
		pointerSpeedSlider.setForeground(TEXT_COLOUR);
		pointerSpeedSlider.setLabelTable(pointerSpeedHash);
		pointerSpeedSlider.setMajorTickSpacing(5);
		pointerSpeedSlider.setMinorTickSpacing(1);
		pointerSpeedSlider.setSnapToTicks(true);
		pointerSpeedSlider.setPaintTicks(true);

		pointerSpeedLabel = new JLabel(labels.getString("pointer.speed"));
		pointerSpeedLabel.setDisplayedMnemonic(labels.getString("pointer.speed.mnemonic").charAt(0));
		pointerSpeedLabel.setLabelFor(pointerSpeedSlider);
		pointerSpeedLabel.setFont(TEXT_FONT);
		pointerSpeedLabel.setForeground(Color.black);

		Hashtable pointerAccelHash = new Hashtable();
		slow = new JLabel(hashLabels.getString("slow"));
		slow.setForeground(Color.black);
		medium = new JLabel(hashLabels.getString("medium"));
		medium.setForeground(Color.black);
		fast = new JLabel(hashLabels.getString("fast"));
		fast.setForeground(Color.black);
		pointerAccelHash.put(new Integer(0), slow);
		pointerAccelHash.put(new Integer(5), medium);
		pointerAccelHash.put(new Integer(10), fast);

		pointerAccelSlider = new JSlider(SwingConstants.HORIZONTAL, 0, 10, 5);
		pointerAccelSlider.setPaintLabels(true);
		pointerAccelSlider.setBackground(PANEL_BACKGROUND);
		pointerAccelSlider.setForeground(TEXT_COLOUR);
		pointerAccelSlider.setMajorTickSpacing(5);
		pointerAccelSlider.setMinorTickSpacing(1);
		pointerAccelSlider.setLabelTable(pointerAccelHash);
		pointerAccelSlider.setSnapToTicks(true);
		pointerAccelSlider.setPaintTicks(true);

		pointerAccelLabel = new JLabel(labels.getString("pointer.accel"));
		pointerAccelLabel.setDisplayedMnemonic(labels.getString("pointer.accel.mnemonic").charAt(0));
		pointerAccelLabel.setLabelFor(pointerAccelSlider);
		pointerAccelLabel.setFont(TEXT_FONT);
		pointerAccelLabel.setForeground(Color.black);

 		GridBagLayout gridbag = new GridBagLayout();
 		GridBagConstraints c = new GridBagConstraints();
 		JPanel pointerGridPanel = new JPanel();
 		pointerGridPanel.setBackground(PANEL_BACKGROUND);
 		pointerGridPanel.setLayout(gridbag);

		Insets insets = new Insets(5, 5, 5, 5);

 		c.fill = GridBagConstraints.HORIZONTAL; 
 		c.anchor = GridBagConstraints.WEST;
		c.gridheight = 1;
		c.weighty = 0.5;
		c.insets = insets;

 		c.gridx = 0;
 		c.gridy = 0;
 		c.weightx = 0.0;
 		pointerGridPanel.add(pointerSpeedLabel, c);

 		c.gridx = 1;
 		c.gridy = 0;
 		c.weightx = 0.5;
 		pointerGridPanel.add(pointerSpeedSlider, c);

 		c.gridx = 0;
 		c.gridy = 1;
 		c.weightx = 0.0;
 		pointerGridPanel.add(pointerAccelLabel, c);

 		c.gridx = 1;
 		c.gridy = 1;
 		c.weightx = 0.5;
 		pointerGridPanel.add(pointerAccelSlider, c);

		pointerTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("pointer.title"));
		pointerTitle.setTitleColor(BORDER_TITLE_COLOUR);
		pointerTitle.setTitleFont(BORDER_TITLE_FONT);

 		JPanel pointerPanel = new JPanel(new GridLayout(1, 1));
 		pointerPanel.setBorder(pointerTitle);
 		pointerPanel.setBackground(PANEL_BACKGROUND);
 		pointerPanel.add(pointerGridPanel);

                AccessibleContext ac = pointerSpeedLabel.getAccessibleContext();
                ac.setAccessibleParent(pointerPanel);
                ac = pointerSpeedSlider.getAccessibleContext();
                ac.setAccessibleParent(pointerPanel);
                ac = pointerAccelLabel.getAccessibleContext();
                ac.setAccessibleParent(pointerPanel);
                ac = pointerAccelSlider.getAccessibleContext();
                ac.setAccessibleParent(pointerPanel);                

		this.add(pointerPanel);
		this.add(Box.createVerticalGlue());

		keypad = new ComboBoxItem(labels.getString("keypad"), "keypad");
		keyboard = new ComboBoxItem(labels.getString("keyboard"), "keyboard");
		switchDev = new ComboBoxItem(labels.getString("switch"), "switch");

		ComboBoxItem[] tempDevices = { keypad, keyboard, switchDev };
		devices = tempDevices;

		deviceComboBox = new JComboBox(devices);
		deviceComboBox.setForeground(TEXT_COLOUR);
		deviceComboBox.setFont(TEXT_FONT);
		deviceComboBox.setBackground(PANEL_BACKGROUND);		
		deviceComboBox.setSelectedItem(keypad);

		deviceLabel = new JLabel(labels.getString("device"));
		deviceLabel.setDisplayedMnemonic(labels.getString("device").charAt(0));
		deviceLabel.setLabelFor(deviceComboBox);
		deviceLabel.setFont(TEXT_FONT);
		deviceLabel.setForeground(TEXT_COLOUR);

		deviceTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("device.title"));
		deviceTitle.setTitleColor(BORDER_TITLE_COLOUR);
		deviceTitle.setTitleFont(BORDER_TITLE_FONT);

		JPanel deviceSelectPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		deviceSelectPanel.setBackground(PANEL_BACKGROUND);
		deviceSelectPanel.setBorder(deviceTitle);
		deviceSelectPanel.add(deviceLabel);
		deviceSelectPanel.add(deviceComboBox);

		this.add(deviceSelectPanel);
		this.add(Box.createVerticalGlue());
		
	}

	/**
	 * Set all the JPanel labels to the current PreferenceManager.language value.
	 */
	protected void setNewLabels() {
        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.MouseEmulation", pm.language);
        ResourceBundle newHashLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.HashTables", pm.language);

		pointerTitle.setTitle(newLabels.getString("pointer.title"));
		pointerAccelLabel.setText(newLabels.getString("pointer.accel"));
		pointerAccelLabel.setDisplayedMnemonic(newLabels.getString("pointer.accel.mnemonic").charAt(0));
		pointerSpeedLabel.setText(newLabels.getString("pointer.speed"));
		pointerSpeedLabel.setDisplayedMnemonic(newLabels.getString("pointer.speed.mnemonic").charAt(0));
		pitchLow.setText(newHashLabels.getString("low"));
		pitchMedium.setText(newHashLabels.getString("medium"));
		pitchHigh.setText(newHashLabels.getString("high"));
		slow.setText(newHashLabels.getString("slow"));
		medium.setText(newHashLabels.getString("medium"));
		fast.setText(newHashLabels.getString("fast"));

		deviceTitle.setTitle(newLabels.getString("device.title"));

		deviceLabel.setText(newLabels.getString("device"));
		deviceLabel.setDisplayedMnemonic(newLabels.getString("device.mnemonic").charAt(0));

		keypad.name = newLabels.getString("keypad");
		keyboard.name = newLabels.getString("keyboard");
		switchDev.name = newLabels.getString("switch");

		setNewButtonLabels();

		revalidate();
		repaint();
	}
	
	/**
	 * Set all the JPanel's components to their correct values corresponding to 
	 * the user's XML preferences passed in through the constructor.
	 */
	protected void setDomValues() {
		Element temp = DOMUtil.getFirstChildElement(generic);
		if (temp != null && temp.getTagName().equals(xmlLabels.getString(ME_GENERIC_SPEED))) {
			pointerSpeedSlider.setValue( (int) (Float.parseFloat(temp.getAttribute(VALUE)) * 10) );
			temp = DOMUtil.getNextSiblingElement(temp);
		}
		if (temp != null && temp.getTagName().equals(xmlLabels.getString(ME_GENERIC_ACCEL))) {
			pointerAccelSlider.setValue( (int) (Float.parseFloat(temp.getAttribute(VALUE)) * 10) );
			temp = DOMUtil.getNextSiblingElement(temp);
		}

		if (temp != null && temp.getTagName().equals(xmlLabels.getString(ME_GENERIC_DEVICE))) {
			deviceComboBox.setSelectedItem(findItem(devices, temp.getAttribute(VALUE)));
		}

	}
	
	/**
	 * Construct the XML sub-tree for keyboard setup according to the user's current selections.
	 * @return    Element    The root element of the new XML sub-tree created.
	 */
	protected Element getRootElement() {
		Element temp;
	
		pm.removeAllChildren(generic);

		temp = document.createElement(xmlLabels.getString(ME_GENERIC_SPEED));
		temp.setAttribute(VALUE, String.valueOf(pointerSpeedSlider.getValue() / 10.0));
		generic.appendChild(temp); 

		temp = document.createElement(xmlLabels.getString(ME_GENERIC_ACCEL));
		temp.setAttribute(VALUE, String.valueOf(pointerAccelSlider.getValue() / 10.0));
		generic.appendChild(temp); 

		temp = document.createElement(xmlLabels.getString(ME_GENERIC_DEVICE));
		ComboBoxItem deviceItem = (ComboBoxItem) deviceComboBox.getSelectedItem();
		temp.setAttribute(VALUE, deviceItem.value);

		generic.appendChild(temp); 

		return document.getDocumentElement();
	}

	protected void doDefault() {
		pointerSpeedSlider.setValue(5);
		pointerAccelSlider.setValue(5);
		deviceComboBox.setSelectedItem(keypad);
	}


	/**
	 * Get the entire app type XML subtree including default preferences and third party preferences.
	 * @return    The entire <mouse_alt> XML sub-tree.
	 */
	protected Document getAppTypeDoc() {
		return document;
	}

}
