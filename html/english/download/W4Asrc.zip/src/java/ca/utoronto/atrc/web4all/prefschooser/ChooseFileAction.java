/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            ChooseFileAction.java
 *
 * Synopsis:        package ca.utoronto.atrc.web4all.prefschooser;
 * 
]*/

package ca.utoronto.atrc.web4all.prefschooser;

import javax.swing.Action;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFileChooser;
import javax.swing.JMenuItem;
import java.io.File;

/**
 * Handle choosing a file or directory from the "Files" or "Directories" menu
 * displayed with the file chooser dialog
 * @author Joseph Scheuhammer.
 * @version $Id: ChooseFileAction.java,v 1.5 2006/03/28 21:17:27 clown Exp $
 */
public class ChooseFileAction implements ActionListener
{
    /**
     * The key into the menu item that contains the File object chosen.
     */
    public final static String FILE_KEY =
        "ca.utoronto.atrc.web4all.prefschooser.file";
    
    /**
     * File chooser on which to perform the file choosing action.
     */
    private JFileChooser theFileChooser;
    
    /**
     * Constructor
     */
    public ChooseFileAction (JFileChooser ioFileChooser)
    {
        super();
        theFileChooser = ioFileChooser;
    
    }   // end ChooseFileAction().
    
//===============================
// ActionListener implementation.
//===============================

    /**
     * If the event represents a choice of a file from in the file chooser's
     * "Files" menu, set the chooser's current selected file.  If the choice is
     * a directcory from the chooser's "Directories" menu, set the chooser's
     * current directory to that chosen.
     * @param   inChoice    The ActionEvent that represents the choice.
     */
    public void actionPerformed (ActionEvent inChoice)
    {
        // Get the source of the event.  If it's not a JMenuItem, do nothing
        // (this handles only menu selections).
        //
        Object src = inChoice.getSource();
        if (src instanceof JMenuItem)
        {
            // Assume that there is a File object stored as a client property
            // of the <src> that corresponds to the user's choice.
            //
            JMenuItem menuItem = (JMenuItem) src;
            File fileToChoose = (File) menuItem.getClientProperty (FILE_KEY);
            if (fileToChoose != null)
            {
                if (fileToChoose.isDirectory())
                    theFileChooser.setCurrentDirectory (fileToChoose);
                else
                {
                    theFileChooser.setSelectedFile (fileToChoose);
                    theFileChooser.approveSelection();
                }
            }
        }
    
    }   // end actionPeformed()

}   // end class ChooseFileAction
