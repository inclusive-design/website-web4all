/**
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
*/   
package ca.utoronto.atrc.web4all;

import ca.utoronto.atrc.web4all.web4AllCardService.*;
import java.util.*;
import java.io.*;
import opencard.core.*;
import opencard.core.service.*;
import opencard.core.event.*;
import opencard.core.terminal.*;
import opencard.core.terminal.CardTerminalRegistry;
import opencard.core.util.*;
import opencard.opt.util.*;
import opencard.opt.iso.fs.*;
import javax.swing.*;

/**
  * This class starts and shuts down the Web4All system and provides the 
  * interface between the smart card and the rest of the system. 
  * @version 1.02 01 Apr 04
  * @author	Allen Forsyth
  * @author Joseph Scheuhammer Minor change to name of resource file to "CardControlProps".
*/   

public class CardControl implements CTListener {
	
    private static Object monitor    = "Main Monitor";
	private static CardControl theCC;	// The singleton CardControl object.
	private InsertProcessor theIP;	// An Active object to process Card Inserted Events.
	private Thread theIPThread;		// The Thread to run the InsertProcessor.
	private Thread theRPThread;		// The Thread to run the RemoveProcessor.
	private SmartCardLogFile theLF;	// Log file for messages.
	private RemoveProcessor theRP; // An Active object to process Card Removed Events.
	private ControlHub w4a;			// ControlHub object that does the real work.
	private ResourceBundle theRB;	// Language independent messages store.
    private Properties theProperties; // Properties File.
	private boolean multipleSessions = false;	// Handle multiple sessions or shutdown when a card is removed.
    private CardTerminal theCardTerminal;  // the CardTerminal which is handling the current card.
    private int theSlot;  // the Slot number for the current card.
	private boolean w4aRunning = false;	// Has web4All been started?
    private boolean shutDownOnError = true;  // Shutdown JVM on OpenCard Exceptions.
    private boolean insertEvent = false;  // control of initial "waiting for insert" message.
    //FIXME - use of this is UGLY; must be a better way.
    private boolean dontWait = false;  // prevent initial wait if error occurs when card present on startup.
    private boolean shutDownStarted = false; // prevent multiple shutdown requests from being initiated.
    private boolean shutDownOnRemoveRequest = false;  // Shutdown has been requested - do it when card is removed.
	private boolean lowMemory; // use low memory binding or not.
//  JVM exit codes.
    private final static int normalShutDownExitCode=0; // exit code for normal shutdown.
    private final static int requestedShutDownExitCode=1; // exit code when system administrator asks for shutdown.
    private final static int errorShutDownExitCode=2; // exit code when errors too severe for continuation have occurred.
    private int exitCode = normalShutDownExitCode; // settable exit code - the value to actually use.	
		
	public CardControl(ResourceBundle rb, Properties pf) {
		super();
		// Get Properties file as a Resource Bundle.
		theRB = rb;
        theProperties = pf;
        String mss = theProperties.getProperty("CC.multipleSessions", "false");
        multipleSessions = (Boolean.valueOf(mss)).booleanValue();
        // Set log file logging level.
        String ll = theProperties.getProperty("CC.logLevel", "");
        if (! ll.equals("")) {
            try {
                int logLevel = Integer.parseInt(ll);
                SmartCardLogFile.setLogLevel(logLevel);
            }
            catch (NumberFormatException ne) {
                SmartCardLogFile.writeLog("Log Level is invalid");
            }
        }
        // Should we shut down when OpenCard Exceptions occur?
        String sd = theProperties.getProperty("CC.shutDownOnError", "true");
        shutDownOnError = Boolean.valueOf(sd).booleanValue();
		
		// Use low memory?
		String lm = theProperties.getProperty("CC.lowmemory", "false");
		lowMemory = Boolean.valueOf(lm).booleanValue();

		theIP = new InsertProcessor(this);
		theIPThread = new Thread(theIP, "theIPThread");
		theRP = new RemoveProcessor(this);
		theRPThread = new Thread(theRP, "theRPThread");
		theCC = this;
	}
    
/**    
  * Are we supposed to shut down when OpenCard Exceptions occur?
  * @return true if yes, false otherwise. 
*/   
	boolean errorShutdown() {
        return shutDownOnError;
    }
    
/**	
  * Tell us when web4All has been started and stopped.
  * @param status true when web4All has been started; false when it has been stopped.
*/   
	synchronized void setw4aStatus(boolean status) {
		w4aRunning = status;
	}
	
/**	
  * Query the status of web4All.
  * @return true when web4All's kickitMethod has been called; false when web4All's
  * stopIt method has been called or it's never been started.
*/   
	synchronized boolean getw4aStatus() {
		return w4aRunning;
	}

/**	
  * Whether or not to handle multiple "sessions". A session is the activity that
  * takes place between the insertion of a card and its removal.
  * @return true  
*/   
	protected boolean multipleSessions() {
		return multipleSessions;
	}
    
/**    
  * A method to save the CardTerminal and Slot in which the card we're using was inserted.
*/   
    private synchronized void setTerminal(CardTerminalEvent cte) {
        theCardTerminal = cte.getCardTerminal();
        theSlot = cte.getSlotID();
    }
        
/**    
  * A method to determine whether the card we're working with is still present in the reader.
  * @return true if its is; false otherwise.
*/   
    public boolean isCardPresent() {
        if (theCardTerminal != null) {
            try {
                return theCardTerminal.isCardPresent(theSlot);
            }
            catch(CardTerminalException cte) {
                // No way to recover gracefully - shut the whole thing down.
                SmartCardLogFile.logException(cte);
                requestShutdownOnRemove();
                SmartCardLogFile.writeLog("isCardPresent sending message to user.");
                ShutDownMessage sdm = new ShutDownMessage();
                sdm.start();
                try {
                    sdm.join(10000L); // give user 10 seconds to respond.
                }
                catch(InterruptedException ie) {
                }
                SmartCardLogFile.writeLog("isCardPresent initiating shutdown.");
                shutDown();
                return false;
            }
        }
        else {
            // FIXME - put call stack in logfile - throw Exception and catch it?
            SmartCardLogFile.writeLog("CardControl.isCardPresent called before theCardTerminal initialized.", SmartCardLogFile.LOG_DEBUG);
            return false;
        }
    }
    
/**	
  * A method to shutdown the entire system. 
*/   
	
	public void shutDown() {
        synchronized(this) { // prevent multiple shutdown requests.
            if (shutDownStarted) {
                return;
            }
            else {
                shutDownStarted = true;
            }
        }
		// Cancel ourself as a listener.
		EventGenerator.getGenerator().removeCTListener(this);
        SmartCardLogFile.writeLog("CardControl beginning shutdown processing.", SmartCardLogFile.LOG_DEBUG);
        // Waken main thread which is waiting for a shutdown request.
        // - it does most of the work. See run().
		synchronized (monitor) {
            dontWait = true;  // Prevent initial wait when shutdown is needed.
			monitor.notify ();
		}
	}
    
/**    
  * A method to request a SmartCard/VM shutdown when a card is removed.  
*/   
    synchronized void requestShutdownOnRemove() {
        shutDownOnRemoveRequest = true;
    }
    
/**    
  * Has a shutdown when a card is removed been requested? 
  * @return true if it has; false otherwise.
*/   
    synchronized boolean shutDownOnRemove() {
        return shutDownOnRemoveRequest;
    }
/**	
  * A method to "reset" the SmartCard sub-system. Needed only because of a bug
  * somewhere in the sub-system which prevents the FontColourSetup code from
  * completing.  
  * @return true if the reset was successful; false otherwise.
*/   
	public boolean reset() {
		SmartCardLogFile.writeLog("Starting reset processing.");
		Process p = null;
		
		// Terminate the "problem" Windows process.
		try {
			String pathOfKiller = theProperties.getProperty("CC.pathOfKiller", "");
			if (pathOfKiller.length() > 0) {
				p = Runtime.getRuntime().exec(pathOfKiller);
				p.waitFor();
				SmartCardLogFile.writeLog("Process killer returned " + p.exitValue());
				if (p.exitValue() != 0) {
					return false;
				}
			}
			else {
				SmartCardLogFile.writeLog("No Process killer defined");
			}
		}
		catch (IOException ioe) {
			SmartCardLogFile.logException(ioe);
			return false;
		}
		catch (InterruptedException ie) {
			SmartCardLogFile.logException(ie);
		}
/*		try {
			SmartCardLogFile.writeLog("Before SmartCard.shutdown()");
			System.out.println("before shutdown");
			SmartCard.shutdown ();
			SmartCardLogFile.writeLog("After SmartCard.shutdown()");
			System.out.println("after shutdown");
		}
		catch (CardTerminalException cte) {
			SmartCardLogFile.logException(cte);
			return false;
		}*/
		return true;
//		return startSC();
	}
	
/**	
  * A method to lookup a key in the ResourceBundle. 
  * @param key the key of the lookup table.
  * @return the value associated with the key or the empty string if no match.
*/   
	public String lookup(String key) {
		try {
			return theRB.getString(key);
		}
		catch (MissingResourceException mre) {
			SmartCardLogFile.writeLog("Resource bundle lookup failed for " + key);
			SmartCardLogFile.logException(mre);
		}
		return "";
	}
	
	/**
	  * This method gets control when the JVM starts. It creates a CardControl object
	  * and invokes its run method.
	*/   
    public static void main (String [] args) {
        Properties pf = null;
		ResourceBundle rb = null;
		boolean ms = false;
		String ds;
        String mss;
        pf = new Properties();
		// Try to get the Properties File. Die if fail.
		try {
            //FIXME - path to Properties file should come from command line
			pf.load(new FileInputStream(new File("CardControl.properties")));
		}
		catch (IOException ioe) {
			System.err.println("IO Exception accessing properties file");
			System.exit(errorShutDownExitCode);
		}
		// Try to get the ResourceBundle. Die if fail.
		try {
			 rb = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.CardControlProps");
		}
		catch (MissingResourceException mre) {
			mre.printStackTrace(System.err);
			System.exit(errorShutDownExitCode);
		}
		// Try to create a log file. Die if fail.
		ds = pf.getProperty("CC.logFileDirectory", "");
        //FIXME - add code to get booleans for stdout and stderr from Properties file.
		if (!SmartCardLogFile.createLogFile(ds, true, true)) {	// Create/open log file.
			System.err.println("Unable to create log file");
			System.exit(errorShutDownExitCode);
		}
		// Create a CardControl object
		theCC = new CardControl(rb, pf);
		theCC.run();
	}
	
/**	
  * A method to return the singleton CardControl instance.
  * @return the CardControl instance. 
*/   
	public static CardControl getCC() {
		return theCC;
	}
	
/**	
  * This method starts OpenCard, waits for a shutdown event and then shuts down
  * OpenCard. 
*/   
	private void run() {
		// Put a startup message in the log file.
		SmartCardLogFile.writeLog("Web4All system starting.");
        SmartCardLogFile.writeLog("multipleSessions is " + multipleSessions(), SmartCardLogFile.LOG_DEBUG);
        SmartCardLogFile.writeLog("shutDownOnError is " + shutDownOnError, SmartCardLogFile.LOG_DEBUG);
		// Create an instance of ControlHub.
		w4a = ControlHub.startWeb4All(System.getProperty("user.dir"), theIP);
		
		// Start the InsertProcessor.
		try {
			synchronized (this) {
				theIPThread.start();
				wait(); // wait till theIP says its ready for wakeup calls.
						// We can miss an insertion event if we don't do this.
				SmartCardLogFile.writeLog("Card Insertion Processor is ready for work");
				theRPThread.start();
				wait(); // wait till theIP says its ready for wakeup calls.
						// We can miss a removal event if we don't do this.
				SmartCardLogFile.writeLog("Card Removal Processor is ready for work");
			}
		}
		catch (InterruptedException e) {
			SmartCardLogFile.writeLog("InterruptedException while attempting to start insert or removal processor.");
			System.exit(errorShutDownExitCode);
		}
		
        // Do the SmartCard initilization.
		if (startSC()) {
            // If no card is currently in the reader, display a "waiting for insertion" status message.
            if (! insertEvent) {
                w4a.updateStatusMessage(lookup("CC.waitForInsert"));
            }
		}
		else {
			SmartCardLogFile.writeLog("Unable to start SmartCard. Shutting down.");
            if (SmartCard.isStarted()) {
                try {
                SmartCard.shutdown();
                }
                catch (CardTerminalException cte) {
                    SmartCardLogFile.logException(cte);
                }
            }
			System.exit(errorShutDownExitCode);
		}
		
        // stop execution of the current thread here to wait for a shutdown
		// request.
		synchronized (monitor) {
			try {
                if (! dontWait) {
                    SmartCardLogFile.writeLog("Main Thread is waiting for shutdown request.");
                    monitor.wait ();
                }
                else {
                    SmartCardLogFile.writeLog("Bypassing wait for shutdown request.", SmartCardLogFile.LOG_DEBUG);
                }
			}
			catch (InterruptedException ie) {
				// Log shutdown request here.
				SmartCardLogFile.writeLog("Shutdown request received.");
			}
			// Shut down the the threads which handle insert and remove events.
			if (theIPThread.isAlive()) {
				SmartCardLogFile.writeLog("Shutting down InsertProcessor.");
                w4a.updateStatusMessage(null);
				theIPThread.interrupt();
				try {
					SmartCardLogFile.writeLog("Waiting for InsertProcessor to terminate.");
					theIPThread.join(5000L); // five second wait.
					SmartCardLogFile.writeLog("After join on InsertProcessor.");
				}
				catch (InterruptedException ie) {
					SmartCardLogFile.writeLog("InterrptedException trying to shut down InsertProcessor.");
				}
			}
			if (theRPThread.isAlive()) {
				SmartCardLogFile.writeLog("Shutting down RemoveProcessor.");
                w4a.updateStatusMessage(null);
				theRPThread.interrupt();
				try {
					SmartCardLogFile.writeLog("Waiting for RemoveProcessor to terminate.");
					theRPThread.join(5000L); // five second wait.
					SmartCardLogFile.writeLog("After join on RemoveProcessor.");
				}
				catch (InterruptedException ie) {
					SmartCardLogFile.writeLog("InterrptedException trying to shut down RemoveProcessor.");
				}
			}
			try {
				SmartCardLogFile.writeLog("Initiating OpenCard shut down.");
				SmartCard.shutdown();
				SmartCardLogFile.writeLog("OpenCard has been shut down.");
			}
			catch (CardTerminalException cte) {
				SmartCardLogFile.logException(cte);
			}
		}
		SmartCardLogFile.writeLog("Exiting...");
        SmartCardLogFile.close();
		System.exit(exitCode);

    }
    
/**    
  * A method to perform the shutdown when the system administrator has requested it. 
*/   
    synchronized void processShutdownRequest() {
        exitCode = requestedShutDownExitCode;
        shutDown();
    }
	
/**	
  * A method to get the ControlHub object which provides the services to the user. 
*/   
	
	protected synchronized ControlHub getWeb4All() {
		return w4a;
	}
	
/**	
  * This method is invoked when a card has been inserted into the reader. 
  * It attempts to get a SmartCard object and, if successful, passes control
  * to another Thread.
  * @param ctEvent the CardTerminalEvent.
*/   
    public void cardInserted (CardTerminalEvent ctEvent) {
        w4a.updateStatusMessage(""); // Clear the status message.
        insertEvent = true;  // Insert event occurred.
		SmartCardLogFile.writeLog("Card insertion has been detected.");
		try {
            setTerminal(ctEvent);
			SmartCard card = SmartCard.getSmartCard(ctEvent, new CardRequest(CardRequest.ANYCARD, null, null));
            theIP.setCard(card);
            synchronized(theIP) {
                theIP.notifyAll(); // Set theIP running.
            }
		}
		catch (CardTerminalException ex){
            SmartCardLogFile.logException(ex);
            requestShutdownOnRemove();
            setTerminal(ctEvent);
            //FIXME - should really create only one of these and reuse it.
            ShutDownMessage sdm = new ShutDownMessage();
            sdm.start(); // send shutdown message to user
            try {
                sdm.join(10000L); // give user 10 seconds to respond.
            }
            catch(InterruptedException ie) {
            }
            shutDown(); // don't try to recover from this.
            /*if (errorShutdown()) { 
                if (isCardPresent()) {
                    requestShutdownOnRemove();
                }
            }
            if (!isCardPresent()) {
            }*/
		}
    } // cardInserted


    /**
     * Is invoked if a card is removed.
     *
     * @param ctEvent  the event indicating the terminal and slot
     */
    public void cardRemoved (CardTerminalEvent ctEvent) {
		try {
			SmartCardLogFile.writeLog("Card removal has been detected.");
            if (shutDownOnRemove()) {
                // if an error has occurred and we should shutdown...
                shutDown();
            }
            else {
    			synchronized(theRP) {
    				theRP.notifyAll(); // Set theRP running.
    			}
            }
		}
		catch (Exception e) {
			SmartCardLogFile.logException(e);
		}
    } 
	
/**	
  * A method to start the SmartCard sub-system and add ourself as a CTLListener
  * If an exception occurs, it's logged.
  * @return true if successful; false otherwise. 
*/   
	protected boolean startSC() {
        try {
            // get OpenCard up and running
            SmartCard.start();
        }
        catch (OpenCardPropertyLoadingException plfe) {
			w4a.updateStatusMessage(lookup("CC.canNotStart"), JOptionPane.ERROR_MESSAGE);
			SmartCardLogFile.logException(plfe);
			return false;
        }
        catch (ClassNotFoundException cnfe) {
			w4a.updateStatusMessage(lookup("CC.canNotStart"), JOptionPane.ERROR_MESSAGE);
			SmartCardLogFile.logException(cnfe);
			return false;
        }
        catch (CardServiceException cse) {
			w4a.updateStatusMessage(lookup("CC.canNotStart"), JOptionPane.ERROR_MESSAGE);
			SmartCardLogFile.logException(cse);
			return false;
        }
        catch (CardTerminalException cte) {
			w4a.updateStatusMessage(lookup("CC.canNotStart"), JOptionPane.ERROR_MESSAGE);
			SmartCardLogFile.logException(cte);
			return false;
        }
        SmartCardLogFile.writeLog("OpenCard system started.");
        Enumeration en = CardTerminalRegistry.getRegistry().getCardTerminals();
        SmartCardLogFile.writeLog("Terminals are:");
        while (en.hasMoreElements()) {
            CardTerminal ct = (CardTerminal) en.nextElement();
            SmartCardLogFile.writeLog(ct.toString());
        }
        EventGenerator.getGenerator().addCTListener (this);

        // Check for cards already in the reader when we start.
        try {
            EventGenerator.getGenerator().createEventsForPresentCards(this);
        }
        catch (CardTerminalException cte) {
            SmartCardLogFile.writeLog("Unable to create events for present cards.");
			w4a.updateStatusMessage(lookup("CC.canNotStart"), JOptionPane.ERROR_MESSAGE);
			SmartCardLogFile.logException(cte);
			return false;
        }
		return true;
	}

	/**
	 * Gets whether or not we are using a low memory binding.
	 *
	 * @return  true if we are using low memory, false o.w.
	 */
	protected boolean useLowMemory() {
		return lowMemory;
	}
		
/**    
  * An inner class to handle the user interaction when a we get an error trying
  * to handle an insertion event. Needed since user interaction can block the
  * card event Thread. 
*/   
    protected class ShutDownMessage extends Thread {
        private long waitTime = 0;
        
        ShutDownMessage() {
            super();
            setName("ShutDownMessage Thread");
            setDaemon(true); // Let JVM shut down even if we're running.
        }
        
        public void run() {
            SmartCardLogFile.writeLog("ShutDownMessage - sending message to user", SmartCardLogFile.LOG_DEBUG);
   			w4a.updateStatusMessage(null);
   			w4a.updateStatusMessage(lookup("CC.fatalError"), JOptionPane.ERROR_MESSAGE);
            SmartCardLogFile.writeLog("ShutDownMessage - after sending message to user", SmartCardLogFile.LOG_DEBUG);
        }
    }

}
