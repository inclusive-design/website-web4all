/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import ca.utoronto.atrc.web4all.ControlHub;
import ca.utoronto.atrc.web4all.Web4AllConstants;
import ca.utoronto.atrc.web4all.Web4AllPropNames;

import java.util.*;
import java.io.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import org.apache.xerces.dom.*;
import org.apache.xml.serialize.*;

import org.apache.xpath.*;
import javax.xml.transform.TransformerException;
import org.apache.xerces.util.DOMUtil;

/**
 * PreferenceManager is the manager of all the preference panels. 
 * It controls which panels are shown at what time and creates
 * the entire preference XML document which is saved to the user's smartcard.
 *
 * @author David Weinkauf    
 * @author Joseph Scheuhammer
 * @version $Revision: 1.69 $, $Date: 2006/03/28 16:31:10 $
 */
public class PreferenceManager extends JDialog 
    implements DialogConstants, Web4AllConstants {

    /** The initial dialog in which the user selects the language.*/
    private LanguagePanel languagePanel;

    /** The control preferences dialog.*/
    private ControlPrefs controlPrefs;

    /** The display preferences dialog.*/
    private DisplayPrefs displayPrefs;

    /** The alternatives to keyboard settings dialog.*/
    private AltKeyboard altKeyboard;

    /** The coded input settings dialog.*/
    private CodedInput codedInput;

    /** The prediction settings dialog.*/
    private Prediction prediction;

    /** The keyboard setup editing panel.*/
    private KeyboardEnhanced keyboardEnhanced;

    /** The screen enhancement editing panel.*/
    private ScreenEnhancement screenEnhance;

    /** The text highlight editing panel.*/
    private TextHighlight textHighlight;

    /** The screen reading editing panel.*/
    private ScreenReader screenReader;

    /** The alternative pointing editing panel.*/
    private AltPointing altPointing;

    /** The mouse alternative editing panel.*/
    private MouseEmulation mouseEmulation;

    /** The first onscreen keyboard editing panel.*/
    private OnscreenKeyboard onscreenKeyboard;

    /** The Braille settings panel.*/
    private Braille braille;

    /** The Visual Alert settings panel.*/
    private VisualAlert visualAlert;

    /** The Voice Recognition settings panel.*/
    private VoiceRec voiceRec;

    /** The third party selector dialog.*/
    private ThirdPartyAppSelector thirdPartySelector;
    
    /** The ResourceBundle for the DTD XML elements.*/
    private ResourceBundle xmlLabels;

    /** The ResourceBundle for the panel titles.*/
    private ResourceBundle titles;
    
    /** The reference to ControlHub.*/
    private ControlHub w4a;
    
    /** PreferenceManager.language holds the current value 
        of the users preferred language.*/
    protected Locale language;
    
    /** The user's initial language in case they exit the PWM.*/ 
    private Locale initialLanguage;

    /** The system's initial language in case of a card removal in the PWM.*/ 
    private Locale defaultLanguage;

    /** The user's XML preferences.*/
    private Document preference;

    /** Boolean to tell whether or not the PWM was prematurely killed.*/
    private boolean killed;

    /** Boolean to tell whether or not this is a new preference or an
        edited one.*/
    private boolean inNewPreference;

    /** Third party app selector title key.*/
    private static final String TP_TITLE_KEY = "third.party.title";

    /** Language panel key.*/
    private static final String LP_TITLE_KEY = "language.title";

    /** Application suffix resource key.*/
    private static final String APP_SUFFIX = ".app";

    /** Control preferences title key.*/
    protected static final String CONTROL_PREFS = "control.prefs";

    /** Display preferences title key.*/
    protected static final String DISPLAY_PREFS = "display.prefs";

    /** The content pane of the PWM.*/
    private Container contentPane;

    /** The NORTH title panel.*/
    private JPanel titlePanel;

    /** The title label for all the different panels.*/
    private JLabel titleLabel;

    /** The constant PWM title.*/
    private JLabel pwTitle;

    /** The application type to panel hashtable.*/
    private Hashtable appTypeToPanel;

    /** The application type to Boolean value denoting if the type has
        been selected.*/
    private Hashtable appTypeSelected;

    /** Array of all the application types which come under the <display>
        portion of the ACCLIP.*/
    private String[] displayTechs;

    /** Array of all the application types which come under the <control>
        portion of the ACCLIP.*/
    private String[] controlTechs;

    /** The main dialog ordering vector.*/
    private Vector appTypeOrder;

    /** Boolean variable to designate whether or not coded input is set
        through onscreen keyboard.*/
    private boolean isCodedInputSetThroughOnscreenKeyboard;

    /** Boolean variable to toggle printing out preference to stdout.*/
    private static boolean debug_prefs = true;

    /**
     * Sole Constructor. Initializes the screen positioning and
     * navigational constructs.
     *
     * @param  w4a      the ControlHub Object which initializes this
     * @param  inOwner  the parent window - i.e. the splash screen
     */
    public PreferenceManager(ControlHub w4a, JFrame inOwner) {
        super(inOwner);
        this.w4a = w4a;

        xmlLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.Applications");
                
        this.setSize(DIALOG_WIDTH, DIALOG_HEIGHT);
        this.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        this.setResizable(true);        
        this.addWindowListener(new MyWindowAdapter());

        inNewPreference = false;

        language = Locale.getDefault();
        defaultLanguage = language;
        initialLanguage = language;
        setDefaultLocale(language);

        isCodedInputSetThroughOnscreenKeyboard = false;

        contentPane = getContentPane();         
        contentPane.setBackground(PANEL_BACKGROUND);

        String[] tempDisplayTechs = { SCREEN_ENHANCE, SCREEN_READER, 
                                      TEXT_READING_HIGHLITE, BRAILLE, 
                                      VISUAL_ALERT };
        displayTechs = tempDisplayTechs;

        String[] tempControlTechs = { KEYBOARD_ENHANCED, MOUSE_EMULATION, 
                                      ALT_POINTING, ONSCREEN_KEYBOARD, 
                                      VOICE_REC, ALT_KEYBOARD, CODED_INPUT, 
                                      PREDICTION };
        controlTechs = tempControlTechs;

        initAppTypeOrder();

    }

    /**
     * Initializes the 'North' title panel with the logo's and title labels.
     */
    private void initTitlePanel() {

        titleLabel = new JLabel("");
        titleLabel.setFont(TITLE_FONT);
        titleLabel.setForeground(THEME_COLOUR);

        pwTitle = new JLabel(titles.getString("pw.title")); 
        pwTitle.setFont(BORDER_TITLE_FONT);
        pwTitle.setForeground(TEXT_COLOUR);

        Class pmClass = this.getClass();

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel topGridPanel = new JPanel();
        topGridPanel.setBackground(PANEL_BACKGROUND);
        topGridPanel.setLayout(gridbag);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.weighty = 0.5;
        c.gridheight = 1;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        topGridPanel.add(pwTitle, c);

        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 1.0;
        topGridPanel.add(Box.createHorizontalStrut(1), c);

        JPanel topPanel = new JPanel(new GridLayout(1, 1));
        topPanel.setBackground(PANEL_BACKGROUND);
        topPanel.add(topGridPanel);

        ImageIcon w4aIcon = new ImageIcon (pmClass.getResource ("w4a_logo.png"),
                                           titles.getString("w4a.logo.alt"));
        JLabel w4aIconLabel = new JLabel(w4aIcon);
        w4aIconLabel.getAccessibleContext().setAccessibleName(
                    titles.getString("w4a.logo.alt"));

        JPanel w4aIconPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        w4aIconPanel.setBackground(PANEL_BACKGROUND);
        w4aIconPanel.add(w4aIconLabel);

        gridbag = new GridBagLayout();
        c = new GridBagConstraints();
        JPanel gridPanel = new JPanel();
        gridPanel.setBackground(PANEL_BACKGROUND);
        gridPanel.setLayout(gridbag);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.weighty = 0.5;
        c.gridheight = 2;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        gridPanel.add(w4aIconPanel, c);

        c.gridheight = 1;

        c.anchor = GridBagConstraints.SOUTHWEST;
        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 1.0;
        gridPanel.add(topPanel, c);

        c.anchor = GridBagConstraints.WEST;
        c.gridx = 1;
        c.gridy = 1;
        c.weightx = 0.0;
        gridPanel.add(titleLabel, c);

        JPanel generalPanel = new JPanel(new GridLayout(1, 1));
        generalPanel.setBackground(PANEL_BACKGROUND);
        generalPanel.add(gridPanel);

        titlePanel = new JPanel(new BorderLayout());
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.X_AXIS));
        titlePanel.setBackground(PANEL_BACKGROUND);

        titlePanel.add(Box.createHorizontalStrut(15), BorderLayout.EAST);
        titlePanel.add(generalPanel, BorderLayout.CENTER);
        titlePanel.add(Box.createHorizontalStrut(15), BorderLayout.WEST);
               
    }

    /**
     * Initializes the main application type ordering of the dialogs.
     */
    private void initAppTypeOrder() {

        if (appTypeOrder != null)
            appTypeOrder.removeAllElements();

        appTypeOrder = new Vector();
        appTypeOrder.addElement(DISPLAY_PREFS);
        appTypeOrder.addElement(CONTROL_PREFS);
        appTypeOrder.addElement(SCREEN_ENHANCE);
        appTypeOrder.addElement(TEXT_READING_HIGHLITE);
        appTypeOrder.addElement(SCREEN_READER);
        appTypeOrder.addElement(BRAILLE);
        appTypeOrder.addElement(VISUAL_ALERT);
        appTypeOrder.addElement(KEYBOARD_ENHANCED);
        appTypeOrder.addElement(ONSCREEN_KEYBOARD);
        appTypeOrder.addElement(ALT_KEYBOARD);
        appTypeOrder.addElement(MOUSE_EMULATION);
        appTypeOrder.addElement(ALT_POINTING);
        appTypeOrder.addElement(VOICE_REC);
        appTypeOrder.addElement(CODED_INPUT);
        appTypeOrder.addElement(PREDICTION);

    }


    /**
     * Initializes the application type to edit panel hashtable.
     */
    private void initAppTypeToPanel() {

        appTypeToPanel = new Hashtable();
        appTypeToPanel.put(SCREEN_ENHANCE, screenEnhance);
        appTypeToPanel.put(SCREEN_READER, screenReader);
        appTypeToPanel.put(TEXT_READING_HIGHLITE, textHighlight);
        appTypeToPanel.put(KEYBOARD_ENHANCED, keyboardEnhanced);
        appTypeToPanel.put(MOUSE_EMULATION, mouseEmulation);
        appTypeToPanel.put(ALT_POINTING, altPointing);
        appTypeToPanel.put(ONSCREEN_KEYBOARD, onscreenKeyboard);
        appTypeToPanel.put(BRAILLE, braille);
        appTypeToPanel.put(VISUAL_ALERT, visualAlert);
        appTypeToPanel.put(VOICE_REC, voiceRec);
        appTypeToPanel.put(ALT_KEYBOARD, altKeyboard);
        appTypeToPanel.put(CODED_INPUT, codedInput);
        appTypeToPanel.put(PREDICTION, prediction);
        appTypeToPanel.put(DISPLAY_PREFS, displayPrefs);
        appTypeToPanel.put(CONTROL_PREFS, controlPrefs);

    }


    /**
     * Creates a new set of preferences.
     *
     * @return  the new set of user preferences, or null if cancelled.
     */
    public Document newPreference() {

        inNewPreference = true;

        language = Locale.getDefault();
        initialLanguage = language;

        Document doc = null;

        // Create a new Document instance with schema described in 
        // the PreferenceManager.properties file.
        //
        try {
                        
            DOMImplementation impl = new DOMImplementationImpl();

            doc = impl.createDocument(w4a.getGlobalProperty(ControlHub.XMLNS_VAL), 
                                      xmlLabels.getString(ROOT_DATUM), null);
                        
            Element root = doc.getDocumentElement();

            root.setAttribute("xmlns", w4a.getGlobalProperty(ControlHub.XMLNS_VAL));
            root.setAttribute("xmlns:xsi", w4a.getGlobalProperty(ControlHub.XMLNS_XSI_VAL));
            root.setAttribute("xsi:schemaLocation", w4a.getGlobalProperty(ControlHub.XMLNS_VAL) 
                              + " " + w4a.getGlobalProperty(ControlHub.SCHEMA_LOCATION_VAL));
            root.setAttribute("schemaVersion", w4a.getGlobalProperty(ControlHub.SCHEMA_VERSION_VAL));

            Element context = doc.createElement(xmlLabels.getString(CONTEXT));
            context.setAttribute(xmlLabels.getString(CONTEXT_ID), w4a.getGlobalProperty(ControlHub.CONTEXT_ID_VAL));

            root.appendChild(context);
                        
        } catch (FactoryConfigurationError e) { 
            System.out.println("Could not locate a DOMImplementation class."); 
        }

        return doPreferences(doc);

    }

    /**
     * Edits a set of preferences.
     *
     * @param  doc  the XML Document attained from the users card
     * @return      the edited set of user preferences, or null if cancelled
     */
    public Document editPreference(Document doc) {

        // If the Document is null, go to a <newPreference>.
        //
        if (doc == null) {
            System.out.println("Attempting to edit a null preference, creating new preference.");
            return newPreference();
        }
                
        if (debug_prefs) {
            OutputFormat out = new OutputFormat(doc, null, true);
            XMLSerializer serializer = new XMLSerializer(System.out, out);
            try {
                serializer.serialize(doc);              
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }

        inNewPreference = false;

        Element root = doc.getDocumentElement();

        Element context = getW4AContext(doc);

        if (context == null) {
            context = doc.createElement(xmlLabels.getString(CONTEXT));
            context.setAttribute(xmlLabels.getString(CONTEXT_ID), 
                                 w4a.getGlobalProperty(ControlHub.CONTEXT_ID_VAL));
            root.appendChild(context);
        }

        // Fix bug #44 - move xml:lang from 'accessForAll' to 'context'.
        //
        if (context.getAttribute(xmlLabels.getString(PREF_LANG)) == null &&
            root.getAttribute(xmlLabels.getString(PREF_LANG)) != null) {
            
            context.setAttribute(xmlLabels.getString(PREF_LANG), 
                                 root.getAttribute(xmlLabels.getString(PREF_LANG)));

            root.removeAttribute(xmlLabels.getString(PREF_LANG));
        }

        // Set the user language.
        //
        language = getLocaleFromString(context.getAttribute(xmlLabels.getString(PREF_LANG)));
        initialLanguage = (Locale) language.clone();
                
        return doPreferences(doc);

    }

    /**
     * Does the user preferences. Initializes all the assistive-tech type panels and documents and 
     * shows the first panel.
     *
     * @param  doc  the accessForAll doc
     * @return      the new accessForAll doc, or null if user cancelled.
     */
    private Document doPreferences(Document doc) {

        this.setLocation(DIALOG_LOC);
        this.setSize(DIALOG_WIDTH, DIALOG_HEIGHT);
        killed = false;

        appTypeSelected = new Hashtable();

        preference = doc;

        titles = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Titles", language);

        initTitlePanel();

        Element display = null;
        Element control = null;
        Element current = null;
        Element context = getW4AContext(preference);

        try {
            display = (Element) XPathAPI.selectSingleNode(context, ".//display");
            control = (Element) XPathAPI.selectSingleNode(context, ".//control");
        } catch (TransformerException te) {
            te.printStackTrace();
        }

        // Initialize DISPLAY section of tree
        //
        if (display != null) 
            current = DOMUtil.getFirstChildElement(display);                

        if (current != null && current.getTagName().equals(xmlLabels.getString(SCREEN_READER))) {
            screenReader = new ScreenReader(this, current, SCREEN_READER);
            appTypeSelected.put(SCREEN_READER, Boolean.TRUE);
            current = DOMUtil.getNextSiblingElement(current);
            screenReader.setDomValues();
        } else {
            screenReader = new ScreenReader(this, null, SCREEN_READER);
        }
                
        if (current != null && current.getTagName().equals(xmlLabels.getString(SCREEN_ENHANCE))) {
            screenEnhance = new ScreenEnhancement(this, current, SCREEN_ENHANCE);
            appTypeSelected.put(SCREEN_ENHANCE, Boolean.TRUE);
            current = DOMUtil.getNextSiblingElement(current);
            screenEnhance.setDomValues();
        } else {
            screenEnhance = new ScreenEnhancement(this, null, SCREEN_ENHANCE);
        }
                
        if (current != null && current.getTagName().equals(xmlLabels.getString(TEXT_READING_HIGHLITE))) {
            textHighlight = new TextHighlight(this, current, TEXT_READING_HIGHLITE);
            appTypeSelected.put(TEXT_READING_HIGHLITE, Boolean.TRUE);
            current = DOMUtil.getNextSiblingElement(current);
            textHighlight.setDomValues();
        } else {
            textHighlight = new TextHighlight(this, null, TEXT_READING_HIGHLITE);
        }

        if (current != null && current.getTagName().equals(xmlLabels.getString(BRAILLE))) {
            braille = new Braille(this, current, BRAILLE);
            appTypeSelected.put(BRAILLE, Boolean.TRUE);
            current = DOMUtil.getNextSiblingElement(current);
            braille.setDomValues();
        } else {
            braille = new Braille(this, null, BRAILLE);
        }

        if (current != null && current.getTagName().equals(xmlLabels.getString(VISUAL_ALERT))) {
            visualAlert = new VisualAlert(this, current, VISUAL_ALERT);
            appTypeSelected.put(VISUAL_ALERT, Boolean.TRUE);
            current = DOMUtil.getNextSiblingElement(current);
            visualAlert.setDomValues();
        } else {
            visualAlert = new VisualAlert(this, null, VISUAL_ALERT);
        }
                
        current = null;

        // Initialize CONTROL section of tree
        //
        if (control != null) {
            current = DOMUtil.getFirstChildElement(control);
        }

        if (current != null && current.getTagName().equals(xmlLabels.getString(KEYBOARD_ENHANCED))) {
            keyboardEnhanced = new KeyboardEnhanced(this, current, KEYBOARD_ENHANCED);
            appTypeSelected.put(KEYBOARD_ENHANCED, Boolean.TRUE);
            current = DOMUtil.getNextSiblingElement(current);
            keyboardEnhanced.setDomValues();
        } else {
            keyboardEnhanced = new KeyboardEnhanced(this, null, KEYBOARD_ENHANCED);
        }
                
        if (current != null && current.getTagName().equals(xmlLabels.getString(ONSCREEN_KEYBOARD))) {
            onscreenKeyboard = new OnscreenKeyboard(this, current, ONSCREEN_KEYBOARD);
            appTypeSelected.put(ONSCREEN_KEYBOARD, Boolean.TRUE);
            current = DOMUtil.getNextSiblingElement(current);
            onscreenKeyboard.setDomValues();
        } else {
            onscreenKeyboard = new OnscreenKeyboard(this, null, ONSCREEN_KEYBOARD);
        }
                
        if (current != null && current.getTagName().equals(xmlLabels.getString(ALT_KEYBOARD))) {
            altKeyboard = new AltKeyboard(this, current, ALT_KEYBOARD);
            appTypeSelected.put(ALT_KEYBOARD, Boolean.TRUE);
            current = DOMUtil.getNextSiblingElement(current);
            altKeyboard.setDomValues();
        } else {
            altKeyboard = new AltKeyboard(this, null, ALT_KEYBOARD);
        }

        if (current != null && current.getTagName().equals(xmlLabels.getString(MOUSE_EMULATION))) {
            mouseEmulation = new MouseEmulation(this, current, MOUSE_EMULATION);
            appTypeSelected.put(MOUSE_EMULATION, Boolean.TRUE);
            current = DOMUtil.getNextSiblingElement(current);
            mouseEmulation.setDomValues();
        } else {
            mouseEmulation = new MouseEmulation(this, null, MOUSE_EMULATION);
        }
                
        if (current != null && current.getTagName().equals(xmlLabels.getString(ALT_POINTING))) {
            altPointing = new AltPointing(this, current, ALT_POINTING);
            appTypeSelected.put(ALT_POINTING, Boolean.TRUE);
            current = DOMUtil.getNextSiblingElement(current);
            altPointing.setDomValues();
        } else {
            altPointing = new AltPointing(this, null, ALT_POINTING);
        }

        if (current != null && current.getTagName().equals(xmlLabels.getString(VOICE_REC))) {
            voiceRec = new VoiceRec(this, current, VOICE_REC);
            appTypeSelected.put(VOICE_REC, Boolean.TRUE);
            current = DOMUtil.getNextSiblingElement(current);
            voiceRec.setDomValues();
        } else {
            voiceRec = new VoiceRec(this, null, VOICE_REC);
        }
                
        if (current != null && current.getTagName().equals(xmlLabels.getString(CODED_INPUT))) {
            codedInput = new CodedInput(this, current, CODED_INPUT);
            appTypeSelected.put(CODED_INPUT, Boolean.TRUE);
            current = DOMUtil.getNextSiblingElement(current);
            codedInput.setDomValues();
        } else {
            codedInput = new CodedInput(this, null, CODED_INPUT);
        }

        if (current != null && current.getTagName().equals(xmlLabels.getString(PREDICTION))) {
            prediction = new Prediction(this, current, PREDICTION);
            appTypeSelected.put(PREDICTION, Boolean.TRUE);
            current = DOMUtil.getNextSiblingElement(current);
            prediction.setDomValues();
        } else {
            prediction = new Prediction(this, null, PREDICTION);
        }


        thirdPartySelector = new ThirdPartyAppSelector(this, TP_TITLE_KEY);

        controlPrefs = new ControlPrefs(this, CONTROL_PREFS, appTypeSelected);
        displayPrefs = new DisplayPrefs(this, DISPLAY_PREFS, appTypeSelected);

        appTypeSelected.put(CONTROL_PREFS, Boolean.TRUE);
        appTypeSelected.put(DISPLAY_PREFS, Boolean.TRUE);

        if (onscreenKeyboard.isUsingCodeSelection()) {
            setUseCodedInput(true);
        }

        initAppTypeToPanel();

        languagePanel = new LanguagePanel(this, LP_TITLE_KEY);
        languagePanel.initLanguage();

        setNewLabels(language);

        this.setModal(true);

        showPanel(languagePanel);

        return preference;
    }

    /**
     * Does the XML binding for all the edit panels.
     */
    protected void doXMLBinding() {

        Element root = preference.getDocumentElement();

        Element context = getW4AContext(preference);

        // Put language in xml:lang format.
        //
        context.setAttribute(xmlLabels.getString(PREF_LANG), language.getLanguage() + "-" + language.getCountry());

        Element display = null;
        Element control = null;
        Element temp, child = null;

        try {
            display = (Element) XPathAPI.selectSingleNode(context, ".//display");
            control = (Element) XPathAPI.selectSingleNode(context, ".//control");
        } catch (TransformerException te) {
            te.printStackTrace();
        }

        // TODO: CHECK FOR APPLICATIONS WITH DELETED APPLICATION->PARAMS.
        //

        Boolean isDisplay = Boolean.FALSE;
        for (int i = 0; i < displayTechs.length; i++) {
            isDisplay = (Boolean) appTypeSelected.get(displayTechs[i]);
            if (isDisplay == Boolean.TRUE) {
                break;
            }
        }

        if (isDisplay == Boolean.TRUE) {
            if (display == null) {
                display = preference.createElement(xmlLabels.getString(DISPLAY));
                context.insertBefore(display, DOMUtil.getFirstChildElement(context));
            } else {
                removeAllChildren(display);
            }
        } else if (display != null) {
            context.removeChild(display);
        }

        Boolean isControl = Boolean.FALSE;
        for (int i = 0; i < controlTechs.length; i++) {
            isControl = (Boolean) appTypeSelected.get(controlTechs[i]);
            if (isControl == Boolean.TRUE)
                break;
        }

        if (isControl == Boolean.TRUE) {
            if (control == null) {
                control = preference.createElement(xmlLabels.getString(CONTROL));
                context.appendChild(control);                   
            } else {
                removeAllChildren(control);
            }
        } else if (control != null) {
            context.removeChild(control);
        }

        // Display elements
        //
        if ( ((Boolean) appTypeSelected.get(SCREEN_READER)) == Boolean.TRUE ) {
            display.appendChild((Element) preference.importNode(screenReader.getRootElement(), true));
        }
        if ( ((Boolean) appTypeSelected.get(SCREEN_ENHANCE)) == Boolean.TRUE ) {
            display.appendChild((Element) preference.importNode(screenEnhance.getRootElement(), true));
        }
        if ( ((Boolean) appTypeSelected.get(TEXT_READING_HIGHLITE)) == Boolean.TRUE ) {
            display.appendChild((Element) preference.importNode(textHighlight.getRootElement(), true));
        }
        if ( ((Boolean) appTypeSelected.get(BRAILLE)) == Boolean.TRUE ) {
            display.appendChild((Element) preference.importNode(braille.getRootElement(), true));
        }
        if ( ((Boolean) appTypeSelected.get(VISUAL_ALERT)) == Boolean.TRUE ) {
            display.appendChild((Element) preference.importNode(visualAlert.getRootElement(), true));
        }

        // Control elements
        //
        if ( ((Boolean) appTypeSelected.get(KEYBOARD_ENHANCED)) == Boolean.TRUE ) {
            control.appendChild((Element) preference.importNode(keyboardEnhanced.getRootElement(), true));
        }
        if ( ((Boolean) appTypeSelected.get(ONSCREEN_KEYBOARD)) == Boolean.TRUE ) {
            control.appendChild((Element) preference.importNode(onscreenKeyboard.getRootElement(), true));
        }
        if ( ((Boolean) appTypeSelected.get(ALT_KEYBOARD)) == Boolean.TRUE ) {
            control.appendChild((Element) preference.importNode(altKeyboard.getRootElement(), true));
        }
        if ( ((Boolean) appTypeSelected.get(MOUSE_EMULATION)) == Boolean.TRUE ) {
            control.appendChild((Element) preference.importNode(mouseEmulation.getRootElement(), true));
        }
        if ( ((Boolean) appTypeSelected.get(ALT_POINTING)) == Boolean.TRUE ) {
            control.appendChild((Element) preference.importNode(altPointing.getRootElement(), true));
        }
        if ( ((Boolean) appTypeSelected.get(VOICE_REC)) == Boolean.TRUE ) {
            control.appendChild((Element) preference.importNode(voiceRec.getRootElement(), true));
        }
        if ( ((Boolean) appTypeSelected.get(CODED_INPUT)) == Boolean.TRUE ) {
            control.appendChild((Element) preference.importNode(codedInput.getRootElement(), true));
        }
        if ( ((Boolean) appTypeSelected.get(PREDICTION)) == Boolean.TRUE ) {
            control.appendChild((Element) preference.importNode(prediction.getRootElement(), true));
        }
                
        if (debug_prefs) {
            OutputFormat out = new OutputFormat(preference, null, true);
            XMLSerializer serializer = new XMLSerializer(System.out, out);
            try {
                serializer.serialize(preference);               
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }

    }

    /**
     * Saves and exits the PWM. If the this is not a first-time user preference editing,
     * confirm with the user as to if he/she is sure they want to save preferences.
     */
    protected void saveAndExit() {
        
        String enableConfig = "true";
        try {
            enableConfig = w4a.getGlobalProperty(Web4AllPropNames.ENABLE_CONFIG);
        } catch (MissingResourceException mre) {
            mre.printStackTrace();
        }

        if (!isInNewPreference() && enableConfig.equals("true")) {
            int areYouSure =  JOptionPane.showConfirmDialog(this, 
                                                            titles.getString("are.you.sure"), 
                                                            titles.getString("are.you.sure.title"), 
                                                            JOptionPane.YES_NO_OPTION, 
                                                            JOptionPane.QUESTION_MESSAGE);
            if (areYouSure != JOptionPane.YES_OPTION) {
                // Do nothing.
                return;
            }
        }

        doXMLBinding();

        thirdPartySelector = null;

        Enumeration keys = appTypeToPanel.keys();
        PWMEditPanel panel;
        String key;
        while (keys.hasMoreElements()) {
            key = (String) keys.nextElement();
            panel = (PWMEditPanel) appTypeToPanel.get(key);
            panel = null;
        }

        this.dispose(); 
    }
    
    /**
     * Calls all the PWM dialogs to change the Labels corresponding to the new Locale.
     *
     * @param           language        The new language selected by the user
     */
    protected void setNewLabels(Locale inLanguage) {
        language = inLanguage;

        setDefaultLocale(language);

        titles = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Titles", language);

        pwTitle.setText(titles.getString("pw.title"));

        titleLabel.setText(titles.getString("language.title"));

        this.setTitle(titles.getString("language.title"));
        this.getAccessibleContext().setAccessibleDescription(
            titles.getString("language.title"));

        languagePanel.setNewLabels();
        thirdPartySelector.setNewLabels();

        Enumeration keys = appTypeToPanel.keys();
        PWMEditPanel panel;
        String key;
        while (keys.hasMoreElements()) {
            key = (String) keys.nextElement();
            panel = (PWMEditPanel) appTypeToPanel.get(key);
            panel.setNewLabels();
        }
                
        w4a.updateLanguagePref(language);
    }

    /**
     * Shows the next application type panel.
     *
     * @param  inAppType  the application type ID
     */
    protected void doNextAppType(String inAppType) {
        String nextType = getNextType(inAppType, appTypeOrder, 
                                      appTypeSelected);

        if (nextType != null) {
            PWMEditPanel nextPanel = (PWMEditPanel) appTypeToPanel.get(nextType);

            // Update the "Next" button.
            if (nextPanel instanceof ControlPrefs) {
                ((ControlPrefs) nextPanel).checkNextButton();
            }
            showPanel(nextPanel);
        } else {
            saveAndExit();
        }
    }

    /**
     * Shows the previous application type panel.
     *
     * @param  inAppType  the application type ID
     */
    protected void doPrevAppType(String inAppType) {
        String prevType = getPrevType(inAppType, appTypeOrder, appTypeSelected);

        if (prevType != null) {
            if (prevType != CONTROL_PREFS && prevType != DISPLAY_PREFS) {
                doThirdPartySelector(prevType);
            } else {
                showPanel( (PWMEditPanel) appTypeToPanel.get(prevType));
            }
        } else {
            showPanel(languagePanel);
        }
    }

    /**
     * Gets the next type.
     *
     * @param  inType  the type
     * @param  orderVector  the vector of types indexed by their order
     * @param  selectedTable  the table of Boolean values conveying 
     *                        user-selected types
     */
    protected String getNextType(String inType, Vector orderVector, 
                                 Hashtable selectedTable) {
        String nextType;                
        int index;

        if (inType != null) {
            index = orderVector.indexOf(inType);

            if (index == (orderVector.size() - 1)) {
                return null;
            }
            index++;
        } else {
            index = 0;
        }

        nextType = (String) orderVector.elementAt(index);

        if ( ((Boolean) selectedTable.get(nextType)) == Boolean.TRUE) {
            return nextType;
        } else {
            return getNextType(nextType, orderVector, selectedTable);
        }

    }

    /**
     * Gets the previous type.
     *
     * @param  inType  the type
     * @param  orderVector  the vector of types indexed by their order
     * @param  selectedTable  the table of Boolean values conveying user-selected types
     */
    protected String getPrevType(String inType, Vector orderVector, Hashtable selectedTable) {
        String prevType;                
        int index;

        if (inType != null) {
            index = orderVector.indexOf(inType);

            if (index == 0) {
                return null;
            }
            --index;
        } else {
            index = orderVector.size() - 1;
        }

        prevType = (String) orderVector.elementAt(index);

        if ( ((Boolean) selectedTable.get(prevType)) == Boolean.TRUE) {
            return prevType;
        } else {
            return getPrevType(prevType, orderVector, selectedTable);
        }
    }

    /**
     * Checks if the given application type is the last one to be edited.
     *
     * @param  inAppType  the application type ID
     */
    protected boolean isLastApp(String inAppType) {

        if (getNextType(inAppType, appTypeOrder, appTypeSelected) != null) {
            return false;
        }

        return true;
    }

    /**
     * Shows the first panel for the given application type.
     *
     * @param  inAppType  the application type ID
     */
    protected void doFirstAppTypePanel(String inAppType) {

        showPanel((PWMEditPanel) appTypeToPanel.get(inAppType));

    }

    /**
     * Shows the last panel for the given application type.
     *
     * @param  inAppType  the application type ID
     */
    protected void doLastAppTypePanel(String inAppType) {

        PWMEditPanel panel = (PWMEditPanel) appTypeToPanel.get(inAppType);

        showPanel(panel.getLastPanel());

    }
        
    /**
     * Displays the thirdPartySelector panel for the corresponding appType.
     *
     * @param  appType  the application type to display
     */
    protected void doThirdPartySelector(String appType) {
        thirdPartySelector.setUpPanel(appType);
        showPanel(thirdPartySelector);
    }


    /**
     * Displays the next editing panel from the third party selector panel.
     *
     * @param  appType  The current application type in the third party app selector dialog.
     */
    protected void doNextThirdPartySelector(String appType) {

        doNextAppType(appType);
    }
    
    /**
     * Displays the previous panel from the third party selector.
     *
     * @param    appType    The application type of the third party selector.
     */
    protected void doPrevThirdPartySelector(String appType) {
                
        doLastAppTypePanel(appType);
                
    }

    /**
     * Shows the given panel and sets the corresponding title.
     *
     * @param  panel     the panel to display
     */
    protected void showPanel(PWMEditPanel panel) {

        contentPane.removeAll();
        contentPane.add(titlePanel, BorderLayout.NORTH);
        contentPane.add(Box.createHorizontalStrut(15), BorderLayout.WEST);
        contentPane.add(Box.createHorizontalStrut(15), BorderLayout.EAST);
        contentPane.add(panel, BorderLayout.CENTER);            
        contentPane.add( panel.getButtonPanel(), BorderLayout.SOUTH);

        if (panel instanceof ThirdPartyAppSelector) {
            titleLabel.setText(titles.getString(panel.getAppType() + APP_SUFFIX));
            setTitle(titles.getString(panel.getAppType() + APP_SUFFIX));                    
        } else {
            titleLabel.setText(titles.getString(panel.getTitleKey()));
            setTitle(titles.getString(panel.getTitleKey()));
        }

        repaint();
        show();
        if (panel.nextButton.isEnabled()) {
            panel.nextButton.requestFocus();
        } else {
            panel.prevButton.requestFocus();
        }
    }

    
    /**
     * Queries the user as to if he/she is sure they want to 
     * cancel and if so, cleans up the PWM and disposes of it.
     */
    protected void cancel() {
        if (JOptionPane.showConfirmDialog(this, titles.getString("cancel.question"), 
                                          titles.getString("cancel.title"), 
                                          JOptionPane.YES_NO_OPTION, 
                                          JOptionPane.QUESTION_MESSAGE) 
            == JOptionPane.YES_OPTION) {

            // Change back to initial Locale.
            //
            setDefaultLocale(initialLanguage);
            w4a.updateLanguagePref(initialLanguage);                        

            cleanUp();
            this.dispose();
        }
    }
    
    /**
     * Kills the PWM, but first cleans it up.
     */
    public void kill() {
        killed = true;          

        // Change back to default Locale.
        //
        setDefaultLocale(defaultLanguage);
        w4a.updateLanguagePref(defaultLanguage);

        cleanUp();
        this.dispose();
    }

    /**
     * Sets the system default locale and updates the built-in UI 
     * components to this locale.
     *
     * @param  inLocale  the locale to switch to
     */
    private void setDefaultLocale(Locale inLocale) {

        Locale.setDefault(inLocale);

        String laf = UIManager.getCrossPlatformLookAndFeelClassName();
        try {
            UIManager.setLookAndFeel(laf);
        } catch (UnsupportedLookAndFeelException ulafe) {
            System.err.println("Warning: UnsupportedLookAndFeel: " + laf);
        } catch (Exception e) {
            System.err.println("Error loading " + laf + ": " + e);
        }

    }

    /**
     * Cleans up the PWM by killing the third party prefs wizard 
     * and getting rid of the user's current set of XML preferences 
     * and all the editing dialogs.
     */
    private void cleanUp() {

        if (thirdPartySelector != null) {
            thirdPartySelector.cleanUp();
        }

        // Set everything to null.
        //
        preference = null;
        thirdPartySelector = null;

        if (appTypeToPanel != null) {
            Enumeration keys = appTypeToPanel.keys();
            PWMEditPanel panel;
            String key;
            while (keys.hasMoreElements()) {
                key = (String) keys.nextElement();
                panel = (PWMEditPanel) appTypeToPanel.get(key);
                panel.cleanUp();
                panel = null;
            }
        }
    }
    
    /**
     * Checks if the PWM been killed.
     */
    public boolean isKilled() {
        return killed;
    }
    
    /**
     * Resets the value of killed to false.
     */
    public void resetKilled() {
        killed = false;
    }
    
    /**
     * Gets the current user's locale.
     *
     * @return  A clone of the user's locale.
     */
    public Locale getLocale() {
        if (language == null) {
            language = Locale.getDefault();
        }
 
        return (Locale) language.clone();               
    }
    
    /**
     * Checks if we are in a new preference or not.
     *
     * @return  Is this a new preference?
     */
    protected boolean isInNewPreference() {
        return inNewPreference;
    }
    
    /**
     * Sets the use of coded input to be mandatory or not.
     *
     * @param  inCodedInput  the use coded input value
     */
    protected void setUseCodedInput(boolean inUseCodedInput) {

        if (inUseCodedInput) {
            if ( ((Boolean) appTypeSelected.get(CODED_INPUT)) == Boolean.FALSE) {
                isCodedInputSetThroughOnscreenKeyboard = true;
            }
        }

        controlPrefs.setMandatoryCodedInput(inUseCodedInput, 
                                            isCodedInputSetThroughOnscreenKeyboard);

        if (!inUseCodedInput && isCodedInputSetThroughOnscreenKeyboard) {
            isCodedInputSetThroughOnscreenKeyboard = false;
                
        }

    }
                        

    /**
     * Gets the Vector of thirdparty application IDs for a given app type.
     *
     * @param    inAppType    The application type
     * @return                A Vector of third party app IDs.
     */
    protected Vector get3rdPartyAppIds (String inAppType) {
        return w4a.get3rdPartyAppIds (inAppType);
    }

    /**
     * Gets the third party preference wizard class for a give app ID.
     *
     * @param    inAppID    The unique application ID
     * @return              The name of the 3rd party wizard class
     */
    protected String get3rdPartyPrefsClass (String inAppID) {
        return w4a.get3rdPartyPrefsClass (inAppID);
    }

    /**
     * Gets the full product name for a given application.
     *
     * @param    inAppID    The unique application ID
     * @return              The full name of the application
     */
    protected String get3rdPartyFullProductName(String inAppID) {
        return w4a.get3rdPartyFullProductName(inAppID);
    }

    /**
     * Gets the Vector of types of an application.
     *
     * @param    inAppID    The unique application ID
     * @return              The application types
     */
    protected Vector get3rdPartyAppTypes(String inAppID) {
        Vector v = null;
        try {
            v = w4a.get3rdPartyAppTypes(inAppID);
        } catch (MissingResourceException mre) {
            System.out.println("Cannot get application types: " + inAppID);
        }

        return v;
    }

    /**
     * Checks if the given application ID exist on the system
     *
     * @param    inAppID    The unique application ID
     * @return              <code>true</code> if the application exists on the system,
     *                      <code>false</code> false, otherwise
     */
    protected boolean thirdPartyAppExists(String inAppID) {
        return w4a.thirdPartyAppExists(inAppID);
    }
    

    /**
     * Gets the assistive-tech branch Document for the corresponding appType.
     *
     * @param  appType  the assistive-tech type
     * @return          the assistive-tech branch Document
     */
    protected Document getAppTypeDoc(String appType) {

        if (appType.equals(SCREEN_READER)) {
            return screenReader.getAppTypeDoc();
        } else if (appType.equals(SCREEN_ENHANCE)) {
            return screenEnhance.getAppTypeDoc();
        } else if (appType.equals(ONSCREEN_KEYBOARD)) {
            return onscreenKeyboard.getAppTypeDoc();
        } else if (appType.equals(ALT_POINTING)) {
            return altPointing.getAppTypeDoc();
        } else if (appType.equals(TEXT_READING_HIGHLITE)) {
            return textHighlight.getAppTypeDoc();
        } else if (appType.equals(KEYBOARD_ENHANCED)) {
            return keyboardEnhanced.getAppTypeDoc();
        } else if (appType.equals(MOUSE_EMULATION)) {
            return mouseEmulation.getAppTypeDoc();
        } else if (appType.equals(BRAILLE)) {
            return braille.getAppTypeDoc();
        } else if (appType.equals(VISUAL_ALERT)) {
            return visualAlert.getAppTypeDoc();
        } else if (appType.equals(VOICE_REC)) {
            return voiceRec.getAppTypeDoc();
        } else if (appType.equals(ALT_KEYBOARD)) {
            return altKeyboard.getAppTypeDoc();
        } else if (appType.equals(CODED_INPUT)) {
            return codedInput.getAppTypeDoc();
        } else if (appType.equals(PREDICTION)) {
            return prediction.getAppTypeDoc();
        }

        return null;
    }

    /**
     * Gets a Locale from an xml:lang formed string.
     *
     * @param  locale  the string representation of the locale
     * @return         the locale
     */
    public static Locale getLocaleFromString(String locale) {
        String language, country;

        int index = locale.indexOf("-");
        if (index != -1) {
            language = locale.substring(0, locale.indexOf("-"));
            country = locale.substring(locale.indexOf("-") + 1, locale.length());
        } else {
            // Assume it's a two letter language representation.
            language = locale;
            country = Locale.getDefault().getCountry();
        }

        return new Locale(language, country);
    }

    /**
     * Gets the Web-4-All context element.
     *
     * @param  doc  the document to search over
     * @return  a context
     */
    public Element getW4AContext(Document doc) {

        Element context = null;

        try {
            String query = "//context[@" + xmlLabels.getString(CONTEXT_ID) + "='" + 
                w4a.getGlobalProperty(ControlHub.CONTEXT_ID_VAL) + "']";
            context = (Element) XPathAPI.selectSingleNode(doc, query);
        } catch (TransformerException te) {
            te.printStackTrace();
        }

        return context;
    }

    
    /**
     * MyWindowAdaptor calls up a cancel dialog to make 
     * sure the user is certain he/she wishes to exit.
     */
    class MyWindowAdapter extends WindowAdapter {
        public void windowClosing(WindowEvent e) {
            cancel();
        }
    } 

    /**
     * Removes all child elements for a given element.
     *
     * @param  element  the element
     */
    protected static void removeAllChildren(Element element) {
        Element temp;
        Element child = DOMUtil.getFirstChildElement(element);
        while (child != null) {
            temp = DOMUtil.getNextSiblingElement(child);
            element.removeChild(child);
            child = temp;
        }
    }

    /**
     * Pops up a message dialog warning the user that a value is out of range.
     *
     * @param  low  the low value in the accepted range
     * @param  high  the high value in the accepted range
     * @param  field  the UI field in which the violation has occured
     */ 
    protected void doRangeWarning(String low, String high, String field) {
        String quotedField = "\"" + field + "\"";
        StringBuffer warning = new StringBuffer();
        warning.append(titles.getString("warning1"));
        warning.append(" " + low + " ");
        warning.append(titles.getString("warning2"));
        warning.append(" " + high + " ");
        warning.append(titles.getString("warning3"));
        warning.append(" " + quotedField + " ");
        warning.append(titles.getString("warning4"));
        JOptionPane.showMessageDialog(this, warning.toString(),
                                      titles.getString("warning.title"),
                                      JOptionPane.ERROR_MESSAGE);
    }

}
