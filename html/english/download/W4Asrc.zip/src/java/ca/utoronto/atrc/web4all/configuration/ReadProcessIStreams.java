/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:			ReadProcessIStreams.java
 *
 * Synoposis:		package ca.utoronto.atrc.web4all.configuration;
 * 
]*/

package ca.utoronto.atrc.web4all.configuration;

import java.io.*;

/**
 * Read the "stdout" and "stderr" streams of a Process object to insure that they
 * are cleared as they fill up.
 *
 * @version $Id: ReadProcessIStreams.java,v 1.4 2006/03/28 21:17:27 clown Exp $
 * @author	Joseph Scheuhammer.
 *
 */
	
public class ReadProcessIStreams
{
    /**
     * Read the given Process instance's "stdout" and "stderr" streams until they are
     * empty, and throw away their contents.
     * @param		inProcess	The Process instance whose streams are to be read.
     * @see #readStreams(Process,boolean)
     */
	public void readStreams (Process inProcess)
	{
		readStreams (inProcess, false);
	
	}	// end readStreams().

    /**
     * Read the given Process instance's "stdout" and "stderr" streams until they are
     * empty.  Optionally, discard the stream contents, or record it to a log.
     * @param		inProcess	The Process instance whose streams are to be read.
     * @param		logFlag		If <code>true</code> log the streams as they are read into
     *							the ConfigManager's log file.  Otherwise, the contents of
     *							the streams are lost.
     * @see #readStreams(Process)
     */
	public void readStreams (Process inProcess, boolean logFlag)
	{
		// Don't do anyting if <inProcess> is null.
		//
		if (inProcess != null)
		{
			// First, handle "stdout".
			//
			BufferedReader bufRead = new BufferedReader (new InputStreamReader (inProcess.getInputStream()));
			doRead (bufRead, logFlag);
			
			// Second, handle "stderr".
			//
			bufRead = new BufferedReader (new InputStreamReader (inProcess.getErrorStream()));
			doRead (bufRead, logFlag);
		}
	
	}	// end readStreams()

    /**
     * Implementation of the actual stream reading and logging (if any).
     * @param		inBufReader	The BufferedReader being read.
     * @param		logFlag		If <code>true</code>, log the streams as they are read into
     *							the ConfigManager's log file.  Otherwise, the contents of
     *							<code>inBufReader</code> are discarded.
     */
	private void doRead (BufferedReader inBufReader, boolean logFlag)
	{
		String aLine = null;
		try
		{
			while ((aLine = inBufReader.readLine()) != null)
			{
				if (logFlag)
					ConfigManager.logDebugStatement (aLine);
			}
		}
		
		// If this happens, assume that the stream is empty.
		//
		catch (IOException ioe)
		{
			if (logFlag && (aLine != null))
			{
				ConfigManager.logDebugStatement (aLine);
				ConfigManager.logException (ioe);
			}
		}
	
	}	// end doRead().
	
}	// end class ReadProcessIStreams.

