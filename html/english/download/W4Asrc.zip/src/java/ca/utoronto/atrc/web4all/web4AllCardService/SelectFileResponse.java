/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 */   
package ca.utoronto.atrc.web4all.web4AllCardService;

import java.util.*;
import opencard.core.*;
import opencard.core.service.*;
import opencard.core.event.*;
import opencard.core.terminal.*;
import opencard.core.terminal.CardTerminalRegistry;
import opencard.core.util.*;
import opencard.opt.util.*;
import opencard.opt.iso.fs.*;

/**
  * A helper class for Web4AllCardService. The process of accessing the Web4All preferences
  * file entails a number of validity checks and operations. His class encapsulates
  * the results of these checks and operations.
*/   
public class SelectFileResponse {
    private static final int validFileSize = 2048;
	private int fileSize = 0;  // size of the file - how to get is card specific.
	private ResponseAPDU ra;   // result of the APDU which retrieved the file.
	private int status;        // status bytes
	private int length;        // size of the ResponseAPDU
	private boolean valid = false;   // Is the file a valid Web4All preferences file?
	private boolean found = false;   // Did we find a preferences file?
	
	
	SelectFileResponse() {
		super();
	}
	
	SelectFileResponse(ResponseAPDU r) {
		ra = r;
		status = ra.sw();
		length = ra.getLength();
	}
    
    public boolean wasFound() {
        return found;
    }
	
    public void setFound() {
        found = true;
    }
    
	public int getFileSize() {
		return fileSize;
	}
	
	public int getLength() {
		return length;
	}
	
	public ResponseAPDU getResponse() {
		return ra;
	}
	
	public int sw() {
		return status;
	}
	
	public boolean isValid() {
		return found && (fileSize == validFileSize);
	}
	
	public void setFileSize(int s) {
		fileSize = s; 
	}
	
	public void setResponse(ResponseAPDU r) {
		ra = r;
		length = ra.getLength();
		status = ra.sw();
	}
}
