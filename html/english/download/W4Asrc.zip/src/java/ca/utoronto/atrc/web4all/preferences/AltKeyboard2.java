/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.net.URL;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;

/**
 * Class to represent the second panel in the alternative keyboard settings.
 */
public class AltKeyboard2 extends KeyboardEnhanced2 {

	/**
	 * The next panel.
	 */
	protected PWMEditPanel nextDialog;

	/**
	 * Sole constructor. Initializes the panel.
	 *
	 * @param  pm  the PreferenceManager
	 * @param  inAltKeyboard  the first edit panel
	 * @param  inAppType  the panel's application type
	 * @param  inTitleKey  the panel's title key
	 */
	public AltKeyboard2(PreferenceManager pm, AltKeyboard inAltKeyboard, String inAppType, String inTitleKey) {
		super(pm, inAltKeyboard, inAppType, inTitleKey);
		
		previousDialog = inAltKeyboard;

		nextDialog = new AltKeyboard3(pm, this, inAppType, inTitleKey);
	}

	/**
	 * Adds the XML elements for this edit panel to the document.
	 *
	 * @param  document  the XML document added to
	 */
	protected void addElementsTo(Document document) {

		super.addElementsTo(document);

		((AltKeyboard3) nextDialog).addElementsTo(document);

	}

	/**
	 * Gets the last panel for this application type.
	 */
	protected PWMEditPanel getLastPanel() {
		return nextDialog;
	}
	
	/**
	 * Sets the UI values for this panel according to the XML elements passed in.
	 *
	 * @param  generic  the generic element for this application type
	 */
	protected void setDomValues(Element generic) {
		super.setDomValues(generic);

		((AltKeyboard3) nextDialog).setDomValues(generic);
	}

	/**
	 * Sets the new labels for this application panel.
	 */
	protected void setNewLabels() {
		super.setNewLabels();

		((AltKeyboard3) nextDialog).setNewLabels();
	}

	/**
	 * Shows the next panel.
	 */
	protected void doNext() {
		pm.showPanel(nextDialog);
	}

}
