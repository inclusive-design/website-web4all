/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            TextEntrySpeaker.java
 *
 * Synopsis:        package ca.utorontl.atrc.web4all.prefschooser;
 * 
]*/

package ca.utoronto.atrc.web4all.prefschooser;

import java.awt.Toolkit;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;
import javax.accessibility.*;

/**
 * A document event listener that speaks the changes in a text entry field.
 *
 * @version $Id: TextEntrySpeaker.java,v 1.5 2006/03/28 21:17:27 clown Exp $
 * @author  Joseph Scheuhammer.
 *
 */
public class TextEntrySpeaker extends Speaker
    implements DocumentListener, CaretListener
{
    /**
     * Key for the "deleting" speech.
     */
    public final static String DELETING_CHAR    =   "deleting.char";
    
    /** 
     * The text entry field to self-voice.
     */
    private JTextComponent theEntryField;
    
    /**
     * Zero argument constructor that initializes the speaker super class only.
     */
    public TextEntrySpeaker()
    {
        super();
        theEntryField = null;
    
    }   // end TextEntrySpeaker()

    /**
     * Constructor that records the JTextComponenet it is speaking.
     * @param   inTextEntryField    The JTextComponent <code>this</code> is
     *                              self-voicing.
     * @see #setEntryField(JTextComponent)
     */
    public TextEntrySpeaker (JTextComponent inEntryField)
    {
        this();
        setEntryField (inEntryField);
    
    }   // end TextEntrySpeaker (JTextComponent inTextEntryField)
    
    /**
     * (Re)set the JTextComponenet that <code>this</code> is speaking.  Also,
     * attaches <code>this</code> as a DocumentListener that the given
     * JTextComponent's document.
     * @param   inTextEntryField    The JTextComponent to self-voice.
     * @see #unsetEntryField()
     */
    void setEntryField (JTextComponent inTextEntryField)
    {
        // Detach <this> from any existing even source.
        //
        unsetEntryField();
        
        // Record <inTextEntryField> and setup to listen to its events.
        //
        theEntryField = inTextEntryField;
        theEntryField.getDocument().addDocumentListener (this);
        theEntryField.addCaretListener (this);
        
    }   // end setEntryField()

    /**
     * Forget the JTextComponent that is currently recorded as the text entry
     * field, and remove <code>this</code> as an event listener on it.
     * @see #setEntryField()
     */
    void unsetEntryField()
    {
        if (theEntryField != null)
        {
            theEntryField.getDocument().removeDocumentListener (this);
            theEntryField.removeCaretListener (this);
        }
        theEntryField = null;
    
    }   // end unsetEntryField()
    
    /**
     * Have the current JTextComponent that this is speaking request focus.
     */
    void requestFocus()
    {
        if (theEntryField != null)
        {
            theEntryField.requestFocus();
            theEntryField.selectAll();
        }
    
    }   // end requestFocus().
    
    /**
     * Speak the contents of the text entry field, if there is one.  The label
     * of the text field, if any, is always prepended.  The caller can
     * optionally provide a prefix speech to prepend to the label + contents.
     * @param   inPrefix    Prepend the given string to the speech.
     */
    public void speakContents (String inPrefix)
    {
        StringBuffer speech = new StringBuffer();
        
        // Add the prefix.
        //
        if (inPrefix != null)
        {
            speech.append (inPrefix);
            speech.append (" ");    // space.
        }
            
        // Get <theEntryField>'s label and contents, if any.
        //
        String contents = null;
        if (theEntryField != null)
        {
            AccessibleContext ac = theEntryField.getAccessibleContext();
            String label = ac.getAccessibleName();
            if (label != null)
            {
                speech.append (label);
                speech.append (" ");    // space.
            }
            contents = theEntryField.getText();
            speech.append (contents);
        }
        
        // Finally, put it all together.  If the <speech> is empty, just
        // beep to give some kind of feedback.
        //
        contents = speech.toString();
        if (contents.length() == 0)
            Toolkit.getDefaultToolkit().beep();
        else
            speak (contents);
                
    }   // end speakContents().
    
    /**
     * Allow client to move the caret to the end of the document.
     */
    public void moveCaretToEnd()
    {
        if (theEntryField != null)
        {
            String all = theEntryField.getText();
            theEntryField.getCaret().setDot (all.length());
        }
    
    }   // end moveCaretToEnd()
    
    /**
     * Utility for clients to check to see if there is any text to speak.
     */
    public boolean isEmpty()
    {
        boolean empty = true;
        try
        {
            if (theEntryField != null)
            {
                if (theEntryField.getText().length() > 0)
                    empty = false;
            }
        }
        catch (NullPointerException npe)
        { 
            empty = true;
        }
        return empty;
    
    }   // end isEmpty().

//============================
// interface DocumentListener.
//============================

    /**
     * Handle character insertion events.
     * @param   inDocEvent  The DocumentEvent that called us.
     */
    public void insertUpdate (DocumentEvent inDocEvent)
    {
/*
        try
        {
            Document doc = inDocEvent.getDocument();
            int length = inDocEvent.getLength();
            int offset = inDocEvent.getOffset();
            speak (doc.getText (offset, length));
        }
        catch (BadLocationException be)     // possible???
        { ; }
*/    
    }   // end insertUpdate().

    /**
     * Handle character delete events.
     * @param   inDocEvent  The DocumentEvent that called us.
     */
    public void removeUpdate (DocumentEvent inDocEvent)
    {
/*
        try
        {
            // Get the document.  If it's empty, just beep.
            //
            Document doc = inDocEvent.getDocument();
            if (doc.getLength() == 0)
                Toolkit.getDefaultToolkit().beep();
            
            else
            {
                int length = inDocEvent.getLength();
                int offset = inDocEvent.getOffset();
                
                // Reset <offset> to get the just previous character, unless
                // it's already zero.
                //
                if (offset != 0)
                    offset--;
                speak (doc.getText (offset, length));
            }
        }
        catch (BadLocationException be)     // possible???
        { ; }
*/    
    }   // end removeUpdate().
    
    /**
     * Handle document changes (no-op).
     * @param   inDocEvent  The DocumentEvent that called us.
     */
    public void changedUpdate (DocumentEvent inDocEvent)
    {
        ;
        
    }   // end removeUpdate().

//=========================
// interface CaretListener.
//=========================

    /**
     * Speak the character just to left of the caret, as it moves.  If at the
     * beginning or end of the text, beep as well.
     * @param   inEvent     The CaretEvent that invoked us.
     */
    public void caretUpdate (CaretEvent inEvent)
    {
        try
        {
            // Get the character just to the left of the caret, and speak it, unless
            // at the beginning (dotPos is zero).
            //
            int dotPos = inEvent.getDot();
            if (dotPos != 0)
                speak (theEntryField.getText (dotPos-1, 1));
            
            // If at beginning or ending, beep.
            //
            String all = theEntryField.getText();
            if (dotPos == 0)
                Toolkit.getDefaultToolkit().beep();
        }
        
        // From theEntryField.getText (offset, length).
        //
        catch (BadLocationException be)     // possible???
        { ; }
        
        // From theEntryField.getText()
        //
        catch (NullPointerException npe)    // possible??>
        { ; }
    
    }   // caretUpdate().
    
}   // end class TextEntrySpeaker.

