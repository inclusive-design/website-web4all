/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:        AbstractSetterLauncher.java
 *
 * Synoposis:   package ca.utoronto.atrc.web4all;
 * 
]*/

package ca.utoronto.atrc.web4all.configuration;

import java.util.*;
import java.io.*;

import org.w3c.dom.*;
import org.apache.xerces.util.DOMUtil;

import ca.utoronto.atrc.web4all.*;

/**
 * Class that provides the base structure of a SetterLauncher without actually implementing
 * the methods of the interface.  It also provides a number of utility methods that a specific
 * SetterLauncher might want to use.
 *
 * @version $Id: AbstractSetterLauncher.java,v 1.11 2006/03/28 21:17:27 clown Exp $
 * @author Joseph Scheuhammer
 */
    
public abstract class AbstractSetterLauncher implements SetterLauncher
{
    /**
     * Array of SettingsBundle's ultimately handled by this SetterLauncher.  Each member of
     * the Vector is individuated by the type of technology that SettingsBundle is for.  The type
     * of technology is taken from the ACCLIP (e.g, "screenReader").
     */
    private SettingsBundle theParamsHandled[];
    
    /**
     * OLD CODE, JUST FOR COMPILING.  ULTIMATELY DELETE.
     */
    private Vector thePrefsState;

    /**
     * For mapping the parameter values in the preferences schema to those needed by the adaptive
     * technology.  This is a "map of maps":  given a parameter, this chooses a value map
     * that is used to map between the preferences value and the correct output value. 
     */
    private ResourceBundle theValueMapChooser;

    /**
     * The file to write the settings to (PrintWriter), if any.
     * @see #createOutput, #writeSettings.
     */
    private PrintWriter theOutput;

    /**
     * The array of positional parameters for the command line executable that sets up the
     * technology.
     * @see #setArgs, #getArgs, #addArgToArray
     */
    private String theArgsArray[];
   
   /**
    * The argument index map:  this maps third party preference names to their position in the
    * argument array.
    * @see #setArgIndex, #getArgIndex
    */
   private ResourceBundle theArgIndexMap;

    /**
     * This represents the settings as retrieved from the preferences -- the subtree of the DOM that
     * deals with settings for a particular application type.  The children of this Element are (1) the
     * default settings for that application type, and (2) the 3rd party applications settings.  One of the
     * latter will be used to actually configure the system.  
     */
    private Element theAppSettings;

    /**
     * This is the Control Hub that contains information needed by the particular instance of the
     * SetterLauncher.  
     */
    private ControlHub theControlHub;

    /**
     * The application ID for this configurator.
     */
    private String theAppID;

    /**
     * Local properties held in trust by <code>theControlHub</code>.
     */
    private ResourceBundle theLocalProps;

    /**
     * The process object created by calling <code>doLaunch()</code>.
     */
    private Process theProcess;

    /**
     * The object for reading/emptying the InputStreams associated with <code>theProcess</code>.
     */
    private ReadProcessIStreams theReadProcessIStreams;
    
    /**
     * Initialize the SetterLauncher with all of its internal data initially set to "null", and
     * then perform the initialization proper via a call to <code>init()</code>.
     * @see #init()
     */
    public AbstractSetterLauncher()
    {
        super();
        theParamsHandled = null;
        thePrefsState = null;
        theValueMapChooser = null;
        theOutput = null;
        theArgsArray = null;
        theArgIndexMap = null;
        theAppSettings = null;
        theAppID = null;
        theProcess = null;
        theReadProcessIStreams = null;
        theLocalProps = null;
        
        // Do class specific initialization.
        //
        init();

    }  // end AbstractSetterLauncher().

    /**
     * Class specific initialization -- must be overridden.
     * @see #setUpParameters(SettingsBundle[],ResourceBundle)
     * @see #createOutput(String,String).
     * @see #createOutput(String,String,boolean).
     * @see #createOutput(String).
     * @see #createArgsArray(int)
     * @see #setArgsArray(String[])
     * @see #getArgsArray()
     * @see #setArgsIndexMap(ResourceBundle)
     * @see #getArgsIndexMap()
     */
    protected abstract void init();

    /**
     * Initialize the technology specific parameters of interest and the value map chooser.
     * This should be called only once during initialization.
     * @param   inParams            An array of SettingsBundle for the technology specific settings 
     *                              handled by this SetterLauncher.  There is one bundle for each
     *                              type of technology.
     * @param   inValueMapChooser   A ResourceBundle that, given a parameter name, chooses a value
     *                              map that associates an ACCLIP preference value with a
     *                              technology parameter value.
     * @see #init()
     * @see #clearParamsWritten(String)
     */
    protected void setUpParameters (SettingsBundle[] inParams, ResourceBundle inValueMapChooser)
    {
        // Initialize <theParamsHandled> and <theValueMapChooser>.
        //
        theParamsHandled = inParams;
        theValueMapChooser = inValueMapChooser;

    }   // end setUpParameters().

    /**
     * Utility for setting parameters' written state array to false.  The relevant parameters are
     * determined by the given technology type, and only their written state is cleared.
     * The given type of technology is expressed in the vocabulary of the ACCLIP.
     * @param   inTechType      The type of technology whose parameters written state
     *                          are to be cleared.
     * @see #setUpParameters(SettingsBundle[],ResourceBundle)
     */
    protected void clearParamsWritten (String inTechType)
    {
        // Loop thru <theParamsHandled> looking for the preferences that <this> handles
        // in the context of <inTechType>.
        //
        if (theParamsHandled != null)
        {
            for (int i = 0; i < theParamsHandled.length; i++)
            {
                SettingsBundle aBundle = theParamsHandled[i];
                if (aBundle.getTechType().equals (inTechType))
                {
                    aBundle.clearWrittenState();
                    break;
                }
            }
        }

    }  // end clearParamsWritten().

    /**
     * Create the output file, given a relative path to a directory, and a file name.  The directory
     * referenced by th path is assumed to be a sub-directory of Web-4-All's home directory.
     * @param       inHomeDir   Path to the directory relative to Web-4-All's home directory.
     * @param       inFileName  The name of the file to create.
     * @return                  A FileWriter, or <code>null</code> if an I/O error occurred.
     * @see #init()
     * @see ca.utoronto.atrc.web4all.ControlHub#getHomeDirectory()
     * @see #createOutput(String,String,boolean)
     * @see #createOutput(String)
     */
    protected PrintWriter createOutput (String inHomeDir, String inFileName)
    {
        return createOutput (inHomeDir, inFileName, true);
    
    }   // end createOutput (String inHomeDir, String inFileName).

    /**
     * Create the output file, given a relative or absolute path to a directory, a file name, and whether the
     * directory is a sub-directory.  If the first argument is an absolute path, then the flag should
     * be <code>false</code>.  If it is <code>true</code> the path is assumed to be relative, and
     * relative to Web-4-All's home directory.
     * @param       inHomeDir   Path to a directory relative to Web-4-All's home directory, "or",
     *                          the full path to the directory containing the file
     *                          (see argument <code>useSubDir</code> below).
     * @param       inFileName  The name of the file.
     * @param       useSubDir   A flag that indicates whether <code>inHomeDir</code> is a sub-folder
     *                          or a full path to some other directory.
     * @return                  A FileWriter, or <code>null</code> if there was an I/O error.
     * @see #init()
     * @see ControlHub#getHomeDirectory()
     * @see #createOutput(String,String)
     * @see #createOutput(String)
     */
    protected PrintWriter createOutput (String inHomeDir, String inFileName, boolean useSubDir)
    {
        // Create a full path to the file in question, as a String.
        //
        String dirSep = System.getProperty ("file.separator");
        String fullPath = null;

        // Get <theControlHub> directory and create the file in that folder.
        //
        if (useSubDir && (theControlHub != null))
            fullPath = theControlHub.getHomeDirectory() + dirSep + inHomeDir + dirSep + inFileName;
        
        // Assume that <inHomeDir> is a full path, and create the file in that folder.
        //
        else
            fullPath = inHomeDir + dirSep + inFileName;
        
        // Let the general case method do the rest.
        //
        return createOutput (fullPath); 

    }  // end createOutput (String inHomeDir, String inFileName, boolean useSubDir).

    /**
     * Create the output file from a full path to the file.
     * @param       inFullPath  A String that is the full path to the file.
     * @return      A FileWriter, or <code>null</code> if there was an I/O error.
     * @see #init()
     * @see #createOutput(String,String)
     * @see #createOutput(String,String,boolean)
     */
    protected PrintWriter createOutput (String inFullPath)
    {
    	return createOutput (inFullPath, false);
    	
	}  // end createOutput (String inFullPath).
	
    /**
     * Create the output file from a full path to the file.
     * @param       inFullPath  A String that is the full path to the file.
     * @param		inAppend	A boolean indicating whether or not to append the output.
     * @return      A FileWriter, or <code>null</code> if there was an I/O error.
     * @see #init()
     * @see #createOutput(String,String)
     * @see #createOutput(String,String,boolean)
     */
    protected PrintWriter createOutput (String inFullPath, boolean inAppend)
    {
        PrintWriter printWriter = null;

        // Clean up any old output.
        //
        closeOutput();

        // Create the file, and its PrintWriter.
        //
        try
        {
            File aFile = new File (inFullPath);
            if (aFile != null)
                printWriter = new PrintWriter (new FileWriter (aFile, inAppend));
        }

        catch (IOException ioe)
        {
            ConfigManager.logException(ioe);
            printWriter = null;
        }

        // Assign the (new) output file.
        //
        theOutput = printWriter;
        return theOutput;

    }  // end createOutput (String inFullPath, boolean inAppend).

    /**
     * Flush and close the current output file.  The connection to the output file is lost.
     * @see #createOutput(String,String)
     * @see #createOutput(String,String,boolean)
     * @see #createOutput(String)
     */
    protected void closeOutput()
    {
        if (theOutput != null)
        {
            theOutput.flush();
            theOutput.close();
            theOutput = null;
        }

    }  // end closeOutput().

    /**
     * Create an empty String array to hold a set of command line arguments.  Also, the
     * array is retained internally as if set by <code>setArgsArray()</code>.
     * @param   inNumArgs   The number of arguments in the array.
     * @return              A String array.
     * @see #setArgsArray(String[])
     * @see #getArgsArray()
     * @see #setArgsIndexMap(ResourceBundle)
     * @see #getArgsIndexMap()
     */
    protected String[] createArgsArray (int inNumArgs)
    {
        theArgsArray = new String[inNumArgs];
        return theArgsArray;
    
    }   // end createArgsArray().

    /**
     * Use the given String array for the command line arguments.
     * @param   ioArgsArray       Array to use for the arguments.
     * @see #createArgsArray(int)
     * @see #getArgsArray()
     * @see #setArgsIndexMap(ResourceBundle)
     * @see #getArgsIndexMap()
     */
    protected void setArgsArray (String[] ioArgsArray)
    {
        theArgsArray = ioArgsArray;
    
    }   // end setArgsArray().

    /**
     * Retrieve the array of strings that represent a set of command line arguments.
     * @return      The array of command line arguments.
     * @see #createArgsArray(int)
     * @see #setArgsArray(String[])
     * @see #setArgsIndexMap(ResourceBundle)
     * @see #getArgsIndexMap()
     */
    protected String[] getArgsArray()
    {
        return theArgsArray;
    
    }   // end getArgsArray().

    /**
     * Set the argument index map for a command line argument array.  This is needed when the
     * meaning of each command line argument is determined by its position within the command line.
     * @param   inArgsIndexMap      Mapping between setting names and their index, or position,
     *                              in a command line.
     * @see #getArgsIndexMap()
     * @see #createArgsArray(int)
     * @see #setArgsArray(String[])
     * @see #getArgsArray()
     */
    protected void setArgsIndexMap (ResourceBundle inArgsIndexMap)
    {
        theArgIndexMap = inArgsIndexMap;
    
    }   // end setArgsIndexMap()
    
    /**
     * Retrieve the argument index map for a command line argument string.  This is needed when the
     * meaning of each command line argument is determined by its position within the command line.
     * @return      The ResourceBundle that define the mapping between parameter names and their
     *              index, or position, in the command line.
     * @see #setArgsIndexMap(ResourceBundle)
     * @see #createArgsArray(int)
     * @see #setArgsArray(String[])
     * @see #getArgsArray()
     */
    protected ResourceBundle getArgsIndexMap()
    {
        return theArgIndexMap;
    
    }   // end getArgsIndexMap()
    
    /**
     * Set the root of the ACCLIP document for the current technology that the SetterLauncher
     * is processing.  This root contains both the generic and application specific preferences
     * for one type of technology (e.g., the "screenReader" root).  The root element can change
     * as the SetterLauncher processes preferences for different types of technology.
     * @param   inAppSettings   The subtree of the settings that contain the generic and
     *                          application specific preferences.
     * @see #getAppSettings()
     */
    public void setAppSettings (Element inAppSettings)
    {
        theAppSettings = inAppSettings;
    
    }   // end setAppSettings().
    
    /**
     * Retrieve the root of the ACCLIP DOM for the current technology that this SetterLauncher
     * is processing.  This root contains both the generic and application specific preferences
     * for one type of technology (e.g., the "screenReader" root).  The root element can change
     * as the SetterLauncher processes preferences for different types of technology.
     * @return      The subtree of the preferences document as an org.w3c.dom.Element.
     * @see #setAppSettings(Element)
     */
    public Element getAppSettings()
    {
        return theAppSettings;
    
    }   // end getAppSettings().        
    
    /**
     * Set the Control Hub property.  The Control Hub is used to retrieve properties of the
     * plug-in.
     * @param   inControlHub    The ControlHub instance that is controlling the system.
     * @see #getControlHub()
     */
    public void setControlHub (ControlHub inControlHub)
    {
        theControlHub = inControlHub;
    
    }   // end setControlHub().
    
    /**
     * Get the Control Hub property.  The Control Hub is used to retrieve properties of the
     * plug-in.
     * @return      The ControlHub instance that is controlling the system.  Note that this can be
     *              <code>null</code> if <code>setControlHub()</code> was not called.
     * @see #setControlHub(ControlHub)
     */
    public ControlHub getControlHub()
    {
        return theControlHub;
    
    }   // end getControlHub().     
    
    /**
     * Set the application ID for the SetterLauncher.  Typicially, this is acquired from the ACCLIP
     * specific settings container element.
     * @param   inAppID     The application ID.
     * @see #setAppID(Element)
     * @see #getAppID()
     */
    public void setAppID (String inAppID)
    {
        theAppID = inAppID;
    
    }   // end setAppID (String inAppID).
    
    /**
     * Retrieve the application ID for the SetterLauncher.
     * @return      The application ID as a String.  Note that this can be <code>null</code> if
     *              the property was not set by <code>setAppID()</code>.
     * @see #setAppID(String)
     * @see #setAppID(Element)
     */
    public String getAppID()
    {
        return theAppID;
    
    }   // end getAppID().      
    
    /**
     * Set the application ID for this SetterLauncher based on an application preferences element
     * from the ACCLIP.
     * @param   in3rdPartyPrefs     An application preferences Element; its name attribute is used
     *                              to set the application ID.
     * @see #setAppID(String)
     * @see #getAppID()
     */
    protected void setAppID (Element in3rdPartyPrefs)
    {
        // Get the app id attribute out of <in3rdPartyPrefs>.
        //
        if (in3rdPartyPrefs != null)
        {
            String attrName = theControlHub.getPrefElementName (Web4AllConstants.APP_NAME);
            setAppID (in3rdPartyPrefs.getAttribute (attrName));
        }
    
    }   // end setAppID (Element in3rdPartyPrefs).
    
    /**
     * Set the process launched by this SetterLauncher.  Typically, the process is created as a
     * result of <code>doLaunch()</code>.
     * @param   inProcess   The Process.
     * @see #doLaunch()
     * @see #getProcess()
     */
    protected void setProcess (Process inProcess)
    {
        theProcess = inProcess;
    
    }   // end setProcess();
    
    /**
     * Retrieve the process launched by this SetterLauncher.  Typically, the process is created as a
     * result of <code>doLaunch()</code>.
     * @return      The Process.
     * @see #doLaunch()
     * @see #setProcess(Process).
     */
    protected Process getProcess()
    {
        return theProcess;
    
    }   // end getProcess();
    
    /**
     * Loop through the generic preferences from the ACCLIP for the given type of technology.  As the
     * preference elements are encountered, handle them via a call to <code>handlePref()</code>.
     * Sub-classes that wish to handle the generics differently should either not call this method,
     * override it to do something else, or override <code>handlePref()</code> to handle them
     * differently.
     * @param   inTechType              The type of technology the given generic preferences are for
     *                                  expressed in the ACCLIP's vocabulary (e.g. "screenReader").
     * @param   inGenericContainer      The parent generic Element, (e.g. "screenReaderGeneric").
     * @see #handlePref(String,Element,boolean)
     */
    protected void loopThruGenerics (String inTechType, Element inGenericContainer)
    {
        if ((inGenericContainer != null) && (theControlHub != null))
        {
            // Get the immediate children of <inGenericContainer>, go through them, matching
            // against <theParamsHandled>.  If that setting is declared in the children,
            // write it out.
            //
            Element aChild = DOMUtil.getFirstChildElement (inGenericContainer);
            while (aChild != null)
            {
                String childName = aChild.getNodeName();
                ConfigManager.logDebugStatement ("For '" + inTechType + "' *generic* pref '" + childName + "'");
                handlePref (inTechType, aChild, true);
                ConfigManager.logDebugStatement ("");   // new line.
                aChild = DOMUtil.getNextSiblingElement (aChild);
            }
        }
    
    }   // end  loopThruGenerics().

    /**
     * Loop thru the specific preferences for the given type of technology.  As each is
     * encountered, it calls <code>handlePref()</code>, passing the child element, and indicating
     * it is not a generic preference.
     * @param   inTechType              The type of technology the application specific preferences
     *                                  are for, as taken from the ACCLIP (e.g. "screenReader").
     * @param   in3rdPartyPrefs         The &lt;application&gt; container element for specific 
     *                                  preferences.
     * @see #handlePref(String,Element,boolean)
     */
    protected void loopThru3rdPartyPrefs (String inTechType, Element in3rdPartyPrefs)
    {
        if (in3rdPartyPrefs != null)
        {
            // Get the immediate children of <inDefaults>, go through them, matching
            // against <theParamsHandled>.  If that setting is declared in the children,
            // write it out.
            //
            Element aChild = DOMUtil.getFirstChildElement (in3rdPartyPrefs);
            while (aChild != null)
            {
                String childName = aChild.getNodeName();
                ConfigManager.logDebugStatement ("For '" + inTechType + "' *3rd party* pref '" + childName + "'");
                handlePref (inTechType, aChild, false);
                ConfigManager.logDebugStatement ("");   // new line.
                aChild = DOMUtil.getNextSiblingElement (aChild);
            }
        }
        
    }   // end  loopThru3rdPartyPrefs().

    /**
     * Given a technology type and a preference for that type, determine if it is one that
     * this SetterLauncher handles.  If so, write out its technology specific value.  This simply
     * calls the other version of <code>handlePref()</code>  with <code>false</code>
     * (this preference is not a generic preference).
     * @param   inTechType      The type of technology this preference is for, as taken from the
     *                          ACCLIP (e.g. "screenReader").
     * @param   inPref          The preference Element from the preferences that represents a
     *                          single setting.
     * @see #handlePref(String,Element,boolean)
     */
    protected void handlePref (String inTechType, Element inPref)
    {
        handlePref (inTechType, inPref, false);

    }  // end handleValue (String inTechType, Element inPref).

    /**
     * Given a technology type and a preference for that type, determine if it is one that
     * this SetterLauncher handles.  If so, write out its technology specific value via a
     * call to <code>doWriteSetting()</code>.  This also sets the parameter's written state
     * to <code>true</code>.
     * <P>
     * This method is useful for the simple case of a straight match between the ACCLIP preference
     * and the technology's parameter value (i.e. no hierarchical nesting of preferences, nor
     * exclusive-or with respect to a containing Element).
     * @param   inTechType      The type of technology these generic preferences are for, as
     *                          taken from the ACCLIP (e.g. "screenReader").
     * @param   inPref          The pref Element from the preferences that represents a
     *                          single setting.
     * @param   isGeneric       Did the preference come from the generic container in 
     *                          the ACCLIP?  This is passed to <code>findParameter()</code>.
     * @see #handlePref(String,Element)
     * @see #findParameter(String,String,boolean)
     * @see #doWriteSetting(String,String)
     */
    protected void handlePref (String inTechType, Element inPref, boolean isGeneric)
    {
        // Get the attributes, and look to see if it is one we handle.
        //
        String prefName = inPref.getTagName();
        ConfigManager.logDebugStatement (prefName);

        // Look for <uid> in <inParams>.  If found, write out the setting.
        //
        ParameterState techParamState = findParameter (inTechType, prefName, isGeneric);
        if (techParamState != null)
        {
            String techParanmName = techParamState.getParamName();
            ConfigManager.logDebugStatement (techParanmName);
            String value = getValueValue (inPref);
            String realValue = mapValue (techParanmName, value);
            doWriteSetting (techParanmName, realValue);
            techParamState.setSetState (true);
            ConfigManager.logDebugStatement ("wrote " + techParanmName);
        }
        else
        {
            ConfigManager.logDebugStatement ("'" + inPref + "' not handled");
        }

    }  // end handlePref (Element inPref, boolean isDefault).

    /**
     * Given a type of technology and a preference name from the ACCLIP, determine if it is
     * a parameter this plug-in handles.  If so, return that preference's ParameterState instance.
     * Otherwise, return <code>null</code>.  This method is a convenience for calling the full
     * version of <code>findParameter()</code> -- this passes <code>false</code> to indicate that
     * the preference is not a generic preference.
     * @param   inTechType          The type of technology this preference are for, as taken from
     *                              the ACCLIP (e.g. "screenReader").
     * @param   inAccLipPrefName    String representing the preference found in the ACCLIP.
     * @return                      A ParameterState instance for this preference, or
     *                              <code>null</code> if this technology does not handle this
     *                              preference.
     * @see ParameterState
     * @see #findParameter(String,String,boolean)
     */
    public ParameterState findParameter (String inTechType, String inAccLipPrefName)
    {
        return findParameter (inTechType, inAccLipPrefName, false);

    }  // end findParameter (String inTechType, String inAccLipPrefName).

    /**
     * Given a type of technology and a preference name from the ACCLIP document, determine if it is
     * a parameter this technology handles.  If so, return that preference's ParameterState instance.
     * Otherwise, return <code>null</code>.  Note that this method only handles generic preferences
     * at this level in the derivation hierarchy.  Sub-classes should override to handle specfic
     * preferences.
     * @param   inTechType          The type of technology this preference are for, as taken from
     *                              taken from the ACCLIP (e.g. "screenReader").
     * @param   inAccLipPrefName    String representing the preference found in the ACCLIP.
     * @param   isGeneric           Did the preference come from the generic container in the
     *                              ACCLIP?  This is ignored.
     * @return                      A ParameterState instance for this preference, or
     *                              <code>null</code> if this technology does not handle this
     *                              preference.
     * @see ParameterState
     * @see #findParameter(String,String)
     */
    public ParameterState findParameter (String inTechType, String inAccLipPrefName, boolean isGeneric)
    {
        ParameterState result = null;
        
        // Check that the necessary equipment is available.
        //
        if (theParamsHandled != null)
        {
            // Find the SettingsBundle associated with <inTechType>.
            //
            for (int i = 0; i < theParamsHandled.length; i++)
            {
                SettingsBundle aBundle = (SettingsBundle) theParamsHandled[i];
                if (aBundle.getTechType().equals (inTechType))
                {
                    // Get the ParameterState instance for <inAccLipPrefName>.
                    //
                    try
                    {
                        result = (ParameterState) aBundle.getObject (inAccLipPrefName);
                        break;
                    }
                    catch (MissingResourceException mre)
                    {
                        result = null;
                    }
                }
            }
        }
        return result;

    }  // end findParameter (String inTechType, String inAccLipPrefName, boolean isGeneric).

    /**
     * Given a prefs element, find its <code>Web4AllConstansts.VAL_ATT</code> attribute and return
     * the value of that attribute.
     * @param  inPref       The preference Element whose value attribute is sought.
     * @return              The attribute value as a String, or <code>null</code> if none is found.
     * @see ControlHub#VAL_ATT
     */
    public String getValueValue (Element inPref)
    {
        String retVal = null;

        // Get the children of <inValue> and look for its "value" attribute.
        //
        if (inPref != null)
        {
            String attrName = theControlHub.getPrefElementName (Web4AllConstants.VAL_ATT);
            String value = inPref.getAttribute (attrName);
            ConfigManager.logDebugStatement ("For pref '" + inPref.getTagName() + "', value is '" + value + "'");
            if (value.length() > 0)
                retVal = value;
        }
        return retVal;

    }  // end getValueValue().

    /**
     * Map the value retrieved from the preferences document to the parameter's value.
     * @param  inParam      The parameter of interest.  This is expressed using the technology's
     *                      vocabulary.
     * @param  inValue      The value from the ACCLIP.
     * @return              The value to of the parameter, as a String.
     * @see #linearCalcTechVal(String,float,float)
     */
    protected String mapValue (String inParam, String inValue)
    {
        String result = null;

        // Choose a value map.
        //
        if (theValueMapChooser != null)
        {
            // Choose a value map.
            //
            ResourceBundle valueMap = (ResourceBundle) theValueMapChooser.getObject (inParam);
            if (valueMap != null)
            {
                result = valueMap.getObject (inValue).toString();
                ConfigManager.logDebugStatement ("For (" + inParam + "," + inValue + "), result is '" + result + "'");
            }
        }
        return result;
    
    }   // end mapValue().

    /**
     * Utility to convert a floating point ACCLIP preference value to a parameter value.   This
     * performs a linear transformation.
     * @param   inAccLipVal     Floating point value from the ACCLIP.
     * @param   inSlope         A float that represents the slope of the line.
     * @param   inIntercept     A float that represents the y-intercept of the line.
     * @return                  A float that represents the parameter's value.
     * @see #mapValue(String,String)
     */
    public float linearCalcTechVal (String inAccLipVal, float inSlope, float inIntercept)
    {
        // Convert <inAccLipVal> to a float.
        //
        float accLipVal = Float.parseFloat (inAccLipVal);
        
        // Compute and return VDK value.
        //
        return (accLipVal * inSlope + inIntercept);
    
    }   // end linearCalcTechVal().
            
    /**
     * Write out default values for those preferences that were not in the ACCLIP document. This is
     * done only if:
     * <UL>
     * <LI>there are parameters to write,</LI>
     * <LI>the specific technology requires that those parameters be set,</LI>
     * <LI>they have default values.</LI>
     * </UL>
     * @param   inTechType      The type of technology that this is configuring, expressed using
     *                          the ACCLIP vocabulary.
     */
    protected void handleUnwrittenParams (String inTechType)
    {
        // Do this only if there are preferences that this handles.
        //
        if (theParamsHandled != null)
        {
            for (int i = 0; i < theParamsHandled.length; i++)
            {
                SettingsBundle aBundle = theParamsHandled[i];
                if (aBundle.getTechType().equals (inTechType))
                {
                    // This is the bundle of settings to write.  Do so via an enumeration of
                    // its ParameterState instances.
                    //
                    Enumeration keys = aBundle.getKeys();
                    while (keys.hasMoreElements())
                    {
                        ParameterState aParamState = (ParameterState) aBundle.getObject ((String) keys.nextElement());
                        if ((aParamState.isRequired()) && (aParamState.getSetState() == false))
                            doWriteSetting (aParamState.getParamName(), aParamState.getDefaultValue().toString());
                    }
                    break;
                }
            }
        }
    }  // end handleUnwrittenParams().

    /**
     * Abstract method for "writing" the setting.  This could be writing the setting
     * to a file, or adding it as a command line arugment.  Sub-classes must override to have this
     * do what they require.
     * @param  inParameter  The parameter to "write".
     * @param  inValue      The value of the parameter.
     * @see #writeSetting(String,String)
     * @see #writeSetting(String,int)
     * @see #writeSetting(String,Number)
     * @see #addArgToArray(String,String)
     */
    protected abstract void doWriteSetting (String inParameter, String inValue);

    /**
     * Write the given paramater and its value.  It is assumed that the output is valid; that is,
     * that <code>createOutputFile()</code> was called at some point prior to this method.
     *
     * @param  inParameter  String representing the parameter to write.
     * @param  inValue      String representing the value of <code>inParameter</code>.
     * @see #createOutput(String,String)
     * @see #createOutput(String,String,boolean)
     * @see #createOutput(String)
     * @see #doWriteSetting(String,String)
     * @see #writeSetting(String,int)
     * @see #writeSetting(String,Number)
     */
    protected void writeSetting (String inParameter, String inValue)
    {
        if ((inParameter != null) && (inValue != null))
        {
            theOutput.print (inParameter);
            theOutput.print ("=");
            theOutput.println (inValue);
        }

    }  // writeSetting (String, String).

    /**
     * Write the given paramater and its value.  It is assumed that the output is valid; that is,
     * that <code>createOutputFile()</code> was called at some point prior to this method.
     *
     * @param  inParameter  String representing the parameter to write.
     * @param  inValue      An int representing the value of <code>inParameter</code>.
     * @see #createOutput(String,String)
     * @see #createOutput(String,String,boolean)
     * @see #createOutput(String)
     * @see #doWriteSetting(String,String)
     * @see #writeSetting(String,String)
     * @see #writeSetting(String,Number)
     */
    protected void writeSetting (String inParameter, int inValue)
    {
        if (inParameter != null)
        {
            theOutput.print (inParameter);
            theOutput.print ("=");
            theOutput.println (inValue);
        }

    }  // writeSetting (String, int).

    /**
     * Write the given paramater and its value.  It is assumed that the output is valid; that is,
     * that <code>createOutputFile()</code> was called at some point prior to this method.
     *
     * @param  inParameter  String representing the parameter to write.
     * @param  inValue      Number representing the value of <code>inParameter</code>.
     * @see #createOutput(String,String)
     * @see #createOutput(String,String,boolean)
     * @see #createOutput(String)
     * @see #doWriteSetting(String,String)
     * @see #writeSetting(String,String)
     * @see #writeSetting(String,int)
     */
    protected void writeSetting (String inParameter, Number inValue)
    {
        if ((inParameter != null) && (inValue != null))
        {
            theOutput.print (inParameter);
            theOutput.print ("=");
            theOutput.println (inValue);
        }

    }  // writeSetting (String, int).
    
    /**
     * Add the given parameter's value to the command line argument array.
     * Note that this assumes the argument array and argument index map are valid; that is,
     * that either <code>createArgsArray()</code> or <code>setArgsArray()</code>, and
     * <code>setArgsIndexMap()</code> were used to initialize the command line argument
     * arrays.
     *
     * @param  inParameter  The parameter to write.
     * @param  inValue      The value of <code>inParameter</code>.
     * @see #createArgsArray(int)
     * @see #setArgsArray(String[])
     * @see #setArgsIndexMap(ResourceBundle)
     */
    protected void addArgToArray (String inParameter, String inValue)
    {
        if ((inParameter != null) && (inValue != null))
        {
            // Determine the index of the command line argument.
            //
            Integer index = (Integer) theArgIndexMap.getObject (inParameter);
            if ((index != null) && (index.intValue() < theArgsArray.length))
                theArgsArray[index.intValue()] = inValue;
        }        
    
    }   // end addArgToArray(String inParameter, String inValue).
    
    /**
     * Allocate the ReadProcessIStreams object, if desired.  The ReadProcessIStreams captures and
     * a Process's input stream(s) content.  Sub-classes can make use of this as needed.
     * @see ReadProcessIStreams
     * @see #handleProcessIStreams(Process)
     * @see #handleProcessIStreams(Process,boolean)
     */
    protected void createReadProcessIStreams()
    {
        theReadProcessIStreams = new ReadProcessIStreams();
    
    }   // end createReadProcessIStreams().

    /**
     * Activate the ReadProcessIStreams object.  In this case, the ReadProcessIStreams is
     * configured to capture and dispose of a Process's input stream(s) content.  Sub-classes
     * can make use of this as needed.
     * @param inProcess     The Process whose InputStreams are to read.
     * @see ReadProcessIStreams
     * @see #createReadProcessIStreams()
     * @see #handleProcessIStreams(Process,boolean)
     */
    protected void handleProcessIStreams (Process inProcess)
    {
        handleProcessIStreams (inProcess, false);
    
    }   // end handleProcessIStreams (Process inProcess).

    /**
     * Activate the ReadProcessIStreams object.  In this case, the ReadProcessIStreams is
     * configured to capture and log a Process's input stream(s) content.  Sub-classes
     * can make use of this as needed.
     * @param inProcess     The Process whose InputStreams are to read.
     * @param logFlag       If <code>true</code> the contents of the InputStreams are
     *                      written to the ConfigManager's log file.
     * @see ReadProcessIStreams
     * @see #createReadProcessIStreams()
     * @see #handleProcessIStreams(Process)
     */
    protected void handleProcessIStreams (Process inProcess, boolean logFlag)
    {
        if (theReadProcessIStreams != null)
        {
            theReadProcessIStreams.readStreams (inProcess, logFlag);
        }
    
    }   // end handleProcessIStreams (Process inProcess, boolean logFlag).

    /**
     * Retrieve one of the plug-in's local properties.  Use only after initializing the local
     * properties via <code>initLocalProps()</code> -- this checks to see if the local properties
     * have been  initialized, and, if not, throws a MissingResourceException.  If they have been
     * initialized, then the desired property is retrieved.  If the property does not exist,
     * a MissingResourceException is thrown.
     * @param   inPropName      Name of the property to be retrieved.
     * @return                  The property value.
     * @exception               MissingResourceException Occurs if the local properties have not
     *                          been initialized, or the given property is not known.
     * @see #initLocalProps()
     */
    protected String getLocalProperty (String inPropName) throws MissingResourceException
    {
        if (theLocalProps != null)
            return theLocalProps.getString (inPropName);
        else
            throw new MissingResourceException ("", getAppID(), inPropName);
     
    }   // end getLocalProperty().

//=========================================================================================
// SetterLauncher implementation -- methods "doSettings()" and "doLaunch()" still abstract.
//=========================================================================================

    /**
     * Basic implementation of the SetterLauncher kill method.  If there is a valid Process, then 
     * it is destroyed; otherwise do nothing.  Sub-classes should override to first reset the technology's
     * settings to some default state before actually killing the Process.
     */
    public void kill()
    {
        if (theProcess != null)
        {
            theProcess.destroy();
            theProcess = null;
        }
    
    }   // end kill().

    /**
     * Basic implementation for acquiring the local properties of the plug-in.  The
     * properties are assumed to be held by the Control Hub, which is acquired
     * via <code>getControlHub()</code>.  The properties are stored as a
     * java.util.ResourceBundle.  If such a bundle does not exist, this will fail.
     * @return      A flag to indicate success/failure in acquiring the local properties.
     * @see #getControlHub()
     * @see #getLocalProperty(String)
     * @see ControlHub#get3rdPartyProperties(String)
     */
    public boolean initLocalProps()
    {
        boolean success = false;

        // Get the local properties.
        //
        try
        {
            theLocalProps = getControlHub().get3rdPartyProperties (getAppID());
            success = true;
        }
        catch (MissingResourceException mre)
        {
            ConfigManager.logException (mre);
            success = false;
        }
        return success;

    }   // end initLocalProps().
            
}   // end class AbstractSetterLauncher.

