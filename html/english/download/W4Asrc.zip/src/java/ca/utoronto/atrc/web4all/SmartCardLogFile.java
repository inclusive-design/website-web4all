/**
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 */   
package ca.utoronto.atrc.web4all;

import ca.utoronto.atrc.web4all.web4AllCardService.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class SmartCardLogFile {
	public static final int LOG_NONE = Integer.MAX_VALUE;
	public static final int LOG_INFORMATION = 1;
	public static final int LOG_DEBUG = 2;
	public static final int LOG_ALL = Integer.MIN_VALUE;
	
	static SmartCardLogFile theLF = null;
	private static int logLevel = LOG_INFORMATION;	// controls which messages are actually written to the log file.
    private static PrintWriter logFile = null;            // File for logging exceptions.
	private static SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss.sss");
    private static String emptyString = ""; 
	
/**
  * A constructor to set up the file to be used by the logException
  * method.
*/
	public static boolean  createLogFile(String ds, boolean stdout, boolean stderr) {
		String directoryString = ds;
  //  public SmartCardLogFile() {
		// use date/time to form a log file name
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MMM-dd");
		String logFileName = "CC" + sdf.format(new Date()) + ".log"; 
		String outFileName = "W4A" + sdf.format(new Date()) + ".out"; 
		String errFileName = "W4A" + sdf.format(new Date()) + ".err"; 
		File directory;
		if ((directoryString != null) && directoryString.length() > 0) {
			try {
				directory = new File(directoryString);
		        logFile = new PrintWriter(new FileOutputStream((new File(directory, logFileName)).getAbsolutePath(), true), true);
                if (stdout) {
    		        System.setOut(new PrintStream(new FileOutputStream((new File(directory, outFileName)).getAbsolutePath(), true)));
                }
                if (stderr) {
    		        System.setErr(new PrintStream(new FileOutputStream((new File(directory, errFileName)).getAbsolutePath(), true)));
                }
				return true;
			}
			catch (IOException ioe ) {
				System.err.println("Unable to create log file(s) with logFileDirectory");
				ioe.printStackTrace(System.err);
			}
		}
		directoryString = System.getProperties().getProperty("user.dir");
		if ((directoryString != null) && directoryString.length() > 0) {
			try {
				directory = new File(directoryString);
				logFile = new PrintWriter(new FileOutputStream((new File(directory, logFileName)).getAbsolutePath(), true), true);
                if (stdout) {
    		        System.setOut(new PrintStream(new FileOutputStream((new File(directory, outFileName)).getAbsolutePath(), true)));
                }
                if (stderr) {
    		        System.setErr(new PrintStream(new FileOutputStream((new File(directory, errFileName)).getAbsolutePath(), true)));
                }
				return true;
			}
			catch (IOException ioe ) {
				System.err.println("Unable to create log file(s) with user.dir");
				ioe.printStackTrace(System.err);
			}
		}
		try {
			logFile = new PrintWriter(new FileOutputStream(logFileName, true), true);
            if (stdout) {
                System.setOut(new PrintStream(new FileOutputStream((new File(outFileName)).getAbsolutePath(), true)));
            }
            if (stderr) {
                System.setErr(new PrintStream(new FileOutputStream((new File(errFileName)).getAbsolutePath(), true)));
            }
			return true;
		}
		catch(IOException ioe) {
			System.err.println("Unable to create log file in default directory");
			ioe.printStackTrace(System.err);
		}
		return false;
    }
	
	public static void setLogLevel(int level) {
		logLevel = level;
	}
	
/**    
  * A method to supply identifying information about the current Thread. 
  * @return the Thread's name or the empty String;
*/   
    private static String genThreadInfo() {
        if (logLevel < LOG_DEBUG) {
            return emptyString;
        }
        else {
            return " " + Thread.currentThread().getName();
        }
    }
        
    public static void logException(Throwable e) {
        if (logFile != null) {
			logFile.println(formatter.format(new Date()) + genThreadInfo() + ": Exception logged ");
            logFile.flush();
			e.printStackTrace(logFile);
            logFile.flush();
			if (logFile.checkError()) {
				System.err.println("Unable to write to log file - disabling further log activities");
				logFile = null;
			}
		}
		else {
			System.err.println(formatter.format(new Date()) + genThreadInfo() + ": Exception logged ");
			e.printStackTrace(System.err);
		}
    }
	
	public static void writeLog(String msg, int sev) {
		if (sev > logLevel) {
			return;
		}
        if (logFile != null) {
			logFile.println(formatter.format(new Date()) + genThreadInfo() + ": " + msg);
            logFile.flush();
			if (logFile.checkError()) {
				System.err.println("Unable to write to log file - disabling further log activities");
				logFile = null;
			}
		}
		else {
			System.err.println(formatter.format(new Date()) + genThreadInfo() + ": " + msg);
		}
    }
	
	public static void writeLog(String msg) {
		SmartCardLogFile.writeLog(msg, LOG_INFORMATION);
	}
    
    public static void close() {
        if (logFile != null) {
            logFile.close();
        }
    }
    
}
