/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            WFileChooser.java
 *
 * Synoposis:       package ca.utoronto.atrc.web4all.prefschooser;
 *
]*/

package ca.utoronto.atrc.web4all.prefschooser;

import javax.swing.JFileChooser;
import javax.swing.JDialog;
import javax.swing.JMenuBar;
import javax.swing.KeyStroke;

import java.awt.event.*;
import java.awt.Component;
import java.awt.HeadlessException;

import java.io.File;

import javax.swing.plaf.metal.*;    // for large text version of the chooser.
import javax.swing.UIManager;
import javax.swing.SwingUtilities;

/**
 * Derivation from Swing's JFileChooser in order to get at the window that the
 * file chooser is displayed in.
 * @author Joseph Scheuhammer
 * @version $Id: WFileChooser.java,v 1.7 2006/03/28 21:17:27 clown Exp $
 */
public class WFileChooser extends JFileChooser
{
    /**
     * The JMenuBar to set on <code>theDialog</code>.
     */
    private JMenuBar theMenuBar;
    
    /**
     * The Speaker that is self-voicing this file chooser.
     */
    private ChooserSpeaker theChooserSpeaker;
    
    /**
     * The large text MetalTheme to skin <code>this</code> with.
     */
    private LargeTextTheme theLargeTextTheme;
    
    /**
     * The default MetalTheme to skin <code>this</code> with.
     */
    private DefaultMetalTheme theDefaultTheme;
    
    /**
     * Window closed event handler to reset back to the default theme.
     */
    private ResetThemeOnClose theResetHandler;
    
    /**
     * Allocate the large text theme, and store a copy of the default theme.
     */
    public WFileChooser (File inFile)
    {
        super (inFile);
        theLargeTextTheme = new LargeTextTheme();
        theDefaultTheme = new DefaultMetalTheme();
        theResetHandler = new ResetThemeOnClose();
    
    }   // end WFileChooser (File).
    
    /**
     * Constructor, calls super().  Necessary because of constructor above.
     * Erase if above constructor disappears.
     */
    public WFileChooser()
    {
        super();
        theLargeTextTheme = new LargeTextTheme();
        theDefaultTheme = new DefaultMetalTheme();
        theResetHandler = new ResetThemeOnClose();
    
    }   // end WFileChooser().
    
    /**
     * Allow other classes in the package to store a JMenuBar within the
     * instance.  This will take effect only when the window (actually a
     * JDialog) is created to present the file chooser -- see
     * <code>createDialog()</code>.
     * @param   inMenuBar   The MenuBar to set on the dialog, when appropriate.
     * @see #createDialog(Component)
     */
    void setJMenuBar (JMenuBar inMenuBar)
    {
        theMenuBar = inMenuBar;
    
    }   // end setJMenuBar().

    /**
     * Allow other classes in the package to (re)set the ChooserSpeaker that
     * will self-voice this chooser.
     * @param   inChooserSpeaker    The ChooserSpeaker to set on the dialog.
     * @see #createDialog(Component)
     */
    void setChooserSpeaker (ChooserSpeaker inChooserSpeaker)
    {
        theChooserSpeaker = inChooserSpeaker;
    
    }   // end setChooserSpeaker().

    /**
     * Override the dialog creation code so that a menu bar can be associated
     * with that dialog.
     * @param       parent   The parent component of the dialog; can be null.
     * @exception   HeadlessException if GraphicsEnvironment.isHeadless()
     *              returns true.
     */
    protected JDialog createDialog (Component parent) throws HeadlessException
    {
        // Make the actual dialog window , and add <theMenuBar>, if any, to it,
        // and hook in <theResetHandler>.  Also attach <theChooserSpeaker>, if
        // any, as a window listener.
        //
        JDialog dialog = super.createDialog (parent);
        if (theMenuBar != null)
        {
            dialog.setJMenuBar (theMenuBar);
            dialog.addWindowListener (theResetHandler);
        }
        if (theChooserSpeaker != null)
            dialog.addWindowFocusListener (theChooserSpeaker);
        
        // Theme it for large text.  For some reason, this resets the
        // file filter to "all files"; compensating...  Also, make the
        // <dialog> bigger to begin with.
        //
        javax.swing.filechooser.FileFilter filter = getFileFilter();
        setTheme (theLargeTextTheme, dialog);
        setFileFilter (filter);
        dialog.setSize (616 /*width*/, 464 /*height*/);
        return dialog;
        
    }   // end createDialog().
    
    /**
     * Utility method to set the sking (metal theme) of the window containing
     * this file chooser.
     * @param   inTheme     The MetalTheme to set the window to.
     * @param   ioDialog    The window in question.
     */
    private void setTheme (MetalTheme inTheme, JDialog ioDialog)
    {
        MetalLookAndFeel.setCurrentTheme (inTheme);
        try
        {
            UIManager.setLookAndFeel (
                "javax.swing.plaf.metal.MetalLookAndFeel"
            );
            SwingUtilities.updateComponentTreeUI (ioDialog);
        }
        catch (Exception e)
        {
            ;
        }
    
    }   // reset2Default().
    
    /**
     * Inner WindowListener to switch back to the DefaultMetalTheme when
     * the window that contains the FileChooser is closed.
     * @author  Joseph Scheuhammer.
     */
    private class ResetThemeOnClose extends WindowAdapter
    {
        /**
         * On closed, reset the window that contains this file chooser back to
         * the DefaultMetalTheme.
         * @param   inEvent     The "closed" WindowEvent.
         * @see #WFileChooser.setTheme(MetalTheme,JDialog)
         */
        public void windowClosed (WindowEvent inEvent)
        {
            JDialog window = (JDialog) inEvent.getWindow();
            WFileChooser.this.setTheme (theDefaultTheme, window);
        
        }   // end windowClose().
    
    }   // end inner class RestThemeOnClose.

}       // end class WFileChooser.