/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.net.URL;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xpath.*;
import java.text.NumberFormat;
import javax.xml.transform.TransformerException;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

/**
 * Class which encapsulates the keyboard enhanced preferences.
 *
 * @author David Weinkauf
 * @version $Revision: 1.9 $, $Date: 2006/03/28 16:31:10 $
 */
public class KeyboardEnhanced2 extends PWMEditPanel {

    /**
     * The slow key slider.
     */
    private JSlider slowKeySlider;

    /**
     * The slow key check box to enable/disable slow keys.
     */
    private JCheckBox slowKeyCheckBox;

    /**
     * The slow keys label with its three options of short, medium, and long under the slowKeySlider.
     */
    private JLabel slowKeyLabel, shortPeriodLabel, mediumPeriodLabel, longPeriodLabel;

    /**
     * The slow key title.
     */
    private TitledBorder slowKeyTitle;

    /**
     * The bounce title label.
     */
    private TitledBorder bounceTitle;

    /**
     * The bounce interval label.
     */
    private JLabel bounceIntervalLabel;

    /**
     * The bounce checkbox.
     */
    private JCheckBox bounce;

    /**
     * The bounce interval slider.
     */
    private JSlider bounceIntervalSlider;

    /**
     * The previous dialog.
     */
    protected PWMEditPanel previousDialog;

    /**
     * Sole constructor. Initializes the UI.
     *
     * @param  pm  the reference to the PreferenceManager
     * @param  inKeyboard  the previous keyboard enhanced dialog
     * @param  inAppType  the application type
     * @param  inTitleKey  the title key
     */
    public KeyboardEnhanced2(PreferenceManager pm, KeyboardEnhanced inKeyboard, String inAppType, String inTitleKey) {

        super(pm, inAppType, inTitleKey);
        previousDialog = inKeyboard;

        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.KeyboardEnhanced", pm.language);

        Hashtable slowKeyHash = new Hashtable();
        shortPeriodLabel = new JLabel(labels.getString("short.period"));
        shortPeriodLabel.setForeground(Color.black);
        mediumPeriodLabel = new JLabel(labels.getString("medium.period"));
        mediumPeriodLabel.setForeground(Color.black);
        longPeriodLabel = new JLabel(labels.getString("long.period"));
        longPeriodLabel.setForeground(Color.black);
        slowKeyHash.put(new Integer(0), shortPeriodLabel);
        slowKeyHash.put(new Integer(5), mediumPeriodLabel);
        slowKeyHash.put(new Integer(10), longPeriodLabel);

        slowKeySlider = new JSlider(SwingConstants.HORIZONTAL, 0, 10, 5);
        slowKeySlider.setPaintLabels(true);
        slowKeySlider.setForeground(TEXT_COLOUR);
        slowKeySlider.setBackground(PANEL_BACKGROUND);
        slowKeySlider.setMajorTickSpacing(1);
        slowKeySlider.setLabelTable(slowKeyHash);
        slowKeySlider.setSnapToTicks(true);
        slowKeySlider.setPaintTicks(true);

        slowKeyLabel = new JLabel(labels.getString("keys.held.down"));
        slowKeyLabel.setDisplayedMnemonic(labels.getString("keys.held.down.mnemonic").charAt(0));
        slowKeyLabel.setLabelFor(slowKeySlider);
        slowKeyLabel.setFont(TEXT_FONT);
        slowKeyLabel.setForeground(Color.black);

        JPanel slowKeyPanel = new JPanel();
        slowKeyPanel.setLayout(new BoxLayout(slowKeyPanel, BoxLayout.X_AXIS));
        slowKeyPanel.setBackground(PANEL_BACKGROUND);
        slowKeyPanel.add(Box.createHorizontalStrut(SPACING_VALUE));
        slowKeyPanel.add(slowKeyLabel);
        slowKeyPanel.add(Box.createHorizontalStrut(SPACING_VALUE));
        slowKeyPanel.add(slowKeySlider);

        slowKeyCheckBox = new JCheckBox(labels.getString("enable.slow.keys"));
        slowKeyCheckBox.setMnemonic(labels.getString("enable.slow.keys").charAt(0));
        slowKeyCheckBox.setBackground(PANEL_BACKGROUND);
        slowKeyCheckBox.setFont(TEXT_FONT);
        slowKeyCheckBox.setSelected(true);
        slowKeyCheckBox.addChangeListener(new SlowKeyListener());
		
        JPanel slowKeyCheckBoxPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        slowKeyCheckBoxPanel.setBackground(PANEL_BACKGROUND);
        slowKeyCheckBoxPanel.add(slowKeyCheckBox);

        slowKeyTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("slow.key.title"));
        slowKeyTitle.setTitleColor(BORDER_TITLE_COLOUR);
        slowKeyTitle.setTitleFont(BORDER_TITLE_FONT);

        JPanel slowKeyPanel2 = new JPanel();
        slowKeyPanel2.setBorder(slowKeyTitle);
        slowKeyPanel2.setLayout(new BoxLayout(slowKeyPanel2, BoxLayout.Y_AXIS));
        slowKeyPanel2.setBackground(PANEL_BACKGROUND);
        slowKeyPanel2.add(slowKeyCheckBoxPanel);
        slowKeyPanel2.add(slowKeyPanel);

        AccessibleContext ac = slowKeyLabel.getAccessibleContext();
        ac.setAccessibleParent(slowKeyPanel2);
        ac = slowKeySlider.getAccessibleContext();
        ac.setAccessibleParent(slowKeyPanel2);
        ac = slowKeyCheckBox.getAccessibleContext();
        ac.setAccessibleParent(slowKeyPanel2);        

        this.add(slowKeyPanel2);
        this.add(Box.createVerticalGlue());

        bounce = new JCheckBox(labels.getString("bounce"));
        bounce.setMnemonic(labels.getString("bounce.mnemonic").charAt(0));
        bounce.setBackground(PANEL_BACKGROUND);
        bounce.setFont(TEXT_FONT);
        bounce.setSelected(false);
        bounce.addChangeListener(new BounceListener());

        JPanel bounceCheckBoxPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bounceCheckBoxPanel.setBackground(PANEL_BACKGROUND);
        bounceCheckBoxPanel.add(bounce);

        Hashtable bounceIntervalHash = new Hashtable();
        JLabel secondsLabel;
        NumberFormat numberFormat = NumberFormat.getInstance(pm.language);
        for (int i = 0; i <= 20; i += 2) {
            secondsLabel = new JLabel(numberFormat.format(i / 4.0d));
            secondsLabel.setForeground(Color.black);
            bounceIntervalHash.put(new Integer(i), secondsLabel);
        }

        bounceIntervalSlider = new JSlider(SwingConstants.HORIZONTAL, 0, 20, 2);
        bounceIntervalSlider.setPaintLabels(true);
        bounceIntervalSlider.setBackground(PANEL_BACKGROUND);
        bounceIntervalSlider.setForeground(TEXT_COLOUR);
        bounceIntervalSlider.setMajorTickSpacing(4);
        bounceIntervalSlider.setMinorTickSpacing(1);
        bounceIntervalSlider.setLabelTable(bounceIntervalHash);
        bounceIntervalSlider.setSnapToTicks(true);
        bounceIntervalSlider.setPaintTicks(true);
        bounceIntervalSlider.setEnabled(false);

        bounceIntervalLabel = new JLabel(labels.getString("bounce.interval"));
        bounceIntervalLabel.setDisplayedMnemonic(labels.getString("bounce.interval.mnemonic").charAt(0));
        bounceIntervalLabel.setForeground(Color.black);
        bounceIntervalLabel.setFont(TEXT_FONT);
        bounceIntervalLabel.setLabelFor(bounceIntervalSlider);
        bounceIntervalLabel.setEnabled(false);

        JPanel bounceSliderPanel = new JPanel();
        bounceSliderPanel.setLayout(new BoxLayout(bounceSliderPanel, BoxLayout.X_AXIS));
        bounceSliderPanel.setBackground(PANEL_BACKGROUND);
        bounceSliderPanel.add(Box.createHorizontalStrut(SPACING_VALUE));
        bounceSliderPanel.add(bounceIntervalLabel);
        bounceSliderPanel.add(Box.createHorizontalStrut(SPACING_VALUE));
        bounceSliderPanel.add(bounceIntervalSlider);

        bounceTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("bounce.title"));
        bounceTitle.setTitleColor(BORDER_TITLE_COLOUR);
        bounceTitle.setTitleFont(BORDER_TITLE_FONT);
		
        JPanel bouncePanel = new JPanel();
        bouncePanel.setLayout(new BoxLayout(bouncePanel, BoxLayout.Y_AXIS));
        bouncePanel.setBorder(bounceTitle);
        bouncePanel.setBackground(PANEL_BACKGROUND);
        bouncePanel.add(bounceCheckBoxPanel);
        bouncePanel.add(bounceSliderPanel);

        ac = bounceIntervalSlider.getAccessibleContext();
        ac.setAccessibleParent(bouncePanel);
        ac = bounceIntervalLabel.getAccessibleContext();
        ac.setAccessibleParent(bouncePanel);
        ac = bounce.getAccessibleContext();
        ac.setAccessibleParent(bouncePanel);

        this.add(bouncePanel);
        this.add(Box.createVerticalGlue());

    }

    /**
     * Initializes the UI according to the application type's XML document.
     */
    protected void setDomValues(Element current) {
        Element temp = current;

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(KE_GENERIC_SLOW))) {
            if (temp.getAttribute(VALUE).equals("false"))
                slowKeyCheckBox.setSelected(false);
            else {
                slowKeyCheckBox.setSelected(true);

                Element slowKeyChild = DOMUtil.getFirstChildElement(temp);
                if (slowKeyChild != null && slowKeyChild.getTagName().equals(xmlLabels.getString(KE_GENERIC_SLOW_INTERVAL)))
                    slowKeySlider.setValue( (int) (Float.parseFloat(slowKeyChild.getAttribute(VALUE)) * 10) );
            }

            temp = DOMUtil.getNextSiblingElement(temp);			
        }
		
        if (temp != null && temp.getTagName().equals(xmlLabels.getString(KE_GENERIC_DEBOUNCE))) {
            if (temp.getAttribute(VALUE).equals("false"))
                bounce.setSelected(false);
            else {
                bounce.setSelected(true);

                Element bounceChild = DOMUtil.getFirstChildElement(temp);
                if (bounceChild != null && bounceChild.getTagName().equals(xmlLabels.getString(KE_GENERIC_DEBOUNCE_INTERVAL)))
                    bounceIntervalSlider.setValue( (int) ((Float.parseFloat(bounceChild.getAttribute(VALUE))) * 4.0) );
            }

            temp = DOMUtil.getNextSiblingElement(temp);
        }
		
    }

    /**
     * Adds elements to the XML document.
     *
     * @param  document  the application type's XML document
     */
    protected void addElementsTo(Document document) {

        Element temp;
        Element child;
        Element generic = DOMUtil.getFirstChildElement(document.getDocumentElement());

        temp = document.createElement(xmlLabels.getString(KE_GENERIC_SLOW));
        generic.appendChild(temp);

        if (slowKeyCheckBox.isSelected()) {
            temp.setAttribute(VALUE, "true");

            child = document.createElement(xmlLabels.getString(KE_GENERIC_SLOW_INTERVAL));
            child.setAttribute(VALUE, String.valueOf(slowKeySlider.getValue() / 10.0));
            temp.appendChild(child);			
        }
        else
            temp.setAttribute(VALUE, "false");

        temp = document.createElement(xmlLabels.getString(KE_GENERIC_DEBOUNCE));
        generic.appendChild(temp);

        if (bounce.isSelected()) {
            temp.setAttribute(VALUE, "true");

            child = document.createElement(xmlLabels.getString(KE_GENERIC_DEBOUNCE_INTERVAL));
            child.setAttribute(VALUE, String.valueOf(bounceIntervalSlider.getValue() / 4.0));						
            temp.appendChild(child);
        }
        else
            temp.setAttribute(VALUE, "false");
			
    }

    /**
     * Sets the UI labels to the user locale.
     */
    protected void setNewLabels() {
        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.KeyboardEnhanced", pm.language);

        slowKeyTitle.setTitle(newLabels.getString("slow.keys"));
        shortPeriodLabel.setText(newLabels.getString("short.period"));
        mediumPeriodLabel.setText(newLabels.getString("medium.period"));
        longPeriodLabel.setText(newLabels.getString("long.period"));

        slowKeyLabel.setText(newLabels.getString("keys.held.down"));
        slowKeyLabel.setDisplayedMnemonic(newLabels.getString("keys.held.down.mnemonic").charAt(0));

        slowKeyCheckBox.setText(newLabels.getString("enable.slow.keys"));
        slowKeyCheckBox.setMnemonic(newLabels.getString("enable.slow.keys.mnemonic").charAt(0));

        bounceTitle.setTitle(newLabels.getString("bounce.title"));
        bounce.setText(newLabels.getString("bounce"));
        bounce.setMnemonic(newLabels.getString("bounce.mnemonic").charAt(0));
        bounceIntervalLabel.setText(newLabels.getString("bounce.interval"));
        bounceIntervalLabel.setDisplayedMnemonic(newLabels.getString("bounce.interval.mnemonic").charAt(0));

        Hashtable bounceIntervalHash = new Hashtable();
        JLabel secondsLabel;
        NumberFormat numberFormat = NumberFormat.getInstance(pm.language);
        for (int i = 0; i <= 20; i += 2) {
            secondsLabel = new JLabel(numberFormat.format(i / 4.0d));
            secondsLabel.setForeground(Color.black);
            bounceIntervalHash.put(new Integer(i), secondsLabel);
        }
                
        bounceIntervalSlider.setLabelTable(bounceIntervalHash);

        setNewButtonLabels();

        revalidate();
        repaint(); 

    }

    /**
     * Listener to the slow keys check box.
     */
    class SlowKeyListener implements ChangeListener {
        public void stateChanged(ChangeEvent e) {
            JCheckBox box = (JCheckBox) e.getSource();
            if (box.isSelected()) {
                slowKeySlider.setEnabled(true);
                slowKeyLabel.setEnabled(true);
            }
            else {
                slowKeySlider.setEnabled(false);
                slowKeyLabel.setEnabled(false);
            }
        }
    }

    /**
     * Listener to the bounce keys check box.
     */
    class BounceListener implements ChangeListener {
        public void stateChanged(ChangeEvent e) {
            JCheckBox box = (JCheckBox) e.getSource();
            if (box.isSelected()) {
                bounceIntervalSlider.setEnabled(true);
                bounceIntervalLabel.setEnabled(true);
            }
            else {
                bounceIntervalSlider.setEnabled(false);
                bounceIntervalLabel.setEnabled(false);
            }
        }
    }

    /**
     * Gets the first panel in this application type edit panel grouping.
     */
    protected PWMEditPanel getFirstPanel() {
        return previousDialog;
    }

    /**
     * Shows the previous dialog.
     */
    protected void doPrev() {
        pm.showPanel(previousDialog);
    }

    /**
     * Sets the UI widgets to their default values.
     */
    protected void doDefault() {
        slowKeyCheckBox.setSelected(true);
        slowKeyLabel.setEnabled(true);
        slowKeySlider.setEnabled(true);
        slowKeySlider.setValue(5);
        bounce.setSelected(false);
        bounceIntervalSlider.setEnabled(false);
        bounceIntervalSlider.setValue(2);
        bounceIntervalLabel.setEnabled(false);
    }
}
