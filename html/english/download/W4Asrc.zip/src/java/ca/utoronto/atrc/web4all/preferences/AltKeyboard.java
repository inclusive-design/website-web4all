/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.net.URL;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;

/**
 * Class which displays the alternative keyboard settings.
 */
public class AltKeyboard extends KeyboardEnhanced {

	/**
	 * Sole constructor.
	 *
	 * @param  pm  the PreferenceManager
	 * @param  root  the root element of this application type's document tree
	 * @param  inAppType  the panel's applicaiton type
	 */
	public AltKeyboard(PreferenceManager pm, Element root, String inAppType) {
		super(pm, root, inAppType);

		document = initDocument(root, xmlLabels.getString(ALT_KEYBOARD), xmlLabels.getString(AK_GENERIC));
		generic = DOMUtil.getFirstChildElement(document.getDocumentElement());

		
		nextDialog = new AltKeyboard2(pm, this, inAppType, titleKey);

	}

	/**
	 * Sets the UI values to their correct setting as demonstrated in the passed generic element.
	 *
	 * @param  generic  the generic element for this application type's document
	 */
	protected void setDomValues() {
		super.setDomValues();
		
		((AltKeyboard2) nextDialog).setDomValues(generic);
	}

	/**
	 * Gets the last panel for this application type.
	 */
	protected PWMEditPanel getLastPanel() {
		return nextDialog.getLastPanel();
	}

}
