/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.event.*;
import java.util.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

/**
 * Class which encapsulates the second dialog of screen enhancement preferences.
 *
 * @author David Weinkauf
 * @revision $Revision: 1.9 $, $Date: 2006/03/28 16:31:10 $
 */
public class ScreenEnhancement2 extends PWMEditPanel implements ActionListener {
  
    /**
     * The three radio buttons for tracking.
     */
    private JCheckBox mouse, caret, focus;

    /**
     * The screen tracking label.
     */
    private JLabel trackingLabel;

    /**
     * The three cursor size slider value labels.
     */
    private JLabel standard, large, xLarge;

    /**
     * The cursor size slider.
     */
    private JSlider cursorSizeSlider;

    /**
     * The cursor trails slider.
     */
    private JSlider cursorTrailSlider;
	
    /**
     * The cursor trail labels.
     */
    private JLabel noTrail, medium, longest;

    /**
     * The labels of the panel.
     */
    private JLabel cursorColourLabel, cursorSizeLabel, cursorTrailLabel;

    /**
     * Enable/disable magnification check box.
     */
    private JCheckBox magnificationCheckBox;

    /**
     * The magnification rate slider label.
     */
    private JLabel magnificationRateLabel;

    /**
     * The magnification rate slider.
     */
    private JSlider magnificationRateSlider;

    /**
     * The border titles for the various UI sections.
     */
    private TitledBorder magnificationTitle, cursorSizeTitle;

    /**
     * The cursor color select button.
     */
    private JButton cursorColourButton;

    /**
     * The colour chooser dialog.
     */
    private JDialog colourChooserDialog;

    /**
     * The colour the colour chooser returns.
     */
    private Color colour;

    /**
     * The colour chooser.
     */
    private JColorChooser colourChooser;
	
    /**
     * The action listeners for the modal colour chooser.
     */
    private ActionListener okListener, cancelListener;

    /**
     * Reference to the first screen enhancement dialog.
     */ 
    private ScreenEnhancement screenEnhancement;

    /**
     * The constructor initializes all the components in the dialog and displays them accordingly.
     * @param    pm                     reference to the PreferenceManagaer
     * @param    screenEnhancement      referent to the first screen enhancement dialog
     * @param    inAppType              application type
     */
    public ScreenEnhancement2(PreferenceManager pm, ScreenEnhancement screenEnhancement, String inAppType) {
        super(pm, inAppType, inAppType + TITLE_SUFFIX);
		
        this.screenEnhancement = screenEnhancement;
    
        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.ScreenEnhancement", pm.language);
    
        standard = new JLabel(labels.getString("standard"));
        standard.setForeground(Color.black);
        large = new JLabel(labels.getString("large"));
        large.setForeground(Color.black);
        xLarge = new JLabel(labels.getString("x.large"));
        xLarge.setForeground(Color.black);

        Hashtable cursorSizeHash = new Hashtable();
        cursorSizeHash.put(new Integer(0), standard);
        cursorSizeHash.put(new Integer(5), large);
        cursorSizeHash.put(new Integer(10), xLarge);

        cursorSizeSlider = new JSlider(SwingConstants.HORIZONTAL, 0, 10, 0);
        cursorSizeSlider.setPaintLabels(true);
        cursorSizeSlider.setBackground(PANEL_BACKGROUND);
        cursorSizeSlider.setForeground(TEXT_COLOUR);
        cursorSizeSlider.setLabelTable(cursorSizeHash);
        cursorSizeSlider.setMajorTickSpacing(1);
        cursorSizeSlider.setMinorTickSpacing(1);
        cursorSizeSlider.setSnapToTicks(true);
        cursorSizeSlider.setPaintTicks(true);

        cursorSizeLabel = new JLabel(labels.getString("cursor.size"));
        cursorSizeLabel.setFont(TEXT_FONT);
        cursorSizeLabel.setForeground(TEXT_COLOUR);
        cursorSizeLabel.setDisplayedMnemonic(labels.getString("cursor.size.mnemonic").charAt(0));
        cursorSizeLabel.setLabelFor(cursorSizeSlider);

        noTrail = new JLabel(labels.getString("no.trail"));
        noTrail.setForeground(Color.black);
        medium = new JLabel(labels.getString("medium"));
        medium.setForeground(Color.black);
        longest = new JLabel(labels.getString("longest"));
        longest.setForeground(Color.black);

        Hashtable cursorTrailHash = new Hashtable();
        cursorTrailHash.put(new Integer(0), noTrail);
        cursorTrailHash.put(new Integer(5), medium);
        cursorTrailHash.put(new Integer(10), longest);

        cursorTrailSlider = new JSlider(SwingConstants.HORIZONTAL, 0, 10, 0);
        cursorTrailSlider.setPaintLabels(true);
        cursorTrailSlider.setBackground(PANEL_BACKGROUND);
        cursorTrailSlider.setForeground(TEXT_COLOUR);
        cursorTrailSlider.setLabelTable(cursorTrailHash);
        cursorTrailSlider.setMajorTickSpacing(1);
        cursorTrailSlider.setMinorTickSpacing(1);
        cursorTrailSlider.setSnapToTicks(true);
        cursorTrailSlider.setPaintTicks(true);

        cursorTrailLabel = new JLabel(labels.getString("cursor.trail"));
        cursorTrailLabel.setFont(TEXT_FONT);
        cursorTrailLabel.setForeground(TEXT_COLOUR);
        cursorTrailLabel.setDisplayedMnemonic(labels.getString("cursor.trail.mnemonic").charAt(0));
        cursorTrailLabel.setLabelFor(cursorTrailSlider);

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel cursorGridPanel = new JPanel();
        cursorGridPanel.setBackground(PANEL_BACKGROUND);
        cursorGridPanel.setLayout(gridbag);

        Insets insets = new Insets(5, 5, 5, 5);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 1;
        c.weightx = 0.0;
        cursorGridPanel.add(cursorSizeLabel, c);

        c.gridx = 1;
        c.gridy = 1;
        c.weightx = 0.5;
        cursorGridPanel.add(cursorSizeSlider, c);

        c.gridx = 0;
        c.gridy = 2;
        c.weightx = 0.0;
        cursorGridPanel.add(cursorTrailLabel, c);

        c.gridx = 1;
        c.gridy = 2;
        c.weightx = 0.5;
        cursorGridPanel.add(cursorTrailSlider, c);

        JPanel cursorSliderPanel = new JPanel(new GridLayout(1, 1));
        cursorSliderPanel.setBackground(PANEL_BACKGROUND);
        cursorSliderPanel.add(cursorGridPanel);

        cursorColourButton = new JButton(labels.getString("cursor.colour"));
        cursorColourButton.setIcon(new ColourIcon(Color.white));
        cursorColourButton.setBackground(PANEL_BACKGROUND);
        cursorColourButton.addActionListener(this);
        cursorColourButton.setMnemonic(labels.getString("cursor.colour.mnemonic").charAt(0));
        cursorColourButton.setHorizontalAlignment(SwingConstants.LEFT);

        JPanel cursorColourPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        cursorColourPanel.setBackground(PANEL_BACKGROUND);
        cursorColourPanel.add(cursorColourButton);

        cursorSizeTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("cursor"));
        cursorSizeTitle.setTitleFont(BORDER_TITLE_FONT);
        cursorSizeTitle.setTitleColor(BORDER_TITLE_COLOUR);
        
        JPanel cursorPanel = new JPanel();
        cursorPanel.setLayout(new BoxLayout(cursorPanel,BoxLayout.Y_AXIS));
        cursorPanel.setBorder(cursorSizeTitle);
        cursorPanel.setBackground(PANEL_BACKGROUND);
        cursorPanel.add(cursorSliderPanel);
        cursorPanel.add(Box.createVerticalStrut(SPACING_VALUE));
        cursorPanel.add(cursorColourPanel);

        AccessibleContext ac = cursorSizeLabel.getAccessibleContext();
        ac.setAccessibleParent(cursorPanel);
        ac = cursorSizeSlider.getAccessibleContext();
        ac.setAccessibleParent(cursorPanel);
        ac = cursorTrailLabel.getAccessibleContext();
        ac.setAccessibleParent(cursorPanel);
        ac = cursorTrailSlider.getAccessibleContext();
        ac.setAccessibleParent(cursorPanel);
        ac = cursorColourButton.getAccessibleContext();
        ac.setAccessibleParent(cursorPanel);
        
    
        this.add(cursorPanel);
        this.add(Box.createVerticalGlue());

        mouse = new JCheckBox(labels.getString("mouse"));
        mouse.setMnemonic(labels.getString("mouse.mnemonic").charAt(0));
        mouse.setBackground(PANEL_BACKGROUND);
        mouse.setFont(TEXT_FONT);
        mouse.setSelected(true);

        caret = new JCheckBox(labels.getString("caret"));
        caret.setMnemonic(labels.getString("caret.mnemonic").charAt(0));
        caret.setBackground(PANEL_BACKGROUND);
        caret.setFont(TEXT_FONT);
        caret.setSelected(true);
		
        focus = new JCheckBox(labels.getString("focus"));
        focus.setMnemonic(labels.getString("focus.mnemonic").charAt(0));
        focus.setBackground(PANEL_BACKGROUND);
        focus.setFont(TEXT_FONT);
        focus.setSelected(true);

        trackingLabel = new JLabel(labels.getString("tracking"));
        trackingLabel.setFont(TEXT_FONT);
        trackingLabel.setForeground(TEXT_COLOUR);

        Hashtable magnificationRateTable = new Hashtable();
        JLabel rate;
        rate = new JLabel("1X");
        rate.setForeground(TEXT_COLOUR);
        magnificationRateTable.put(new Integer(1), rate);
        for (int i = 5; i <= 20; i += 5) {
            rate = new JLabel(String.valueOf(i) + "X");
            rate.setForeground(TEXT_COLOUR);
            magnificationRateTable.put(new Integer(i), rate);
        }

        magnificationRateSlider = new JSlider(SwingConstants.HORIZONTAL, 1, 20, 1);
        magnificationRateSlider.setPaintLabels(true);
        magnificationRateSlider.setBackground(PANEL_BACKGROUND);
        magnificationRateSlider.setForeground(TEXT_COLOUR);
        magnificationRateSlider.setLabelTable(magnificationRateTable);
        magnificationRateSlider.setMajorTickSpacing(1);
        magnificationRateSlider.setSnapToTicks(true);
        magnificationRateSlider.setPaintTicks(true);

        magnificationRateLabel = new JLabel(labels.getString("magnification.rate"));
        magnificationRateLabel.setDisplayedMnemonic(labels.getString("magnification.rate.mnemonic").charAt(0));
        magnificationRateLabel.setLabelFor(magnificationRateSlider);
        magnificationRateLabel.setFont(TEXT_FONT);
        magnificationRateLabel.setForeground(TEXT_COLOUR);

        magnificationCheckBox = new JCheckBox(labels.getString("use.magnification"));
        magnificationCheckBox.setMnemonic(labels.getString("use.magnification.mnemonic").charAt(0));
        magnificationCheckBox.setBackground(PANEL_BACKGROUND);
        magnificationCheckBox.setFont(TEXT_FONT);

        magnificationCheckBox.addChangeListener(new ChangeListener() {
                
                public void stateChanged(ChangeEvent e) {
                    JCheckBox box = (JCheckBox) e.getSource();
                    if (box.isSelected()) {
                        magnificationRateLabel.setEnabled(true);
                        magnificationRateSlider.setEnabled(true);
                        trackingLabel.setEnabled(true);
                        mouse.setEnabled(true);
                        caret.setEnabled(true);
                        focus.setEnabled(true);
                    }
                    else {
                        magnificationRateLabel.setEnabled(false);
                        magnificationRateSlider.setEnabled(false);
                        trackingLabel.setEnabled(false);
                        mouse.setEnabled(false);
                        caret.setEnabled(false);
                        focus.setEnabled(false);
                    }
                }
                
            });

        // Generate state change event to disable widgets.
        //
        magnificationCheckBox.setSelected(true);
        magnificationCheckBox.setSelected(false);

        JPanel magnificationCheckBoxPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        magnificationCheckBoxPanel.setBackground(PANEL_BACKGROUND);
        magnificationCheckBoxPanel.add(magnificationCheckBox);
        
        gridbag = new GridBagLayout();
        c = new GridBagConstraints();
        JPanel magnificationGridPanel = new JPanel();
        magnificationGridPanel.setBackground(PANEL_BACKGROUND);
        magnificationGridPanel.setLayout(gridbag);

        insets = new Insets(0, INDENT_VALUE, 0, INDENT_VALUE);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        magnificationGridPanel.add(trackingLabel, c);

        c.gridx = 0;
        c.gridy = 1;
        c.weightx = 0.0;
        magnificationGridPanel.add(magnificationRateLabel, c);

        c.weightx = 0.16;
        c.gridx = 1;
        c.gridy = 0;
        magnificationGridPanel.add(mouse, c);
        c.gridx = 2;
        c.gridy = 0;
        magnificationGridPanel.add(caret, c);
        c.gridx = 3;
        c.gridy = 0;
        magnificationGridPanel.add(focus, c);

        c.gridx = 1;
        c.gridy = 1;
        c.weightx = 0.5;
        c.gridwidth = 3;
        magnificationGridPanel.add(magnificationRateSlider, c);

        JPanel repeatPanel = new JPanel(new GridLayout(1, 1));
        repeatPanel.setBackground(PANEL_BACKGROUND);
        repeatPanel.add(magnificationGridPanel);

        magnificationTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("magnification.title"));
        magnificationTitle.setTitleFont(BORDER_TITLE_FONT);
        magnificationTitle.setTitleColor(BORDER_TITLE_COLOUR);

        JPanel magnificationPanel = new JPanel();
        magnificationPanel.setLayout(new BoxLayout(magnificationPanel, BoxLayout.Y_AXIS));
        magnificationPanel.setBackground(PANEL_BACKGROUND);
        magnificationPanel.setBorder(magnificationTitle);
        magnificationPanel.add(magnificationCheckBoxPanel);
        magnificationPanel.add(magnificationGridPanel);

        ac = magnificationCheckBox.getAccessibleContext();
        ac.setAccessibleParent(magnificationPanel);
        ac = trackingLabel.getAccessibleContext();
        ac.setAccessibleParent(magnificationPanel);
        ac = mouse.getAccessibleContext();
        ac.setAccessibleParent(magnificationPanel);
        ac = caret.getAccessibleContext();
        ac.setAccessibleParent(magnificationPanel);
        ac = focus.getAccessibleContext();
        ac.setAccessibleParent(magnificationPanel);
        ac = magnificationRateLabel.getAccessibleContext();
        ac.setAccessibleParent(magnificationPanel);
        ac = magnificationRateSlider.getAccessibleContext();
        ac.setAccessibleParent(magnificationPanel);


        this.add(magnificationPanel);
        this.add(Box.createVerticalGlue());

        okListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    colour = colourChooser.getColor();
                    colourChooserDialog.dispose();
                }
            };

        cancelListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    colour = null;
                    colourChooserDialog.dispose();
                }
            };

        magnificationCheckBox.setSelected(false);

    }
    

    /**
     * Set all the JPanel labels to the current PreferenceManager.language value.
     */
    protected void setNewLabels() {
        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.ScreenEnhancement", pm.language);

        magnificationTitle.setTitle(newLabels.getString("magnification.title"));

        trackingLabel.setText(newLabels.getString("tracking"));
        mouse.setText(newLabels.getString("mouse"));
        mouse.setMnemonic(newLabels.getString("mouse.mnemonic").charAt(0));
        caret.setText(newLabels.getString("caret"));
        caret.setMnemonic(newLabels.getString("caret.mnemonic").charAt(0));
        focus.setText(newLabels.getString("focus"));
        focus.setMnemonic(newLabels.getString("focus.mnemonic").charAt(0));

        cursorSizeTitle.setTitle(newLabels.getString("cursor"));
        cursorSizeLabel.setText(newLabels.getString("cursor.size"));
        cursorSizeLabel.setDisplayedMnemonic(newLabels.getString("cursor.size.mnemonic").charAt(0));
        cursorTrailLabel.setText(newLabels.getString("cursor.trail"));
        cursorTrailLabel.setDisplayedMnemonic(newLabels.getString("cursor.trail.mnemonic").charAt(0));

        noTrail.setText(newLabels.getString("no.trail"));
        medium.setText(newLabels.getString("medium"));
        longest.setText(newLabels.getString("longest"));

        standard.setText(newLabels.getString("standard"));
        large.setText(newLabels.getString("large"));
        xLarge.setText(newLabels.getString("x.large"));

        cursorColourButton.setMnemonic(newLabels.getString("cursor.colour.mnemonic").charAt(0));
        cursorColourButton.setText(newLabels.getString("cursor.colour"));

        magnificationCheckBox.setText(newLabels.getString("use.magnification"));
        magnificationCheckBox.setMnemonic(newLabels.getString("use.magnification.mnemonic").charAt(0));

        magnificationRateLabel.setText(newLabels.getString("magnification.rate"));
        magnificationRateLabel.setDisplayedMnemonic(newLabels.getString("magnification.rate.mnemonic").charAt(0));

        setNewButtonLabels();

        revalidate();
        repaint();
    }
  
    /**
     * Cleans up any outstanding dialogs.
     */
    protected void cleanUp() {
        if (colourChooserDialog != null)
            colourChooserDialog.dispose();
    }

    /**
     * Listens to the the colour buttons and spawns a colour chooser if activated.
     */
    public void actionPerformed(ActionEvent e) {		
        Color whichColour = ((ColourIcon) ((JButton) e.getSource()).getIcon()).colour;
        colourChooser = new JColorChooser(whichColour);
        colourChooserDialog = JColorChooser.createDialog(this, ((JButton) e.getSource()).getText(), true, colourChooser,  okListener, cancelListener);
    	   
        colourChooserDialog.show();
		
        if (colour != null) {
            ((ColourIcon) ((JButton) e.getSource()).getIcon()).colour = colour;
        }
        cursorColourButton.repaint();
    }

    /**
     * Set all the JPanel's components to their correct values corresponding to 
     * the user's XML preferences passed in through the constructor.
     */
    protected void setDomValues(Element highlightColor) {
        Element temp = DOMUtil.getNextSiblingElement(highlightColor);

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(SE_GENERIC_CURSOR_SIZE))) {	  
            cursorSizeSlider.setValue( (int) (Float.parseFloat(temp.getAttribute(VALUE)) * 10) );
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(SE_GENERIC_CURSOR_COLOUR))) {
            String cursorColourVal = temp.getAttribute(VALUE);
            ((ColourIcon) cursorColourButton.getIcon()).colour = ScreenEnhancement.getACCLIPColour(cursorColourVal);
            temp = DOMUtil.getNextSiblingElement(temp);			
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(SE_GENERIC_CURSOR_TRAILS))) {	  
            cursorTrailSlider.setValue( (int) (Float.parseFloat(temp.getAttribute(VALUE)) * 10) );
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(SE_GENERIC_TRACKING))) {
            magnificationCheckBox.setSelected(true);
            Element track = DOMUtil.getFirstChildElement(temp);
            if (track != null && track.getTagName().equals(xmlLabels.getString(SE_GENERIC_MOUSE))) {
                if (track.getAttribute(VALUE).equals("true"))
                    mouse.setSelected(true);
                else
                    mouse.setSelected(false);
                track = DOMUtil.getNextSiblingElement(track);
            }
            if (track != null && track.getTagName().equals(xmlLabels.getString(SE_GENERIC_CARET))) {
                if (track.getAttribute(VALUE).equals("true"))
                    caret.setSelected(true);
                else
                    caret.setSelected(false);
                track = DOMUtil.getNextSiblingElement(track);
            }
            if (track != null && track.getTagName().equals(xmlLabels.getString(SE_GENERIC_FOCUS))) {
                if (track.getAttribute(VALUE).equals("true"))
                    focus.setSelected(true);
                else
                    focus.setSelected(false);
            }

            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(SE_GENERIC_MAGNIFICATION))) {
            magnificationCheckBox.setSelected(true);
            magnificationRateSlider.setValue(Integer.parseInt(temp.getAttribute(VALUE)));
        }

    }

    /**
     * Construct the XML sub-tree for keyboard setup according to the user's current selections.
     * @return    Element    The root element of the new XML sub-tree created.
     */
    protected void addElementsTo(Document document) {
        Element temp;
        Element generic = DOMUtil.getFirstChildElement(document.getDocumentElement());
    
        temp = document.createElement(xmlLabels.getString(SE_GENERIC_CURSOR_SIZE));
        temp.setAttribute(VALUE, String.valueOf(cursorSizeSlider.getValue() / 10.0));
        generic.appendChild(temp);
    
        temp = document.createElement(xmlLabels.getString(SE_GENERIC_CURSOR_COLOUR));
        temp.setAttribute(VALUE, ScreenEnhancement.getACCLIPHex(((ColourIcon) cursorColourButton.getIcon()).colour));
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(SE_GENERIC_CURSOR_TRAILS));
        temp.setAttribute(VALUE, String.valueOf(cursorTrailSlider.getValue() / 10.0));
        generic.appendChild(temp);

        if (magnificationCheckBox.isSelected()) {
            temp = document.createElement(xmlLabels.getString(SE_GENERIC_TRACKING));
            generic.appendChild(temp);
            
            Element track = document.createElement(xmlLabels.getString(SE_GENERIC_MOUSE));
            if (mouse.isSelected())
                track.setAttribute(VALUE, "true");
            else
                track.setAttribute(VALUE, "false");
            temp.appendChild(track);
            
            track = document.createElement(xmlLabels.getString(SE_GENERIC_CARET));
            if (caret.isSelected())
                track.setAttribute(VALUE, "true");
            else
                track.setAttribute(VALUE, "false");
            temp.appendChild(track);
            
            track = document.createElement(xmlLabels.getString(SE_GENERIC_FOCUS));
            if (focus.isSelected())
                track.setAttribute(VALUE, "true");
            else
                track.setAttribute(VALUE, "false");
            temp.appendChild(track);
            
            temp = document.createElement(xmlLabels.getString(SE_GENERIC_MAGNIFICATION));
            temp.setAttribute(VALUE, String.valueOf(magnificationRateSlider.getValue()));
            generic.appendChild(temp);
        }

    }

    /**
     * Sets the value of the UI to its default state.
     */
    protected void doDefault() {

        mouse.setSelected(true);
        caret.setSelected(true);
        focus.setSelected(true);
        magnificationRateSlider.setValue(1);
        magnificationCheckBox.setSelected(false);

        ((ColourIcon) cursorColourButton.getIcon()).colour = Color.white;
        cursorColourButton.repaint();

        cursorSizeSlider.setValue(0);	
        cursorTrailSlider.setValue(0);
    }

    /**
     * Shows the previous dialog.
     */
    protected void doPrev() {
        pm.showPanel(screenEnhancement);
    }	

    /**
     * The colour icon for the colour chooser buttons.
     */
    class ColourIcon implements Icon {

        public Color colour;
				
        public int getIconWidth() {
            return 15;
        }

        public int getIconHeight() {
            return 15;
        }

        public ColourIcon(Color inColour) {
            super();
            colour = inColour;
        }

        public void paintIcon(Component c, Graphics g, int x, int y) {
            g.setColor(Color.black);
            g.fillRect(x, y, getIconWidth(), getIconHeight());
            g.setColor(colour);
            g.fillRect(x + 2, y + 2, getIconWidth() - 4, getIconHeight() - 4);
        }

    }

}
