/**
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 */   
package ca.utoronto.atrc.web4all.web4AllCardService;

import ca.utoronto.atrc.web4all.SmartCardLogFile;
import ca.utoronto.atrc.web4all.ControlHub;
import ca.utoronto.atrc.web4all.binding.*;
import opencard.core.*;
import opencard.core.service.*;
import opencard.core.event.*;
import opencard.core.terminal.*;
import opencard.core.terminal.CardTerminalRegistry;
import opencard.core.util.*;
import opencard.opt.util.*;
import opencard.opt.iso.fs.*;
import com.ibm.opencard.util.*;
import java.util.*;
import java.util.zip.*;
import java.io.*;
import org.w3c.dom.*;

public abstract class Web4AllCardService extends CardService { 

    protected Object monitor    = "synchronization monitor";
    protected byte[] selectMF;		// A command that selects the MF.
    protected byte[] selectDF;		// A command that selects a DF.
    protected byte[] selectEF;		// A command that selects a EF.
    protected byte[] updateBinary; // A command to update a binary file.
    protected byte[] readBinary;	// A command to read a binary file.
    protected byte[][] validResponses;	// An array of valid response codes.
    protected boolean validated;
    protected byte[] theATR;
    protected int buffSize;
    protected int maxAPDU;   	  
	 
    private boolean useLowMemory; // Enable or disable low memory binding.	 
    private LowMemoryXMLBinding lowMemBind; // The low memory binding adaptor.
	
    public Web4AllCardService() {
        super();
    }
	
    protected void initialize(CardServiceScheduler sched, SmartCard sc, boolean blocking) 
        throws CardServiceException {
        super.initialize(sched, sc, blocking);
        theATR = sc.getCardID().getATR();
        maxAPDU = theATR[4] & 0x000000ff;
        buffSize = maxAPDU - 6; // 6 = Header size (4) + LC (1) + LE (1)
    }
	
    public abstract boolean canInitialize();
	
    public abstract void initializeCard() throws OpenCardException;
	
    public abstract boolean validCard() throws OpenCardException;
	
    public String readPreferences() throws Exception {
        Web4AllPrefsFile pf;
        byte[] theCompressedData;
        byte[] theUncompressedData = new byte[8192];
        CardChannel theChannel;
        String preferences;
        try {
            allocateCardChannel();
            theChannel = getCardChannel();
            pf = new Web4AllPrefsFile(this, selectPrefsFile(theChannel));
            if (!pf.isInitialized()) {  
                pf.initialize(); // Should have been done already in InitializeCard.
            }
            theCompressedData = pf.readData();
            if (theCompressedData != null) {
                int compressedSize = theCompressedData.length;
                SmartCardLogFile.writeLog("Read " + compressedSize + " bytes of compressed data from preferences file.");
                ByteArrayInputStream bais = new ByteArrayInputStream(theCompressedData);
                Inflater inf = new Inflater();
                GZIPInputStream gz = new GZIPInputStream(new InflaterInputStream(bais, inf));
                //int br = gz.read(theUncompressedData, 0, 8192);
                preferences = getUncompressedString(gz);
                int expandedSize = preferences.length();
                double ratio = 0.0;
                if (expandedSize > 0) {
                    ratio = (double) compressedSize / (double) expandedSize;
                }
                //FIXME - format ratio.
                SmartCardLogFile.writeLog("Data expanded to " + expandedSize + " bytes.  Ratio is " + ratio);
                gz.close();
                bais.close();
                //String s = new String(theUncompressedData, 0, br);
                //return new String(s);
                SmartCardLogFile.writeLog("Preferences string read from card is\n" + preferences);
				
                // DO LOW-MEMORY BINDING!!!!
                //
                if (useLowMemory) {
                    XMLBindingAdaptor xmlBindAdaptor = XMLBindingAdaptor.getSharedInstance();				
                    preferences = xmlBindAdaptor.createBindingFromHash(preferences, lowMemBind.getLowHighTable(), false);
                }

                return preferences;
            }
            else {
                SmartCardLogFile.writeLog("No data found in preferences file.");
                return null;
            }
        }
        finally {
            releaseCardChannel();
        }
    }
	
    private String getUncompressedString(GZIPInputStream gz) throws IOException {
        byte[] buffer = new byte[4096];
        int pos = 0;
        int b;
        int limit = buffer.length;
        boolean done = false;
        while (true) {
            b = gz.read();
            if (b == -1) {
                break;
            }
            if (pos < limit) {
                buffer[pos++] = (byte) b;
            }
            else {
                byte[] newbuffer = new byte[2 * buffer.length];
                for (int i = 0; i < buffer.length; i++) {
                    newbuffer[i] = buffer[i];
                }
                newbuffer[pos++] = (byte) b;
                buffer = newbuffer;
                limit = limit * 2;
            }
        }
        return new String(buffer, 0, pos);
    }
	
    public void writePreferences(Document doc) throws Exception {
        String prefs = null;
        Web4AllPrefsFile pf;
        byte[] theRawData, theCompressedData;
        CardChannel theChannel;
        try {

            // DO LOW-MEMORY BIND!!!
            //
            if (useLowMemory) {
                XMLBindingAdaptor xmlBindAdaptor = XMLBindingAdaptor.getSharedInstance();
                doc = xmlBindAdaptor.createBindingFromHash(doc, lowMemBind.getHighLowTable());
            }
            prefs = XMLBindingAdaptor.serializeXML(doc, false);

            allocateCardChannel();
            theChannel = getCardChannel();
            pf = new Web4AllPrefsFile(this, selectPrefsFile(theChannel));
            if (!pf.isInitialized()) {  
                pf.initialize(); // Should have been done already in InitializeCard.
            }
            SmartCardLogFile.writeLog("Preferences string before write is\n" + prefs);
            theRawData = prefs.getBytes();
            int rawSize = theRawData.length;
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            Deflater df = new Deflater();
            GZIPOutputStream gz = new GZIPOutputStream(new DeflaterOutputStream(baos, df));
            gz.write(theRawData, 0, theRawData.length);
            gz.flush();
            gz.close();
            theCompressedData = baos.toByteArray();
            baos.close();
            int compressedSize = theCompressedData.length;
            double ratio = 0.0;
            if (rawSize > 0) {
                ratio = (double) compressedSize / (double) rawSize;
            }
            //FIXME - format ratio.
            SmartCardLogFile.writeLog("Data compressed to " + compressedSize + " from " + rawSize + ". Ratio is " + ratio);
            pf.writeData(theCompressedData);
            SmartCardLogFile.writeLog("Data written to preferences file.");
        }
        finally {
            releaseCardChannel();
        }
    }
	
    public int getBuffSize() {
        return buffSize;
    }
	
    public int getMaxAPDU() {
        return maxAPDU;
    }
	
    public boolean validResponse(byte sw1, byte sw2) {
        byte[] sw = new byte[2];
        sw[0] = sw1;
        sw[1] = sw2;
        return validResponse(sw);
    }
	
    public boolean validResponse(ResponseAPDU res) {
        return validResponse(res.sw1(), res.sw2());
    }
			
	
    public boolean validResponse(byte[] sw) {
        boolean valid = false;
        for (int i = 0; i < validResponses.length; i++) {
            if (ByteArray.equal(validResponses[i], sw)) {
                valid = true;
                break;
            }
        }
        return valid;
    }
	
    public abstract SelectFileResponse selectPrefsFile(CardChannel chan) throws OpenCardException;
		
    void testRead(int datalen) {
        CardChannel theChannel;
        CommandAPDU smf = new CommandAPDU(selectMF);
        CommandAPDU sdf = new CommandAPDU(selectDF);
        CommandAPDU sef = new CommandAPDU(selectEF);
        ResponseAPDU res;
        SelectFileResponse sfres;
        try {
            allocateCardChannel();
            theChannel = getCardChannel();
            if (theChannel != null) {
                sfres = selectPrefsFile(theChannel);
                System.out.println("FileSize is " + sfres.getFileSize());
                System.out.println("Length of selectEF ResponseADPU is " + sfres.getLength());
                System.out.println("Status from selectEeF ResponseADPU is " + HexString.hexifyShort(sfres.sw()));
                byte[] rbufr = new byte[datalen];
                for (int i = 0; i < datalen; i++) {
                    rbufr[i] = (byte) 0;
                }
                readEF(theChannel, sfres.getFileSize(), rbufr);
                System.out.println("Data read is\n" + HexString.hexify(rbufr));
            }
            else {
                //log message
            }
        }
        catch (Exception ex){
            //log message
            ex.printStackTrace(System.err);
        }
        finally {
            releaseCardChannel();
        }
    }
		
    void testWrite(int datalen) {
        CardChannel theChannel;
        CommandAPDU smf = new CommandAPDU(selectMF);
        CommandAPDU sdf = new CommandAPDU(selectDF);
        CommandAPDU sef = new CommandAPDU(selectEF);
        ResponseAPDU res;
        SelectFileResponse sfres;
        try {
            allocateCardChannel();
            theChannel = getCardChannel();
            if (theChannel != null) {
                System.out.println("Got CardChannel");
                sfres = selectPrefsFile(theChannel);
                byte[] wbufr = new byte[datalen];
                for (int i = 0; i < datalen; i++) {
                    wbufr[i] = (byte) (i % 256);
                }
                writeEF(theChannel, sfres.getFileSize(), wbufr);
            }
            else {
                //log
                System.err.println("Failed to get CardChannel");
            }
        }
        catch (Exception ex){
            ex.printStackTrace(System.err);
        }
        finally {
            releaseCardChannel();
        }
    }
	
    void writeEF(CardChannel theChannel, int fileSize, byte[] data, int os, int len) throws OpenCardException {
        if (len > fileSize) {
            throw new W4ACardServiceException("Data too big for file.");
        }
        ResponseAPDU res = null;
        short offset = (short) os;
        int writeLen;
        int dataLen = Math.min(Math.min(fileSize, data.length), len);
        int len1 = updateBinary.length + 1;
        int len2 = len1 + (dataLen >= buffSize ? buffSize : dataLen);
        byte[] ubapdu = new byte[len2 + 1];
        for (int i = 0; i < updateBinary.length; i++) {
            ubapdu[i] = updateBinary[i];
        }
        while (dataLen > 0) {
            ubapdu[2] = (byte) (offset >>> 8);
            ubapdu[3] = (byte) offset;
            writeLen = dataLen >= buffSize ? buffSize : dataLen;
            ubapdu[updateBinary.length] = (byte) writeLen;
            int dataPos = offset - os;
            for (int i = 0; i < writeLen; i++) {
                ubapdu[i + len1] = data[dataPos + i];
            }
            int apduLen = len1 + writeLen;
            ubapdu[apduLen] = (byte)0x00;
            CommandAPDU ubef = new CommandAPDU(ubapdu);
            ubef.setLength(apduLen); 
            res = theChannel.sendCommandAPDU(ubef);
            //if (validResponse(res.sw1(), res.sw2())) {
            if (!validResponse(res.sw1(), res.sw2())) {
                String msg = new String("Invalid write response code of " + 
					HexString.hexify(res.sw1())  + " " + HexString.hexify(res.sw2()));
                throw new W4ACardServiceException(msg);
            }
            offset += writeLen;
            dataLen -= writeLen;
        }
    }
	
    void writeEF(CardChannel theChannel, int fileSize, byte[] data) throws OpenCardException {
        writeEF(theChannel, fileSize, data, 0, data.length);
    }
	
    void readEF(CardChannel theChannel, int fileSize, byte[] data, int os, int len) throws OpenCardException {
        if (len > fileSize) {
            throw new W4ACardServiceException("Data too big for file.");
        }
        byte[] buffer;
        ResponseAPDU res = null;
        short offset = (short) os;
        int readLen;
        int dataLen = Math.min(Math.min(fileSize, data.length), len);
        int len1 = readBinary.length + 1;
        int len2 = len1 + (dataLen >= buffSize ? buffSize : dataLen);
        byte[] rbapdu = new byte[len1];
        for (int i = 0; i < readBinary.length; i++) {
            rbapdu[i] = readBinary[i];
        }
        while (dataLen > 0) {
            rbapdu[2] = (byte) (offset >>> 8);
            rbapdu[3] = (byte) offset;
            readLen = dataLen >= buffSize ? buffSize : dataLen;
            rbapdu[readBinary.length] = (byte) readLen;
            CommandAPDU rbef = new CommandAPDU(rbapdu);
            res = theChannel.sendCommandAPDU(rbef);
            if (validResponse(res.sw1(), res.sw2())) {
                buffer = res.getBytes();
                int dataPos = offset - os;
                for (int i = 0; i < readLen; i++) {
                    data[dataPos + i] = buffer[i];
                }
            }
            else {
                String msg = new String("Invalid read response code of " + 
					HexString.hexify(res.sw1())  + " " + HexString.hexify(res.sw2()));
                throw new W4ACardServiceException(msg);
            }
            offset += readLen;
            dataLen -= readLen;
        }
    }
	
    void readEF(CardChannel theChannel, int fileSize, byte[] data) throws OpenCardException {
        readEF(theChannel, fileSize, data, 0, data.length);
    }

    /**
     * Initialize the low memory binding settings.
     *
     * @param  w4a  reference to ControlHub
     * @param  useLowMemory  use low memory binding or not
     */
    public void initLowMemoryBind(ControlHub w4a, boolean useLowMemory) {

        this.useLowMemory = useLowMemory;

        if (useLowMemory) {
            String schemaFile = w4a.getGlobalProperty(ControlHub.SCHEMA_LOCATION_VAL);
            String lipContentypeFile = w4a.getGlobalProperty(ControlHub.LIP_CONTENTYPE_LOCATION_VAL);
            String homeDir = System.getProperty ("user.dir");
            String dirSep = System.getProperty ("file.separator");
			
            String schemaString = ControlHub.createXMLString(homeDir + dirSep + schemaFile);
            String lipContentypeString = ControlHub.createXMLString(homeDir + dirSep + lipContentypeFile);
			
            try {
                lowMemBind = new LowMemoryXMLBinding(schemaString);
                lowMemBind.addToBinding(lipContentypeString);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

}
