/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.net.URL;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

/**
 * Class which encapsulates the editing of a user's screen reader preferences.
 *
 * @author David Weinkauf
 * @version $Revision: 1.10 $, $Date: 2006/03/28 16:31:10 $
 */
public class ScreenReader extends PWMEditPanel {
  
    /**
     * The voice pitch slider value labels.
     */
    private JLabel pitchLow, pitchMedium, pitchHigh;

    /**
     * The voice volume slider value labels.
     */
    private JLabel volumeSoft, volumeMedium, volumeLoud;
  
    /**
     * The direction buttons.
     */
    private JButton prevButton, nextButton, defaultButton, cancelButton;

    /**
     * The voice volume slider.
     */
    private JSlider voiceVolumeSlider;

    /**
     * The voice pitch slider.
     */
    private JSlider voicePitchSlider;

    /**
     * The voice section title.
     */
    private TitledBorder voiceTitle;

    /**
     * The link label.
     */
    private JLabel linkLabel;

    /**
     * The link section title.
     */
    private TitledBorder linkTitle;

    /**
     * The four check boxes for the link value.
     */
    private JCheckBox differentVoice, speakLink, soundEffect;

    /**
     * The four title labels for the differenct sections.
     */
    private JLabel voiceSpeedLabel, voicePitchLabel, voiceVolumeLabel;
	
    /**
     * The words per minute text field.
     */
    private RangedTextField wpmField;

    /**
     * The XML Document sub-tree this dialog produces in a user's preferences.
     */
    private Document document;

    /**
     * The root element of the keypad default prefs under <screen_reader>.
     */
    private Element generic;

    /**
     * Sole constructor. Initializes all the UI components and displays them accordingly.
     * @param  pm  reference to the preference manager
     * @param  root  the root of the user's screen reader preferences
     * @param  inAppType  the application type
     */
    public ScreenReader(PreferenceManager pm, Element root, String inAppType) {
        super(pm, inAppType, inAppType + TITLE_SUFFIX);
    
        document = initDocument(root, xmlLabels.getString(SCREEN_READER), xmlLabels.getString(SR_GENERIC));
        generic = DOMUtil.getFirstChildElement(document.getDocumentElement());

        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.ScreenReader", pm.language);
        ResourceBundle voiceLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Voice", pm.language);
        ResourceBundle hashLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.HashTables", pm.language);
    
        // Setup the panel!!!

        differentVoice = new JCheckBox(labels.getString("different.voice"));
        differentVoice.setMnemonic(labels.getString("different.voice.mnemonic").charAt(0));
        differentVoice.setBackground(PANEL_BACKGROUND);
        differentVoice.setSelected(false);

        speakLink = new JCheckBox(labels.getString("speak.link"));
        speakLink.setMnemonic(labels.getString("speak.link.mnemonic").charAt(0));
        speakLink.setBackground(PANEL_BACKGROUND);
        speakLink.setSelected(true);

        soundEffect = new JCheckBox(labels.getString("sound.effect"));
        soundEffect.setMnemonic(labels.getString("sound.effect.mnemonic").charAt(0));
        soundEffect.setBackground(PANEL_BACKGROUND);
        soundEffect.setSelected(false);

        linkLabel = new JLabel(labels.getString("link"));
        linkLabel.setFont(TEXT_FONT);
        linkLabel.setForeground(TEXT_COLOUR);

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel linkGridPanel = new JPanel();
        linkGridPanel.setBackground(PANEL_BACKGROUND);
        linkGridPanel.setLayout(gridbag);

        Insets insets = new Insets(5, 5, 5, 5);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.weighty = 0.5;
        c.gridheight = 1;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.5;
        linkGridPanel.add(linkLabel, c);

        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0.5;
        linkGridPanel.add(speakLink, c);

        c.gridx = 2;
        c.gridy = 0;
        c.weightx = 0.5;
        linkGridPanel.add(differentVoice, c);

        c.gridx = 3;
        c.gridy = 0;
        c.weightx = 0.5;
        linkGridPanel.add(soundEffect, c);

        linkTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("link.title"));
        linkTitle.setTitleColor(BORDER_TITLE_COLOUR);
        linkTitle.setTitleFont(BORDER_TITLE_FONT);
    
        JPanel identifyLinkPanel = new JPanel(new GridLayout(1, 1));
        identifyLinkPanel.setBorder(linkTitle);
        identifyLinkPanel.setBackground(PANEL_BACKGROUND);
        identifyLinkPanel.add(linkGridPanel);

        AccessibleContext ac = linkLabel.getAccessibleContext();
        ac.setAccessibleParent(identifyLinkPanel);
        ac = speakLink.getAccessibleContext();
        ac.setAccessibleParent(identifyLinkPanel);
        ac = differentVoice.getAccessibleContext();
        ac.setAccessibleParent(identifyLinkPanel);
        ac = soundEffect.getAccessibleContext();
        ac.setAccessibleParent(identifyLinkPanel);
        
        this.add(identifyLinkPanel);
        this.add(Box.createVerticalGlue());

        JTextField textField = new JTextField(5);
        textField.setFont(TEXT_FONT);

        wpmField = new RangedTextField(new Integer(1), new Integer(1000), textField);
        wpmField.setText("160");

        voiceSpeedLabel = new JLabel(voiceLabels.getString("voice.speed"));
        voiceSpeedLabel.setDisplayedMnemonic(voiceLabels.getString("voice.speed.mnemonic").charAt(0));
        voiceSpeedLabel.setLabelFor(wpmField.textField);
        voiceSpeedLabel.setForeground(TEXT_COLOUR);
        voiceSpeedLabel.setFont(TEXT_FONT);
    
        JPanel wpmPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        wpmPanel.setBackground(PANEL_BACKGROUND);
        wpmPanel.add(voiceSpeedLabel);
        wpmPanel.add(wpmField.textField);
		
        Hashtable voicePitchHash = new Hashtable();
        pitchLow = new JLabel(hashLabels.getString("low"));
        pitchLow.setForeground(TEXT_COLOUR);
        pitchMedium = new JLabel(hashLabels.getString("medium"));
        pitchMedium.setForeground(TEXT_COLOUR);
        pitchHigh = new JLabel(hashLabels.getString("high"));
        pitchHigh.setForeground(TEXT_COLOUR);
        voicePitchHash.put(new Integer(0), pitchLow);
        voicePitchHash.put(new Integer(5), pitchMedium);
        voicePitchHash.put(new Integer(10), pitchHigh);
    
        voicePitchSlider = new JSlider(SwingConstants.HORIZONTAL, 0, 10, 5);
        voicePitchSlider.setBackground(PANEL_BACKGROUND);
        voicePitchSlider.setForeground(TEXT_COLOUR);
        voicePitchSlider.setPaintLabels(true);
        voicePitchSlider.setLabelTable(voicePitchHash);
        voicePitchSlider.setMajorTickSpacing(5);
        voicePitchSlider.setMinorTickSpacing(1);
        voicePitchSlider.setSnapToTicks(true);
        voicePitchSlider.setPaintTicks(true);
    
        voicePitchLabel = new JLabel(voiceLabels.getString("voice.pitch"));
        voicePitchLabel.setDisplayedMnemonic(voiceLabels.getString("voice.pitch.mnemonic").charAt(0));
        voicePitchLabel.setLabelFor(voicePitchSlider);
        voicePitchLabel.setForeground(TEXT_COLOUR);
        voicePitchLabel.setFont(TEXT_FONT);
    
        Hashtable voiceVolumeHash = new Hashtable();
        volumeSoft = new JLabel(hashLabels.getString("soft"));
        volumeSoft.setForeground(TEXT_COLOUR);
        volumeMedium = new JLabel(hashLabels.getString("medium"));
        volumeMedium.setForeground(TEXT_COLOUR);
        volumeLoud = new JLabel(hashLabels.getString("loud"));
        volumeLoud.setForeground(TEXT_COLOUR);
        voiceVolumeHash.put(new Integer(0), volumeSoft);
        voiceVolumeHash.put(new Integer(5), volumeMedium);
        voiceVolumeHash.put(new Integer(10), volumeLoud);
    
        voiceVolumeSlider = new JSlider(SwingConstants.HORIZONTAL, 0, 10, 5);
        voiceVolumeSlider.setBackground(PANEL_BACKGROUND);
        voiceVolumeSlider.setForeground(TEXT_COLOUR);
        voiceVolumeSlider.setPaintLabels(true);
        voiceVolumeSlider.setLabelTable(voiceVolumeHash);
        voiceVolumeSlider.setMajorTickSpacing(5);
        voiceVolumeSlider.setMinorTickSpacing(1);
        voiceVolumeSlider.setSnapToTicks(true);
        voiceVolumeSlider.setPaintTicks(true);
    
        voiceVolumeLabel = new JLabel(voiceLabels.getString("voice.volume"));
        voiceVolumeLabel.setDisplayedMnemonic(voiceLabels.getString("voice.volume.mnemonic").charAt(0));
        voiceVolumeLabel.setLabelFor(voiceVolumeSlider);
        voiceVolumeLabel.setForeground(TEXT_COLOUR);
        voiceVolumeLabel.setFont(TEXT_FONT);
    
        gridbag = new GridBagLayout();
        c = new GridBagConstraints();
        JPanel voiceGridPanel = new JPanel();
        voiceGridPanel.setBackground(PANEL_BACKGROUND);
        voiceGridPanel.setLayout(gridbag);

        insets = new Insets(5, 5, 5, 5);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.weighty = 0.5;
        c.gridheight = 1;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        voiceGridPanel.add(voicePitchLabel, c);

        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0.5;
        voiceGridPanel.add(voicePitchSlider, c);

        c.gridx = 0;
        c.gridy = 1;
        c.weightx = 0.0;
        voiceGridPanel.add(voiceVolumeLabel, c);

        c.gridx = 1;
        c.gridy = 1;
        c.weightx = 0.5;
        voiceGridPanel.add(voiceVolumeSlider, c);

        voiceTitle = new TitledBorder(BORDER_TITLE_LINE, voiceLabels.getString("voice.title"));
        voiceTitle.setTitleFont(BORDER_TITLE_FONT);
        voiceTitle.setTitleColor(BORDER_TITLE_COLOUR);

        JPanel voiceSliderPanel = new JPanel(new GridLayout(1, 1));
        voiceSliderPanel.setBackground(PANEL_BACKGROUND);
        voiceSliderPanel.add(voiceGridPanel);

        JPanel voicePanel = new JPanel();
        voicePanel.setLayout(new BoxLayout(voicePanel, BoxLayout.Y_AXIS));
        voicePanel.setBorder(voiceTitle);
        voicePanel.setBackground(PANEL_BACKGROUND);
        voicePanel.add(wpmPanel);
        voicePanel.add(voiceSliderPanel);

        ac = voiceSpeedLabel.getAccessibleContext();
        ac.setAccessibleParent(voicePanel);
        ac = wpmField.textField.getAccessibleContext();
        ac.setAccessibleParent(voicePanel);
        ac = voicePitchLabel.getAccessibleContext();
        ac.setAccessibleParent(voicePanel);
        ac = voicePitchSlider.getAccessibleContext();
        ac.setAccessibleParent(voicePanel);
        ac = voiceVolumeLabel.getAccessibleContext();
        ac.setAccessibleParent(voicePanel);
        ac = voiceVolumeSlider.getAccessibleContext();
        ac.setAccessibleParent(voicePanel);

        this.add(voicePanel);
        this.add(Box.createVerticalGlue());

    }

    /**
     * Sets all the JPanel labels to the current PreferenceManager.language value.
     */
    protected void setNewLabels() {
        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.ScreenReader", pm.language);
        ResourceBundle newHashLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.HashTables", pm.language);
        ResourceBundle newVoiceLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Voice", pm.language);
    
        differentVoice.setText(newLabels.getString("different.voice"));
        differentVoice.setMnemonic(newLabels.getString("different.voice.mnemonic").charAt(0));
        speakLink.setText(newLabels.getString("speak.link"));
        speakLink.setMnemonic(newLabels.getString("speak.link.mnemonic").charAt(0));
        soundEffect.setText(newLabels.getString("sound.effect"));
        soundEffect.setMnemonic(newLabels.getString("sound.effect.mnemonic").charAt(0));

        linkTitle.setTitle(newLabels.getString("link.title"));
        linkLabel.setText(newLabels.getString("link"));

        voiceSpeedLabel.setText(newVoiceLabels.getString("voice.speed"));
        voiceSpeedLabel.setDisplayedMnemonic(newVoiceLabels.getString("voice.speed.mnemonic").charAt(0));
        pitchLow.setText(newHashLabels.getString("low"));
        pitchMedium.setText(newHashLabels.getString("medium"));
        pitchHigh.setText(newHashLabels.getString("high"));
        voicePitchLabel.setText(newVoiceLabels.getString("voice.pitch"));
        voicePitchLabel.setDisplayedMnemonic(newVoiceLabels.getString("voice.pitch.mnemonic").charAt(0));
        volumeSoft.setText(newHashLabels.getString("soft"));
        volumeMedium.setText(newHashLabels.getString("medium"));
        volumeLoud.setText(newHashLabels.getString("loud"));
        voiceVolumeLabel.setText(newVoiceLabels.getString("voice.volume"));
        voiceVolumeLabel.setDisplayedMnemonic(newVoiceLabels.getString("voice.volume.mnemonic").charAt(0));
    
        voiceTitle.setTitle(newVoiceLabels.getString("voice.title"));

        wpmField.reformat();

        setNewButtonLabels();

        revalidate();
        repaint();
    
    }

    /**
     * Sets all the JPanel's components to their correct values corresponding to 
     * the user's XML preferences passed in through the constructor.
     */
    protected void setDomValues() {
        Element temp = DOMUtil.getFirstChildElement(generic);

        speakLink.setSelected(false);
        differentVoice.setSelected(false);
        soundEffect.setSelected(false);

        while (temp != null && temp.getTagName().equals(xmlLabels.getString(SR_GENERIC_LINK))) {
            if (temp.getAttribute(VALUE).equals("speakLink"))
                speakLink.setSelected(true);
            else if (temp.getAttribute(VALUE).equals("differentVoice"))
                differentVoice.setSelected(true);
            else if (temp.getAttribute(VALUE).equals("soundEffect"))
                soundEffect.setSelected(true);
            else if (temp.getAttribute(VALUE).equals("none")) {
                speakLink.setSelected(false);
                differentVoice.setSelected(false);
                soundEffect.setSelected(false);
            }

            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(SR_GENERIC_SPEECH_RATE))) {
            wpmField.setText(temp.getAttribute(VALUE));
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(SR_GENERIC_PITCH))) {
            voicePitchSlider.setValue( (int) (Float.parseFloat(temp.getAttribute(VALUE)) * 10) );
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(SR_GENERIC_VOLUME))) {
            voiceVolumeSlider.setValue( (int) (Float.parseFloat(temp.getAttribute(VALUE)) * 10) );
        }

    }

    /**
     * Constructs the XML sub-tree for keyboard setup according to the user's current selections.
     *
     * @return    Element    The root element of the new XML sub-tree created.
     */
    protected Element getRootElement() {
        Element temp;

        PreferenceManager.removeAllChildren(generic);
    
        if (!speakLink.isSelected() &&
            !differentVoice.isSelected() &&
            !soundEffect.isSelected()) {
            temp = document.createElement(xmlLabels.getString(SR_GENERIC_LINK));
            temp.setAttribute(VALUE, "none");
            generic.appendChild(temp);
        }
        else {
            if (speakLink.isSelected()) {
                temp = document.createElement(xmlLabels.getString(SR_GENERIC_LINK));
                temp.setAttribute(VALUE, "speakLink");
                generic.appendChild(temp);
            }
            if (differentVoice.isSelected()) {
                temp = document.createElement(xmlLabels.getString(SR_GENERIC_LINK));
                temp.setAttribute(VALUE, "differentVoice");
                generic.appendChild(temp);
            }
            if (soundEffect.isSelected()) {
                temp = document.createElement(xmlLabels.getString(SR_GENERIC_LINK));
                temp.setAttribute(VALUE, "soundEffect");
                generic.appendChild(temp);
            }
        }
    
        temp = document.createElement(xmlLabels.getString(SR_GENERIC_SPEECH_RATE));
        temp.setAttribute(VALUE, wpmField.getValue());
        generic.appendChild(temp);
    
        temp = document.createElement(xmlLabels.getString(SR_GENERIC_PITCH));
        temp.setAttribute(VALUE, String.valueOf(voicePitchSlider.getValue() / 10.0));
        generic.appendChild(temp);
    
        temp = document.createElement(xmlLabels.getString(SR_GENERIC_VOLUME));
        temp.setAttribute(VALUE, String.valueOf( voiceVolumeSlider.getValue() / 10.0));
        generic.appendChild(temp);
    
        return document.getDocumentElement();
    }

    /**
     * Sets the UI widgets to their default position.
     */
    protected void doDefault() {
        speakLink.setSelected(true);
        soundEffect.setSelected(false);
        differentVoice.setSelected(false);
        wpmField.setText("160");
        voicePitchSlider.setValue(5);
        voiceVolumeSlider.setValue(5);		
    }

    /**
     * Shows the next panel.
     */
    protected void doNext() {
        ResourceBundle voiceLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Voice", pm.language);

        if (!wpmField.isInsideRange())
            pm.doRangeWarning(wpmField.getLowValue(), 
                              wpmField.getHighValue(), 
                              voiceLabels.getString("voice.speed"));
        else
            super.doNext();
    }

    /**
     * Gets the entire app type XML subtree including default preferences and third party preferences.
     * @return  the screen reader preferences
     */
    protected Document getAppTypeDoc() {
        return document;
    }


}
