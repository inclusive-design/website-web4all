/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.net.URL;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;
import org.apache.xpath.*;
import javax.xml.transform.TransformerException;
import javax.accessibility.AccessibleContext;

/**
 * Class which encapsulates all the switch settings for an onscreen keyboard.
 *
 * @author David Weinkauf
 * @version $Revision: 1.11 $, $Date: 2006/03/28 16:31:10 $
 */
public class OnscreenKeyboard2 extends PWMEditPanel {
    
    /**
     * The array of all the switch items.
     */
    private ComboBoxItem[] switches;

    /**
     * The switch input label.
     */
    private JLabel switchInputLabel;

    /**
     * The switch title.
     */
    private TitledBorder switchInputTitle;

    /**
     * The input type combo box.
     */
    private JComboBox switchInputType;

    /**
     * The input type items.
     */
    private ComboBoxItem mouse, game, serial, usb, firewire, infrared, bluetooth;

    /**
     * The number of switches combo box.
     */
    private JComboBox numSwitchesComboBox;

    /**
     * The number of switches label.
     */
    private JLabel numSwitches;

    /**
     * The array of all the switch combo boxes.
     */
    private JComboBox[] switchComboBoxes;

    /**
     * The array of group/item scanning types.
     */
    private ComboBoxItem[] groupItems;

    /**
     * The array of directed scanning types.
     */
    private ComboBoxItem[] directeds;

    /**
     * The array of selected scanning types.
     */
    private ComboBoxItem[] selectedItems;

    /**
     * The 'Unused' item.
     */
    private ComboBoxItem unused;

    /**
     * The maximum number of switches.
     */
    private static final int MAX_SWITCHES = 5;

    /**
     * The panel which houses the switch number combo boxes and its explanation.
     */
    private JPanel switchPanel, switchNotificationPanel;
	
    /**
     * The switch assignment title.
     */
    private TitledBorder switchAssignmentTitle;

    /**
     * The dwell time label.
     */
    private JLabel dwellTime;

    /**
     * The dwell time check box.
     */
    private JCheckBox dwellTimeCheckBox;

    /**
     * The dwell time panel.
     */
    private JPanel dwellTimePanel;

    /**
     * The dwell time field.
     */
    private RangedTextField dwellTimeField;

    /**
     * The dwell field panel.
     */
    private JPanel dwellFieldPanel;

    /**
     * The switch assignment items.
     */
    private ComboBoxItem select, cancel, scan, up, down, left, right, horizontal, vertical;

    /**
     * The directional buttons.
     */
    private JButton prevButton, nextButton, defaultButton, cancelButton;

    /**
     * The selection method item.
     */
    private ComboBoxItem selectItem;

    /**
     * The first onscreen keyboard dialog.
     */
    private OnscreenKeyboard onscreenKeyboard1;
  
    /**
     * The third onscreen keyboard dialog.
     */
    private OnscreenKeyboard3 onscreenKeyboard3;

    private JPanel switchAssignmentPanel;
    
    /**
     * Sole constructor. Initializes all the components in the dialog and displays them accordingly.
     *
     * @param  pm  reference to the PreferenceManager
     * @param  inOnscreenKeyboard1  reference to the first onscreen keyboard dialog
     * @param  inAppType  the app type ID
     * @param  inTitleKey  the title key
     */
    public OnscreenKeyboard2(PreferenceManager pm, OnscreenKeyboard inOnscreenKeyboard1, String inAppType, String inTitleKey) {
        super(pm, inAppType, inTitleKey);

        this.onscreenKeyboard1 = inOnscreenKeyboard1;

        onscreenKeyboard3 = new OnscreenKeyboard3(pm, this, inAppType, titleKey);

        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.OnscreenKeyboard", pm.language);

        mouse = new ComboBoxItem(labels.getString("mouse"), "mouse");
        game = new ComboBoxItem(labels.getString("game"), "game");
        serial = new ComboBoxItem(labels.getString("serial"), "serial");
        usb = new ComboBoxItem(labels.getString("usb"), "usb");
        firewire = new ComboBoxItem(labels.getString("firewire"), "firewire");
        infrared = new ComboBoxItem(labels.getString("infrared"), "infrared");
        bluetooth = new ComboBoxItem(labels.getString("bluetooth"), "bluetooth");

        ComboBoxItem[] tempSwitches = {mouse, game, serial, usb, firewire, infrared, bluetooth};
        switches = tempSwitches;

        switchInputType = new JComboBox(switches);
        switchInputType.setBackground(PANEL_BACKGROUND);
		
        switchInputLabel = new JLabel(labels.getString("switch.input"));
        switchInputLabel.setFont(TEXT_FONT);
        switchInputLabel.setForeground(TEXT_COLOUR);
        switchInputLabel.setLabelFor(switchInputType);
        switchInputLabel.setDisplayedMnemonic(labels.getString("switch.input.mnemonic").charAt(0));

        String[] numSwitchesItems = new String[MAX_SWITCHES];		
        for (int i = 0; i < MAX_SWITCHES; i++) {
            numSwitchesItems[i] = String.valueOf(i + 1);
        }

        numSwitchesComboBox = new JComboBox(numSwitchesItems);
        numSwitchesComboBox.setForeground(TEXT_COLOUR);
        numSwitchesComboBox.setFont(TEXT_FONT);
        numSwitchesComboBox.setBackground(PANEL_BACKGROUND);
    
        numSwitches = new JLabel(labels.getString("num.switches"));
        numSwitches.setDisplayedMnemonic(labels.getString("num.switches.mnemonic").charAt(0));
        numSwitches.setLabelFor(numSwitchesComboBox);
        numSwitches.setFont(TEXT_FONT);
        numSwitches.setForeground(TEXT_COLOUR);

        dwellTimeCheckBox = new JCheckBox(labels.getString("dwell.time.question"));
        dwellTimeCheckBox.setMnemonic(labels.getString("dwell.time.question.mnemonic").charAt(0));
        dwellTimeCheckBox.setBackground(PANEL_BACKGROUND);
        dwellTimeCheckBox.setSelected(false);
        dwellTimeCheckBox.addItemListener(new DwellTimeListener());

        JTextField textField = new JTextField(5);
        textField.setFont(TEXT_FONT);

        dwellTimeField = new RangedTextField(new Float(0.0), new Float(3.0), textField);
        dwellTimeField.setText("0.5");
        dwellTimeField.textField.setEnabled(false);
		
        dwellTime = new JLabel(labels.getString("dwell.time"));
        dwellTime.setDisplayedMnemonic(labels.getString("dwell.time.mnemonic").charAt(0));
        dwellTime.setLabelFor(dwellTimeField.textField);
        dwellTime.setFont(TEXT_FONT);
        dwellTime.setForeground(TEXT_COLOUR);
        dwellTime.setEnabled(false);		

        dwellFieldPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        dwellFieldPanel.setBackground(PANEL_BACKGROUND);
        dwellFieldPanel.add(dwellTime);
        dwellFieldPanel.add(dwellTimeField.textField);

        switchInputTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("switch.input.title"));
        switchInputTitle.setTitleFont(BORDER_TITLE_FONT);
        switchInputTitle.setTitleColor(BORDER_TITLE_COLOUR);

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel switchInputGridPanel = new JPanel();
        switchInputGridPanel.setBackground(PANEL_BACKGROUND);
        switchInputGridPanel.setLayout(gridbag);

        Insets insets = new Insets(5, INDENT_VALUE, 5, 5);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        switchInputGridPanel.add(switchInputLabel, c);

        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0.0;
        switchInputGridPanel.add(switchInputType, c);

        c.gridx = 2;
        c.gridy = 0;
        c.weightx = 0.5;
        switchInputGridPanel.add(Box.createHorizontalStrut(1), c);

        c.gridx = 0;
        c.gridy = 1;
        c.weightx = 0.0;
        switchInputGridPanel.add(numSwitches, c);

        c.gridx = 1;
        c.gridy = 1;
        c.weightx = 0.0;
        switchInputGridPanel.add(numSwitchesComboBox, c);

        c.gridx = 0;
        c.gridy = 2;
        c.weightx = 0.0;
        switchInputGridPanel.add(dwellTimeCheckBox, c);

        c.gridx = 1;
        c.gridy = 2;
        c.weightx = 0.0;
        switchInputGridPanel.add(dwellFieldPanel, c);
		
        JPanel topPanel = new JPanel(new GridLayout(1, 1));
        topPanel.setBackground(PANEL_BACKGROUND);
        topPanel.setBorder(switchInputTitle);
        topPanel.add(switchInputGridPanel);		

        AccessibleContext ac = switchInputLabel.getAccessibleContext();
        ac.setAccessibleParent(topPanel);
        ac = switchInputType.getAccessibleContext();
        ac.setAccessibleParent(topPanel);
        ac = numSwitches.getAccessibleContext();
        ac.setAccessibleParent(topPanel);
        ac = numSwitchesComboBox.getAccessibleContext();
        ac.setAccessibleParent(topPanel);
        ac = dwellTimeCheckBox.getAccessibleContext();
        ac.setAccessibleParent(topPanel);
        ac = dwellTime.getAccessibleContext();
        ac.setAccessibleParent(topPanel);
        ac = dwellTimeField.textField.getAccessibleContext();
        ac.setAccessibleParent(topPanel);        

        this.add(topPanel);
        this.add(Box.createVerticalGlue());

        unused = new ComboBoxItem(labels.getString("unused"), "unused");

        select = new ComboBoxItem(labels.getString("select"), "select");
        cancel = new ComboBoxItem(labels.getString("cancel"), "cancel");
        scan = new ComboBoxItem(labels.getString("scan"), "scan");

        up = new ComboBoxItem(labels.getString("up"), "up");
        down = new ComboBoxItem(labels.getString("down"), "down");
        left = new ComboBoxItem(labels.getString("left"), "left");
        right = new ComboBoxItem(labels.getString("right"), "right");
        horizontal = new ComboBoxItem(labels.getString("horizontal"), "horizontal");
        vertical = new ComboBoxItem(labels.getString("vertical"), "vertical");

        ComboBoxItem[] tempGroupItems = { unused, select, scan, cancel };
        groupItems = tempGroupItems;

        ComboBoxItem[] tempDirecteds = { unused, select, scan, up, down, left, right, horizontal, vertical, cancel };
        directeds = tempDirecteds;

        switchPanel = new JPanel(new GridLayout(MAX_SWITCHES, 1));
        switchPanel.setBackground(PANEL_BACKGROUND);

        switchNotificationPanel = new JPanel();
        switchNotificationPanel.setLayout(new BoxLayout(switchNotificationPanel, BoxLayout.Y_AXIS));
        switchNotificationPanel.setBackground(PANEL_BACKGROUND);

        switchComboBoxes = new JComboBox[MAX_SWITCHES];
			
        switchAssignmentTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("switch.assignment.title"));
        switchAssignmentTitle.setTitleFont(BORDER_TITLE_FONT);
        switchAssignmentTitle.setTitleColor(BORDER_TITLE_COLOUR);

        gridbag = new GridBagLayout();
        c = new GridBagConstraints();
        JPanel switchGridPanel = new JPanel();
        switchGridPanel.setBackground(PANEL_BACKGROUND);
        switchGridPanel.setLayout(gridbag);

        insets = new Insets(5, INDENT_VALUE, 5, 5);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        switchGridPanel.add(switchPanel, c);

        c.anchor = GridBagConstraints.NORTHWEST;
        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 1.0;
        switchGridPanel.add(switchNotificationPanel, c);

        switchAssignmentPanel = new JPanel(new GridLayout(1, 1));
        switchAssignmentPanel.setBackground(PANEL_BACKGROUND);
        switchAssignmentPanel.setBorder(switchAssignmentTitle);

        switchAssignmentPanel.add(switchGridPanel);

        numSwitchesComboBox.addItemListener(new NumSwitchListener());		

        this.add(switchAssignmentPanel);
    }

    /**
     * Checks whether or not switches are used - hence, whether or not this panel is needed.
     *
     * @return  are switches used in this user's preference
     */
    protected boolean isSwitchUsed() {

        if (selectItem.value.equals(xmlLabels.getString(OK_GENERIC_DIRECTED_SCAN)) || selectItem.value.equals(xmlLabels.getString(OK_GENERIC_INVERSE_SCAN)) || selectItem.value.equals(xmlLabels.getString(OK_GENERIC_AUTO_SCAN)))
            return true;

        return false;
    }

    /**
     * Sets up the notification panel.
     */
    private void setUpNotification(ResourceBundle labels) {

        switchNotificationPanel.removeAll();

        JLabel selectionMethodLabel = new JLabel(labels.getString("select.method.value") + " " + selectItem.name);
        selectionMethodLabel.setFont(TEXT_FONT);
        selectionMethodLabel.setForeground(TEXT_COLOUR);

        JPanel selectionMethodPanel = new JPanel();
        selectionMethodPanel.setLayout(new BoxLayout(selectionMethodPanel, BoxLayout.X_AXIS));
        selectionMethodPanel.setBackground(PANEL_BACKGROUND);
        selectionMethodPanel.add(selectionMethodLabel);
        selectionMethodPanel.add(Box.createHorizontalGlue());
		
        switchNotificationPanel.add(selectionMethodPanel);

        AccessibleContext ac = selectionMethodLabel.getAccessibleContext();
        ac.setAccessibleParent(switchAssignmentPanel);

        JLabel noteLabel = new JLabel(labels.getString(selectItem.value + ".note"));
        noteLabel.setFont(TEXT_FONT);
        noteLabel.setForeground(TEXT_COLOUR);

        JPanel notePanel = new JPanel();
        notePanel.setLayout(new BoxLayout(notePanel, BoxLayout.X_AXIS));
        notePanel.setBackground(PANEL_BACKGROUND);
        notePanel.add(noteLabel);		
        notePanel.add(Box.createHorizontalGlue());

        ac = noteLabel.getAccessibleContext();
        ac.setAccessibleParent(switchAssignmentPanel);
        
        JPanel notePanel2 = null;
        JPanel notePanel3 = null;
        JLabel noteLabel2 = null;
        JLabel noteLabel3 = null;
        try {
            noteLabel2 = new JLabel(labels.getString(selectItem.value + ".note2"));
            noteLabel2.setFont(TEXT_FONT);
            noteLabel2.setForeground(TEXT_COLOUR);

            notePanel2 = new JPanel();
            notePanel2.setLayout(new BoxLayout(notePanel2, BoxLayout.X_AXIS));
            notePanel2.setBackground(PANEL_BACKGROUND);
            notePanel2.add(noteLabel2);		
            notePanel2.add(Box.createHorizontalGlue());

            noteLabel3 = new JLabel(labels.getString(selectItem.value + ".note3"));
            noteLabel3.setFont(TEXT_FONT);
            noteLabel3.setForeground(TEXT_COLOUR);

            notePanel3 = new JPanel();
            notePanel3.setLayout(new BoxLayout(notePanel3, BoxLayout.X_AXIS));
            notePanel3.setBackground(PANEL_BACKGROUND);
            notePanel3.add(noteLabel3);		
            notePanel3.add(Box.createHorizontalGlue());

        } catch (MissingResourceException mre) {
            ;
        }

        switchNotificationPanel.add(notePanel);
        if (notePanel2 != null) {
            switchNotificationPanel.add(notePanel2);			
            ac = noteLabel2.getAccessibleContext();
            ac.setAccessibleParent(switchAssignmentPanel);
        }

        if (notePanel3 != null) {
            switchNotificationPanel.add(notePanel3);			
            ac = noteLabel3.getAccessibleContext();
            ac.setAccessibleParent(switchAssignmentPanel);
        }

    }

    /**
     * Initializes the switches according to the user selection method.
     */
    protected void setUpSwitches(ComboBoxItem selectItem) {

        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.OnscreenKeyboard", pm.language);		

        if (this.selectItem == selectItem) {
            if (isSwitchUsed())
                setUpNotification(labels);			
            return;
        }

        this.selectItem = selectItem;		

        if (!isSwitchUsed()) {
            return;
        }

        setUpNotification(labels);

        switchPanel.removeAll();

        int num_switch = Integer.parseInt((String) numSwitchesComboBox.getSelectedItem());

        SwitchListener sl = new SwitchListener();
        JLabel comboLabel;
        JPanel comboPanel;
        for (int i = 0; i < MAX_SWITCHES; i++) {
            comboLabel = new JLabel(String.valueOf(i + 1));
            comboLabel.setFont(TEXT_FONT);
            comboLabel.setForeground(TEXT_COLOUR);
            comboLabel.setDisplayedMnemonic(String.valueOf(i + 1).charAt(0));

            if (selectItem.value.equals(xmlLabels.getString(OK_GENERIC_DIRECTED_SCAN))) {
                switchComboBoxes[i] = new JComboBox(directeds);
            } else {
                switchComboBoxes[i] = new JComboBox(groupItems);
            }

            if (i == 0) {
                if (selectItem.value.equals(xmlLabels.getString(OK_GENERIC_DIRECTED_SCAN))) {
                    switchComboBoxes[i].setSelectedItem(scan);
                } else if (selectItem.value.equals(xmlLabels.getString(OK_GENERIC_INVERSE_SCAN))) {
                    switchComboBoxes[i].setSelectedItem(scan);
                } else if (selectItem.value.equals(xmlLabels.getString(OK_GENERIC_AUTO_SCAN))) {
                    switchComboBoxes[i].setSelectedItem(select);
                }
            }
				

            switchComboBoxes[i].setForeground(TEXT_COLOUR);
            switchComboBoxes[i].setFont(TEXT_FONT);
            switchComboBoxes[i].setBackground(PANEL_BACKGROUND);
            switchComboBoxes[i].addItemListener(sl);
            comboLabel.setLabelFor(switchComboBoxes[i]);

            comboPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            comboPanel.setBackground(PANEL_BACKGROUND);
            comboPanel.add(comboLabel);
            comboPanel.add(switchComboBoxes[i]);
			
            if (i >= num_switch) {
                switchComboBoxes[i].setEnabled(false);
            }

            switchPanel.add(comboPanel);

            AccessibleContext ac = switchComboBoxes[i].getAccessibleContext();
            ac.setAccessibleParent(switchAssignmentPanel);
        }

        if (selectItem.value.equals(xmlLabels.getString(OK_GENERIC_AUTO_SCAN))) {
            dwellTimeCheckBox.setSelected(false);
            dwellTimeCheckBox.setEnabled(false);
        } else {
            dwellTimeCheckBox.setEnabled(true);
        }
		
        doSwitchValueDefault();

    }
		

    /**
     * Sets all the JPanel's components to their correct values corresponding to 
     * the user's XML preferences.
     *
     * @param  onscreen  the user's onscreen keyboard preferences
     * @param  selectionMethod  the onscreen keyboard scanning type
     */
    protected void setDomValues(Document onscreen, Element selectionMethod) {
        Element generic = DOMUtil.getFirstChildElement(onscreen.getDocumentElement());
        Element temp = null;
        Element switchCount = null;
        Element theSwitches = null;
        Element mainSwitch = null;
        ComboBoxItem switchValueItem;
        int highestSwitch = 1;
        int switchNum;
        String mainSwitchType = null;

        // Set the switch type.
        try {
            temp = (Element) XPathAPI.selectSingleNode(onscreen, ".//" + xmlLabels.getString(OK_GENERIC_SWITCH_TYPE));
        }
        catch (TransformerException te) {
            te.printStackTrace();
        }
        if (temp != null && temp.getTagName().equals(xmlLabels.getString(OK_GENERIC_SWITCH_TYPE))) {
            ComboBoxItem switchItem = (ComboBoxItem) findItem(switches, temp.getAttribute(VALUE));
            switchInputType.setSelectedItem(switchItem);			
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        // Set the dwell time.
        if (temp != null && temp.getTagName().equals(xmlLabels.getString(OK_GENERIC_DWELL_TIME))) {
            dwellTimeCheckBox.setSelected(true);
            dwellTimeField.setText(temp.getAttribute(VALUE));
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        // Set the number of total switches.
        try {
            switchCount = (Element) XPathAPI.selectSingleNode(onscreen, ".//" + xmlLabels.getString(OK_GENERIC_SWITCH));
            theSwitches = switchCount;
        }
        catch (TransformerException te) {
            te.printStackTrace();
        }
        while (switchCount != null && switchCount.getTagName().equals(xmlLabels.getString(OK_GENERIC_SWITCH))) {
            switchNum = Integer.parseInt(switchCount.getAttribute(xmlLabels.getString(OK_GENERIC_SWITCH_NUM)));

            if (switchNum <= MAX_SWITCHES && switchNum > highestSwitch)
                highestSwitch = switchNum;

            switchCount = DOMUtil.getNextSiblingElement(switchCount);
        }		
        numSwitchesComboBox.setSelectedItem(String.valueOf(highestSwitch));

        
        // Set the 'main' switch. Each scanning type has a switch value which takes precedence
        // over other valued switches. Hence, we must set this first b/c of the built-in UI
        // checks to make sure the 'main' switch is always present in a user's preferences.
        if (selectionMethod.getTagName().equals(xmlLabels.getString(OK_GENERIC_AUTO_SCAN)))
            mainSwitchType = "select";
        else if (selectionMethod.getTagName().equals(xmlLabels.getString(OK_GENERIC_INVERSE_SCAN)) ||
                 selectionMethod.getTagName().equals(xmlLabels.getString(OK_GENERIC_DIRECTED_SCAN)))
            mainSwitchType = "scan";
        try {
            mainSwitch = (Element) XPathAPI.selectSingleNode(onscreen, ".//" + xmlLabels.getString(OK_GENERIC_SWITCH) + 
                                                               "[@value='" + mainSwitchType + "']");
        }
        catch (TransformerException te) {
            te.printStackTrace();
        }
        if (mainSwitch != null) {
            switchNum = Integer.parseInt(mainSwitch.getAttribute(xmlLabels.getString(OK_GENERIC_SWITCH_NUM)));
            if (switchNum > 0 && switchNum <= MAX_SWITCHES) {
                switchValueItem = (ComboBoxItem) findItem(directeds, mainSwitch.getAttribute(VALUE));

                switchComboBoxes[switchNum - 1].setSelectedItem(switchValueItem);
            }
        }

        // Set the rest of the switches.
        while (theSwitches != null && theSwitches.getTagName().equals(xmlLabels.getString(OK_GENERIC_SWITCH))) {
            switchNum = Integer.parseInt(theSwitches.getAttribute(xmlLabels.getString(OK_GENERIC_SWITCH_NUM)));
            if (switchNum > 0 && switchNum <= MAX_SWITCHES) {
                switchValueItem = (ComboBoxItem) findItem(directeds, theSwitches.getAttribute(VALUE));

                switchComboBoxes[switchNum - 1].setSelectedItem(switchValueItem);
            }
            theSwitches = DOMUtil.getNextSiblingElement(theSwitches);
        }
		
        onscreenKeyboard3.setDomValues(onscreen);
    }

    /**
     * Constructs the XML sub-tree for keyboard setup according to the user's current selections.
     *
     * @return    Element    The root element of the new XML sub-tree created.
     */
    protected void addElementsTo(Document onscreen, Element method) {        
        Element generic = DOMUtil.getFirstChildElement(onscreen.getDocumentElement());

        if (method != null) {
            Element temp;
            Element autoScanEl = DOMUtil.getFirstChildElement(method);
            autoScanEl = DOMUtil.getNextSiblingElement(DOMUtil.getNextSiblingElement(autoScanEl));

            ComboBoxItem inputItem = (ComboBoxItem) switchInputType.getSelectedItem();
            temp = onscreen.createElement(xmlLabels.getString(OK_GENERIC_SWITCH_TYPE));
            temp.setAttribute(VALUE, inputItem.value);
            method.insertBefore(temp, autoScanEl);

            if (dwellTimeCheckBox.isEnabled() && dwellTimeCheckBox.isSelected()) {
                temp = onscreen.createElement(xmlLabels.getString(OK_GENERIC_DWELL_TIME));
                temp.setAttribute(VALUE, dwellTimeField.getValue());
                method.appendChild(temp);
            }

            ComboBoxItem switchSetting;
            int switchNum = 1;
            for (int i = 0; i < Integer.parseInt((String) numSwitchesComboBox.getSelectedItem()); i++) {
                switchSetting = (ComboBoxItem) switchComboBoxes[i].getSelectedItem();
                if (switchSetting == unused)
                    continue;
                temp = onscreen.createElement(xmlLabels.getString(OK_GENERIC_SWITCH));
                temp.setAttribute(xmlLabels.getString(OK_GENERIC_SWITCH_NUM), String.valueOf(switchNum++));
                temp.setAttribute(VALUE, switchSetting.value);
				
                method.appendChild(temp);
            }

        }

        onscreenKeyboard3.addElementsTo(onscreen);				
    }

    /**
     * Sets all the labels to the current PreferenceManager.language value.
     */
    protected void setNewLabels() {
        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.OnscreenKeyboard", pm.language);

        switchInputTitle.setTitle(newLabels.getString("switch.input.title"));
        switchInputLabel.setText(newLabels.getString("switch.input"));
        switchInputLabel.setDisplayedMnemonic(newLabels.getString("switch.input.mnemonic").charAt(0));
        mouse.name = newLabels.getString("mouse");
        game.name = newLabels.getString("game");
        serial.name = newLabels.getString("serial");
        usb.name = newLabels.getString("usb");
        firewire.name = newLabels.getString("firewire");
        infrared.name = newLabels.getString("infrared");
        bluetooth.name = newLabels.getString("bluetooth");

        switchAssignmentTitle.setTitle(newLabels.getString("switch.assignment.title"));
        numSwitches.setText(newLabels.getString("num.switches"));
        numSwitches.setDisplayedMnemonic(newLabels.getString("num.switches.mnemonic").charAt(0));

        dwellTimeCheckBox.setText(newLabels.getString("dwell.time.question"));
        dwellTimeCheckBox.setMnemonic(newLabels.getString("dwell.time.question.mnemonic").charAt(0));
        dwellTime.setText(newLabels.getString("dwell.time"));
        dwellTime.setDisplayedMnemonic(newLabels.getString("dwell.time.mnemonic").charAt(0));

        unused.name = newLabels.getString("unused");
        select.name = newLabels.getString("select");
        cancel.name = newLabels.getString("cancel");
        scan.name = newLabels.getString("scan");
        up.name = newLabels.getString("up");
        down.name = newLabels.getString("down");
        left.name = newLabels.getString("left");
        right.name = newLabels.getString("right");
        horizontal.name = newLabels.getString("horizontal");
        vertical.name = newLabels.getString("vertical");

        dwellTimeField.reformat();

        setNewButtonLabels();

        revalidate();
        repaint();

        onscreenKeyboard3.setNewLabels();
    }

    /**
     * Listener to enable / disable the dwell time option.
     */
    class DwellTimeListener implements ItemListener {
        public void itemStateChanged(ItemEvent e) {
            JCheckBox box = (JCheckBox) e.getItem();
			
            if (box.isSelected()) {
                dwellTime.setEnabled(true);
                dwellTimeField.textField.setEnabled(true);
            }
            else {
                dwellTime.setEnabled(false);
                dwellTimeField.textField.setEnabled(false);
            }

            for (int i = 0; i < switchComboBoxes.length; i++) {
                if (box.isSelected() && switchComboBoxes[i].getItemAt(1) == select)
                    switchComboBoxes[i].removeItem(select);
                else if (switchComboBoxes[i].getItemAt(1) != select)
                    switchComboBoxes[i].insertItemAt(select, 1);
            }
        }
    }
				
    /**
     * Listener to make sure switches are unique.
     */
    class SwitchListener implements ItemListener {
        public void itemStateChanged(ItemEvent e) {
            ComboBoxItem item = (ComboBoxItem) e.getItem();
            boolean isScan = false;
            boolean isSelect = false;
            boolean isHorizontal = false;
            boolean isVertical = false;
			
            if (e.getStateChange() == ItemEvent.DESELECTED)
                return;

            JComboBox comboBox = (JComboBox) e.getItemSelectable();

            ComboBoxItem otherItem;
            for (int i = 0; i < switchComboBoxes.length; i++) {

                if (switchComboBoxes[i] == comboBox)
                    continue;
				
                otherItem = (ComboBoxItem) switchComboBoxes[i].getSelectedItem();
                if (otherItem == scan)
                    isScan = true;
                else if (otherItem == select)
                    isSelect = true;
                else if (otherItem == horizontal || otherItem == left || otherItem == right)
                    isHorizontal = true;
                else if (otherItem == vertical || otherItem == up || otherItem == down)
                    isVertical = true;

                if (item != unused && otherItem == item)
                    switchComboBoxes[i].setSelectedItem(unused);

            }
			
            // Forcing a vertical and horizontal scan for directedScanning is not implemented
            // b/c the combination of options is too large to force a default.
            //
            if (selectItem.value.equals(xmlLabels.getString(OK_GENERIC_INVERSE_SCAN)) && !isScan)
                switchComboBoxes[0].setSelectedItem(scan);
            else if (selectItem.value.equals(xmlLabels.getString(OK_GENERIC_AUTO_SCAN)) && !isSelect)
                switchComboBoxes[0].setSelectedItem(select);
			
        }
    }
    
    /**
     * Listener to enable / disable switches on the number of switches.
     */
    class NumSwitchListener implements ItemListener {
        public void itemStateChanged(ItemEvent e) {
            String item = (String) e.getItem();

            if (e.getStateChange() == ItemEvent.DESELECTED)
                return;

            int limit = Integer.parseInt(item) - 1;
            for (int i = 0; i < switchComboBoxes.length; i++) {

                if (i <= limit)
                    switchComboBoxes[i].setEnabled(true);
                else {
                    switchComboBoxes[i].setSelectedItem(unused);
                    switchComboBoxes[i].setEnabled(false);
                }
            }

        }
    }	

    /**
     * Sets the UI widgets into their default positions.
     */
    protected void doDefault() {
        switchInputType.setSelectedItem(mouse);
		
        dwellTimeField.setText("0.5");

        doSwitchValueDefault();
    }

    /**
     * Sets the switch values to their default positions according to the scan selection type.
     */
    private void doSwitchValueDefault() {
        if (selectItem.value.equals(xmlLabels.getString(OK_GENERIC_AUTO_SCAN))) {
            switchComboBoxes[0].setSelectedItem(select);
            switchComboBoxes[1].setSelectedItem(scan);			
            numSwitchesComboBox.setSelectedItem("2");
        }
        else if (selectItem.value.equals(xmlLabels.getString(OK_GENERIC_DIRECTED_SCAN))) {
            dwellTimeCheckBox.setSelected(false);			
            switchComboBoxes[0].setSelectedItem(up);
            switchComboBoxes[1].setSelectedItem(down);			
            switchComboBoxes[2].setSelectedItem(left);			
            switchComboBoxes[3].setSelectedItem(right);			
            switchComboBoxes[4].setSelectedItem(select);			
            numSwitchesComboBox.setSelectedItem("5");
        }
        else if (selectItem.value.equals(xmlLabels.getString(OK_GENERIC_INVERSE_SCAN))) {
            dwellTimeCheckBox.setSelected(false);
            switchComboBoxes[0].setSelectedItem(scan);
            switchComboBoxes[1].setSelectedItem(select);			
            numSwitchesComboBox.setSelectedItem("2");
        }

    }

    /**
     * Shows the previous dialog.
     */
    protected void doPrev() {
        pm.showPanel(onscreenKeyboard1);
    }

    /**
     * Shows the next dialog.
     */
    protected void doNext() {
        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.OnscreenKeyboard", pm.language);

        if (dwellTimeCheckBox.isSelected() && !dwellTimeField.isInsideRange())
            pm.doRangeWarning(dwellTimeField.getLowValue(), 
                              dwellTimeField.getHighValue(), 
                              labels.getString("dwell.time"));
        else
            pm.showPanel(onscreenKeyboard3);
    }

    /**
     * Gets the last edit panel in this app type series.
     */
    protected PWMEditPanel getLastPanel() {
        return onscreenKeyboard3.getLastPanel();
    }

    /**
     * Gets the first panel in this app type series.
     */
    protected PWMEditPanel getFirstPanel() {
        return onscreenKeyboard1.getFirstPanel();
    }

}
