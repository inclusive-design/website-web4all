/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import java.awt.*;
import java.util.ResourceBundle;
import javax.swing.border.*;
import javax.swing.*;

/**
 * Shared constants implemented by the dialogs of the Preference Wizard Manager.
 *
 * @author David Weinkauf
 * @version $Revision: 1.15 $, $Date: 2006/03/28 16:31:10 $
 */
public interface DialogConstants {

    /**
     * The PWM dialog width. This is optimized for a minimal screen width of 800 pixels.
     */
    public static final int DIALOG_WIDTH = Toolkit.getDefaultToolkit().getScreenSize().width < 800 ? Toolkit.getDefaultToolkit().getScreenSize().width : 800;

    /**
     * The PWM dialog height. This is optimized for a minimal screen height of 600 pixels.
     */
    public static final int DIALOG_HEIGHT = Toolkit.getDefaultToolkit().getScreenSize().height < 600 ? Toolkit.getDefaultToolkit().getScreenSize().height : 600;
	
    /**
     * The X-axis screen placement of the PWM dialog.
     */
    public static final int DIALOG_X = (int) ((Toolkit.getDefaultToolkit().getScreenSize().width - DIALOG_WIDTH) / 2);

    /**
     * The Y-axis screen placement of the PWM dialog.
     */
    public static final int DIALOG_Y = (int) ((Toolkit.getDefaultToolkit().getScreenSize().height - DIALOG_HEIGHT) / 2);
	
    /**
     * The PWM Point object consisting of its location on the screen.
     */
    public static final Point DIALOG_LOC = new Point(DIALOG_X, DIALOG_Y);
	
    /**
     * The default dimension for the lower direction buttons on the PWM.
     */
    public static final Dimension LOWER_BUTTON_DIM = new Dimension(110, 45);

    /**
     * The larger dimension for the Control and Display direction 
     * buttons on the PWM.
     */
    public static final Dimension LARGE_BUTTON_DIM = new Dimension(175, 45);

    /**
     * The title key suffix.
     */
    public static final String TITLE_SUFFIX = ".title";
	
    /**
     * The default text font for the PWM.
     */
    public static final Font TEXT_FONT = new Font("Dialog", Font.BOLD, 13);

    /**
     * The title font.
     */
    public static final Font TITLE_FONT = new Font("Verdana", Font.BOLD, 25);

    /**
     * The border title font.
     */ 
    public static final Font BORDER_TITLE_FONT = new Font("Verdana", Font.PLAIN, 17);
	
    /**
     * The question font.
     */
    public static final Font QUESTION_FONT = BORDER_TITLE_FONT;

    /**
     * The commonly used value attribute.
     */
    public static final String VALUE = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.Applications").getString("value.attribute");

    /**
     * The panel background.
     */
    public static final Color PANEL_BACKGROUND = Color.white;

    /**
     * The theme colour.
     */
    public static final Color THEME_COLOUR = Color.red;

    /**
     * The border title colour.
     */
    public static final Color BORDER_TITLE_COLOUR = Color.black;

    /**
     * The colour of the text displayed.
     */
    public static final Color TEXT_COLOUR = Color.black;

    /**
     * The colour of the button panel background.
     */
    public static final Color BUTTON_PANEL_BACKGROUND = Color.gray;

    /**
     * The background of the navigational buttons.
     */
    public static final Color BUTTON_BACKGROUND = Color.white;

    /**
     * The border for content buttons.
     */
    public static final BevelBorder RAISED_BUTTON_BORDER = new BevelBorder(BevelBorder.RAISED, Color.lightGray, Color.darkGray);

    /**
     * The default border for buttons.
     */
    public static final LineBorder BUTTON_BORDER = new LineBorder(Color.red, 2);

    /**
     * The border for content groupings.
     */
    public static final LineBorder BORDER_TITLE_LINE = new LineBorder(THEME_COLOUR);

    /**
     * The default spacing value.
     */
    public static final int SPACING_VALUE = 5;

    /**
     * The default indent value.
     */
    public static final int INDENT_VALUE = 5;

    /**
     * The left button indent.
     */
    public static final int LEFT_BUTTON_INDENT = 20;

    /**
     * The right button indent.
     */
    public static final int RIGHT_BUTTON_INDENT = 40;


}
