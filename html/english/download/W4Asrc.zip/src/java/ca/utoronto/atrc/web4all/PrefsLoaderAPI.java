/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:			PrefsLoaderAPI.java
 *
 * Synoposis:		package ca.utoronto.atrc.web4all;
 * 
]*/

package ca.utoronto.atrc.web4all;

import java.util.Properties;
import org.w3c.dom.*;

/**
 * Interface that defines the API for the Web4All preferences loader module.
 *
 * @version $Id: PrefsLoaderAPI.java,v 1.4 2006/03/28 21:17:27 clown Exp $
 * @author	Joseph Scheuhammer
 * @author  Allen Forsyth
 * @author  David Weinkauf
 *
 */
public interface PrefsLoaderAPI
{
    public final static String preferencesMediaInitializedQueryKey = "wasMediaInitialized";
    
    /**
     * Allows an instance of a preference loader to initialize itself.
     */
	public void startup();

    /**
     * Allows a client of the preferences loader to pass it a XML Document to write the preferences
     * to some storage medium.
     * @param		doc 	The data (XML Document) to write (save).
     */
	public void savePrefs (Document doc);

    /**
     * Allows a client of the preferences loader to retrieve a preferences-loaded
     * property.
     * @return	the preferences-loaded Properties object. 
     */   
	public Properties getPrefsLoadedProperties();
	
	/**
	 * Gracefully clean everything up, and exit the JVM.
	 */
	public void shutdown();
	
}	// end interface PrefsLoaderAPI.

