/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

/**
 * Class which encapsulates all the visual alert preferences.
 */
public class VisualAlert extends PWMEditPanel {

	/**
	 * The visual alert document.
	 */
	private Document document;

	/**
	 * The generic element.
	 */
	private Element generic;

	/**
	 * Combo box for system sounds preferences.
	 */
	private JComboBox systemSoundsComboBox;

	/**
	 * Check box for enabling/disabing captions.
	 */
	private JCheckBox captions;

	/**
	 * The system sounds labels.
	 */
	private JLabel systemSoundsLabel;

	/**
	 * The system sounds items.
	 */
	private ComboBoxItem none, desktop, captionBar, window;
	
	/**
	 * Array of system sounds items.
	 */
	private ComboBoxItem[] systemSoundsItems;

	/**
	 * The border title.
	 */
	private TitledBorder generalTitle;

	/**
	 * Sole constructor. Initializes all the components in the dialog and displays them accordingly.
	 */
	public VisualAlert(PreferenceManager pm, Element root, String inAppType) {
		super(pm, inAppType, inAppType + TITLE_SUFFIX);

		document = initDocument(root, xmlLabels.getString(VISUAL_ALERT), xmlLabels.getString(VA_GENERIC));
		generic = DOMUtil.getFirstChildElement(document.getDocumentElement());
	
		ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.VisualAlert", pm.language);

		none = new ComboBoxItem(labels.getString("none"), "none");
		desktop = new ComboBoxItem(labels.getString("desktop"), "desktop");
		captionBar = new ComboBoxItem(labels.getString("caption.bar"), "captionBar");
		window = new ComboBoxItem(labels.getString("window"), "window");

		ComboBoxItem[] tempSystemSoundsItems = {none, desktop, captionBar, window};
		systemSoundsItems = tempSystemSoundsItems;

		systemSoundsComboBox = new JComboBox(systemSoundsItems);
		systemSoundsComboBox.setForeground(TEXT_COLOUR);
		systemSoundsComboBox.setFont(TEXT_FONT);
		systemSoundsComboBox.setBackground(PANEL_BACKGROUND);		
		systemSoundsComboBox.setSelectedIndex(0);

		systemSoundsLabel = new JLabel(labels.getString("system.sounds"));
		systemSoundsLabel.setDisplayedMnemonic(labels.getString("system.sounds.mnemonic").charAt(0));
		systemSoundsLabel.setLabelFor(systemSoundsComboBox);
		systemSoundsLabel.setFont(TEXT_FONT);
		systemSoundsLabel.setForeground(TEXT_COLOUR);

		JPanel systemSoundsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		systemSoundsPanel.setBackground(PANEL_BACKGROUND);
		systemSoundsPanel.add(systemSoundsLabel);
		systemSoundsPanel.add(systemSoundsComboBox);

		captions = new JCheckBox(labels.getString("captions"));
		captions.setMnemonic(labels.getString("captions.mnemonic").charAt(0));
		captions.setBackground(PANEL_BACKGROUND);
		captions.setFont(TEXT_FONT);
			
		JPanel captionsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		captionsPanel.setBackground(PANEL_BACKGROUND);
		captionsPanel.add(captions);

		generalTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("general.title"));
		generalTitle.setTitleFont(BORDER_TITLE_FONT);
		generalTitle.setTitleColor(BORDER_TITLE_COLOUR);

		JPanel generalPanel = new JPanel(new GridLayout(2, 1));
		generalPanel.setBackground(PANEL_BACKGROUND);
		generalPanel.setBorder(generalTitle);
		generalPanel.add(systemSoundsPanel);
		generalPanel.add(captionsPanel);

                AccessibleContext ac = systemSoundsLabel.getAccessibleContext();
                ac.setAccessibleParent(generalPanel);
                ac = systemSoundsComboBox.getAccessibleContext();
                ac.setAccessibleParent(generalPanel);
                ac = captions.getAccessibleContext();
                ac.setAccessibleParent(generalPanel);                

		this.add(generalPanel);
		this.add(Box.createVerticalGlue());

	}

	/**
	 * Does the default settings for all the UI.
	 */
	protected void doDefault() {
		systemSoundsComboBox.setSelectedItem(none);
		captions.setSelected(false);
	}

	/**
	 * Gets the root element of the application type document.
	 */ 
	protected Element getRootElement() {
		Element temp;

		PreferenceManager.removeAllChildren(generic);

		temp = document.createElement(xmlLabels.getString(VA_GENERIC_SYSTEM_SOUNDS));
		ComboBoxItem ssItem = (ComboBoxItem) systemSoundsComboBox.getSelectedItem();
		temp.setAttribute(VALUE, ssItem.value);
		generic.appendChild(temp);
		
		temp = document.createElement(xmlLabels.getString(VA_GENERIC_CAPTIONS));
		if (captions.isSelected())
			temp.setAttribute(VALUE, "true");
		else
			temp.setAttribute(VALUE, "false");
		generic.appendChild(temp);

		return document.getDocumentElement();
	}

	/**
	 * Sets the UI according to the values in the application type document.
	 */
	protected void setDomValues() {
		Element temp = DOMUtil.getFirstChildElement(generic);

		if (temp != null && temp.getTagName().equals(xmlLabels.getString(VA_GENERIC_SYSTEM_SOUNDS))) {
			systemSoundsComboBox.setSelectedItem(findItem(systemSoundsItems, temp.getAttribute(VALUE)));
			temp = DOMUtil.getNextSiblingElement(temp);
		}

		if (temp != null && temp.getTagName().equals(xmlLabels.getString(VA_GENERIC_CAPTIONS))) {
			if (temp.getAttribute(VALUE).equals("true"))
				captions.setSelected(true);
			else
				captions.setSelected(false);
			temp = DOMUtil.getNextSiblingElement(temp);
		}
		
	}

	/**
	 * Sets the UI labels according to the user's preferred locale.
	 */
	protected void setNewLabels() {
		ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.VisualAlert", pm.language);
		
		none.name = newLabels.getString("none");
		desktop.name = newLabels.getString("desktop");
		captionBar.name = newLabels.getString("caption.bar");
		window.name = newLabels.getString("window");

		generalTitle.setTitle(newLabels.getString("general.title"));

		systemSoundsLabel.setText(newLabels.getString("system.sounds"));
		systemSoundsLabel.setDisplayedMnemonic(newLabels.getString("system.sounds.mnemonic").charAt(0));
		
		captions.setText(newLabels.getString("captions"));
		captions.setMnemonic(newLabels.getString("captions.mnemonic").charAt(0));

		setNewButtonLabels();

		revalidate();
		repaint();	

	}

	/**
	 * Gets the application type's document.
	 */
	protected Document getAppTypeDoc() {
		return document;
	}


}
