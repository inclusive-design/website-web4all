/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            Web4AllConstants.java
 *
 * Synoposis:       package ca.utoronto.atrc.web4all;
 * 
]*/

package ca.utoronto.atrc.web4all;

/**
 * Top-level constants used in the Web-4-All system. One group of constants defines keys
 * for looking up properties in plug-in .properties files.  The other group defines keys
 * for looking up the name of an ACCLIP element or attribute.
 *
 * @version $Id: Web4AllConstants.java,v 1.23 2006/03/28 21:17:27 clown Exp $
 * @author  Joseph Scheuhammer.
 */
public interface Web4AllConstants
{
    /**
     * The name of the preferences DTD file.
     */
    public final static String PREFS_DTD_NAME               = "prefs.DTD";
    
    /**
     * Third party application name property key.  This is used in the plug-in's
     * .properties file.
     */
    public final static String APP_ID                       = "appID";
    
    /** 
     * The application type property.  This is used in the plug-in's
     * .properties file.
     */
    public final static String APP_TYPE                     = "appType";
    
    /** 
     * Suffix for the preferences wizard class property.  This is used in the plug-in's
     * .properties file.
     */
    public final static String PREFS_CLASS_SUFFIX           = ".prefs";
    
    /** 
     * Suffix for the configuration class property.  This is used in the plug-in's
     * .properties file.
     */
    public final static String CONFIG_CLASS_SUFFIX          = ".config";
    
    /** 
     * Suffix for the application path property.  This is used in the plug-in's
     * .properties file.
     */
    public final static String EXEC_SUFFIX                  = ".exec";

    /** 
     * Suffix for the ".ini" path property.  This is used in the plug-in's
     * .properties file.
     */
    public final static String INI_SUFFIX                   = ".ini";

    /** 
     * Suffix for the full product name property.  This is used in the plug-in's
     * .properties file.
     */
    public final static String PRODUCT_NAME_SUFFIX          = ".product.name";

    /**
     * Root element key for the preferences (XML) element.
     */
    public final static String  ROOT_DATUM                  =   "root.element";
    
    /**
     * Language attribute key.
     */
    public final static String  PREF_LANG                   =   "root.lang";

    /**
     * Context element key.
     */
    public final static String  CONTEXT                 =   "context";

    /**
     * Context identifier attribute key.
     */
    public final static String  CONTEXT_ID                  =   "context.id";

    /**
     * Display element key.
     */
    public final static String  DISPLAY                 =   "display";

    /**
     * Control element key.
     */
    public final static String  CONTROL                 =   "control";
    
    /**
     * For the generic preferences, this is the key for their value attribute.
     */
    public final static String  VAL_ATT                     =   "value.attribute";

    /**
     * Key for alphabetic layout of onscreen or alternative keyboards.
     */
    public final static String  ALPHA_LAYOUT_INTERNAL       =   "alpha.layout.internal";

    /**
     * Key for alphabetic layout of onscreen or alternative keyboards.
     */
    public final static String  ALPHA_LAYOUT_EXTERNAL       =   "alpha.layout.external";
    
    /**
     * Screen reader preferences key.
     */
    public final static String  SCREEN_READER               =   "screen.reader";
    
    /**
     * Screen reader generic preferences key.
     */
    public final static String  SR_GENERIC                  =   "sr.generic";
    
    /**
     * Screen reader.
     */
    public final static String  SR_GENERIC_LINK             =   "sr.generic.link";
    
    /**
     * Screen reader.
     */
    public final static String  SR_GENERIC_SPEECH_RATE      =   "sr.generic.speech.rate";
    
    /**
     * Screen reader.
     */
    public final static String  SR_GENERIC_PITCH            =   "sr.generic.pitch";
    
    /**
     * Screen reader.
     */
    public final static String  SR_GENERIC_VOLUME           =   "sr.generic.volume";
    
    /**
     * Onscreen keyboard preference key.
     */
    public final static String  ONSCREEN_KEYBOARD                       =   "onscreen.keyboard";
    
    /**
     * Onscreen keyboard generic preferences key.
     */
    public final static String  OK_GENERIC                              =   "ok.generic";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_LAYOUT                       =   "ok.generic.layout";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_KEY_WIDTH                    =   "ok.generic.key.width";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_KEY_HEIGHT                   =   "ok.generic.key.height";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_KEY_SPACING                  =   "ok.generic.key.spacing";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_KEY_SOUND                    =   "ok.generic.key.sound";

    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_POINT_CLICK                  =   "ok.generic.point.click";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_POINT_DWELL                  =   "ok.generic.point.dwell";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_AUTO_SCAN                    =   "ok.generic.auto.scan";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_INVERSE_SCAN                 =   "ok.generic.inverse.scan";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_DIRECTED_SCAN                =   "ok.generic.directed.scan";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_CODE_SELECTION               =   "ok.generic.code.selection";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_SWITCH                       =   "ok.generic.switch";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_SWITCH_NUM                   =   "ok.generic.switch.num";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_SWITCH_DELAY                 =   "ok.generic.switch.delay";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_DWELL_TIME                   =   "ok.generic.dwell.time";

    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_SCAN_SPEED                   =   "ok.generic.scan.speed";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_AUTO_SCAN_INIT_DELAY         = "ok.generic.auto.scan.init.delay";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_SCAN_SWITCH_DELAY            =   "ok.generic.scan.switch.delay";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_AUTO_SCAN_REPEAT             =   "ok.generic.auto.scan.repeat";
    
    /**
     * Onscreen keyboard.
     */
    public final static String  OK_GENERIC_SWITCH_TYPE                  =   "ok.generic.switch.type";
    
    /**
     * Screen enhancement preferences key,
     */
    public final static String  SCREEN_ENHANCE              =   "screen.enhance";
    
    /**
     * Screen enhancement generic preferences key.
     */
    public final static String  SE_GENERIC                  =   "se.generic";
    
    /**
     * Screen enhancement.
     */
    public final static String  SE_GENERIC_FONT_FACE        =   "se.generic.font.face";
    
    /**
     * Screen enhancement.
     */
    public final static String  SE_GENERIC_GENERIC_FACE     =   "se.generic.generic.face";
    
    /**
     * Screen enhancement.
     */
    public final static String  SE_GENERIC_FONT_SIZE        =   "se.generic.font.size";
    
    /**
     * Screen enhancement.
     */
    public final static String  SE_GENERIC_INVERT_COLOURS   =   "se.generic.invert.colours";

    /**
     * Screen enhancement.
     */
    public final static String  SE_GENERIC_FG_COLOUR        =   "se.generic.fg.colour";
    
    /**
     * Screen enhancement.
     */
    public final static String  SE_GENERIC_BG_COLOUR        =   "se.generic.bg.colour";
    
    /**
     * Screen enhancement.
     */
    public final static String  SE_GENERIC_HI_COLOUR        =   "se.generic.hi.colour";
    
    /**
     * Screen enhancement.
     */
    public final static String  SE_GENERIC_CURSOR_SIZE      =   "se.generic.cursor.size";
    
    /**
     * Screen enhancement.
     */
    public final static String  SE_GENERIC_CURSOR_COLOUR    =   "se.generic.cursor.colour";
    
    /**
     * Screen enhancement.
     */
    public final static String  SE_GENERIC_CURSOR_TRAILS    =   "se.generic.cursor.trails";
    
    /**
     * Screen enhancement.
     */
    public final static String  SE_GENERIC_TRACKING         =   "se.generic.tracking";
    
    /**
     * Screen enhancement.
     */
    public final static String  SE_GENERIC_MOUSE            =   "se.generic.mouse";
    
    /**
     * Screen enhancement.
     */
    public final static String  SE_GENERIC_CARET            =   "se.generic.caret";
    
    /**
     * Screen enhancement.
     */
    public final static String  SE_GENERIC_FOCUS            =   "se.generic.focus";

    /**
     * Screen enhancement.
     */
    public final static String  SE_GENERIC_MAGNIFICATION    =   "se.generic.magnification";
    
    /**
     * Alternative pointing device preferences key.
     */
    public final static String  ALT_POINTING                =   "alt.pointing";
    
    /**
     * Alternative pointing device generic preferences key.
     */
    public final static String  AP_GENERIC                  =   "ap.generic";
    
    /**
     * Alternative pointing device.
     */
    public final static String  AP_GENERIC_ABS_POINT        = "ap.generic.abs.pointing";
    
    /**
     * Alternative pointing device.
     */
    public final static String  AP_GENERIC_REL_POINT        = "ap.generic.rel.pointing";
    
    /**
     * Alternative pointing device.
     */
    public final static String  AP_GENERIC_SPEED            =   "ap.generic.speed";
    
    /**
     * Alternative pointing device.
     */
    public final static String  AP_GENERIC_ACCEL            =   "ap.generic.accel";
    
    /**
     * Alternative pointing device.
     */
    public final static String  AP_GENERIC_HAND             =   "ap.generic.hand";
    
    /**
     * Alternative pointing device.
     */
    public final static String  AP_GENERIC_DBLCLICK         =   "ap.generic.dblclick";
    
    /**
     * Alternative pointing device.
     */
    public final static String  AP_GENERIC_BUTTON_EXT       =   "ap.generic.button.external";
    
    /**
     * Text reading plus highlighting preferences key.
     */
    public final static String  TEXT_READING_HIGHLITE       =   "text.reading.highlight";
    
    /**
     * Text reading plus highlighting generic preferences key.
     */
    public final static String  TR_GENERIC                  =   "tr.generic";
    
    /**
     * Text reading plus highlighting.
     */
    public final static String  TR_GENERIC_SPEECH_RATE      =   "tr.generic.speech.rate";
    
    /**
     * Text reading plus highlighting.
     */
    public final static String  TR_GENERIC_PITCH            =   "tr.generic.pitch";
    
    /**
     * Text reading plus highlighting.
     */
    public final static String  TR_GENERIC_VOLUME           =   "tr.generic.volume";
    
    /**
     * Text reading plus highlighting.
     */
    public final static String  TR_GENERIC_HIGHLITE         =   "tr.generic.highlight";
    
    /**
     * Text reading plus highlighting.
     */
    public final static String  TR_GENERIC_ALT              =   "tr.generic.alt";
    
    /**
     * Text reading plus highlighting.
     */
    public final static String  TR_GENERIC_TABBING          =   "tr.generic.tabbing";
    
    /**
     * Text reading plus highlighting.
     */
    public final static String  TR_GENERIC_READING_UNIT     =   "tr.generic.reading.unit";
    
    /**
     * Keyboard enhancement preferences key.
     */
    public final static String  KEYBOARD_ENHANCED           =   "keyboard.enhanced";
    
    /**
     * Keyboard enhancement generic preferences key.
     */
    public final static String  KE_GENERIC                  =   "ke.generic";
    
    /**
     * Keyboard enhancement.
     */
    public final static String  KE_GENERIC_LAYOUT           =   "ke.generic.layout";
    
    /**
     * Keyboard enhancement.
     */
    public final static String  KE_GENERIC_STICKY           =   "ke.generic.sticky";
    
    /**
     * Keyboard enhancement.
     */
    public final static String  KE_GENERIC_REPEAT           =   "ke.generic.repeat";
    
    /**
     * Keyboard enhancement.
     */
    public final static String  KE_GENERIC_AUTO_DELAY       =   "ke.generic.auto.delay";
    
    /**
     * Keyboard enhancement.
     */
    public final static String  KE_GENERIC_AUTO_RATE        =   "ke.generic.auto.rate";
    
    /**
     * Keyboard enhancement.
     */
    public final static String  KE_GENERIC_SLOW             =   "ke.generic.slow";
    
    /**
     * Keyboard enhancement.
     */
    public final static String  KE_GENERIC_SLOW_INTERVAL    =   "ke.generic.slow.interval";
    
    /**
     * Keyboard enhancement.
     */
    public final static String  KE_GENERIC_DEBOUNCE         =   "ke.generic.debounce";
    
    /**
     * Keyboard enhancement.
     */
    public final static String  KE_GENERIC_DEBOUNCE_INTERVAL=   "ke.generic.debounce.interval";
    
    /**
     * Alternative keyboard preferences key.
     */
    public final static String  ALT_KEYBOARD                =   "alt.keyboard";
    
    /**
     * Alternative keyboard generic preferences key.
     */
    public final static String  AK_GENERIC                  =   "ak.generic";
    
    /**
     * Alternative keyboard.
     */
    public final static String  AK_GENERIC_RESIZABLE_KEYS   =   "ak.generic.resizable.keys";

    /**
     * Mouse emulation preferences key.
     */
    public final static String  MOUSE_EMULATION             =   "mouse.emulation";

    /**
     * Mouse emulation generic preferences key.
     */
    public final static String  ME_GENERIC                  =   "me.generic";

    /**
     * Mouse emulation.
     */
    public final static String  ME_GENERIC_SPEED            =   "me.generic.speed";

    /**
     * Mouse emulation.
     */
    public final static String  ME_GENERIC_ACCEL            =   "me.generic.accel";

    /**
     * Mouse emulation.
     */
    public final static String  ME_GENERIC_DEVICE           =   "me.generic.device";

    /**
     * Braille preferences key.
     */
    public final static String  BRAILLE                     =   "braille";

    /**
     * Braille generic preferences key.
     */
    public final static String  BRL_GENERIC                 =   "brl.generic";

    /**
     * Braille.
     */
    public final static String  BRL_GENERIC_GRADE           =   "brl.generic.grade";

    /**
     * Braille.
     */
    public final static String  BRL_GENERIC_NUM_DOTS        =   "brl.generic.num.dots";

    /**
     * Braille.
     */
    public final static String  BRL_GENERIC_NUM_CELLS       =   "brl.generic.num.cells";

    /**
     * Braille.
     */
    public final static String  BRL_GENERIC_MARK_HIGHLIGHT  =   "brl.generic.mark.highlight";

    /**
     * Braille.
     */
    public final static String  BRL_GENERIC_MARK_BOLD       =   "brl.generic.mark.bold";

    /**
     * Braille.
     */
    public final static String  BRL_GENERIC_MARK_UNDERLINE  =   "brl.generic.mark.underline";

    /**
     * Braille.
     */
    public final static String  BRL_GENERIC_MARK_ITALIC     =   "brl.generic.mark.italic";

    /**
     * Braille.
     */
    public final static String  BRL_GENERIC_MARK_STRIKEOUT  =   "brl.generic.mark.strikeout";

    /**
     * Braille.
     */
    public final static String  BRL_GENERIC_MARK_COLOR      =   "brl.generic.mark.color";

    /**
     * Braille.
     */
    public final static String  BRL_GENERIC_DOT_PRESSURE    =   "brl.generic.dot.pressure";

    /**
     * Braille.
     */
    public final static String  BRL_GENERIC_STATUS_CELL     =   "brl.generic.status.cell";

    /**
     * Visual alert preferences key.
     */
    public final static String  VISUAL_ALERT                =   "visual.alert";

    /**
     * Visual alert generic preferences key.
     */
    public final static String  VA_GENERIC                  =   "va.generic";

    /**
     * Visual alert.
     */
    public final static String  VA_GENERIC_SYSTEM_SOUNDS    =   "va.generic.system.sounds";

    /**
     * Visual alert.
     */
    public final static String  VA_GENERIC_CAPTIONS         =   "va.generic.captions";

    /**
     * Voice recognition preferences key.
     */
    public final static String  VOICE_REC                   =   "voice.rec";

    /**
     * Voice recognition generic preferences key.
     */
    public final static String  VR_GENERIC                  =   "vr.generic";
 
    /**
     * Voice recognition.
     */
    public final static String  VR_GENERIC_MIC_GAIN         =   "vr.generic.mic.gain";
 
    /**
     * Voice recognition.
     */
    public final static String  VR_GENERIC_CONTROLS_WINDOW  =   "vr.generic.controls.window";
 
    /**
     * Voice recognition.
     */
    public final static String  VR_GENERIC_DICTATION        =   "vr.generic.dictation";
 
    /**
     * Voice recognition.
     */
    public final static String  VR_GENERIC_VOICE_PROFILE_EXT=   "vr.generic.voice.profile.ext";
 
    /**
     * Voice recognition.
     */
    public final static String  VR_GENERIC_COMMAND_CONTROL  =   "vr.generic.command.control";
 
    /**
     * Voice recognition.
     */
    public final static String  VR_GENERIC_VOCABULARY       =   "vr.generic.vocabulary";
 
    /**
     * Voice recognition.
     */
    public final static String  VR_GENERIC_FEEDBACK         =   "vr.generic.feedback";
 
    /**
     * Voice recognition.
     */
    public final static String  VR_GENERIC_MOUSE            =   "vr.generic.mouse";

    /**
     * Coded input preferences key.
     */
    public final static String  CODED_INPUT                 =   "coded.input";
 
    /**
     * Coded input.
     */
    public final static String  CI_CODE                     =   "ci.code";

    /**
     * Coded input.
     */
    public final static String  CI_CODE_SWITCH_NUM          =   "ci.code.switch.num";

    /**
     * Coded input.
     */
    public final static String  CI_CODE_TERM                =   "ci.code.term";

    /**
     * Coded input.
     */
    public final static String  CI_CODE_RATE                =   "ci.code.rate";

    /**
     * Coded input.
     */
    public final static String  CI_CODE_SELECT              =   "ci.code.select";

    /**
     * Coded input.
     */
    public final static String  CI_SWITCH_TYPE              =   "ci.code.switch.type";

    /**
     * Coded input.
     */
    public final static String  CI_CODE_EXT                 =   "ci.code.ext";

    /**
     * Prediction.
     */
    public final static String  PREDICTION                  =   "prediction";
 
    /**
     * Prediction.
     */
    public final static String  PREDICT_COMMAND             =   "predict.command";

    /**
     * Prediction.
     */
    public final static String  PREDICT_WORD                =   "predict.word";

    /**
     * Prediction.
     */
    public final static String  PREDICT_WORD_COMPLETE       =   "predict.word.complete";

    /**
     * Prediction.
     */
    public final static String  PREDICT_NUM_CHOICES         =   "predict.num.choices";

    /**
     * Prediction.
     */
    public final static String  PREDICT_PERSONAL_LEXICON    =   "predict.personal.lexicon";


    /**
     * Third party preferences element key.
     */
    public final static String  APPLICATION                 =   "application";

    /**
     * Third party preferences application name attribute key.
     */
    public final static String  APP_NAME                    =   "app.name";

    /**
     * Third party preferences application priority attribute key.
     */
    public final static String  APP_PRIORITY                =   "app.priority";

    /**
     * Third party preferences application version attribute key.
     */
    public final static String  APP_VERSION                 =   "app.version";

    /**
     * Third party preferences parameter element key.
     */
    public final static String  PARAMETER                   =   "parameter";

    /**
     * Third party preferences parameter name attribute key.
     */
    public final static String  PARAM_NAME                  =   "param.name";

    /**
     * Third party preferences parameter value attribute key.
     */
    public final static String  PARAM_VALUE                 =   "param.value";
    
}   // end interface Web4AllConstants.

