/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            PrefsChooser.java
 *
 * Synoposis:       package ca.utoronto.atrc.web4all.prefschooser;
 *
]*/

package ca.utoronto.atrc.web4all.prefschooser;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;

import org.w3c.dom.*;
import org.xml.sax.*;

import ca.utoronto.atrc.web4all.*;
import ca.utoronto.atrc.web4all.binding.XMLBindingAdaptor;

/**
 * Class for loading/saving preferences using a standard file menu.
 *
 * @version $Id: PrefsChooser.java,v 1.10 2006/03/28 21:17:27 clown Exp $
 * @author  Joseph Scheuhammer.
 */
public class PrefsChooser implements PrefsLoaderAPI, ActionListener, PropertyChangeListener
{
    /**
     * The key in the File properties file that chooses the menu's name.
     */
    public final static String FILE_KEY         =   "file";

    /** The key in the Help properties file that chooses the menu's name.*/
    public final static String HELP_KEY = "help";

    /** The key in the Help properties file that chooses the menu item keys.*/
    public final static String HELP_MENU = "help.menu";

    /**
     * The key in the File properties file that chooses the menu item keys.
     */
    public final static String FILE_MENU        =   "file.menu";

    /** The default file name key.*/
    public final static String DEFAULT_FILE_NAME = "default.file.name";

    /**
     * The suffix to add to a menu item key for that item's label.
     */
    public final static String LABEL_SUFFIX     =   ".label";
    
    /**
     * The suffix to add to acquire the keyboard mnemonic
     */
    public final static String MNEM_SUFFIX      =   ".mnemonic";
    
    /**
     * The suffix to add to a menu item key for that item's key accelerator.
     */
    public final static String ACCEL_SUFFIX     =   ".accelerator";

    /**
     * The suffix to add to a menu item key for that item's key accelerator.
     */
    public final static String TIP_SUFFIX       =   ".tip";

    /**
     * The menu item key that designates a menu separator.
     */
    public final static String MENU_SEP         =   "-";
    
    /**
     * Action command for creating a new preferences file.
     */
    public final static String NEW_ACTION       =   "new";
    
    /**
     * Action command for opening an existing preferences file.
     */
    public final static String OPEN_ACTION      =   "open";
    
    /**
     * Action command for saving the current preferences file.
     */
    public final static String EDIT_ACTION      =   "edit";
    
    /**
     * Action command for saving the current preferences file.
     */
    public final static String CONFIG_ACTION    =   "configure";

    /**
     * Action command for saving the current preferences file.
     */
    public final static String SAVE_ACTION      =   "save";
    
    /**
     * Action command for saving the current preferences file
     * to a new location.
     */
    public final static String SAVE_AS_ACTION   =   "saveas";
            
    /**
     * Action command for ending the session and resetting
     * the work station, without quitting.
     */
    public final static String END_ACTION       =   "endsession";
            
    /**
     * Action command for quitting the application (must be same as menu item key in
     * FileMenuRez.properties).
     */
    public final static String QUIT_ACTION      =   "quit";

    /** Action command for displaying about information.*/
    public final static String ABOUT_ACTION = "about";

    /** The 'About' title properties key.*/
    public static final String ABOUT_TITLE = "about.title";

    /** The 'About' content properties key.*/
    public static final String ABOUT_CONTENT = "about.content";
    
    /**
     * Web4All control hub.
     */
    private ControlHub theControlHub;

    /**
     * Web4All main window.
     */
    private JFrame theMainWindow;

    /** 
     * The file to read/write.
     */
    private File theFile;

    /** 
     * Hot-key modifier ("cmd" on Macs, "ctrl" on windows...).
     */
    private int theHotkeyModifier;
    
    /**
     * The menu bar.
     */
    private JMenuBar theMenuBar;
    
    /**
     * The file menu.
     */
    private JMenu theFileMenu;

    /**
     * The help menu.
     */
    private JMenu theHelpMenu;

    /**
     * The preferences-loaded properties.
     */
    private Properties thePrefsLoadedProps;

    /** The 'About' dialog title.*/
    private String aboutTitle;

    /** The 'About' dialog content.*/
    private String aboutContent;

    /** The XML filter.*/
    private FilenameFilter xmlFilter;

    /** The default file names to save as.*/
    private String defaultFileName;

    /**
     * Initializes the prefs loader.
     */
    public PrefsChooser()
    {
        super();
        
        // Allocate file menu and menubar here.  Build it in buildMenuBar().
        //
        theFile = null;
        theMenuBar = new JMenuBar();
        theMenuBar.setBackground (Color.white);
        theFileMenu = new JMenu ("File");
        theFileMenu.setBackground (Color.white);
        theMenuBar.add (theFileMenu);
        
        theHelpMenu = new JMenu("Help");
        theHelpMenu.setBackground(Color.white);
        theMenuBar.add(theHelpMenu);
        
        // "Dummy" main window for insurance.
        //
        theMainWindow = new JFrame ("File Prefs Loader");
        
        // Hotkey modifier key is system dependent.
        //
        String os = System.getProperty ("os.name");
        if (System.getProperty ("os.name").indexOf ("Mac") < 0)
            theHotkeyModifier = java.awt.Event.CTRL_MASK;
        else
            theHotkeyModifier = java.awt.Event.META_MASK;
            
        // Prefs loader properties.
        // (This class doesn't have any...)
        //
        thePrefsLoadedProps = new Properties();

        xmlFilter = new FilenameFilter() {
                public boolean accept(File dir, String name) {
                    if (name.endsWith(".xml")) {
                        return true;
                    }
                    return false;
                }
            };
        
    }   // end PrefsChooser().
    
    /**
     * (Re)Build the menus and add the menu bar to the main window.  This also
     * starts Web-4-All with <code>this</code> preferences loader, thereby creating the
     * main window.
     * @param   inLocale    The current locale.
     */
    private void buildMenuBar (Locale inLocale)
    {    	    
        // Build <theFileMenu> according to the resources with the relevant Locale.
        // Note that <theMenuBar>, <theFileMenu> and <theHelpMenu> were all
        // allocated in the constructor.  Here, their names, keyboard shortcuts,
        // actions, and so on are added.
        //
        try
        {
            // First, get the resources for the file menu, and build the File JMenu itself.
            //
            ResourceBundle rez = ResourceBundle.getBundle ("ca.utoronto.atrc.web4all.prefschooser.FileMenuRez", inLocale);
            String menuName = rez.getString (PrefsChooser.FILE_KEY + PrefsChooser.LABEL_SUFFIX);
            String menuMnemonic = rez.getString (PrefsChooser.FILE_KEY + PrefsChooser.MNEM_SUFFIX);
            theFileMenu.setText (menuName);
            theFileMenu.setMnemonic (menuMnemonic.charAt (0));
            defaultFileName = rez.getString(PrefsChooser.DEFAULT_FILE_NAME);
            
            // Get the string that lists the menu item keys.  Then loop thru the keys to
            // build each item.
            //
            StringTokenizer menuItemKeys = new StringTokenizer (rez.getString (PrefsChooser.FILE_MENU));
            while (menuItemKeys.hasMoreTokens())
                buildAndAddMenuItem (menuItemKeys.nextToken(), rez, theFileMenu);

            /* Do the same for the 'Help' menu. */
            rez = ResourceBundle.getBundle ("ca.utoronto.atrc.web4all.prefschooser.HelpMenuRez", inLocale);
            menuName = rez.getString (PrefsChooser.HELP_KEY + PrefsChooser.LABEL_SUFFIX);
            menuMnemonic = rez.getString (PrefsChooser.HELP_KEY + PrefsChooser.MNEM_SUFFIX);
            theHelpMenu.setText (menuName);
            theHelpMenu.setMnemonic (menuMnemonic.charAt (0));
            
            menuItemKeys = new StringTokenizer (rez.getString (PrefsChooser.HELP_MENU));
            while (menuItemKeys.hasMoreTokens())
                buildAndAddMenuItem (menuItemKeys.nextToken(), rez, theHelpMenu);

            /* Get the 'about' title and content.*/
            aboutTitle = rez.getString (PrefsChooser.ABOUT_TITLE);
            aboutContent = rez.getString (PrefsChooser.ABOUT_CONTENT);

         }
         
         catch (MissingResourceException mre)   // shouldn't happen.
         {
            mre.printStackTrace();
         }
         
         // Inusre correct enabled state of menu items.
         //
         updateEnabledMenuItems();
    
    }   // end buildMenuBar().
    
    /**
     * Builds a single menu item for the given menu.  Note that this includes menu separators.
     * @param   inItemKey           The key to use to access info about the menu item from the
     *                              resources.
     * @param   inRez               The resources themselves.
     * @param   ioMenu              The JMenu to add the menu item to. 
     */
    private void buildAndAddMenuItem (String inItemKey, ResourceBundle inRez, JMenu ioMenu)
    {    	    
        // Special case -- in the <inItemKey> is the separator character, just add a JMenuSeparator
        // and return.
        //
        if (inItemKey.equals (PrefsChooser.MENU_SEP))
        {
            ioMenu.addSeparator();
        }
        
        // An actual menu item (not a separator).  Build it.
        //
        else
        {
            try
            {
                // Get the label and accelerator.
                //
                String itemLabel = inRez.getString (inItemKey + PrefsChooser.LABEL_SUFFIX);
                String itemAccel = inRez.getString (inItemKey + PrefsChooser.ACCEL_SUFFIX);
                JMenuItem anItem = new JMenuItem (itemLabel);
                anItem.setActionCommand (inItemKey);
                anItem.setAccelerator (KeyStroke.getKeyStroke (itemAccel.charAt (0), theHotkeyModifier));
                anItem.setBackground (Color.white);
                
                // Add tooltip, if there is one.
                //
                try
                {
                    String itemTip = inRez.getString (inItemKey + PrefsChooser.TIP_SUFFIX);
                    anItem.setToolTipText (itemTip);
                }
                catch (MissingResourceException noToolTip)  // not a big deal.
                { ; }
                
                // Add the action listener, and add it to the menu...done.
                //
                anItem.addActionListener (this);
                ioMenu.add (anItem);
            }
            catch (MissingResourceException mre)   // shouldn't happen.
            {
                mre.printStackTrace();
            }
        }

    }   // end buildAndAddMenuItem().
    
    /**
     * Allow the window detector to set the main window, and have this
     * object set its menu bar appropriately.
     * @param   inMainWindow    The JFrame that is the main window.
     * @see #getMainWindow()
     */
    protected void setMainWindow (JFrame inWindow)
    {
        theMainWindow = inWindow;
                
        // Add <theMenuBar> to <theMainWindow>.
        //
        theMainWindow.setJMenuBar (theMenuBar);
        theMainWindow.pack();
    
    }   // end setMainWindow().
    
    /**
     * Expose the main window to subclasses.
     * @return   The JFrame that is the main window.
     * @see #setMainWindow(JFrame)
     */
    protected JFrame getMainWindow()
    {
        return theMainWindow;
                
    }   // end getMainWindow().
    
    /**
     * Allow subclasses to set the preferences File.
     * @param   inFile  The preferences File in the file system.
     * @see #getPrefsFile()
     */
    protected void setPrefsFile (File inFile)
    {
        theFile = inFile;
                
    }   // end setPrefsFile().
    
    /**
     * Expose the preferences File to subclasses.
     * @return  The current preferences File in the file system.  This could
     *          be <code>null</code>.
     * @see #setPrefsFile (File)
     */
    protected File getPrefsFile()
    {
        return theFile;
                
    }   // end getPrefsFile().
    
    /**
     * Update the file menu given a different Locale.
     * @param   inLocale    The new Locale
     */
    protected void updateLocale (Locale inLocale)
    {
        try
        {
            // First, get the resources for the file menu, and update it.
            //
            ResourceBundle rez = ResourceBundle.getBundle ("ca.utoronto.atrc.web4all.prefschooser.FileMenuRez", inLocale);
            String menuName = rez.getString (PrefsChooser.FILE_KEY + PrefsChooser.LABEL_SUFFIX);
            String menuMnemonic = rez.getString (PrefsChooser.FILE_KEY + PrefsChooser.MNEM_SUFFIX);
            theFileMenu.setText (menuName);
            theFileMenu.setMnemonic (menuMnemonic.charAt (0));
            
            // Loop to update each menu item.
            //
            for (int i = 0; i < theFileMenu.getItemCount(); i++)
            {
                JMenuItem item = theFileMenu.getItem (i);
                if (item != null)   // could be separator.
                {
                    String key = item.getActionCommand();
                    String itemLabel = rez.getString (key + PrefsChooser.LABEL_SUFFIX);
                    String itemAccel = rez.getString (key + PrefsChooser.ACCEL_SUFFIX);
                    item.setText (itemLabel);
                    item.setAccelerator (KeyStroke.getKeyStroke (itemAccel.charAt (0), theHotkeyModifier));
                    
                    // Add tooltip, if there is one.
                    //
                    try
                    {
                        String itemTip = rez.getString (key + PrefsChooser.TIP_SUFFIX);
                        item.setToolTipText (itemTip);
                    }
                    catch (MissingResourceException noToolTip)  // not a big deal.
                    { ; }
                }
            }

            /* Update the default file name.*/
            defaultFileName = rez.getString(PrefsChooser.DEFAULT_FILE_NAME);

            /* Do the same for the Help menu.*/
            rez = ResourceBundle.getBundle ("ca.utoronto.atrc.web4all.prefschooser.HelpMenuRez", inLocale);
            menuName = rez.getString (PrefsChooser.HELP_KEY + PrefsChooser.LABEL_SUFFIX);
            menuMnemonic = rez.getString (PrefsChooser.HELP_KEY + PrefsChooser.MNEM_SUFFIX);
            theHelpMenu.setText (menuName);
            theHelpMenu.setMnemonic (menuMnemonic.charAt (0));
            
            for (int i = 0; i < theHelpMenu.getItemCount(); i++)
            {
                JMenuItem item = theHelpMenu.getItem (i);
                if (item != null)   // could be separator.
                {
                    String key = item.getActionCommand();
                    String itemLabel = rez.getString (key + PrefsChooser.LABEL_SUFFIX);
                    String itemAccel = rez.getString (key + PrefsChooser.ACCEL_SUFFIX);
                    item.setText (itemLabel);
                    item.setAccelerator (KeyStroke.getKeyStroke (itemAccel.charAt (0), theHotkeyModifier));
                }
            }

            aboutTitle = rez.getString (PrefsChooser.ABOUT_TITLE);
            aboutContent = rez.getString (PrefsChooser.ABOUT_CONTENT);
        }
        catch (MissingResourceException mre)   // can't happen.
        {
            mre.printStackTrace();
        }
    
    }   // end updateLocale()
    
    /**
     * Open an existing preferences file.
     * @return      Whether the user chose a file (<code>true</code>) or cancelled
     *              (<code>false</code>).  
     */
    protected boolean openPrefsFile()
    {    	    
        // Put up a file chooser to allow user to choose a file.
        //
        File homeDirFile = new File (theControlHub.getHomeDirectory());
        FileDialog aChooser = new FileDialog (theMainWindow, "", FileDialog.LOAD);
        aChooser.setFilenameFilter(xmlFilter);
        aChooser.show();
        String chosen = aChooser.getFile();
        if (chosen != null)
        {
            // User did not cancel the file chooser dialog.  Record <theFile>.
            //
            File aFile = new File (aChooser.getDirectory(), chosen);
            if (!aFile.exists())
            {
                setPrefsFile (null);
                chosen = null;
            }
            else
                setPrefsFile (aFile);
        }
        return (chosen != null);
    
    }   // end openPrefsFile.
    
    /**
     * Check to see if there are preferences, and if so, enable/disable various
     * menu items.
     */
    public void updateEnabledMenuItems()
    {
        // Loop through the menu items.
        //
        for (int i = 0; i < theFileMenu.getItemCount(); i++)
        {
            JMenuItem anItem = theFileMenu.getItem (i);
            if (anItem != null)
            {
                String cmd = anItem.getActionCommand();
                if (    cmd.equals (PrefsChooser.EDIT_ACTION) ||
                        cmd.equals (PrefsChooser.CONFIG_ACTION) ||
                        cmd.equals (PrefsChooser.SAVE_ACTION) ||
                        cmd.equals (PrefsChooser.SAVE_AS_ACTION) )
                        
                    anItem.setEnabled (theFile != null);
            }
        }
    
    }   // end updateEnabledMenuItems().
                    
//==========================
// interface PrefsLoaderAPI.
//==========================

    /**
     * Main entry point of intializing this preferences loader.
     * @param   ioControlHub    The ControlHub instance that acts as a control
     *                          hub for the Web-4-All system.
     */
    public void startup()
    {
        theControlHub = ControlHub.getSharedInstance();
        buildMenuBar (Locale.getDefault());
        
        // Attach <this> asa property change listener so as to get notifiied
        // of language changes.
        //
        theControlHub.addPropertyChangeListener (this);
        
    }   // end startup()

    /**
     * Allows a client of the preferences loader to pass it a XML Document to write the preferences
     * to some storage medium.
     * @param		doc 	The data (XML Document) to write (save).
     */
    public void savePrefs (Document doc)
    {
        // Don't do anything if there is nothing to write.
        //
        if (doc != null)
        {
            // Put up a file chooser dialog.
            //
            FileDialog aChooser = new FileDialog (theMainWindow, "", FileDialog.SAVE);
            aChooser.setFilenameFilter(xmlFilter);                
            if (theFile != null)
            {
                aChooser.setDirectory(theFile.getParent());
                aChooser.setFile(theFile.getName());
            }
            else 
            {
                aChooser.setFile(defaultFileName);
            }
            aChooser.show();
            String chosen = aChooser.getFile();
            
            if (chosen != null)
            {
                // User did not cancel the file chooser dialog.  Serialize
                // <doc> into <prefs> (Note: "true" below means "pretty
                // print".  Write <prefs> to <theFile>.
                //
                theFile = new File (aChooser.getDirectory(), chosen);
                String prefs = XMLBindingAdaptor.serializeXML(doc, true);
                saveSerializedPrefs (theFile, prefs);
            }
            
            // Make sure that certain menu items are enabled/disabled as
            // appropriate.
            //
            updateEnabledMenuItems();
        }
    
    }   // end savePrefs().
    
    /**
     * Utility to write the given XML string to the given file.
     * @param   ioFile      The File to write to.  Nothing is written if
     *                      <code>null</code> nor if the File is a directory.
     * @param   inXmlPrefs  The prefs, as a String, to write.  Nothing is
     *                      written if <code>null</code>.
     */    
    public void saveSerializedPrefs (File ioFile, String inXmlPrefs)
    {
        // Check to see that <ioFile> and <inXmlPrefs> are non-null, and that
        // <ioFile> is not a directory.  If so, write <inXmlPrefs> to <ioFile>.
        //
        if ((ioFile != null) && (inXmlPrefs != null) && (!ioFile.isDirectory()))
        {
            FileWriter fWriter = null;
            try
            {
                fWriter = new FileWriter (ioFile);
                fWriter.write (inXmlPrefs, 0, inXmlPrefs.length());
                fWriter.flush();
                fWriter.close();
                fWriter = null;
            }
            catch (IOException ioe)
            {
                ioe.printStackTrace();
                
                // Try to clean up as best as possible.
                //
                if (fWriter != null)
                {
                    try
                    {
                        fWriter.flush();
                        fWriter.close();
                        fWriter = null;
                    }
                    catch (IOException ioe2)
                    { ; }
                }
            }
        }
    
    }   // end saveSerializedPrefs().

    /**
     * Gracefully clean up everything, and exit the JVM.
     */
    public void shutdown()
    {
        // Let Web4All clean up.
        //
        ControlHub.stopWeb4All();	        
    
        // Make everything go away.  Any non-zero exit code forces W4A to
        // completely quit.  Zero will cause a re-start.
        //
        System.exit (-1);
    
    }   // end shutdown

    /**
     * Provide a reference to the preferences-loaded properties to the outside world.
     * @return      The preferences-loaded Properties object.
     */
    public Properties getPrefsLoadedProperties()
    {
        return thePrefsLoadedProps;
    
    }   // end getPrefsLoadedProperties().
    
//==========================
// interface ActionListener.
//==========================
    
    /**
     * Handle various menu item selections.
     * @param   inActionEvent     The ActionEvent to respond to.
     */
    public void actionPerformed (ActionEvent inActionEvent)
    {
        String cmd = inActionEvent.getActionCommand();
         if (cmd.equals (NEW_ACTION) || cmd.equals (EDIT_ACTION))
        {
            // Instantiate a thread in which to run W4A's preferences wizard.
            // Note:  if there are no preferences (<theFile> is non-null),
            // then this will simply create them anew.  If there are
            // preferences, this will also create new preferences, but
            // <theControlHub> will save the old ones until the user saves the
            // new ones.  At that point, the system will reset to default, and
            // configure according to the new preferences.  If the user cancels
            // the preferences wizard, then any old preferences/configuration
            // will remain in effect.
            //
            if (theFile == null)
                theControlHub.kickIt (null, this);
            else
            {
                Thread editThread = new Thread (theControlHub, "Editing prefs");
                editThread.start();
            }
        }
        
        // Handle open.
        //
        else if (cmd.equals (OPEN_ACTION))
        {
            // If the user chooses a file to open, edit it using the prefs wizard.
            //
            if (openPrefsFile())
                theControlHub.kickIt (ControlHub.createXMLString (theFile.getPath()), this);
        }

        // Handle save.  Just call back into ControlHub to "save the prefs".
        //
        else if (cmd.equals (PrefsChooser.SAVE_ACTION))
            theControlHub.savePrefs();
        
        // Handle save-as.  Set <theFile> to null to force a file-save dialog.
        // Then call back into ControlHub to "save the prefs".
        //
        else if (cmd.equals (PrefsChooser.SAVE_AS_ACTION))
        {
            File currentFile = theFile;
            theFile = null;
            theControlHub.savePrefs();
            
            // If the user cancels the save-dialog, <theFile> will still be
            // "null".  If they actually saved to a new file, <theFile> will
            // reference that new file.  Hence, set <theFile> back to
            // <currentFile> only if they cancelled.
            //
            if (theFile == null)
                theFile = currentFile;
        }

        // Handle configure.  If there are no preferences, do nothing
        //
        else if (cmd.equals (CONFIG_ACTION))
        {
            if (theFile != null)
                theControlHub.kickIt (ControlHub.createXMLString (theFile.getPath()), this);
        }
        
        // Handle resetting without quitting.
        //
        else if (cmd.equals (PrefsChooser.END_ACTION))
        {
            // Tell Web4All to reset to what it is if just first launched...
            //
            theControlHub.stopIt();
            String homeDir = theControlHub.getHomeDirectory();
            theControlHub.startWeb4All (homeDir, this);
            
            // ...and forget any preferences.
            //
            theFile = null;
        }

        // Handle quit.
        //
        else if (cmd.equals (PrefsChooser.QUIT_ACTION))
            shutdown();

        /* Handle 'About Web-4-All' */
        else if (cmd.equals (PrefsChooser.ABOUT_ACTION)) {
            JOptionPane.showMessageDialog(null, aboutContent, 
                                          aboutTitle, 
                                          JOptionPane.INFORMATION_MESSAGE);
        }

        // Regardless of the event, update the enabled state of certain menu
        // items.
        //
        updateEnabledMenuItems();

    }   // end actionPerformed.
    
//==================================
// interface PropertyChangeListener.
//==================================

    /**
     * Handle changes in locale, and changes to Web-4-All's main window.
     *
     * @param   inEvent   The event that called us.
     */
    public void propertyChange (PropertyChangeEvent inEvent)
    {
        // Check for change in locale.
        //
        if (inEvent.getPropertyName() == ControlHub.LOCALE_PROP)
        {
            final Locale newLocale = (Locale) inEvent.getNewValue();
            Runnable rebuildMenu = new Runnable() {
                public void run() {
                    updateLocale (newLocale);
                }
            };
            SwingUtilities.invokeLater (rebuildMenu);
        }
        
        // Check for new W4A main window.
        //
        else if (inEvent.getPropertyName() == ControlHub.MAIN_WINDOW_PROP)
        {
            JFrame mainWindow = (JFrame) inEvent.getNewValue();
            if (mainWindow != null)
                setMainWindow (mainWindow);
        }
    
    }   // end propertyChange().

}   // end inner class PrefsChooser.
