/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import ca.utoronto.atrc.web4all.Web4AllConstants;

import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import java.text.NumberFormat;
import java.text.ParseException;
import java.lang.NumberFormatException;

/**
 * Class which represents the base class of all the PWM 
 * edit panels. It implements the navigational buttons,
 * application type, title, etc.
 */
public abstract class PWMEditPanel extends JPanel 
    implements DialogConstants, Web4AllConstants {

    /**
     * The application type for which this panel corresponds to.
     */
    protected String appType;

    /**
     * The reference to the PreferenceManager.
     */
    protected PreferenceManager pm;

    /**
     * The navigational button panel.
     */
    protected JPanel buttonPanel;

    /**
     * The navigational buttons.
     */
    protected JButton prevButton, nextButton, defaultButton, cancelButton;

    /**
     * The title properties key.
     */
    protected String titleKey;
	
    /**
     * The shared static ResourceBundle for the xml labels.
     */
    protected static ResourceBundle xmlLabels;

    /**
     * Sole constructor. Initializes the class variables.
     */
    public PWMEditPanel(PreferenceManager inPM, String inAppType, String inTitleKey) {
        super();

        pm = inPM;
        appType = inAppType;
        titleKey = inTitleKey;

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(PANEL_BACKGROUND);
		
        if (xmlLabels == null)
            xmlLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.Applications");

        initButtonPanel();
    }

    /**
     * Gets the title key.
     *
     * @return  the title key
     */
    protected String getTitleKey() {
        return titleKey;
    }

    /**
     * Gets the application type of this panel.
     *
     * @return  the application type
     */
    protected String getAppType() {
        return appType;
    }

    /**
     * Gets the first panel in this panel's application group.
     *
     * @return  null - should be overidden by implementing classes
     */
    protected PWMEditPanel getFirstPanel() {
        return this;
    }

    /**
     * Gets the last panel in this panel's application group.
     *
     * @return  null - should be overidden by implementing classes
     */
    protected PWMEditPanel getLastPanel() {
        return this;
    }

    /**
     * Gets the button panel.
     *
     * @return  the button panel
     */
    protected JPanel getButtonPanel() {
        return buttonPanel;
    }

    /**
     * Initializes the button panel.
     */
    protected void initButtonPanel() {
		
        ResourceBundle buttonLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Buttons", pm.language);			
        ButtonListener buttonListener = new ButtonListener();
		
        defaultButton = new JButton(buttonLabels.getString("default"));
        defaultButton.setActionCommand("default");
        defaultButton.setMnemonic(buttonLabels.getString("default.mnemonic").charAt(0));
        defaultButton.addActionListener(buttonListener);
        defaultButton.setPreferredSize(LOWER_BUTTON_DIM);
        defaultButton.setBorder(BUTTON_BORDER);
        defaultButton.setBackground(BUTTON_BACKGROUND);

        nextButton = new JButton(buttonLabels.getString("next"));
        nextButton.setMnemonic(buttonLabels.getString("next.mnemonic").charAt(0));
        nextButton.setActionCommand("next");
        nextButton.addActionListener(buttonListener);
        nextButton.setBorder(BUTTON_BORDER);
        nextButton.setPreferredSize(LOWER_BUTTON_DIM);
        nextButton.setBackground(BUTTON_BACKGROUND);

        prevButton = new JButton(buttonLabels.getString("prev"));
        prevButton.setMnemonic(buttonLabels.getString("prev.mnemonic").charAt(0));
        prevButton.setActionCommand("prev");
        prevButton.addActionListener(buttonListener);
        prevButton.setBorder(BUTTON_BORDER);
        prevButton.setPreferredSize(LOWER_BUTTON_DIM);
        prevButton.setBackground(BUTTON_BACKGROUND);
		
        cancelButton = new JButton(buttonLabels.getString("cancel"));
        cancelButton.setMnemonic(buttonLabels.getString("cancel.mnemonic").charAt(0));
        cancelButton.setActionCommand("cancel");
        cancelButton.addActionListener(buttonListener);
        cancelButton.setBorder(BUTTON_BORDER);
        cancelButton.setPreferredSize(LOWER_BUTTON_DIM);
        cancelButton.setBackground(BUTTON_BACKGROUND);
		
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        //buttonPanel.setBackground(BUTTON_PANEL_BACKGROUND);
        buttonPanel.add(Box.createHorizontalStrut(LEFT_BUTTON_INDENT));
        buttonPanel.add(defaultButton);
        buttonPanel.add(Box.createHorizontalGlue());
        buttonPanel.add(Box.createHorizontalGlue());
        buttonPanel.add(prevButton);
        buttonPanel.add(Box.createHorizontalStrut(INDENT_VALUE));
        buttonPanel.add(nextButton);
        buttonPanel.add(Box.createHorizontalStrut(INDENT_VALUE));
        buttonPanel.add(cancelButton);
        buttonPanel.add(Box.createHorizontalGlue());
		
    }

    /**
     * Sets the new labels for the current locale.
     */
    protected void setNewLabels() {
        setNewButtonLabels();
		
        revalidate();
        repaint();
    }
	
    /**
     * Sets the new labels for the buttons for the current locale.
     */
    protected void setNewButtonLabels() {
        ResourceBundle buttonLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Buttons", pm.language);			

        prevButton.setText(buttonLabels.getString("prev"));
        prevButton.setMnemonic(buttonLabels.getString("prev.mnemonic").charAt(0));

        nextButton.setText(buttonLabels.getString("next"));
        nextButton.setMnemonic(buttonLabels.getString("next.mnemonic").charAt(0));

        defaultButton.setText(buttonLabels.getString("default"));
        defaultButton.setMnemonic(buttonLabels.getString("default.mnemonic").charAt(0));

        cancelButton.setText(buttonLabels.getString("cancel"));
        cancelButton.setMnemonic(buttonLabels.getString("cancel.mnemonic").charAt(0));

        buttonPanel.repaint();

    }

    /**
     * Does the default settings for the UI.
     */
    protected void doDefault() {
        ;
    }

    /**
     * Shows the next panel.
     */
    protected void doNext() {
        pm.doThirdPartySelector(appType);
    }

    /**
     * Shows the previous panel.
     */
    protected void doPrev() {
        pm.doPrevAppType(appType);
    }

    /**
     * Listener for the navigational buttons.
     */
    class ButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String action = e.getActionCommand();
            if (action.equals("default"))
                doDefault();			
            else if (action.equals("next"))
                doNext();
            else if (action.equals("prev"))
                doPrev();
            else if (action.equals("cancel"))
                pm.cancel();		   
			
        }
    }

    /**
     * Initializes the application type's XML document.
     *
     * @param  inRoot  the document element
     * @param  appRootName  the name of the document element
     * @param  appGenericName  the name of the generic element
     * @return  the intialized document
     */
    protected Document initDocument(Element inRoot, String appRootName, String appGenericName) {

        Document document = new DocumentImpl();

        if (inRoot == null) {
            Element root = document.createElement(appRootName);
            document.appendChild(root);
            if (appGenericName != null) {
                Element generic = document.createElement(appGenericName);
                root.appendChild(generic);
            }
        }
        else {
            document.appendChild((Element) document.importNode(inRoot, true));
        }
		
        return document;
    }

    /**
     * Finds the item with the correct value.
     *
     * @param  items  an array of ComboBoxItems
     * @param  inValue  the value to look for
     * @return  the item with the correct value
     */
    protected ComboBoxItem findItem(ComboBoxItem[] items, String inValue) {
        for (int i = 0; i < items.length; i++) {
            if (items[i].value != null && items[i].value.equals(inValue))
                return items[i];
        }
        return null;
    }

    /**
     * Cleans up any outstanding widgets such as modal dialogs.
     */
    protected void cleanUp() {
        ;
    }

    /**
     * A JComboBox item. The value is the XML value and the name is displayed to the user.
     */
    class ComboBoxItem {

        public String name;
        public String value;

        public ComboBoxItem(String inName, String inValue) {
            name = inName;
            value = inValue;
        }

        public String toString() {
            return name;
        }
    }

    /**
     * Class which encapsulates a text field with an imposed value range.
     */
    class RangedTextField {

        private Number low;
        private Number high;
        public JTextField textField;
        private NumberFormat nf;

        /**
         * Sole constructor. Inits all the values.
         */
        public RangedTextField(Number inLow, Number inHigh, JTextField inTextField) {
            low = inLow;
            high = inHigh;
            textField = inTextField;
            nf = NumberFormat.getInstance(pm.language);
        }

        /**
         * Checks whether or not the current text field's value is inside
         * the allowed range constrained by the low and high values.
         *
         * @return  <code>true</code> if text field value is inside range,
         *          <code>false</code> otherwise
         */
        public boolean isInsideRange() {
            nf = NumberFormat.getInstance(pm.language);
            Number value = null;
            
            try {
                value = nf.parse(textField.getText().trim());
            }
            catch (Throwable t) {
                return false;
            }

            if (low instanceof Integer) {
                if (value.intValue() < low.intValue() 
                    || value.intValue() > high.intValue())
                    return false;

                return true;
            }
            else if (low instanceof Float) {
                if (value.floatValue() < low.floatValue() || 
                    value.floatValue() > high.floatValue())
                    return false;
				
                return true;
            }

            return false;
        }

        /**
         * Reformats the text field numeric value to the new
         * <code>PreferenceManager</code>'s language.
         */
        public void reformat() {
            Number num = null;
            try {
                num = nf.parse(textField.getText().trim());
            }
            catch (ParseException pe) {
                pe.printStackTrace();
                num = new Integer(0);
            }

            // Don't set the number formatter until after parsing
            // the value.
            nf = NumberFormat.getInstance(pm.language);
            
            String formatValue;
            try {
                formatValue = nf.format(num.doubleValue());
            }
            catch (NumberFormatException nfe) {
                nfe.printStackTrace();
                formatValue = "0";
            }

            textField.setText(formatValue);
        }

        /**
         * Sets the text field to the corresponding value.
         *
         * @param  value  the numerical value in string format
         *                (usually taken from an XML value)
         */
        public void setText( String value ) {
            nf = NumberFormat.getInstance(pm.language);
            String formatValue;

            try {
                formatValue = nf.format(Double.parseDouble(value));
            }
            catch (NumberFormatException nfe) {
                nfe.printStackTrace();
                formatValue = "0";
            }

            textField.setText(formatValue);
        }

        /**
         * Gets the numerical value of the text field in string
         * format. Typically used to enter information into an XML string.
         *
         * @return  the numerical value of the text field in string format
         */
        public String getValue() {
            nf = NumberFormat.getInstance(pm.language);
            Number num = null;
            try {
                num = nf.parse(textField.getText().trim());
            }
            catch (ParseException pe) {
                pe.printStackTrace();
                return "0";
            }
            
            if (low instanceof Integer)
                return String.valueOf(num.intValue());
            else
                return String.valueOf(num.floatValue());                
        }

        /**
         * Gets the low (floor) value.
         */
        public String getLowValue() {
            nf = NumberFormat.getInstance(pm.language);
            return nf.format(low.doubleValue());
        }

        /**
         * Gets the high (ceiling) value.
         */
        public String getHighValue() {
            nf = NumberFormat.getInstance(pm.language);
            return nf.format(high.doubleValue());
        }
		
    }
}
