/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            ChooserSpeaker.java
 *
 * Synopsis:        package ca.utoronto.atrc.web4all.prefschooser;
 * 
]*/

package ca.utoronto.atrc.web4all.prefschooser;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.filechooser.*;
import javax.swing.text.*;
import javax.accessibility.*;

import java.beans.*;
import java.io.File;
import java.util.*;

/**
 * Responds to GUI events by updating a JFileChooser's display and
 * by generating text output that is passed to a TTS system.
 *
 * @version $Id: ChooserSpeaker.java,v 1.12 2006/03/29 15:52:00 clown Exp $
 * @author  Joseph Scheuhammer.
 *
 */
public class ChooserSpeaker extends Speaker
    implements PropertyChangeListener, ActionListener, WindowFocusListener
{
    /**
     * The key in the Commands properties file that chooses the menu's name.
     */
    public final static String CMDS_KEY         = "commands";

    /**
     * The key in the Commands properties file that chooses the menu item keys.
     */
    public final static String CMDS_MENU        = "commands.menu";

    /**
     * The key in the Commands properties file that chooses the files
     * listing menu name.
     */
    public final static String FILE_LIST_MENU   = "fileList";

    /**
     * Key for "no available files" menu item.
     */
    public final static String NO_FILES         = "fileList.nofiles";
        
    /**
     * The key in the Commands properties file that chooses the directories
     * listing menu name.
     */
    public final static String DIR_LIST_MENU    = "directoryList";

    /**
     * Key for "no available files" menu item.
     */
    public final static String NO_SUBDIRS       = "directoryList.noFiles";
        
    /**
     * The suffix to add to a menu item key for that item's label.
     */
    public final static String LABEL_SUFFIX     =  ".label";
    
    /**
     * The suffix to add to acquire the keyboard mnemonic
     */
    public final static String MNEM_SUFFIX      = ".mnemonic";
    
    /**
     * The suffix to add to a menu item key for that item's key accelerator.
     */
    public final static String ACCEL_SUFFIX     = ".accelerator";

    /**
     * The suffix to add to a menu item key for that item's key accelerator.
     */
    public final static String TIP_SUFFIX       = ".tip";

    /**
     * The menu item key that designates a menu separator.
     */
    public final static String MENU_SEP         = "-";
    
    /**
     * Action command for naming the parent of the current directory.
     */
    public final static String NAME_PARENT_ACTION   = "parent";
    
    /**
     * Action command for navigating to the parent directory.
     */
    public final static String GO_PARENT_ACTION     = "goParent";
    
    /**
     * Action command for navigating to the home directory.
     */
    public final static String GO_HOME_ACTION       = "goHome";
    
    /**
     * Action command for navigating to the parent directory.
     */
    public final static String GO_ROOT_ACTION       = "goRoot";

    /**
     * Action to activate the files menu.
     */
    public final static String LIST_CURRENT_ACTION  = "listCurrentFiles";

    /**
     * Action to speak the currently selected file.
     */
    public final static String SPEAK_FILE_ACTION    = "speakCurrentFile";

    /**
     * Action to speak the current directory.
     */
    public final static String SPEAK_DIR_ACTION     = "speakCurrentDir";

    /**
     * Action to edit the currently selected file's name.
     */
    public final static String EDIT_FNAME_ACTION    = "editFileName";

    /**
     * Action command for listing the contents of the current directory.
     */
    public final static String NEW_FOLDER_ACTION    = "newFolder";
    
    /**
     * Action command for stopping a speech.
     */
    public final static String STOP_SPEECH_ACTION   = "stop";

    /**
     * Action command to open the current file.
     */
    public final static String OPEN_ACTION          = "open";
    
    /**
     * Action command to save the current file.
     */
    public final static String SAVE_ACTION          = "save";
    
    /**
     * Action command for cancelling out of the chooser.
     */
    public final static String CANCEL_ACTION        = "cancel";
    
    /**
     * Key for "unknown command" speech.
     */
    public final static String UNKOWN_ACTION        = "unknown.command";
    
    /**
     * Key for "parent directory" speech.
     */
    public final static String PARENT_DIR           = "parent.dir.is";
    
    /**
     * Key for "current directory" speech.
     */
    public final static String CURRENT_DIR          = "current.dir.is";
    
    /**
     * Key for "directory changed" speech.
     */
    public final static String DIR_CHANGED          = "directory.changed";
    
    /**
     * Key for "no current file" speech.
     */
    public final static String NO_CURRENT_FILE      = "no.current.file";

    /**
     * Key for "current file is" speech.
     */
    public final static String CURRENT_FILE         = "current.file.is";
    
    /**
     * Key for "selected folder is" speech.
     */
    public final static String SELECTED_DIR         = "selected.dir.is";
    
    /**
     * Key for "opening file" speech.
     */
    public final static String OPENING_FILE         = "opening.file";
    
    /**
     * Key for "saving file" speech.
     */
    public final static String SAVING_FILE          = "saving.file";
    
    /**
     * Key for "chooser title is" speech.
     */
    public final static String CHOOSER_TITLE        = "chooser.title";
        
    /**
     * Key for "save prefs as" speech.
     */
    public final static String SAVE_AS              = "save.prefs.as";
        
    /**
     * Key for "chooser prefs to use" speech.
     */
    public final static String CHOOSE_USE           = "open.prefs.file";
        
    /**
     * Key for "no such file as" speech.
     */
    public final static String NO_SUCH_FILE          = "no.such.file";
        
    /**
     * Key for "editing file name" speech.
     */
    public final static String EDITING_NAME          = "editing.name";
        
    /**
     * The JFileChooser that this object is self-voicing.
     */
    private JFileChooser theFileChooser;
 
    /**
     * Menu bar that contains the menu of commands for navigating and activating
     * various self-voiced features of the file chooser.
     */
    private JMenuBar theMenuBar;
    
    /**
     * The commands menu in <ocde>theMenuBar</code>.
     */
    private JMenu theCommandsMenu;
    
    /**
     * The menu item that is "open" or "save" depending on the type of chooser.
     */
    private JMenuItem theOpenSaveItem;
    
    /**
     * Current directory's sub-folders listed as a menu.
    */
    private JMenu theDirListMenu;
    
    /**
     * Current directory's files listed as a menu.
    */
    private JMenu theFileListMenu;
    
    /**
     * File choose-action to associate with the menu items in
     * <code>theDirListMenu</code> and <code>theFileListMenu</code>.
     */
    private ChooseFileAction theChooseFileAction;
    
    /**
     * The speaker for the file name text entry field.
     */
    private TextEntrySpeaker theTextEntrySpeaker;
    
    /**
     * The ResourceBundle that contains localized text for the menus, speeches,
     * etc.
     */
    private ResourceBundle theResources;
    
    /**
     * Re-usable array of speeches.
     */
    private volatile Vector theSpeeches;
    
    /** 
     * Hot-key modifier ("cmd" on Macs, "ctrl" on Windows...).
     */
    private int theHotkeyModifier;
    
    /**
     * Singleton instance of this class to be shared by all.
     */
    private static ChooserSpeaker sharedInstance;
    
    /**
     * The Window (JDialog) that the file chooser is displayed within.
     */
    private volatile Window theChooserWindow;
    
    /**
     * Acquire or create and acquire the single shared instance of this class.
     * @param ioFileChooser     The WFileChooser that this class self-voices.
     * @param inLocale          The Locale to use for the UI strings.
     * @return                  The global shared instance of the ChooserSpeaker.
     */
    public static ChooserSpeaker getSharedInstance (WFileChooser ioFileChooser, Locale inLocale)
    {
        if (sharedInstance == null)
            sharedInstance = new ChooserSpeaker (ioFileChooser, inLocale);

        return sharedInstance;
    
    }   // end getSharedInstance()
    
    /**
     * Initialize the generator with the JFileChooser that it is self-voicing.
     * @param       ioFileChooser   The WFileChooser that this class
     *              self-voices.
     * @param       inLocale        The Locale to use for the UI strings.
     * @exception   java.lang.IllegalArgumentException This object must be
     *              initialized with a JFileChooser.
     * @see #setFileChooser(JFileChooser)
     */
    public ChooserSpeaker (WFileChooser ioFileChooser, Locale inLocale)
        throws IllegalArgumentException
    {
        super();
        setFileChooser (ioFileChooser);
        theSpeeches = new Vector();
        theTextEntrySpeaker = new TextEntrySpeaker();

        // Hotkey modifier key is system dependent.
        //
        String os = System.getProperty ("os.name");
        if (System.getProperty ("os.name").indexOf ("Mac") < 0)
            theHotkeyModifier = java.awt.Event.CTRL_MASK;
        else
            theHotkeyModifier = java.awt.Event.META_MASK;
        
        // Get the resources, build the commands, and add them to the file
        // chooser.
        //
        try
        {
            theResources = ResourceBundle.getBundle (
                "ca.utoronto.atrc.web4all.prefschooser.CommandsMenuRez",
                inLocale
            );
            buildMenuBar (inLocale);
            ioFileChooser.setJMenuBar (theMenuBar);
            ioFileChooser.setChooserSpeaker (this);
        }
        catch (MissingResourceException mre)    // should not happen.
        { ; }
        
        // To hear open, save, and cancel actions.
        //
        ioFileChooser.addActionListener (this);
   
    }   // end ChooserSpeaker()
    
    /**
     * Reset the JFileChooser that <code>this</code> is voicing.
     * @param       ioFileChooser   The JFileChooser that this class self-voices.
     * @exception   java.lang.IllegalArgumentException  This object must be
     *              initialized with a JFileChooser.
     */
    public void setFileChooser (JFileChooser ioFileChooser)
        throws IllegalArgumentException
    {
        if (ioFileChooser == null)
            throw new IllegalArgumentException (
                "Requires non-null JFileChooser"
            );
        
        theFileChooser = ioFileChooser;
        theFileChooser.addPropertyChangeListener (this);
        
    }   // end setFileChooser().

    /**
     * Build the file chooser menus and add the menu bar to it.  This also
     * @param   inLocale    The current locale.
     */
    private void buildMenuBar (Locale inLocale)
    {    	    
        // Build <theCommandsMenu> according to the resources with the relevant
        // Locale.
        //
        theMenuBar = new JMenuBar();
        theCommandsMenu = new JMenu();
        theMenuBar.add (theCommandsMenu);
        theFileListMenu = new JMenu();
        theMenuBar.add (theFileListMenu);
        theDirListMenu = new JMenu();
        theMenuBar.add (theDirListMenu);
        theChooseFileAction = new ChooseFileAction (theFileChooser);
        try
        {
            // First, get the label and mnemonic for the commands menu
            //
            lookupMenuLabelAndMnemonic (CMDS_KEY, theCommandsMenu);
            
            // Get the string that lists the menu item keys.  Then loop thru the
            // keys to build each item.
            //
            StringTokenizer menuItemKeys = new StringTokenizer (
                theResources.getString (ChooserSpeaker.CMDS_MENU)
            );
            int menuIndex = 1;
            while (menuItemKeys.hasMoreTokens())
                menuIndex = buildAndAddMenuItem (
                    menuItemKeys.nextToken(), theCommandsMenu, menuIndex
                );
            
            // Finally, get the labels of <theFileListMenu> and <theDirListMenu>
            // from the ressource bundle, and build its contents.
            //
            lookupMenuLabelAndMnemonic (FILE_LIST_MENU, theFileListMenu);
            lookupMenuLabelAndMnemonic (DIR_LIST_MENU, theDirListMenu);
            rebuildDirList();
         }
         
         catch (MissingResourceException mre)   // shouldn't happen.
         {
            mre.printStackTrace();
         }
         
         // *** DEBUG *** put a mouse click event on <theMenuBar> to
         // cause show/hide the speech log window.
         //
         addShowHideSpeechFeedbackHandler();
    
    }   // end buildMenuBar().
    
    /**
     * Get a menu lebel and mnemonic from the resource bundle, and assign them
     * to the given JMenu
     * @param   inKey   The lookup key for the label/mnemonic sought.
     * @param   ioMenu  The JMenu to assign the label/mnemonic to.
     * @exception   java.util.MissingResourceException
     */
    private void lookupMenuLabelAndMnemonic (String inKey, JMenu ioMenu)
        throws MissingResourceException
    {
        String value;
        value = theResources.getString (inKey + LABEL_SUFFIX);
        ioMenu.setText (value);
        value = theResources.getString (inKey + MNEM_SUFFIX);
        ioMenu.setMnemonic (value.charAt (0));
    
    }   // end lookupMenuLabelAndMnemonic().
    
    private void addShowHideSpeechFeedbackHandler()
    {
        theMenuBar.addMouseListener (new MouseAdapter() {
            public void mouseClicked (MouseEvent inMouseEvent) {
                // alt-shift-doubleclick..
                //
                if ( (inMouseEvent.getClickCount() == 2) &&
                     (inMouseEvent.isShiftDown()) &&
                     (inMouseEvent.isControlDown()) )
                {
                    SpeechLog.getSharedInstance().showHideFeedbackWindow();
                }
            }
        });
    
    }   // end addShowHideSpeechFeedbackHandler().


    /**
     * Builds a single menu item for the given menu.  Note that this handles
     * menu separators.
     * @param   inItemKey   The key to use to access info about the menu item from the
     *                      resources.
     * @param   ioMenu      The JMenu to add the menu item to.
     * @param   ioIndex     The index of the new menu item, if not a separator.
     *                      This is used for the hot key.
     * @return              <code>ioIndex</code> plus <code>1</code> if this
     *                      is not a separator; otherwise, the given value of
     *                      <ocde>ioIndex</code> is returned.
     */
    private int buildAndAddMenuItem (
        String inItemKey, JMenu ioMenu, int ioIndex)
    {    	    
        // Special case -- in the <inItemKey> is the separator character, add a
        // JMenuSeparator and return.  Do not update <ioIndex>.
        //
        if (inItemKey.equals (ChooserSpeaker.MENU_SEP))
            ioMenu.addSeparator();
        
        // An actual menu item (not a separator).  Build it.
        //
        else
        {
            try
            {
                JMenuItem anItem = new JMenuItem();
                anItem.setActionCommand (inItemKey);
                setLabelTipAccel (anItem, inItemKey);
              
                // Add the action listener, and add it to the menu...done.
                //
                anItem.addActionListener (this);
                ioMenu.add (anItem);
                ioIndex++;
                
                // Record the "open" menu item for when <theFileChooser> is
                // a save-file dialog, and "open" becomes "save".
                //
                if (inItemKey.equals (OPEN_ACTION))
                    theOpenSaveItem = anItem;
            }
            catch (MissingResourceException mre)   // shouldn't happen.
            {
                mre.printStackTrace();
            }
        }
        return ioIndex;

    }   // end buildAndAddMenuItem().
    
    /**
     * Utility method to find a string in <code>theResources</code>, while
     * scorching any <code>MissingResourceException</code>
     * @param   inKey   The key for the string.
     * @return          The String value associated with <code>inKey</code>, or
     *                  the empty String if not found.
     */
    private String getRezString (String inKey)
    {
        String value = "";
        try
        {
            value = theResources.getString (inKey);
        }
        catch (MissingResourceException mre)
        { ; }
        
        return value;
    
    }   // end getRezString().
    
    /**
     * Get the type of file chooser in terms of whether it is an "open-file"
     * or a "save-file" chooser, and adjust the open/save menu item accordingly.
     * @param   inType  The type of the file chooser, one of
     *                  JFileChooser.OPEN_DIALOG or JFileChooser.SAVE_DIALOG.
     *                  The default is an "open-file" chooser.
     */
    void setOpenSaveMenuType (int inType)
    {
        // If it's save, configure <theOpenSaveItem> as appropriate.
        //
        String key;
        if (inType == JFileChooser.SAVE_DIALOG)
            key = SAVE_ACTION;
        else
            key = OPEN_ACTION;
            
        // Reset <theOpenSaveItem>'s label, hot key, tool tip and action
        // command.
        try
        {
            String string = theResources.getString (
                key + ChooserSpeaker.LABEL_SUFFIX
            );
            theOpenSaveItem.setText (string);
            
            string = theResources.getString (
                key + ChooserSpeaker.ACCEL_SUFFIX
            );
            theOpenSaveItem.setAccelerator (KeyStroke.getKeyStroke (
                string.charAt (0), theHotkeyModifier
            ));
            theOpenSaveItem.setActionCommand (key);
            
            // Add tooltip, if there is one.
            //
            string = null;
            try
            {
                string = theResources.getString (
                    key + ChooserSpeaker.TIP_SUFFIX
                );
                theOpenSaveItem.setToolTipText (string);
            }
            catch (MissingResourceException noToolTip)  // not a big deal.
            { ; }
        }
        
        catch (MissingResourceException mre)            // can't happen.
        { ; }
     
    }   // end setOpenSaveMenuType()
    
    /**
     * Update the menus's and menu items' labels and speeches given a switch in
     * locale.
     * @param   inLocale    The Locale to switch the labels and speeched to.
     */
    public void updateLocale (Locale inLocale)
    {
        try
        {
            // First reset <theResources> given <inLocale>.
            //
            theResources = ResourceBundle.getBundle (
                "ca.utoronto.atrc.web4all.prefschooser.CommandsMenuRez",
                inLocale
            );
            
            // Switch the labels on the menus.
            //
            lookupMenuLabelAndMnemonic (CMDS_KEY, theCommandsMenu);
            lookupMenuLabelAndMnemonic (FILE_LIST_MENU, theFileListMenu);
            lookupMenuLabelAndMnemonic (DIR_LIST_MENU, theDirListMenu);
            
            // Loop to update the menu items.
            //
            for (int i = 0; i < theCommandsMenu.getItemCount(); i++)
            {
                JMenuItem item = theCommandsMenu.getItem (i);
                if (item != null)   // could be separator.
                {
                    // Update to localized label.
                    //
                    String key = item.getActionCommand();
                    setLabelTipAccel (item, key);
                }
            }
            
            // Make sure the base class speaker knows that the locale has
            // changed.
            //
            setLocale (inLocale);
        }
        catch (MissingResourceException mre)   // shouldn't happen.
        {
            mre.printStackTrace();
        }

    }   // end updateLocale().
    
    /**
     * Utility to set the label, tooltip, and accelerator on a menu item.
     * @param   ioItem              The menu item to modify.
     * @param   inActionCommand     Key for look up of the information.
     * @exception   java.util.MissingResourceException if the lookup of one of
     *              the label or accelerator fails.  The tooltip can be missing.
     */
    public void setLabelTipAccel (JMenuItem ioItem, String inActionCommand)
        throws MissingResourceException
    {
        // Menu item label.
        //
        String string = theResources.getString (
            inActionCommand + ChooserSpeaker.LABEL_SUFFIX
        );
        ioItem.setText (string);
                
        // Accelerator.  Note: handle special case of up-arrow.
        //
        string = theResources.getString (
            inActionCommand + ChooserSpeaker.ACCEL_SUFFIX
        );
        if (string.equals ("UpArrow"))
        {
            ioItem.setAccelerator (KeyStroke.getKeyStroke (
                KeyEvent.VK_UP, theHotkeyModifier
            ));
        }
        else    // "normal" key.
        {
            ioItem.setAccelerator (KeyStroke.getKeyStroke (
                string.charAt (0), theHotkeyModifier
            ));
        }
        
        // Tooltip
        //
        try
        {
            string = theResources.getString (
                inActionCommand + ChooserSpeaker.TIP_SUFFIX
            );
            ioItem.setToolTipText (string);
        }
        catch (MissingResourceException noToolTip)  // not a big deal.
        { ; }
    
    }   // end setLabelTipAccel().
    
    /**
     * Search the component tree of the file chooser for the text entry field
     * that users type the file name into.  Note that this chooses the first
     * JTextComponent as the answer -- admittedly fragile and unreliable.
     */
    private JTextComponent findTextEntryField()
    {
        JTextComponent result = null;
        AccessibleContext ac = null;
        if (theFileChooser != null)
        {
            // Loop thru the sub-compononents of <theFileChooser>,
            // checking the class type of each child.
            //
            int numChilds = theFileChooser.getComponentCount();
            for (int i = 0; i < numChilds; i++)
            {
                ac = null;
                Component child = theFileChooser.getComponent (i);
                
                // The logic is that if the <child> isa JTextComponent, it
                // must implement both interface Accessible and AccessibleText.
                //
                if (child instanceof Accessible)
                    ac = ((Accessible) child).getAccessibleContext();

                if ((ac != null) && (ac.getAccessibleText() != null))
                {
                    if (child instanceof JTextComponent)
                    {
                        result = (JTextComponent) child;
                        break;  // found, break out of the loop.
                    }
                }
                
                // Recursively search the sub-components of <child> for the
                // text entry field.
                //
                result = recurseFindTextEntryField (child);
                if (result != null)
                    break;  // found, break out of the loop
            }
        }
        return result;
    
    }   // end findTextEntryField().
    
    /**
     * Recursively search a Component tree within the file chooser for the
     * text entry field.
     */
    private JTextComponent recurseFindTextEntryField (Component inParent)
    {
        JTextComponent result = null;
        AccessibleContext ac = null;
        
        // Search the sub-components of <inParent> only if it has any.
        //
        if (inParent instanceof Container)
        {
            int numChilds = ((Container) inParent).getComponentCount();
            for (int i = 0; i < numChilds; i++)
            {
                ac = null;
                Component child = ((Container) inParent).getComponent (i);

                // The logic is that if the <child> isa JTextComponent, it
                // must implement both interface Accessible and AccessibleText.
                //
                if (child instanceof Accessible)
                    ac = ((Accessible) child).getAccessibleContext();

                if ((ac != null) && (ac.getAccessibleText() != null))
                {
                    if (child instanceof JTextComponent)
                    {
                        result = (JTextComponent) child;
                        break;  // found, break out of loop.
                    }
                }
                    
                // Recursively search the sub-components of <child> for the
                // text entry field.
                //
                result = recurseFindTextEntryField (child);
                if (result != null)
                    break;  // found, break out of loop.
            }
        }
        return result;

    }   // end recurseFindTextEntryField().

    /**
     * For debugging to find out the relevant class of an object, usually a
     * java.awt.Component.
     */
    private void printClassHierarchy (Object instance, int tabs)
    {
        for (int i=0; i < tabs; i++)
            System.out.print ("\t");

        Class clzz = instance.getClass();
        System.out.print (clzz.getName() + ", ");
        while (true)
        {
            clzz = clzz.getSuperclass();
            if (clzz == null)
                break;
            System.out.print (clzz.getName() + ", ");
        }
        System.out.println (".");
    
    }   // end printClassHierarchy().
            
    /**
     * Provide speech for telling the user the name of the parent directory.
     */
    private void nameParent()
    {
        // Get the speech prefix.
        //
        theSpeeches.clear();
        theSpeeches.add (getRezString (PARENT_DIR));
        
        // Get the parent folder's name.
        //
        FileSystemView fileSysView = theFileChooser.getFileSystemView();
        File here = theFileChooser.getCurrentDirectory();
        File parentFolder = fileSysView.getParentDirectory (here);
        String parentName = fileSysView.getSystemDisplayName (parentFolder);
                
        // If at top, just speak the current directory.
        //
        theSpeeches.add (" "); // space.
        if ((parentName == null) || (parentName.length() == 0))
            theSpeeches.add (fileSysView.getSystemDisplayName (here));
        else
            theSpeeches.add (parentName);

        speak (theSpeeches);
    
    }   // end nameParent().
    
    /**
     * Move to the parent directory.
     */
    private void goParent()
    {
        theFileChooser.changeToParentDirectory();
    
    }   // end goParent().
    
    /**
     * (Re)build the "Files" and "Directories" menus.  The "Files" menu lists
     * the files in the current directory.  The "Directories" menu lists the
     * sub-directories..
     */
    private void rebuildDirList()
    {
        JMenuItem anItem;
        StringBuffer menuItemName = new StringBuffer();
        
        // First, flush <theDirListMenu>.  Then fill it with the contents of
        // the current directory.
        //
        theFileListMenu.removeAll();
        theDirListMenu.removeAll();
        FileSystemView fileSysView = theFileChooser.getFileSystemView();
        FileView fileView = theFileChooser.getUI().getFileView (theFileChooser);
        File here = theFileChooser.getCurrentDirectory();
        File[] children = fileSysView.getFiles (here, true /*use file hiding*/);
        for (int i = 0; i < children.length; i++)
        {
            File aFile = children[i];
            if (aFile != null)
            {
                // Get the name of <aFile>.  If there is none, loop back.
                //
                String fname = fileView.getName (aFile);
                if (fname == null)
                    continue;
                
                // If it's a directory, add the item to <theDirListMenu>.  Also,
                // store the actual File info as a client property of the menu
                // item.
                //
                if (aFile.isDirectory())
                {
                    anItem = new JMenuItem (fname);
                    anItem.putClientProperty (ChooseFileAction.FILE_KEY, aFile);
                    anItem.addActionListener (theChooseFileAction);
                    theDirListMenu.add (anItem);
                }
                
                // Not a directory.  Check it against the current file filter
                // of the chooser.
                //
                else if (checkFileAgainstFilters (aFile))
                {
                    menuItemName.setLength (0);
                    menuItemName.append (fname);
                    String desc = fileView.getTypeDescription (aFile);
                    if (desc != null)
                    {
                        menuItemName.append (" (");
                        menuItemName.append (desc);
                        menuItemName.append (")");
                    }
                    anItem = new JMenuItem (menuItemName.toString());
                    anItem.putClientProperty (ChooseFileAction.FILE_KEY, aFile);
                    anItem.addActionListener (theChooseFileAction);
                    theFileListMenu.add (anItem);
                }
            }
        }
        
        // Special case where there are no files listed.
        //
        if (theFileListMenu.getItemCount() == 0)
        {
            try 
            {
                anItem = new JMenuItem (
                    theResources.getString (NO_FILES)
                );
                theFileListMenu.add (anItem);
            }
            catch (MissingResourceException mre)    // can't happen.
            { ; }
        }
        if (theDirListMenu.getItemCount() == 0)
        {
            try 
            {
                anItem = new JMenuItem (
                    theResources.getString (NO_SUBDIRS)
                );
                theDirListMenu.add (anItem);
            }
            catch (MissingResourceException mre)    // can't happen.
            { ; }
        }
    
    }   // end rebuildDirList().
    
    /**
     * Check the given file against the current FileFilters employed by the
     * file chooser.
     * @param   inFile  The File to check.
     * @return          <code>true</code> if <code>inFile</code> is acceptable;
     *                  <code>false</code>, otherwise.
     */
    public boolean checkFileAgainstFilters (File inFile)
    {
        FileFilter filter = theFileChooser.getFileFilter();
        if (filter == null)
            return true;
        else
            return filter.accept (inFile);
    
    }   // end checkFileAgainstFilters().
    
    /**
     * Go to the files listing for the current directory, i.e. activate the
     * "Files" menu..
     */
    protected void listCurrent()
    {
        theFileListMenu.doClick();
    
    }   // end listCurrent().
    
    /**
     * Speak the name of the currently selected file.
     */
    protected void speakCurrentFile()
    {
        theSpeeches.clear();
        
        // Get the selected file.  If none, check the text entry field.
        //
        File selFile = checkForSelectedFile (false /* no speech */);
        if (selFile == null)
        {
            if (theTextEntrySpeaker.isEmpty())
                speak (getRezString (NO_CURRENT_FILE));
            else
                theTextEntrySpeaker.speakContents (getRezString (CURRENT_FILE));
        }
        
        // There is a selected file.  Present its name.
        //
        else
        {
            FileView fileView = theFileChooser.getUI().getFileView (theFileChooser);
            theSpeeches.add (getRezString (CURRENT_FILE));
            theSpeeches.add (fileView.getName (selFile));
            speak (theSpeeches);
        }
        
    }   // end speakCurrentFile().

    /**
     * Speak the name of the current directory.
     */
    protected void speakCurrentDir()
    {
        theSpeeches.clear();

        // Get the current directory, and speek it.
        //
        File dir = theFileChooser.getCurrentDirectory();
        FileView fileView = theFileChooser.getUI().getFileView (theFileChooser);
        theSpeeches.add (getRezString (CURRENT_DIR));
        theSpeeches.add (fileView.getName (dir));
        
        // Speak the speech.
        //
        speak (theSpeeches);
   
    }   // end speakCurrentDir().
    
    /**
     * If the user selects a directory, speak its name.
     * @param   inDir   File representing the directory to speak.
     */
    protected void speakSelectedDir (File inDir)
    {
        theSpeeches.clear();
        theSpeeches.add (getRezString (SELECTED_DIR));

        // Get the FileView version of the directory name and speek it.
        //
        FileView fileView = theFileChooser.getUI().getFileView (theFileChooser);
        theSpeeches.add (fileView.getName (inDir));
        speak (theSpeeches);
    
    }   // end speakSelectedDir().
    
    /**
     * Edit the name of the currently selected file, or report that there is
     * no selected file.
     */
    protected void editCurrentFileName()
    {
        // Move focus to the JTextComponent.
        //
        theTextEntrySpeaker.requestFocus();
        theTextEntrySpeaker.speakContents (getRezString (EDITING_NAME));

    }   // editCurrentFileName()
    
    /**
     * Move to the parent directory.
     */
    protected void goRoot()
    {
        System.out.println ("+++ goRoot() is not implemented +++");
    
    }   // end goRoot().
    
    /**
     * Move to the home directory.
     */
    protected void goHome()
    {
        FileSystemView fsv = theFileChooser.getFileSystemView();
        theFileChooser.setCurrentDirectory (fsv.getDefaultDirectory());
    
    }   // end goRoot().
    
    /**
     * Create a new folder.  Currently, not fully implemented from a
     * self-voicing point of view -- no speech feedback when editing
     * folder's name.
     */
    protected void newFolder()
    {
	    File newFolder = null;
	    File currentDirectory = theFileChooser.getCurrentDirectory();
        FileSystemView fsv = theFileChooser.getFileSystemView();
	    try
        {
            newFolder = fsv.createNewFolder (currentDirectory);
            theFileChooser.setSelectedFile (newFolder);
            theFileChooser.rescanCurrentDirectory();
            rebuildDirList();
	    }
        catch (java.io.IOException e)
        {
            Toolkit.getDefaultToolkit().beep();
        }

    }   // end newFolder().
    
    /**
     * Set things up to approve the selection, but only if there is a selected
     * file.  If there isn't one, inform the user.
     * @param inKey     One of <code>OPEN_ACTION</code> or <code>SAVE_ACTION</code>
     */
    protected void openSaveFile()
    {
        // Get the selected file.  If none, put together speech that says
        // that.
        //
        File selFile = checkForSelectedFile();
        if (selFile != null)
            theFileChooser.approveSelection();
                
    }   // end openSaveFile().
    
    /**
     * Check for selected file, and if none, possibly inform the user.
     * @param   inFlag      A boolean that, if <code>true</code> means to
     *                      inform the user via speech if there is no selected
     *                      file.  If <code>false</code>, no speech is output.
     * @return              The selected file, or <code>null</code> if none.
     */
    private File checkForSelectedFile (boolean inFlag)
    {
        File selFile = theFileChooser.getSelectedFile();
        if ((selFile == null) && inFlag)
        {
            speak (getRezString (NO_CURRENT_FILE));
        }
        return selFile;
    
    }   // end checkForSelectedFile().
    
    /**
     * Check for selected file, and if none, inform the user.
     * @return      The selected file, or <code>null</code> if none.
     */
    private File checkForSelectedFile()
    {
        return checkForSelectedFile (true);
    
    }   // end checkForSelectedFile().
    
    /**
     * Vocie thate the currently selected file is being opened/saved.
     */
    protected void chooserApprove()
    {
        theSpeeches.clear();
        int type = theFileChooser.getDialogType();

        // Get the selected file.  If there is one voice that it is being
        // opened/saved.
        //
        File selFile = checkForSelectedFile();
        if (selFile != null)
        {
            FileView fileView = theFileChooser.getUI().getFileView (theFileChooser);
            if (type == JFileChooser.SAVE_DIALOG)
                theSpeeches.add (getRezString (SAVING_FILE));
              
            else if (selFile.exists())  // assume OPENING_FILE
                theSpeeches.add (getRezString (OPENING_FILE));

            else
                theSpeeches.add (getRezString (NO_SUCH_FILE));
            
            theSpeeches.add (" ");  // space
            theSpeeches.add (fileView.getName (selFile));
            speak (theSpeeches);
        }
        
    }   // end chooserApprove().
    
    /**
     * Cancel out of the file chooser dialog.
     */
    protected void cancel()
    {
        theFileChooser.cancelSelection();
        
    }   // end cancel().

    /**
     * File chooser reports cancelling. Voice same.
     */
    protected void chooserCancel()
    {
        speak (getRezString (CANCEL_ACTION + LABEL_SUFFIX));
        
    }   // end cancel().
    
    /**
     * Speech for unknown commands.
     */
    protected void unknownCommmand()
    {
        speak (getRezString (UNKOWN_ACTION));
    
    }   // end unknownCommmand().
        
//==================================
// interface PropertyChangeListener.
//==================================

    /**
     * Handle changes in what the JFileChooser is displaying.
     * @param   inEvent   The PropertyChangeEvent that called us.
     */
    public void propertyChange (PropertyChangeEvent inEvent)
    {
        theSpeeches.clear();
        String prop = inEvent.getPropertyName();
        if (JFileChooser.DIRECTORY_CHANGED_PROPERTY.equals (prop))
        {
            theSpeeches.add (getRezString (DIR_CHANGED));
            theSpeeches.add (
                theFileChooser.getName (theFileChooser.getCurrentDirectory())
            );
            speak (theSpeeches);
            rebuildDirList();
        }
        else if (JFileChooser.DIALOG_TITLE_CHANGED_PROPERTY.equals (prop))
        {
            theSpeeches.add (getRezString (CHOOSER_TITLE));
            theSpeeches.add (theFileChooser.getDialogTitle());
            speak (theSpeeches);
        }
        else if (JFileChooser.SELECTED_FILE_CHANGED_PROPERTY.equals (prop))
        {
            File selFile = checkForSelectedFile();
            if (selFile != null)
            {
                if (selFile.isDirectory())
                    speakSelectedDir (selFile);
                else
                    speakCurrentFile();
            }
            rebuildDirList();
        }
        else if (JFileChooser.FILE_FILTER_CHANGED_PROPERTY.equals (prop))
        {
            rebuildDirList();
        }

    }   // end propertyChange().

//=========================
// interface ActionListener
//=========================

    /**
     * Handle commands to the file chooser itself.
     * @param   inAction    The ActionEvent that called use.
     */
    public void actionPerformed (ActionEvent inAction)
    {
        // Get out the command and the source.  Handle <theFileChooser>
        // actions first.
        //
        String cmd = inAction.getActionCommand();
        Object src = inAction.getSource();
        if (src == theFileChooser)
        {
            if (cmd.equals (JFileChooser.APPROVE_SELECTION))
                chooserApprove();
                
            else if (cmd.equals (JFileChooser.CANCEL_SELECTION))
                chooserCancel();
        }
        
        // Handle our commands.
        //
        else
        {
            if (cmd.equals (NAME_PARENT_ACTION))
                nameParent();

            else if (cmd.equals (GO_PARENT_ACTION))
                goParent();
            
            else if (cmd.equals (GO_HOME_ACTION))
                goHome();
            
            else if (cmd.equals (LIST_CURRENT_ACTION))
                listCurrent();
            
            else if (cmd.equals (SPEAK_FILE_ACTION))
                speakCurrentFile();
            
            else if (cmd.equals (SPEAK_DIR_ACTION))
                speakCurrentDir();
            
            else if (cmd.equals (EDIT_FNAME_ACTION))
                editCurrentFileName();
                
            else if (cmd.equals (NEW_FOLDER_ACTION))
                newFolder();
            
            else if (cmd.equals (STOP_SPEECH_ACTION))
                stopSpeaking();
            
            else if ((cmd.equals (OPEN_ACTION)) || (cmd.equals (SAVE_ACTION)))
                openSaveFile();
            
            else if (cmd.equals (CANCEL_ACTION))
                cancel();
            
            // default speech.
            //
            else
                unknownCommmand();
        }

    }   // end actionPerformed().

//==============================
// interface WindowFocusListener
//==============================
    
    /**
     * The file chooser's window just received focus.  Tell the user that a
     * open-file or save-file dialog is on screen, as appropriate.  Also,
     * store the focussed component, since it is the text field.
     * @param inWinEvent    The WindowEvent that called us.
     */
    public void windowGainedFocus (WindowEvent inWinEvent)
    {
        theChooserWindow = inWinEvent.getWindow();

        // Get the type of <theFileChooser>, speak the appropriate feed back,
        // and insure that <theOpenSaveMenuItem> is in the correct state.
        //
        int type = theFileChooser.getDialogType();
        if (type == JFileChooser.SAVE_DIALOG)
            speak (getRezString (SAVE_AS));
        else
            speak (getRezString (CHOOSE_USE));
        
        setOpenSaveMenuType (type);
        rebuildDirList();
        
        // Find the text entry field in the choose, and put focus there.
        //
        JTextComponent entry = findTextEntryField();
        if (entry != null)
        {
            theTextEntrySpeaker.setEntryField (entry);
            theTextEntrySpeaker.requestFocus();
        }
      
    }   // end windowGanedFocus().

    /**
     * The file chooser's window just lost focus. Forget the focussed component.
     * @param inWinEvent    The WindowEvent that called us.
     */
    public void windowLostFocus (WindowEvent inWinEvent)
    {
        theChooserWindow = null;
        theTextEntrySpeaker.unsetEntryField();
        
    }   // end windowLostFocus().

}   // end class ChooserSpeaker.

