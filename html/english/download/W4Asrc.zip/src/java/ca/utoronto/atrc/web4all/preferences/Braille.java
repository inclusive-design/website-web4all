/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

/**
 * Class to represent the application type settings for Braille.
 *
 * @author David Weinkauf
 * @version $Revision: 1.4 $, $Date: 2006/03/28 16:31:10 $
 */
public class Braille extends PWMEditPanel {

    private JCheckBox markHighlight, markBold, markUnderline, markItalic, markStrikeout, markColor;

    private ComboBoxItem off, left, right;

    private ComboBoxItem[] statusCells;

    private ComboBoxItem uncontracted, contracted;

    private JComboBox gradeComboBox, numDotsComboBox, statusCellComboBox;

    private JSlider dotPressureSlider;

    private RangedTextField numCellsField;

    private JLabel gradeLabel, numDotsLabel, numCellsLabel, dotPressureLabel, statusCellLabel;

    private JLabel lowLabel, mediumLabel, highLabel;

    private TitledBorder generalTitle, markTitle;

    protected Document document;

    protected Element generic;


    /**
     * The constructor initializes all the components in the dialog and displays them accordingly.
     *
     * @param  pm  the PreferenceManager
     * @param  root the root element of the application type's XML document
     * @param  inAppType  the application type of this panel
     */
    public Braille(PreferenceManager pm, Element root, String inAppType) {
        super(pm, inAppType, inAppType + TITLE_SUFFIX);

        document = initDocument(root, xmlLabels.getString(BRAILLE), xmlLabels.getString(BRL_GENERIC));
        generic = DOMUtil.getFirstChildElement(document.getDocumentElement());
	
        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Braille", pm.language);
        ResourceBundle hashLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.HashTables", pm.language);
	
        uncontracted = new ComboBoxItem(labels.getString("uncontracted"), "1");
        contracted = new ComboBoxItem(labels.getString("contracted"), "2");

        ComboBoxItem[] gradeItems = {uncontracted, contracted};
        gradeComboBox = new JComboBox(gradeItems);
        gradeComboBox.setForeground(TEXT_COLOUR);
        gradeComboBox.setFont(TEXT_FONT);
        gradeComboBox.setBackground(PANEL_BACKGROUND);		
        gradeComboBox.setSelectedIndex(0);

        gradeLabel = new JLabel(labels.getString("type"));
        gradeLabel.setDisplayedMnemonic(labels.getString("type.mnemonic").charAt(0));
        gradeLabel.setLabelFor(gradeComboBox);
        gradeLabel.setFont(TEXT_FONT);
        gradeLabel.setForeground(TEXT_COLOUR);


        String[] numDotsItems = {"6", "8"};
        numDotsComboBox = new JComboBox(numDotsItems);
        numDotsComboBox.setForeground(TEXT_COLOUR);
        numDotsComboBox.setFont(TEXT_FONT);
        numDotsComboBox.setBackground(PANEL_BACKGROUND);		
        numDotsComboBox.setSelectedIndex(0);

        numDotsLabel = new JLabel(labels.getString("num.dots"));
        numDotsLabel.setDisplayedMnemonic(labels.getString("num.dots.mnemonic").charAt(0));
        numDotsLabel.setLabelFor(numDotsComboBox);
        numDotsLabel.setFont(TEXT_FONT);
        numDotsLabel.setForeground(TEXT_COLOUR);

        off = new ComboBoxItem(labels.getString("off"), "off");
        left = new ComboBoxItem(labels.getString("left"), "left");
        right = new ComboBoxItem(labels.getString("right"), "right");

        ComboBoxItem[] tempStatusCells = { off, left, right };
        statusCells = tempStatusCells;

        statusCellComboBox = new JComboBox(statusCells);
        statusCellComboBox.setForeground(TEXT_COLOUR);
        statusCellComboBox.setFont(TEXT_FONT);
        statusCellComboBox.setBackground(PANEL_BACKGROUND);		
        statusCellComboBox.setSelectedIndex(0);

        statusCellLabel = new JLabel(labels.getString("status.cell"));
        statusCellLabel.setDisplayedMnemonic(labels.getString("status.cell.mnemonic").charAt(0));
        statusCellLabel.setLabelFor(statusCellComboBox);
        statusCellLabel.setFont(TEXT_FONT);
        statusCellLabel.setForeground(TEXT_COLOUR);

        JTextField textField = new JTextField(5);
        textField.setFont(TEXT_FONT);

        numCellsField = new RangedTextField(new Integer(8), new Integer(120), textField);
        numCellsField.setText("80");

        numCellsLabel = new JLabel(labels.getString("num.cells"));
        numCellsLabel.setDisplayedMnemonic(labels.getString("num.cells.mnemonic").charAt(0));
        numCellsLabel.setLabelFor(numCellsField.textField);
        numCellsLabel.setFont(TEXT_FONT);
        numCellsLabel.setForeground(TEXT_COLOUR);

        Hashtable dotPressureHash = new Hashtable();
        lowLabel = new JLabel(hashLabels.getString("low"));
        lowLabel.setForeground(TEXT_COLOUR);
        mediumLabel = new JLabel(hashLabels.getString("medium"));
        mediumLabel.setForeground(TEXT_COLOUR);
        highLabel = new JLabel(hashLabels.getString("high"));
        highLabel.setForeground(TEXT_COLOUR);
        dotPressureHash.put(new Integer(0), lowLabel);
        dotPressureHash.put(new Integer(5), mediumLabel);
        dotPressureHash.put(new Integer(10), highLabel);

        dotPressureSlider = new JSlider(SwingConstants.HORIZONTAL, 0, 10, 5);
        dotPressureSlider.setPaintLabels(true);
        dotPressureSlider.setBackground(PANEL_BACKGROUND);
        dotPressureSlider.setLabelTable(dotPressureHash);
        dotPressureSlider.setMajorTickSpacing(1);
        dotPressureSlider.setSnapToTicks(true);
        dotPressureSlider.setPaintTicks(true);
        dotPressureSlider.setForeground(TEXT_COLOUR);

        dotPressureLabel = new JLabel(labels.getString("dot.pressure"));
        dotPressureLabel.setDisplayedMnemonic(labels.getString("dot.pressure.mnemonic").charAt(0));
        dotPressureLabel.setLabelFor(dotPressureSlider);
        dotPressureLabel.setFont(TEXT_FONT);
        dotPressureLabel.setForeground(TEXT_COLOUR);

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel gridPanel = new JPanel();
        gridPanel.setBackground(PANEL_BACKGROUND);
        gridPanel.setLayout(gridbag);

        Insets insets = new Insets(5, 5, 5, 5);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        gridPanel.add(gradeLabel, c);

        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0.0;
        c.gridwidth = 1;
        gridPanel.add(gradeComboBox, c);

        c.gridx = 0;
        c.gridy = 1;
        c.weightx = 0.0;
        gridPanel.add(numDotsLabel, c);

        c.gridx = 1;
        c.gridy = 1;
        c.weightx = 0.0;
        c.gridwidth = 1;
        gridPanel.add(numDotsComboBox, c);

        c.gridx = 0;
        c.gridy = 2;
        c.weightx = 0.0;
        gridPanel.add(statusCellLabel, c);

        c.gridx = 1;
        c.gridy = 2;
        c.weightx = 0.0;
        c.gridwidth = 1;
        gridPanel.add(statusCellComboBox, c);

        c.gridx = 0;
        c.gridy = 3;
        c.weightx = 0.0;
        gridPanel.add(numCellsLabel, c);

        c.gridx = 1;
        c.gridy = 3;
        c.weightx = 0.0;
        c.gridwidth = 1;
        gridPanel.add(numCellsField.textField, c);

        c.gridx = 0;
        c.gridy = 4;
        c.weightx = 0.0;
        gridPanel.add(dotPressureLabel, c);

        c.gridx = 1;
        c.gridy = 4;
        c.weightx = 0.5;
        c.gridwidth = 2;
        gridPanel.add(dotPressureSlider, c);


        generalTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("general.title"));
        generalTitle.setTitleFont(BORDER_TITLE_FONT);
        generalTitle.setTitleColor(BORDER_TITLE_COLOUR);

        JPanel generalPanel = new JPanel(new GridLayout(1, 1));
        generalPanel.setBorder(generalTitle);
        generalPanel.setBackground(PANEL_BACKGROUND);
        generalPanel.add(gridPanel);

        AccessibleContext ac = gradeLabel.getAccessibleContext();
        ac.setAccessibleParent(generalPanel);
        ac = gradeComboBox.getAccessibleContext();
        ac.setAccessibleParent(generalPanel);
        ac = numDotsLabel.getAccessibleContext();
        ac.setAccessibleParent(generalPanel);
        ac = numDotsComboBox.getAccessibleContext();
        ac.setAccessibleParent(generalPanel);
        ac = statusCellLabel.getAccessibleContext();
        ac.setAccessibleParent(generalPanel);
        ac = statusCellComboBox.getAccessibleContext();
        ac.setAccessibleParent(generalPanel);
        ac = dotPressureLabel.getAccessibleContext();
        ac.setAccessibleParent(generalPanel);
        ac = dotPressureSlider.getAccessibleContext();
        ac.setAccessibleParent(generalPanel);

        this.add(generalPanel);
        
        this.add(Box.createVerticalGlue());

        markHighlight = new JCheckBox(labels.getString("mark.highlight"));
        markHighlight.setMnemonic(labels.getString("mark.highlight.mnemonic").charAt(0));
        markHighlight.setBackground(PANEL_BACKGROUND);
        markHighlight.setFont(TEXT_FONT);

        markBold = new JCheckBox(labels.getString("mark.bold"));
        markBold.setMnemonic(labels.getString("mark.bold.mnemonic").charAt(0));
        markBold.setBackground(PANEL_BACKGROUND);
        markBold.setFont(TEXT_FONT);

        markUnderline = new JCheckBox(labels.getString("mark.underline"));
        markUnderline.setMnemonic(labels.getString("mark.underline.mnemonic").charAt(0));
        markUnderline.setBackground(PANEL_BACKGROUND);
        markUnderline.setFont(TEXT_FONT);

        markItalic = new JCheckBox(labels.getString("mark.italic"));
        markItalic.setMnemonic(labels.getString("mark.italic.mnemonic").charAt(0));
        markItalic.setBackground(PANEL_BACKGROUND);
        markItalic.setFont(TEXT_FONT);

        markStrikeout = new JCheckBox(labels.getString("mark.strikeout"));
        markStrikeout.setMnemonic(labels.getString("mark.strikeout.mnemonic").charAt(0));
        markStrikeout.setBackground(PANEL_BACKGROUND);
        markStrikeout.setFont(TEXT_FONT);
        markStrikeout.setAlignmentX(Component.LEFT_ALIGNMENT);

        markColor = new JCheckBox(labels.getString("mark.color"));
        markColor.setMnemonic(labels.getString("mark.color.mnemonic").charAt(0));
        markColor.setBackground(PANEL_BACKGROUND);
        markColor.setFont(TEXT_FONT);

        markTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("mark.title"));
        markTitle.setTitleColor(BORDER_TITLE_COLOUR);
        markTitle.setTitleFont(BORDER_TITLE_FONT);

        JPanel markPanel = new JPanel(new GridLayout(2, 3));
        markPanel.setBackground(PANEL_BACKGROUND);
        markPanel.setBorder(markTitle);
        markPanel.add(markHighlight);
        markPanel.add(markBold);
        markPanel.add(markUnderline);
        markPanel.add(markItalic);
        markPanel.add(markStrikeout);
        markPanel.add(markColor);

        this.add(markPanel);
        this.add(Box.createVerticalGlue());

    }

    /**
     * Sets the UI to its default state.
     */
    protected void doDefault() {
        markHighlight.setSelected(false);
        markBold.setSelected(false);
        markUnderline.setSelected(false);
        markItalic.setSelected(false);
        markStrikeout.setSelected(false);
        markColor.setSelected(false);
		
        gradeComboBox.setSelectedItem(uncontracted);
        numDotsComboBox.setSelectedItem("6");
        statusCellComboBox.setSelectedItem(off);
		
        numCellsField.setText("80");
        dotPressureSlider.setValue(5);
    }

    /**
     * Gets the root element for this application type's document with the user selected values.
     */
    protected Element getRootElement() {
        Element temp;

        pm.removeAllChildren(generic);

        temp = document.createElement(xmlLabels.getString(BRL_GENERIC_GRADE));
        ComboBoxItem gradeItem = (ComboBoxItem) gradeComboBox.getSelectedItem();
        temp.setAttribute(VALUE, gradeItem.value);
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(BRL_GENERIC_NUM_DOTS));
        temp.setAttribute(VALUE, (String) numDotsComboBox.getSelectedItem());
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(BRL_GENERIC_NUM_CELLS));
        temp.setAttribute(VALUE, numCellsField.getValue());
        generic.appendChild(temp);
		
        temp = document.createElement(xmlLabels.getString(BRL_GENERIC_MARK_HIGHLIGHT));
        if (markHighlight.isSelected())
            temp.setAttribute(VALUE, "true");
        else
            temp.setAttribute(VALUE, "false");
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(BRL_GENERIC_MARK_BOLD));
        if (markBold.isSelected())
            temp.setAttribute(VALUE, "true");
        else
            temp.setAttribute(VALUE, "false");
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(BRL_GENERIC_MARK_UNDERLINE));
        if (markUnderline.isSelected())
            temp.setAttribute(VALUE, "true");
        else
            temp.setAttribute(VALUE, "false");
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(BRL_GENERIC_MARK_ITALIC));
        if (markItalic.isSelected())
            temp.setAttribute(VALUE, "true");
        else
            temp.setAttribute(VALUE, "false");
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(BRL_GENERIC_MARK_STRIKEOUT));
        if (markStrikeout.isSelected())
            temp.setAttribute(VALUE, "true");
        else
            temp.setAttribute(VALUE, "false");
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(BRL_GENERIC_MARK_COLOR));
        if (markColor.isSelected())
            temp.setAttribute(VALUE, "true");
        else
            temp.setAttribute(VALUE, "false");
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(BRL_GENERIC_DOT_PRESSURE));
        temp.setAttribute(VALUE, String.valueOf(dotPressureSlider.getValue() / 10.0));
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(BRL_GENERIC_STATUS_CELL));
        ComboBoxItem statusCellItem = (ComboBoxItem) statusCellComboBox.getSelectedItem();
        temp.setAttribute(VALUE, statusCellItem.value);
        generic.appendChild(temp);

        return document.getDocumentElement();
		
    }

    /**
     * Setst the UI values according to the application type's XML document.
     */ 
    protected void setDomValues() {
        Element temp = DOMUtil.getFirstChildElement(generic);

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(BRL_GENERIC_GRADE))) {
            if (temp.getAttribute(VALUE).equals(uncontracted.value))			   
                gradeComboBox.setSelectedItem(uncontracted);
            else if (temp.getAttribute(VALUE).equals(contracted.value))			   
                gradeComboBox.setSelectedItem(contracted);
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(BRL_GENERIC_NUM_DOTS))) {
            numDotsComboBox.setSelectedItem(temp.getAttribute(VALUE));
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(BRL_GENERIC_NUM_CELLS))) {
            numCellsField.setText(temp.getAttribute(VALUE));
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(BRL_GENERIC_MARK_HIGHLIGHT))) {
            if (temp.getAttribute(VALUE).equals("true"))
                markHighlight.setSelected(true);
            else
                markHighlight.setSelected(false);
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(BRL_GENERIC_MARK_BOLD))) {
            if (temp.getAttribute(VALUE).equals("true"))
                markBold.setSelected(true);
            else
                markBold.setSelected(false);
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(BRL_GENERIC_MARK_UNDERLINE))) {
            if (temp.getAttribute(VALUE).equals("true"))
                markUnderline.setSelected(true);
            else
                markUnderline.setSelected(false);
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(BRL_GENERIC_MARK_ITALIC))) {
            if (temp.getAttribute(VALUE).equals("true"))
                markItalic.setSelected(true);
            else
                markItalic.setSelected(false);
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(BRL_GENERIC_MARK_STRIKEOUT))) {
            if (temp.getAttribute(VALUE).equals("true"))
                markStrikeout.setSelected(true);
            else
                markStrikeout.setSelected(false);
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(BRL_GENERIC_MARK_COLOR))) {
            if (temp.getAttribute(VALUE).equals("true"))
                markColor.setSelected(true);
            else
                markColor.setSelected(false);
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(BRL_GENERIC_DOT_PRESSURE))) {
            dotPressureSlider.setValue( (int) (Float.parseFloat(temp.getAttribute(VALUE)) * 10) );
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(BRL_GENERIC_STATUS_CELL))) {
            statusCellComboBox.setSelectedItem( findItem(statusCells, temp.getAttribute(VALUE) ) );
            temp = DOMUtil.getNextSiblingElement(temp);
        }

    }
	
    /**
     * Sets the labels for a new locale.
     */
    protected void setNewLabels() {
        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Braille", pm.language);
        ResourceBundle newHashLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.HashTables", pm.language);

        generalTitle.setTitle(newLabels.getString("general.title"));
        markTitle.setTitle(newLabels.getString("mark.title"));
		
        gradeLabel.setText(newLabels.getString("type"));
        gradeLabel.setDisplayedMnemonic(newLabels.getString("type.mnemonic").charAt(0));

        uncontracted.name = newLabels.getString("uncontracted");
        contracted.name = newLabels.getString("contracted");

        numDotsLabel.setText(newLabels.getString("num.dots"));
        numDotsLabel.setDisplayedMnemonic(newLabels.getString("num.dots.mnemonic").charAt(0));

        numCellsLabel.setText(newLabels.getString("num.cells"));
        numCellsLabel.setDisplayedMnemonic(newLabels.getString("num.cells.mnemonic").charAt(0));

        dotPressureLabel.setText(newLabels.getString("dot.pressure"));
        dotPressureLabel.setDisplayedMnemonic(newLabels.getString("dot.pressure.mnemonic").charAt(0));

        statusCellLabel.setText(newLabels.getString("status.cell"));
        statusCellLabel.setDisplayedMnemonic(newLabels.getString("status.cell.mnemonic").charAt(0));

        off.name = newLabels.getString("off");
        left.name = newLabels.getString("left");
        right.name = newLabels.getString("right");

        lowLabel.setText(newHashLabels.getString("low"));
        mediumLabel.setText(newHashLabels.getString("medium"));
        highLabel.setText(newHashLabels.getString("high"));
		
        markHighlight.setText(newLabels.getString("mark.highlight"));
        markHighlight.setMnemonic(newLabels.getString("mark.highlight.mnemonic").charAt(0));

        markBold.setText(newLabels.getString("mark.bold"));
        markBold.setMnemonic(newLabels.getString("mark.bold.mnemonic").charAt(0));

        markUnderline.setText(newLabels.getString("mark.underline"));
        markUnderline.setMnemonic(newLabels.getString("mark.underline.mnemonic").charAt(0));

        markItalic.setText(newLabels.getString("mark.italic"));
        markItalic.setMnemonic(newLabels.getString("mark.italic.mnemonic").charAt(0));

        markStrikeout.setText(newLabels.getString("mark.strikeout"));
        markStrikeout.setMnemonic(newLabels.getString("mark.strikeout.mnemonic").charAt(0));

        markColor.setText(newLabels.getString("mark.color"));
        markColor.setMnemonic(newLabels.getString("mark.color.mnemonic").charAt(0));

        numCellsField.reformat();

        setNewButtonLabels();

        revalidate();
        repaint();	
    }

    /**
     * Shows the next panel and warns the user of invalid values.
     */
    protected void doNext() {
        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Braille", pm.language);

        if (!numCellsField.isInsideRange())
            pm.doRangeWarning(numCellsField.getLowValue(), 
                              numCellsField.getHighValue(), 
                              labels.getString("num.cells"));
        else
            super.doNext();
    }
	
    /**
     * Gets the application type's XML document.
     */
    protected Document getAppTypeDoc() {
        return document;
    }

}
