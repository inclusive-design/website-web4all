/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Class which allows the user to choose their preferred lanaguage.
 *
 * @author David Weinkauf
 * @version $Revision: 1.9 $ $Date: 2006/03/28 16:31:10 $
 */
public class LanguagePanel extends PWMEditPanel {

    /**
     * Vector of language radio buttons.
     */
    private Vector languages;

    public LanguagePanel (PreferenceManager pm, String inTitleKey) {
        super(pm, null, inTitleKey);

        String bundleName = "ca.utoronto.atrc.web4all.preferences.SupportedLocales";
        ResourceBundle supportedLanguages = ResourceBundle.getBundle(bundleName);

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel languageGridPanel = new JPanel();
        languageGridPanel.setBackground(PANEL_BACKGROUND);
        languageGridPanel.setLayout(gridbag);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.weighty = 0.0;
        c.gridheight = 1;
        c.gridx = 0;
		
        languages = getLanguageItems(supportedLanguages);
        LanguageRadioButton button;
        LocaleListener ll = new LocaleListener();
        ButtonGroup localeGroup = new ButtonGroup();
        for (int i = 0; i < languages.size(); i++) {
            button = (LanguageRadioButton) languages.get(i);
            button.addActionListener(ll);
            button.setBackground(PANEL_BACKGROUND);
            button.setFont(QUESTION_FONT);
            localeGroup.add(button);

            JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            panel.setBackground(PANEL_BACKGROUND);
            panel.add(button);

            c.gridy = i;
            languageGridPanel.add(panel, c);

        }

        JPanel languagePanel = new JPanel(new GridLayout(1, 1));
        languagePanel.setBackground(PANEL_BACKGROUND);
        languagePanel.add(languageGridPanel);

        this.add(Box.createVerticalStrut(20));
        this.add(languagePanel);
        this.add(Box.createVerticalGlue());

        prevButton.setEnabled(false);
        defaultButton.setEnabled(false);

        ResourceBundle newButtonLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Buttons", pm.language);			

        nextButton.setPreferredSize(LARGE_BUTTON_DIM);
        nextButton.setText(newButtonLabels.getString("display.next"));
        nextButton.setMnemonic(newButtonLabels.getString("display.next.mnemonic").charAt(0));

    }

    protected void setNewLabels() {
        setNewButtonLabels();

        ResourceBundle newButtonLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Buttons", pm.language);
        nextButton.setText(newButtonLabels.getString("display.next"));
        nextButton.setMnemonic(newButtonLabels.getString("display.next.mnemonic").charAt(0));

        revalidate();
        repaint();
    }

    protected void doPrev() {
        ;
    }

    protected void doNext() {
        pm.doNextAppType(null);
    }

    /**
     * The ActionListener which listens to Locale changes 
     * and calls the PM to change the labels.
     */
    class LocaleListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            Locale locale = ((LanguageRadioButton) e.getSource()).locale;
            pm.setNewLabels(locale);
        }
    }


    /**
     * Sets the language box's selected item. First checks for 
     * exact locale matches against the current PWM language and 
     * if none match, selects the first locale in the list with 
     * the same language. If that fails, selects the first locale listed.
     */
    protected void initLanguage() {
        LanguageRadioButton button;

        for (int i = 0; i < languages.size(); i++) {
            button = (LanguageRadioButton) languages.get(i);

            if (button.locale.equals(pm.language)) {
                button.setSelected(true);		
                return;
            }
        }

        for (int i = 0; i < languages.size(); i++) {
            button = (LanguageRadioButton) languages.get(i);

            if (button.locale.getLanguage().equals(pm.language.getLanguage())) {
                System.out.println("Setting language to " + 
                                   button.locale.getLanguage() + "-" + 
                                   button.locale.getCountry());
                button.setSelected(true);
                pm.setNewLabels(button.locale);
                return;
            }
        }
		
        if (languages.size() > 0) {
            button = (LanguageRadioButton) languages.get(0);
            System.out.println("Warning: " + pm.language + 
                               " not supported by Web-4-All. " + 
                               "Defaulting to first locale " + 
                               button.locale.getLanguage() + "-" + 
                               button.locale.getCountry());
            button.setSelected(true);
            pm.setNewLabels(button.locale);
        }

    }
					   
    /**
     * Gets the supported language items from the properties files.
     *
     * @param  bundle  the ResourceBundle of the supported languages.
     */
    private Vector getLanguageItems(ResourceBundle bundle) {
        Vector vector = new Vector();
        Vector list = new Vector();
        
        Enumeration langKeys = bundle.getKeys();
        while (langKeys.hasMoreElements())
            list.add(langKeys.nextElement());

        Comparator comp = new Comparator() {
                public int compare (Object o1, Object o2) {
                    return ((String) o1).compareTo((String) o2);
                }
                
                public boolean equals(Object o1) {
                    return false;
                }
            };
        
        Collections.sort(list, comp);

        String name, key, code;
        char mnemonic;
        LanguageRadioButton button;
        
        for (int i = 0; i < list.size(); i++) {
            key = (String) list.get(i);
            if (!(key.endsWith(".code") || key.endsWith(".mnemonic"))) {
                name = bundle.getString(key);
                code = bundle.getString(key + ".code");
                mnemonic = bundle.getString(key + ".mnemonic").charAt(0);
                button = new LanguageRadioButton(name, 
                                                 mnemonic, 
                                                 PreferenceManager.getLocaleFromString(code));
                vector.add(button);

            }
        }

        return vector;

    }

    /**
     * The object displayed in the language combo box. 
     * Has a Locale object in order to  make quick changes 
     * for user language preferences.
     */
    class LanguageRadioButton extends JRadioButton {

        public Locale locale;

        public LanguageRadioButton(String name, char mnemonic, Locale inLocale) {
            super(name);
            this.setMnemonic(mnemonic);
            locale = inLocale;
        }

    }

}
