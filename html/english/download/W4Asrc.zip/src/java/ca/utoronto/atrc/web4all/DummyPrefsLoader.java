/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:			DummyPrefsLoader.java
 *
 * Synoposis:		package ca.utoronto.atrc.web4all;
 * 
 ]*/

package ca.utoronto.atrc.web4all;

import ca.utoronto.atrc.web4all.binding.*;
import java.io.*;
import java.util.Properties;
import org.w3c.dom.*;

/**
 * Dummy implementation of interface PrefsLoaderAPI that saves the preferences
 * to the hard drive in a file named "prefs.xml".  This is typcially used for
 * development and debugging only -- NOT TO BE USED IN THE FINAL PRODUCT.
 *
 * @version $Id: DummyPrefsLoader.java,v 1.8 2006/03/28 21:17:27 clown Exp $
 * @author	Joseph Scheuhammer
 * @author	David Weinkauf
 */
	
public class DummyPrefsLoader implements PrefsLoaderAPI
{
    /**
     * The reference to ControlHub.
     */
    private ControlHub w4a;

    /**
     * The low memory binding class.
     */
    private LowMemoryXMLBinding lowMemBind;

    /**
     * Enable/disable low memory binding.
     */
    private boolean useLowMemory;

    /**
     * Enable/disable indenting of XML output.
     */
    private boolean prettyPrint;

    /**
     * The preferences-loaded properties themselves.
     */
    private Properties thePrefsLoadedProps;
    
    /**
     * Usual construtor. Initializes functional arguments and allocates an empty
     * preferences-loaded Properties object.
     *
     * @param  w4a  the reference to ControlHub
     * @param  useLowMemory  use low memory binding or not
     * @param  prettyPrint  indent the XML output or not
     */
    public DummyPrefsLoader(ControlHub w4a, boolean useLowMemory, boolean prettyPrint)
    {
        super();
        this.w4a = w4a;
        this.useLowMemory = useLowMemory;
        this.prettyPrint = prettyPrint;

        thePrefsLoadedProps = new Properties();

        if (useLowMemory)
            initLowMemoryBind(w4a);

    }   // end DummyPrefsLoader().
    
    /**
     * Zero argument constructor for use with pluggable preferences loader
     * system.  In this case, the low memory encoding of the preferences is
     * not used, and the preferences are written indented.
     */
    public DummyPrefsLoader ()
    {
        super();
        w4a = ControlHub.getSharedInstance();
        useLowMemory = false;
        prettyPrint = true;
    }
    
    /**
     * Mostly to satisfy the PrefsLoaderAPI, but can be used in pluggable
     * preferences loader scenario to load the "prefs.xml" file.
     */
    public void startup()
    {
        w4a.kickIt (getPrefs ("prefs.xml"), this);
        
    }   // end startup().
    
    /**
     * Provide a reference to the preferences-loaded properties to the outside
     * world.
     * @return      The preferences-loaded Properties object.
     */
    public Properties getPrefsLoadedProperties()
    {
        return thePrefsLoadedProps;
    
    }   // end getPrefsLoadedProperties().

	/**
	 * Gets the preferences from a file.
	 *
	 * @param  inFileName  the file name
	 * @return  the user preferences
	 */
    public String getPrefs(String inFileName) {
        String prefs = null;

        if (inFileName == null)
            return null;

        if (inFileName != null) {
            String homeDir = System.getProperty ("user.dir");
            String dirSep = System.getProperty ("file.separator");
            prefs = ControlHub.createXMLString(homeDir + dirSep + inFileName);

            if (useLowMemory) {
                XMLBindingAdaptor xmlBindAdaptor = XMLBindingAdaptor.getSharedInstance();				
                prefs = xmlBindAdaptor.createBindingFromHash(prefs, lowMemBind.getLowHighTable(), prettyPrint);
                System.out.println(prefs);
            }
        }
        return prefs;
    }
    
    /**
     * Saves the given string to the file "prefs.xml" in the user directory.
     * @param	doc  the preference XML document
     */
    public void savePrefs (Document doc)
    {
        String prefs = null;

        // Don't do anything if there is nothing to write.
        //
        if (doc != null)
            {

                if (useLowMemory) {
                    XMLBindingAdaptor xmlBindAdaptor = XMLBindingAdaptor.getSharedInstance();
                    doc = xmlBindAdaptor.createBindingFromHash(doc, lowMemBind.getHighLowTable());
                }
                prefs = XMLBindingAdaptor.serializeXML(doc, prettyPrint);

                // Create the file.
                //
                String dirSep = System.getProperty ("file.separator");
                String fName = System.getProperty ("user.dir") + dirSep + "prefs.xml";
		
                // Write <inString>
                //
                FileWriter fWriter = null;
                try
                    {
                        fWriter = new FileWriter (fName);
                        fWriter.write (prefs, 0, prefs.length());
                        fWriter.flush();
                        fWriter.close();
                        fWriter = null;
                    }
			
                catch (IOException ioe)
                    {
                        ioe.printStackTrace();
				
                        // Try to clean up as best as possible.
                        //
                        if (fWriter != null)
                            {
                                try
                                    {
                                        fWriter.flush();
                                        fWriter.close();
                                        fWriter = null;
                                    }
                                catch (IOException ioe2)
                                    { ; }
                            }
                    }
            }
	
    }	// end savePrefs()

	/**
	 * Gracefully clean up everything, and exit the JVM.
	 */
    public void shutdown()
    {
        // Let Web4All clean up.
        //
        ControlHub.stopWeb4All();	        
	
        // Make everything go away.
        //
        System.exit (0);
	
    }   // end shutdown

	/**
	 * Initializes the low-memory binding.
	 *
	 * @param  w4a  reference to ControlHub
	 */
    private void initLowMemoryBind(ControlHub w4a) {

        String schemaFile = w4a.getGlobalProperty(ControlHub.SCHEMA_LOCATION_VAL);
        String lipContentypeFile = w4a.getGlobalProperty(ControlHub.LIP_CONTENTYPE_LOCATION_VAL);
        String homeDir = System.getProperty ("user.dir");
        String dirSep = System.getProperty ("file.separator");
            
        String schemaString = ControlHub.createXMLString(homeDir + dirSep + schemaFile);
        String lipContentypeString = ControlHub.createXMLString(homeDir + dirSep + lipContentypeFile);
            
        try {
            lowMemBind = new LowMemoryXMLBinding(schemaString);
            lowMemBind.addToBinding(lipContentypeString);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
            
    }
	
}	// end class DummyPrefsLoader.

