/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 */
package ca.utoronto.atrc.web4all.binding;

import java.io.*;
import java.util.*;

import org.apache.xpath.*;
import org.apache.regexp.*;
import org.w3c.dom.*;

/**
 * LowMemoryXMLBinding is responsible for creating low-memory XML binding tables (to and from)
 * for a given XML schema.
 *
 * @author  David Weinkauf
 */
public class LowMemoryXMLBinding {

    /**
     * The low-to-high binding table.
     */
    private Hashtable lowHighTable;

    /**
     * The high-to-low binding table.
     */
    private Hashtable highLowTable;

    /**
     * The shared regular expression to find humps in the camel case.
     */
    private static RE findTheHump;       
    
    /**
     * Constructor. Instantiates the shared RE.
     */
    public LowMemoryXMLBinding() throws RESyntaxException {

        findTheHump = new RE("[A-Z]");

    }

    /**
     * Constructor. Instantiates the shared RE and the binding tables.
     *
     * @param  doc  the XML document to convert binding for.
     */
    public LowMemoryXMLBinding (Document doc) throws RESyntaxException, 
                                                     Exception {

        findTheHump = new RE("[A-Z]");

        initBindingTables(doc);

    }

    /**
     * Constructor. Instantiates the shared RE and the binding tables.
     *
     * @param  docString  the XML string to convert binding for.
     */
    public LowMemoryXMLBinding (String docString) throws RESyntaxException, 
                                                         Exception {
        Document doc = XMLBindingAdaptor.parseXML(docString);

        findTheHump = new RE("[A-Z]");
		
        initBindingTables(doc);

    }

    /**
     * Add another schema to the current low memory binding.
     * @param  docString  the schema document string
     */
    public void addToBinding (String docString) throws RESyntaxException, 
                                                         Exception {
        Document doc = XMLBindingAdaptor.parseXML(docString);

        addToBinding(doc);
    }

    /**
     * Add another schema to the current low memory binding.
     * @param  doc  the schema document
     */
    public void addToBinding(Document doc) throws RESyntaxException, 
                                                  Exception {
        initBindingTables(doc);        
    }

    /**
     * Gets the low-to-high memory binding table.
     */
    public Hashtable getLowHighTable() {
        return lowHighTable;
    }

    /**
     * Gets the high-to-low memory binding table.
     */
    public Hashtable getHighLowTable() {
        return highLowTable;
    }

    /**
     * Initializes the two hashtables of low to high and high to low memory bindings for the given XML schema doc.
     *
     * @param  doc  the XML XSD document
     */
    private void initBindingTables (Document doc) throws Exception {

        if (doc == null)
            return;

        if (highLowTable != null)
            highLowTable = new Hashtable(highLowTable);
        else
            highLowTable = new Hashtable();

        if (lowHighTable != null)
            lowHighTable = new Hashtable(lowHighTable);
        else
            lowHighTable = new Hashtable();

        // Retrieve and insert the <element> mappings.
        //
        NodeList nodeList = XPathAPI.selectNodeList(doc, "//element[@name]");

        System.out.println("Number of <element>'s in schema: " + nodeList.getLength());

        Element element;
        String name, ccName;

        for (int i = 0; i < nodeList.getLength(); i++) {

            element = (Element) nodeList.item(i);
            name = element.getAttribute("name");
	    
            if (!highLowTable.contains(name)) {
                ccName = getCamelCaseID(name, highLowTable.values());
                highLowTable.put(name, ccName);
                lowHighTable.put(ccName, name);
            }
        }

        // Now insert the <attribute> mappings.
        //
        nodeList = XPathAPI.selectNodeList(doc, "//attribute[@name]");

        System.out.println("Number of <attribute>'s in schema: " + nodeList.getLength());

        for (int i = 0; i < nodeList.getLength(); i++) {

            element = (Element) nodeList.item(i);
            name = element.getAttribute("name");
	    
            if (!highLowTable.contains(name)) {
                ccName = getCamelCaseID(name, highLowTable.values());
                highLowTable.put(name, ccName);
                lowHighTable.put(ccName, name);
            }	
        }

    }

    /**
     * This is for JUnit testing. SHOULD NOT BE USED!!!
     */
    protected String getCamelCaseIDTester(String name, Collection currentValues) {
        return getCamelCaseID(name, currentValues);
    }


    /**
     * Gets the unique ID for the given name based on its camel case representation.
     * This method is synchronized b/c it uses the shared <code>findTheHump</code> RE.
     *
     * @param  name         the camel cased name
     * @param  currentKeys  the previously computed id's
     * @return              the unique id
     */
    private synchronized String getCamelCaseID (String name, Collection currentValues) {

        StringBuffer key = new StringBuffer();
        key.append(name.substring(0, 1).toLowerCase());

        int char_index = 1;
        while (findTheHump.match(name, char_index)) {

            char_index = findTheHump.getParenStart(0);
            key.append(name.substring(char_index, char_index + 1).toLowerCase());

            char_index++;
        }

        if (currentValues.contains(key.toString())) {
		
            int count = 1;
            while (currentValues.contains(key.toString() + String.valueOf(count)))
                count++;
	    
            key.append(count);
		
        }

        return key.toString();

    }

}
