/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.net.URL;
import java.net.MalformedURLException;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

/**
 * Class which encapsulates all the keyboard enhancement preferences.
 *
 * @author David Weinkauf
 * @revision $Revision: 1.8 $, $Date: 2006/03/28 16:31:10 $
 */
public class KeyboardEnhanced extends PWMEditPanel {

    /**
     * The label for the repeat delay slider.
     */
    private JLabel repeatDelayLabel;
	
    /**
     * The label for the repeat rate slider.
     */
    private JLabel repeatRateLabel;

    /**
     * The repeat delay slider.
     */
    private JSlider repeatDelaySlider;

    /**
     * The repeat rate slider.
     */
    private JSlider repeatRateSlider;

    /**
     * The sticky key check box.
     */
    private JCheckBox stickyKeyCheckBox;

    /**
     * The keyboard repeat check box.
     */
    private JCheckBox keyboardRepeatCheckBox;

    /**
     * Action command for no repeat.
     */
    private static final String NO_REPEAT = "no.repeat";

    /**
     * Action command for slow repeat.
     */
    private static final String SLOW_REPEAT = "slow.repeat";

    /**
     * The alpha layout label.
     */
    private JLabel alphaLayoutLabel;

    /**
     * The external layout check box to enable/disable the preference.
     */
    private JCheckBox extLayoutBox;
	
    /**
     * The external layout URL text field.
     */
    private JTextField extLayoutField;

    /**
     * The alpha layout options radio buttons.
     */
    private ComboBoxItem standard, sequential, frequency;

    /**
     * Array of keyboard layout types.
     */
    private ComboBoxItem[] layouts;

    /**
     * The keyboard layout combo box.
     */
    private JComboBox layoutComboBox;

    /**
     * The labels for the three options of short, medium, and long.
     */
    private JLabel shortLabel, mediumLabel, longLabel;

    /**
     * The titles for the various groupings.
     */
    private TitledBorder stickyKeyTitle, repeatKeyTitle, layoutTitle;

    /**
     * The XML Document sub-tree this dialog produces in a user's preferences.
     */
    protected Document document;

    /**
     * The root element of the keyboard default prefs under <keyboard>.
     */
    protected Element generic;

    /**
     * The next edit dialog.
     */
    protected PWMEditPanel nextDialog;

    /**
     * Sole constructor. Initializes all the components in the dialog and displays them accordingly.
     *
     * @param  pm  the reference to the PreferenceManager
     * @param  root  the root element of the app type's XML document
     * @param  inAppType  the app type ID
     */
    public KeyboardEnhanced(PreferenceManager pm, Element root, String inAppType) {
        super(pm, inAppType, inAppType + TITLE_SUFFIX);
	
        document = initDocument(root, xmlLabels.getString(KEYBOARD_ENHANCED), xmlLabels.getString(KE_GENERIC));
        generic = DOMUtil.getFirstChildElement(document.getDocumentElement());

        nextDialog = new KeyboardEnhanced2(pm, this, inAppType, titleKey);

        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.KeyboardEnhanced", pm.language);
        ResourceBundle hashLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.HashTables", pm.language);
	
        // Setup the panel!!!

        standard = new ComboBoxItem(labels.getString("standard"), "standard");
        sequential = new ComboBoxItem(labels.getString("sequential"), "sequential");
        frequency = new ComboBoxItem(labels.getString("by.frequency"), "frequency");
        
        ComboBoxItem[] tempLayouts = { standard, sequential, frequency };
        layouts = tempLayouts;

        layoutComboBox = new JComboBox(layouts);
        layoutComboBox.setForeground(TEXT_COLOUR);
        layoutComboBox.setFont(TEXT_FONT);
        layoutComboBox.setBackground(PANEL_BACKGROUND);		
        layoutComboBox.setSelectedItem(standard);

        alphaLayoutLabel = new JLabel(labels.getString("alpha.layout"));
        alphaLayoutLabel.setDisplayedMnemonic(labels.getString("alpha.layout.mnemonic").charAt(0));
        alphaLayoutLabel.setLabelFor(layoutComboBox);
        alphaLayoutLabel.setForeground(TEXT_COLOUR);
        alphaLayoutLabel.setFont(TEXT_FONT);
	
        JPanel alphaLayoutPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        alphaLayoutPanel.setBackground(PANEL_BACKGROUND);
        alphaLayoutPanel.add(alphaLayoutLabel);
        alphaLayoutPanel.add(layoutComboBox);

        extLayoutBox = new JCheckBox(labels.getString("ext.layout"));
        extLayoutBox.setMnemonic(labels.getString("ext.layout.mnemonic").charAt(0));
        extLayoutBox.setBackground(PANEL_BACKGROUND);
        extLayoutBox.setForeground(TEXT_COLOUR);
        extLayoutBox.addChangeListener(new ExtLayoutListener());

        extLayoutField = new JTextField("http://", 35);
	extLayoutField.getAccessibleContext().setAccessibleName(labels.getString("ext.layout"));
        extLayoutField.setFont(TEXT_FONT);
        extLayoutField.setEnabled(false);

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel extLayoutPanel = new JPanel();
        extLayoutPanel.setBackground(PANEL_BACKGROUND);
        extLayoutPanel.setLayout(gridbag);

        Insets insets = new Insets(0, INDENT_VALUE, 0, 0);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        extLayoutPanel.add(extLayoutBox, c);

        insets = new Insets(0, 0, 0, INDENT_VALUE);
        c.insets = insets;
        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0.5;
        extLayoutPanel.add(extLayoutField, c);

        JPanel extGridPanel = new JPanel(new GridLayout(1, 1));
        extGridPanel.setBackground(PANEL_BACKGROUND);
        extGridPanel.add(extLayoutPanel);

        layoutTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("layout.title"));
        layoutTitle.setTitleColor(BORDER_TITLE_COLOUR);
        layoutTitle.setTitleFont(BORDER_TITLE_FONT);

        JPanel keyboardLayoutPanel = new JPanel();
        keyboardLayoutPanel.setLayout(new BoxLayout(keyboardLayoutPanel, BoxLayout.Y_AXIS));
        keyboardLayoutPanel.setBorder(layoutTitle);
        keyboardLayoutPanel.setBackground(PANEL_BACKGROUND);
        keyboardLayoutPanel.add(alphaLayoutPanel);
        keyboardLayoutPanel.add(extGridPanel);

        AccessibleContext ac = alphaLayoutLabel.getAccessibleContext();
        ac.setAccessibleParent(keyboardLayoutPanel);
        ac = layoutComboBox.getAccessibleContext();
        ac.setAccessibleParent(keyboardLayoutPanel);
        ac = extLayoutBox.getAccessibleContext();
        ac.setAccessibleParent(keyboardLayoutPanel);
        ac = extLayoutField.getAccessibleContext();
        ac.setAccessibleParent(keyboardLayoutPanel);        

        this.add(keyboardLayoutPanel);
        this.add(Box.createVerticalGlue());

        stickyKeyCheckBox = new JCheckBox(labels.getString("shift.ctrl.alt"));
        stickyKeyCheckBox.setMnemonic(labels.getString("shift.ctrl.alt.mnemonic").charAt(0));
        stickyKeyCheckBox.setBackground(PANEL_BACKGROUND);
        stickyKeyCheckBox.setFont(TEXT_FONT);
        stickyKeyCheckBox.setSelected(true);

        stickyKeyTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("sticky.key.title"));
        stickyKeyTitle.setTitleColor(BORDER_TITLE_COLOUR);
        stickyKeyTitle.setTitleFont(BORDER_TITLE_FONT);

        JPanel stickyKeyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        stickyKeyPanel.setBorder(stickyKeyTitle);
        stickyKeyPanel.setBackground(PANEL_BACKGROUND);
        stickyKeyPanel.add(stickyKeyCheckBox);

        ac = stickyKeyCheckBox.getAccessibleContext();
        ac.setAccessibleParent(stickyKeyPanel);

        this.add(stickyKeyPanel);
        this.add(Box.createVerticalGlue());

        keyboardRepeatCheckBox = new JCheckBox(labels.getString("keyboard.repeat"));
        keyboardRepeatCheckBox.setMnemonic(labels.getString("keyboard.repeat.mnemonic").charAt(0));
        keyboardRepeatCheckBox.setBackground(PANEL_BACKGROUND);
        keyboardRepeatCheckBox.setFont(TEXT_FONT);
        keyboardRepeatCheckBox.setSelected(true);
        keyboardRepeatCheckBox.addChangeListener(new KeyboardRepeatListener());

        JPanel keyboardRepeatPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        keyboardRepeatPanel.setBackground(PANEL_BACKGROUND);
        keyboardRepeatPanel.add(keyboardRepeatCheckBox);
		
        Hashtable repeatHash = new Hashtable();
        shortLabel = new JLabel(hashLabels.getString("short"));
        shortLabel.setForeground(TEXT_COLOUR);
        mediumLabel = new JLabel(hashLabels.getString("medium"));
        mediumLabel.setForeground(TEXT_COLOUR);
        longLabel = new JLabel(hashLabels.getString("long"));
        longLabel.setForeground(TEXT_COLOUR);
        repeatHash.put(new Integer(0), shortLabel);
        repeatHash.put(new Integer(5), mediumLabel);
        repeatHash.put(new Integer(10), longLabel);

        repeatDelaySlider = new JSlider(SwingConstants.HORIZONTAL, 0, 10, 5);
        repeatDelaySlider.setPaintLabels(true);
        repeatDelaySlider.setBackground(PANEL_BACKGROUND);
        repeatDelaySlider.setForeground(TEXT_COLOUR);
        repeatDelaySlider.setMajorTickSpacing(1);
        repeatDelaySlider.setLabelTable(repeatHash);
        repeatDelaySlider.setSnapToTicks(true);
        repeatDelaySlider.setPaintTicks(true);

        repeatDelayLabel = new JLabel(labels.getString("repeat.delay"));
        repeatDelayLabel.setDisplayedMnemonic(labels.getString("repeat.delay.mnemonic").charAt(0));
        repeatDelayLabel.setLabelFor(repeatDelaySlider);
        repeatDelayLabel.setFont(TEXT_FONT);
        repeatDelayLabel.setForeground(TEXT_COLOUR);

        repeatRateSlider = new JSlider(SwingConstants.HORIZONTAL, 0, 10, 5);
        repeatRateSlider.setPaintLabels(true);
        repeatRateSlider.setBackground(PANEL_BACKGROUND);
        repeatRateSlider.setForeground(TEXT_COLOUR);
        repeatRateSlider.setMajorTickSpacing(1);
        repeatRateSlider.setLabelTable(repeatHash);
        repeatRateSlider.setSnapToTicks(true);
        repeatRateSlider.setPaintTicks(true);

        repeatRateLabel = new JLabel(labels.getString("repeat.rate"));
        repeatRateLabel.setDisplayedMnemonic(labels.getString("repeat.rate.mnemonic").charAt(0));
        repeatRateLabel.setLabelFor(repeatRateSlider);
        repeatRateLabel.setFont(TEXT_FONT);
        repeatRateLabel.setForeground(TEXT_COLOUR);

        gridbag = new GridBagLayout();
        c = new GridBagConstraints();
        JPanel repeatGridPanel = new JPanel();
        repeatGridPanel.setBackground(PANEL_BACKGROUND);
        repeatGridPanel.setLayout(gridbag);

        insets = new Insets(0, INDENT_VALUE, 0, INDENT_VALUE);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        repeatGridPanel.add(repeatDelayLabel, c);

        c.gridx = 0;
        c.gridy = 1;
        c.weightx = 0.0;
        repeatGridPanel.add(repeatRateLabel, c);

        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0.5;
        repeatGridPanel.add(repeatDelaySlider, c);

        c.gridx = 1;
        c.gridy = 1;
        c.weightx = 0.5;
        repeatGridPanel.add(repeatRateSlider, c);

        JPanel repeatPanel = new JPanel(new GridLayout(1, 1));
        repeatPanel.setBackground(PANEL_BACKGROUND);
        repeatPanel.add(repeatGridPanel);

        repeatKeyTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("repeat.key.title"));
        repeatKeyTitle.setTitleColor(BORDER_TITLE_COLOUR);
        repeatKeyTitle.setTitleFont(BORDER_TITLE_FONT);

        JPanel repeatKeyPanel = new JPanel();
        repeatKeyPanel.setLayout(new BoxLayout(repeatKeyPanel, BoxLayout.Y_AXIS));
        repeatKeyPanel.setBorder(repeatKeyTitle);
        repeatKeyPanel.setBackground(PANEL_BACKGROUND);
        repeatKeyPanel.add(keyboardRepeatPanel);
        repeatKeyPanel.add(repeatPanel);

        ac = keyboardRepeatCheckBox.getAccessibleContext();
        ac.setAccessibleParent(repeatKeyPanel);
        ac = repeatDelayLabel.getAccessibleContext();
        ac.setAccessibleParent(repeatKeyPanel);
        ac = repeatRateLabel.getAccessibleContext();
        ac.setAccessibleParent(repeatKeyPanel);
        ac = repeatDelaySlider.getAccessibleContext();
        ac.setAccessibleParent(repeatKeyPanel);
        ac = repeatRateSlider.getAccessibleContext();
        ac.setAccessibleParent(repeatKeyPanel);

        this.add(repeatKeyPanel);
        this.add(Box.createVerticalGlue());


    }

    /**
     * Set all the JPanel's components to their correct values corresponding to 
     * the user's XML preferences passed in through the constructor.
     */
    protected void setDomValues() {
        Element temp = DOMUtil.getFirstChildElement(generic);
        Element child;

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(ALPHA_LAYOUT_INTERNAL))) {
            extLayoutBox.setSelected(false);
            layoutComboBox.setSelectedItem(findItem( layouts, temp.getAttribute(VALUE)));
            temp = DOMUtil.getNextSiblingElement(temp);
        }
        else if (temp != null && temp.getTagName().equals(xmlLabels.getString(ALPHA_LAYOUT_EXTERNAL))) {
            extLayoutBox.setSelected(true);
            extLayoutField.setText(temp.getAttribute(VALUE));
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(KE_GENERIC_STICKY))) {
            if (temp.getAttribute(VALUE).equals("true"))
                stickyKeyCheckBox.setSelected(true);
            else 
                stickyKeyCheckBox.setSelected(false);

            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(KE_GENERIC_REPEAT))) {
            if (temp.getAttribute(VALUE).equals("false")) {
                keyboardRepeatCheckBox.setSelected(false);
                repeatDelayLabel.setEnabled(false);
                repeatRateLabel.setEnabled(false);
                repeatDelaySlider.setEnabled(false);
                repeatRateSlider.setEnabled(false);
            }
            else {
                keyboardRepeatCheckBox.setSelected(true);
                repeatDelayLabel.setEnabled(true);
                repeatRateLabel.setEnabled(true);
                repeatDelaySlider.setEnabled(true);
                repeatRateSlider.setEnabled(true);

                child = DOMUtil.getFirstChildElement(temp);

                if (child != null && child.getTagName().equals(xmlLabels.getString(KE_GENERIC_AUTO_DELAY))) {
                    repeatDelaySlider.setValue( (int) (Float.parseFloat(child.getAttribute(VALUE)) * 10) );
                    child = DOMUtil.getNextSiblingElement(child);
                }
				
                if (child != null && child.getTagName().equals(xmlLabels.getString(KE_GENERIC_AUTO_RATE))) {
                    repeatRateSlider.setValue( (int) (Float.parseFloat(child.getAttribute(VALUE)) * 10) );
                    child = DOMUtil.getNextSiblingElement(child);
                }				

            }

            temp = DOMUtil.getNextSiblingElement(temp);
        }
		
		
        ((KeyboardEnhanced2)nextDialog).setDomValues(temp);
    }

    /**
     * Constructs the XML sub-tree for keyboard setup according to the user's current selections.
     *
     * @return The root element of the new XML sub-tree for keyboard setup.
     */
    protected Element getRootElement() {
        Element temp;
        Element child;
        PreferenceManager.removeAllChildren(generic);
	
        if (!extLayoutBox.isSelected()) {
            temp = document.createElement(xmlLabels.getString(ALPHA_LAYOUT_INTERNAL));
            ComboBoxItem layoutItem = (ComboBoxItem) layoutComboBox.getSelectedItem();
            temp.setAttribute(VALUE, layoutItem.value);
        }
        else {
            temp = document.createElement(xmlLabels.getString(ALPHA_LAYOUT_EXTERNAL));
            temp.setAttribute(VALUE, extLayoutField.getText().trim());
        }
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(KE_GENERIC_STICKY));
        generic.appendChild(temp);	

        if (stickyKeyCheckBox.isSelected())
            temp.setAttribute(VALUE, "true");
        else 
            temp.setAttribute(VALUE, "false");

        temp = document.createElement(xmlLabels.getString(KE_GENERIC_REPEAT));
        generic.appendChild(temp);

        if (keyboardRepeatCheckBox.isSelected()) {
            temp.setAttribute(VALUE, "true");

            child = document.createElement(xmlLabels.getString(KE_GENERIC_AUTO_DELAY));
            child.setAttribute(VALUE, String.valueOf(repeatDelaySlider.getValue() / 10.0));
            temp.appendChild(child);
			
            child = document.createElement(xmlLabels.getString(KE_GENERIC_AUTO_RATE));
            child.setAttribute(VALUE, String.valueOf(repeatRateSlider.getValue() / 10.0));
            temp.appendChild(child);		
        }
        else {
            temp.setAttribute(VALUE, "false");
        }

        ((KeyboardEnhanced2)nextDialog).addElementsTo(document);

        return document.getDocumentElement();
    }

    /**
     * Sets all the JPanel labels to the current PreferenceManager.language value.
     */
    protected void setNewLabels() {
        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.KeyboardEnhanced", pm.language);
        ResourceBundle newHashLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.HashTables", pm.language);

        layoutTitle.setTitle(newLabels.getString("layout.title"));
        alphaLayoutLabel.setText(newLabels.getString("alpha.layout"));
        alphaLayoutLabel.setDisplayedMnemonic(newLabels.getString("alpha.layout.mnemonic").charAt(0));

        standard.name = newLabels.getString("standard");
        sequential.name = newLabels.getString("sequential");
        frequency.name = newLabels.getString("by.frequency");

        extLayoutBox.setText(newLabels.getString("ext.layout"));
        extLayoutBox.setMnemonic(newLabels.getString("ext.layout.mnemonic").charAt(0));
	extLayoutField.getAccessibleContext().setAccessibleName(newLabels.getString("ext.layout"));

        stickyKeyTitle.setTitle(newLabels.getString("sticky.key.title"));
        stickyKeyCheckBox.setText(newLabels.getString("shift.ctrl.alt"));
        stickyKeyCheckBox.setMnemonic(newLabels.getString("shift.ctrl.alt.mnemonic").charAt(0));

        repeatKeyTitle.setTitle(newLabels.getString("repeat.key.title"));

        keyboardRepeatCheckBox.setText(newLabels.getString("keyboard.repeat"));
        keyboardRepeatCheckBox.setMnemonic(newLabels.getString("keyboard.repeat").charAt(0));

        repeatRateLabel.setText(newLabels.getString("repeat.rate"));
        repeatRateLabel.setDisplayedMnemonic(newLabels.getString("repeat.rate.mnemonic").charAt(0));
        shortLabel.setText(newHashLabels.getString("short"));
        mediumLabel.setText(newHashLabels.getString("medium"));
        longLabel.setText(newHashLabels.getString("long"));
        repeatDelayLabel.setText(newLabels.getString("repeat.delay"));
        repeatDelayLabel.setDisplayedMnemonic(newLabels.getString("repeat.delay.mnemonic").charAt(0));

        setNewButtonLabels();

        revalidate();
        repaint();

        nextDialog.setNewLabels();
    }


    class KeyboardRepeatListener implements ChangeListener {
        public void stateChanged(ChangeEvent e) {
            JCheckBox box = (JCheckBox) e.getSource();
            if (box.isSelected()) {
                repeatDelayLabel.setEnabled(true);
                repeatRateLabel.setEnabled(true);
                repeatDelaySlider.setEnabled(true);
                repeatRateSlider.setEnabled(true);
            }
            else {
                repeatDelayLabel.setEnabled(false);
                repeatRateLabel.setEnabled(false);
                repeatDelaySlider.setEnabled(false);
                repeatRateSlider.setEnabled(false);
            }
        }
    }

    class ExtLayoutListener implements ChangeListener {
        public void stateChanged(ChangeEvent e) {
            JCheckBox box = (JCheckBox) e.getSource();
            if (box.isSelected()) {				
                extLayoutField.setEnabled(true);
                alphaLayoutLabel.setEnabled(false);
                layoutComboBox.setEnabled(false);
            }
            else {
                extLayoutField.setEnabled(false);
                alphaLayoutLabel.setEnabled(true);
                layoutComboBox.setEnabled(true);
            }
        }
    }

    protected void doDefault() {
        layoutComboBox.setSelectedItem(standard);
        extLayoutField.setText("http://");
        extLayoutBox.setSelected(false);		
        keyboardRepeatCheckBox.setSelected(true);
        repeatDelaySlider.setValue(5);
        repeatRateSlider.setValue(5);
        stickyKeyCheckBox.setSelected(true);
    }

    protected PWMEditPanel getLastPanel() {
        return nextDialog;
    }

    protected void doNext() {

        if (extLayoutBox.isSelected()) {
            try {
                URL lexicon = new URL(extLayoutField.getText());
            }
            catch (MalformedURLException murle) {
                ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.KeyboardEnhanced", pm.language);
                JOptionPane.showMessageDialog(this, labels.getString("malformed.url"),
                                              labels.getString("malformed.url.title"),
                                              JOptionPane.WARNING_MESSAGE);
                return;            
            }
        }

        pm.showPanel(nextDialog);
    }

    /**
     * Gets the entire app type XML subtree including default preferences and third party preferences.
     *
     * @return    The entire <keyboard> XML sub-tree.
     */
    protected Document getAppTypeDoc() {
        return document;
    }


}
