/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:			Percent2Pixels.java
 *
 * Synopsis:		package ca.utoronto.atrc.web4all;
* 
]*/

package ca.utoronto.atrc.web4all;

import java.awt.Toolkit;
import java.awt.Dimension;

/**
 * Utility for converting a size given in percentage of screen to one in pixels.  The
 * percentage is either relative to screen height or screen width.  The screen dimensions
 * are retrieved via the AWT Toolkit (and are therefore in pixels).
 *
 * @version $Id: Percent2Pixels.java,v 1.3 2006/03/28 21:17:27 clown Exp $
 * @author	Joseph Scheuhammer.
 */
	
public class Percent2Pixels
{
	/** 
	 * Flag that indicates the calculation should be relative to the screen width.
	 */
	public final static int WIDTH_FLAG    = 0;
	
	/** 
	 * Flag that indicates the calculation should be relative to the screen height.
	 */
	public final static int HEIGHT_FLAG   = 1;
	
    /**
     * Convert the given percentage to a pixel value.  The percentage is expressed in terms
     * of screen width or screen height, and that is given by the second argument.
     * @param		inPercent	        The percentage of screen width or height to convert.
     * @param		inHeightWidthFlag  	One of <code>WIDTH_FLAG</code> or <code>HEIGHT_FLAG</code>
     *                                  that determines if <code>inPercent</code> is the
     *                                  percentage of width or height.
     * @return                          A size in pixels as an int.  If
     *                                  <code>inHeightWidthFlag</code> is invalid, zero is
     *                                  returned.
     * @see #WIDTH_FLAG
     * @see #HEIGHT_FLAG
     */
	public static int convert2Pixels (float inPercent, int inHeightWidthFlag)
	{
	    int result = 0;
	    
	    // Get the dimensions of the screen in pixels.
	    //
	    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	    
	    // Do the calculation.
	    //
	    if (inHeightWidthFlag == Percent2Pixels.WIDTH_FLAG)
	    {
	        result = Math.round ((inPercent * ((float) screenSize.width)));
	    }
	    else if (inHeightWidthFlag == Percent2Pixels.HEIGHT_FLAG)
	    {
	        result = Math.round ((inPercent * ((float) screenSize.height)));
	    }
	    return result;
	
	}	// end convert2Pixels()
	
}	// end class Percent2Pixels.

