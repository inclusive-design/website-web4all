/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 *
 * File:        ParameterState.java
 *
 * Synoposis:   package ca.utoronto.atrc.web4all.configuration;
 * 
]*/

package ca.utoronto.atrc.web4all.configuration;

/**
 * Stores state information about a specific third party technology parameter, or setting. 
 * States stored include whether the parameter has been set, whether the third party technolgy
 * requires that the parameter be set, and, if required, but not set, the setting's
 * default value.
 * @version $Id: ParameterState.java,v 1.5 2006/03/28 21:17:27 clown Exp $
 * @author Joseph Scheuhammer
 */
public class ParameterState
{
    /**
     * Name of the parameter (application specific -- not ACCLIP name).
     */
    private String theParamName;
    
    /**
     * Has the parameter been set?
     */
    private boolean theSetState;
    
    /**
     * Is this parameter required?
     */
    private boolean theRequiredFlag;
    
    /**
     * If required, what is the default value?
     */
     private Object theDefaultValue;
          
     /**
      * Initialize the state object given a parameter name, whether it is required, and its
      * default value.  The "set" state is initialized to <code>false</code>.
      * @param  inParamName     The technology specific name of the parameter.  This is
      *                         not a preference name from the ACCLIP, but the third
      *                         party technology's corresponding name.
      * @param  inRequiredFlag  Is this parameter required by the third party technology?
      * @param  inDefaultValue  If it is required, this is the default value if it can't
      *                         be set via the ACCLIP document.
      */
     public ParameterState (String inParamName, boolean inRequiredFlag, Object inDefaultValue)
     {
        super();
        theParamName = inParamName;
        theSetState = false;
        theRequiredFlag = inRequiredFlag;
        theDefaultValue = inDefaultValue;
     
     }  // end ParameterState().
 
    /**
     * Retrieve the third party technology specific name of this parameter.
     * @return    The parameter name.
     */
    public String getParamName()
    {
        return theParamName;
    
    }   // end getParamName().
    
    /**
     * Get the "set" state of this parameter.
     * @return    Whether the parameter was set.
     * @see #setSetState(boolean)
     */
    public boolean getSetState()
    {
        return theSetState;

    }   // end getSetState().

    /**
     * Set the "set" state of this parameter.
     * @param   inSetState  <code>true</oode> if the parameter has been set;
     * <code>false</code>, otherwise.
     * @see #getSetState()
     */
    public void setSetState (boolean inSetState)
    {
        theSetState = inSetState;

    }   // end setSetState().
   
    /**
     * Is it required that the parameter be set?
     * @return    Whether the parameter is required.
     * @see #isRequired()
     * @see #setDefaultValue(Object)
     * @see #getDefaultValue()
     */
    public boolean getRequiredFlag()
    {
        return theRequiredFlag;

    }   // end getRequiredFlag().

    /**
     * Is it required that the parameter be set?
     * @return    Whether the parameter is required.
     * @see #getRequiredFlag()
     * @see #setDefaultValue(Object)
     * @see #getDefaultValue()
     */
    public boolean isRequired()
    {
        return getRequiredFlag();

    }   // end isRequired().

    /**
     * Set the default value of this parameter.
     * @param   inDefaultValue  <code>Object</code> that represents the default
     *                          value.
     * @see #getDefaultValue()
     * @see #getRequiredFlag()
     */
    public void setDefaultValue (Object inDefaultValue)
    {
        theDefaultValue = inDefaultValue;

    }   // end setDefaultValue().

    /**
     * Get the default value of the parameter.
     * @return   <code>Object</code> that represents the default value.
     * @see #setDefaultValue(Object)
     * @see #getRequiredFlag
     */
    public Object getDefaultValue()
    {
        return theDefaultValue;

    }   // end getDefaultValue().
     
}   // end class ParameterState.
