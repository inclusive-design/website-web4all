/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            ControlHub.java
 *
 * Synoposis:       package ca.utoronto.atrc.web4all;
 *
]*/

package ca.utoronto.atrc.web4all;

import java.util.*;
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.security.*;
import java.beans.*;

import org.w3c.dom.*;
import org.xml.sax.*;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.apache.xerces.parsers.*;
import org.apache.xerces.dom.*;
import org.apache.xml.serialize.*;
import org.apache.xpath.XPathAPI;
import javax.xml.transform.TransformerException;

import ca.utoronto.atrc.web4all.preferences.*;
import ca.utoronto.atrc.web4all.configuration.*;
import ca.utoronto.atrc.web4all.systemtray.*;

/**
 * Control Hub of the Web4-4-All system.  The Control Hub coordinates activity among the Preference
 * Loader, the Preferences Wizard Manager, the Configuration Manager, and the plug-ins.
 *
 * @version $Id: ControlHub.java,v 1.11 2006/03/28 21:17:27 clown Exp $
 * @author  Joseph Scheuhammer
 * @author  David Weinkauf
 */
public class ControlHub implements Web4AllConstants, ActionListener, Runnable
{
    /** 
     * Base name of the 3rd party folder.  This is not a full or partial path; it is just
     * the name of the folder.
     */
    public final static String THIRD_PARTY_FOLDER   = "3rd_party";

    /**
     * Name of the Web4All properties file.
     */
    private final static String WEB4ALL_PROPS_FILE   = "Web4All.properties";

    /**
     * Name of the CGI url parameters properties file.
     */
    private final static String CGI_URL_PARAMS_PROPS_FILE = "CgiUrlParams.properties";

    /**
     * Key to the xml schema namespace.
     */
    public final static String XMLNS_VAL = "xmlns.val";
    
    /**
     * Key to the xml instance document namespace.
     */
    public final static String XMLNS_XSI_VAL = "xmlns.xsi.val";

    /**
     * Key for fetching the location of the schema.
     */
    public final static String SCHEMA_LOCATION_VAL = "schema.location.val";

    /**
     * Key for fetching the location of the LIP Contentype schema.
     */
    public final static String LIP_CONTENTYPE_LOCATION_VAL = "lip.contentype.location.val";

    /**
     * Key for fetching the version of the schema.
     */
    public final static String SCHEMA_VERSION_VAL = "schema.version.val";

    /**
     * Key for fetching the value of the context ID.
     */
    public final static String CONTEXT_ID_VAL = "context.id.val";

    /**
     * Key for fetching the "Yes" push button label.
     */
    private final static String YES_BUTTON_LABEL = "yes.button.label";

    /**
     * Key for fetching the "Yes" push button alt key equivalent.
     */
    private final static String YES_BUTTON_ALT = "yes.button.alt";

    /**
     * Action command for the "Yes" push button in an alert.
     */
    public final static String YES_BUTTON_CMD = "yesAction";

    /**
     * Key for fetching  the "No" push button label.
     */
    private final static String NO_BUTTON_LABEL = "no.button.label";

    /**
     * Key for fetching the "No" push button alt key equivalent.
     */
    private final static String NO_BUTTON_ALT = "no.button.alt";

    /**
     * Action command for the "No" push button in an alert.
     */
    public final static String NO_BUTTON_CMD = "noAction";

    /**
     * Key for fetching the "Ok" push button label.
     */
    private final static String OK_BUTTON_LABEL = "ok.button.label";

    /**
     * Key for fetching the "Ok" push button alt key equivalent.
     */
    private final static String OK_BUTTON_ALT = "ok.button.alt";

    /**
     * Action command for the "Ok" push button.
     */
    public final static String OK_BUTTON_CMD = "okAction";

	/**
	 * For notifying property change listeners that the locale has changed.
	 */
	public final static String LOCALE_PROP = "locale";

	/**
	 * For notifying property change listeners that the main window has been
     * allocated.
	 */
	public final static String MAIN_WINDOW_PROP = "mainWindow";

    /**
     * Name of the Web4All logo icon.
     */
    private final static String WEB4ALL_LOGO_ICON = "web4all_logo.gif";

    /**
     * Name of encoding to encode the digested bits in.
     */
    private final static String DIGEST_ENCODING = "ASCII";

    /**
     * Splash screen title.
     */
    private final static String SPLASH_TITLE = "splash.title";
    
    /**
     * The invalid preference error key.
     */
    private final static String INVALID_PREFS = "invalid.prefs";

    /**
     * Flag to indicate that the prefs file will be output with tabs.  "False" by default, and
     * should not be used with a smart card.  In main(), where the DummyPrefsLoader is allocated,
     * this flag is set to "true" since the preferences will be save do disk.
     */
    private static boolean PRETTY_PRINT_FLAG = false;

    /** 
     * Shared instance of ControlHub object.
     */
    private static ControlHub sharedInstance = null;
    
    /**
     * Height of the splash screen.
     */
    public final static int SPLASH_HEIGHT = 450;
    
    /**
     * Width of the splash screen.
     */
    public final static int SPLASH_WIDTH = 525;
    
    /**
     * Static flag to control the output of debug information.
     */
    protected final static boolean DEBUG = true;
    
    /**
     * The FileWriter to write debug output to when <code>DEBUG</code> is "true".  It will be written
     * to the <code>theHomeDirectory</code>.
     */
    private static PrintWriter theLog = null;

    /** 
     * The directory in which the Web-4-All jar resides.
     */
    private String theHomeDirectory = null;
    
    /** 
     * The preferences themselves.
     */
    private String thePrefsStr;
    
    /** 
     * The preferences themselves, as a DOM.
     */
    private Document thePrefsDOM;
    
    /** 
     * The preferences loader object.
     */
    private PrefsLoaderAPI thePrefsLoader;
    
    /** 
     * The preferences wizard manager.
     */
    private PreferenceManager thePWM;

    /** 
     * The configurator.
     */
    private ConfigManager theConfigManager;
    
    /** 
     * Properties that map from symbolic names to actual tag names used in the preferences
     * XML.
     */
    private ResourceBundle theXmlElements;
    
    /** 
     * The main window.
     */
    private JFrame theMainWindow;
    
    /**
     * The Preference Manager's main window.
     */
    private JFrame thePMWindow;

    /** 
     * Splash screen handling.
     */
    private SplashScreen theSplashScreen;
    
    /**
     * The system tray representation.
     */
    private W4ASysTray theSysTray;

    /** 
     * URL to third party folder.
     */
    private URL the3rdPartyFolder = null;
    
    /** 
     * Lookup table for finding info based on application ID.
     */
    private Hashtable lookupByAppID;
    
    /** 
     * Lookup table for finding a list of application id's given application type.
     */
    private Hashtable lookupAppIDsByAppType;

    /**
     * Properties object to hold all the sytem properties used for default URL implementation and 
     * 3rd party configuration.
     */
    private Properties systemProps;

    /**
     * More "system properties".  These are schema name spaces, and the schema itself.
     */
    private ResourceBundle theSchemaProps;
        
    /**
     * Place to store the current, if any, JOptionPane created by <code>updateStatusMessage()</code>.
     */
    private volatile JOptionPane theStatusOptionPane;

    /**
     * Whether the modal dialogue showing <code>theStatusOptionPane</code> was dismissed progrmatically.
     */
    private volatile boolean theStatusProgDismissed;

    /** Whether or not to iconify the splash screen.*/
    private boolean iconify;

    /** Whether or not to enable configuration of the system.*/
    private boolean enableConfig;
    
    /**
     * The current Locale.
     */
    private Locale theLocale;
    
    /**
     * For supporting property change listeners.
     */
    private PropertyChangeSupport thePropChanges;

    /** 
     * Allocate a copy of the Control Hub, and launch the Web-4-All system.
     * @param   inDirectory     Full path to the directory that Web-4-All is in.
     * @param   inPrefsLoader   The preferences loader -- implements interface
     *                          PrefsLoaderAPI.
     * @see #stopWeb4All()
     * @see PrefsLoaderAPI
     */
    public static ControlHub startWeb4All (String inDirectory, PrefsLoaderAPI inPrefsLoader)
    {
        // Get/create a shared instance.
        //
        ControlHub controlHub = ControlHub.getSharedInstance (true, inDirectory);
        
        // Set <thePrefsLoader> as per <inPrefsLoader> for now.  Note that this may alter
        // when kickIt() is called.
        //
        controlHub.thePrefsLoader = inPrefsLoader;
        
        // Get up the splash screen, and initialize the Preferences Wizard
        // Manager.
        //
        controlHub.showSplashScreen();
        controlHub.initPWM();
        
        return controlHub;
            
    }   // end startWeb4All().

    /** 
     * Static method to shut down the shared instance of Web-4-All.  This will also close
     * and dipose of the main window, and set the shared instance to <code>null</code>.
     * @see #startWeb4All(String,PrefsLoaderAPI)
     */
    public static void stopWeb4All()
    {
        if (sharedInstance != null) {
            sharedInstance.stopIt();
            
            // Get rid of the splash screen, and its window.
            //
            if (sharedInstance.theMainWindow != null)
                sharedInstance.theMainWindow.dispose();
            
            sharedInstance.theMainWindow = null;

            if (sharedInstance.thePMWindow != null)
                sharedInstance.thePMWindow.dispose();

            sharedInstance.thePMWindow = null;

            sharedInstance.theSplashScreen = null;          
        }
        sharedInstance = null;
    
    }   // end stopWeb4All().

    /** 
     * Acquire the shared instance of the ControlHub, if any.
     * @return      The shared instance, if there is one; <code>null</code> otherwise.
     * @see #getSharedInstance(boolean,String)
     */
    public static ControlHub getSharedInstance()
    {
        return sharedInstance;
    
    }   // end getSharedInstance().

    /** 
     * Acquire the shared instance of ControlHub.  If there is no shared instance, this will allocate
     * one if requested.
     * @param   inCreateFlag    If <code>true</code>, and no shared instance of ControlHub
     *                          exists, then this will create one.  If <code>false</code>
     *                          and there is no shared instance, then none will be created.
     * @param   inDirectory     Full path to Web4All's home directory.  Used only if
     *                          <code>inCreateFlag</code> is <code>true</code>.
     * @return                  The shared instance, if there is one, or one was created; <code>null</code> otherwise.
     * @see #getSharedInstance()
     * @see #startWeb4All(String,PrefsLoaderAPI)
     */
    public static ControlHub getSharedInstance (boolean inCreateFlag, String inDirectory)
    {
        ControlHub result = null;      // return value.
        
        // If there is a shared instance, return it.
        //
        if (sharedInstance != null)
            result = sharedInstance;
        
        // If no shared instance, do we create one?
        //
        else if (inCreateFlag) {
            sharedInstance = new ControlHub (inDirectory);
            result = sharedInstance;
        }
        
        return result;
    
    }   // end getSharedInstance (boolean inCreateFlag).
    
    /**
     * Utility for showing a confirmation dialogue or an alert.  This is a wrapper
     * around JOptionPane.showOptionDialog() where the Control Hub's custom option buttons are
     * used instead of the JOptionPane default set.  <strong>DO NOT</strong> use this if
     * the dialogue is to update the status message -- use one of the
     * <code>updateStatusMessage()</code> methods instead.
     * @param   inParent        The Component whose Window will be the parent of the
     *                          JDialog presented.
     * @param   inMessage       The status message itself.  If <code>null</code> or empty, any
     *                          current status will be simply erased.
     * @param   inTitle         The title for the JDialog.
     * @param   inMessageType   One of <code>JOptionPane.ERROR_MESSAGE</code>, or
     *                          <code>JOptionPane.QUESTION_MESSAGE</code>.  If the
     *                          former, <code>JOptionPane.showMessageDialog()</code> is used.
     *                          If the latter, <code>JOptionPane.showConfirmationDialog()</code>
     *                          is used.
     * @return                  If a confirmation dialogue is presented, the return value is
     *                          either <code>JOptionPane.YES_OPTION</code> or
     *                          <code>JOptionPane.NO_OPTION</code>.
     * @see #updateStatusMessage(String)
     * @see #updateStatusMessage(String,int)
     */
    public static int showOptionDialog (Component inParent, String inMessage, String inTitle, int inMessageType)
    {
        int optionVal = JOptionPane.YES_OPTION;
        
        // Handle confirmation dialogues.
        //
        if (inMessageType == JOptionPane.QUESTION_MESSAGE) {
            if (sharedInstance != null) {
                // 1.  Build the JOptionPane.
                //
                JButton[] yesNoButtons = sharedInstance.createOptionButtons (JOptionPane.QUESTION_MESSAGE);
                JOptionPane aPane = new JOptionPane (inMessage, JOptionPane.QUESTION_MESSAGE, JOptionPane.YES_NO_OPTION, null /* icon */, yesNoButtons, yesNoButtons[0]);
                ActionListener action = sharedInstance.configureOptionButtons (yesNoButtons, aPane);
                
                // 2.  Show it.  This thread will block at aModal.show();
                //
                JDialog aModal = aPane.createDialog (inParent, null);
                aPane.selectInitialValue();
                aModal.show();
                
                // 3.  Deconfigure the buttons, and get the result.
                //
                sharedInstance.deconfigureOptionButtons (yesNoButtons, action);
                Object val = aPane.getValue();
                if (val instanceof Integer)
                    optionVal = ((Integer) val).intValue();
                else
                    optionVal = JOptionPane.CLOSED_OPTION;              
            }
            
            // Use the default buttons/dialogue.
            //
            else
                optionVal = JOptionPane.showConfirmDialog (inParent, inMessage, inTitle, JOptionPane.YES_NO_OPTION, inMessageType);
        }
        
        // Handle simple alerts.  Note that JOptionPane.showMessageDialog() does not return a
        // value, so <optionVal> will have its initial value of JOptionPane.YES_OPTION.
        //
        else
            {
                if (sharedInstance != null) {
                    // 1.  Build the JOptionPane.
                    //
                    JButton[] okButtons = sharedInstance.createOptionButtons (JOptionPane.ERROR_MESSAGE);
                    JOptionPane aPane = new JOptionPane (inMessage, JOptionPane.ERROR_MESSAGE, JOptionPane.DEFAULT_OPTION, null /* icon */, okButtons, okButtons[0]);
                    ActionListener action = sharedInstance.configureOptionButtons (okButtons, aPane);
                
                    // 2.  Show it.  This thread will block at aModal.show();
                    //
                    JDialog aModal = aPane.createDialog (inParent, null);
                    aPane.selectInitialValue();
                    aModal.show();
                
                    // 3.  Deconfigure the buttons, and get the result.
                    //
                    sharedInstance.deconfigureOptionButtons (okButtons, action);
                    Object val = aPane.getValue();
                    if (val instanceof Integer)
                        optionVal = ((Integer) val).intValue();
                    else
                        optionVal = JOptionPane.CLOSED_OPTION;              
                }
            
                // Use the default buttons/dialogue.
                //
                else
                    JOptionPane.showMessageDialog (inParent, inMessage, inTitle, JOptionPane.ERROR_MESSAGE);
            }
        
        return optionVal;

    }   // end showOptionDialog().
    
    /**
     * Retrieve a Web-4-All global property value.
     * @param    inKey    The global property name.
     * @return            The property value.
     */
    public String getGlobalProperty (String inKey) throws MissingResourceException {        
        // First try the <systemProps>.
        //
        String prop = systemProps.getProperty(inKey);
        
        // If not in the <systemProps>, try <theSchemaProps>.
        //
        if (prop == null) {
            if (theSchemaProps == null)
                throw new MissingResourceException (null, "Web4All", inKey);
            else
                prop = theSchemaProps.getString (inKey);
        }
        return prop;
    }
    
    /**
     * Constructor -- must initialize with the path to the directory from which the Web-4-All system
     * was launched.
     * @param   inDirectory     Full path to Web4All's home directory.
     */
    public ControlHub (String inDirectory)
    {
        theHomeDirectory = inDirectory;
        thePrefsStr = null;
        theStatusProgDismissed = false;
        theStatusOptionPane = null;
        iconify = true;
        enableConfig = true;
        boolean notify = true;
        thePropChanges = new PropertyChangeSupport (this);
        theLocale = Locale.getDefault();

        // Load the "Web4All.properties" and setup the <systemProps> 
        //
        File web4AllPropsFile = new File (theHomeDirectory, ControlHub.WEB4ALL_PROPS_FILE);

        try {
            if (DEBUG) System.out.println("Loading Web4All.properties......");
            
            // Load the Web4All.properties.
            FileInputStream web4AllPropsIS = new FileInputStream(web4AllPropsFile);
            systemProps = new Properties();
            systemProps.load(web4AllPropsIS);

            /* Get the NOTIFY, ICONIFY and ENABLE_CONFIG before the 
               SERIAL_NUMBER b/c it might not be there (during testing).*/
            String notifyVal = systemProps.getProperty(Web4AllPropNames.NOTIFY);
            notify = Boolean.valueOf(notifyVal).booleanValue();
            if (DEBUG) System.out.println("Added notify property: " + notify);

            String iconifyVal = systemProps.getProperty(Web4AllPropNames.ICONIFY);
            iconify = Boolean.valueOf(iconifyVal).booleanValue();
            if (DEBUG) System.out.println("Added iconify property: " + iconify);

            String enableConfigVal = systemProps.getProperty(Web4AllPropNames.ENABLE_CONFIG);
            enableConfig = Boolean.valueOf(enableConfigVal).booleanValue();
            if (DEBUG) System.out.println("Added enableConfiguration property: " + 
                                          enableConfig);

            if (DEBUG) System.out.println("Loading CgiUrlParams.properties......");

            // Load the CgiUrlParams.properties
            Class controlHubClass = getClass();
            systemProps.load(controlHubClass.getResourceAsStream(ControlHub.CGI_URL_PARAMS_PROPS_FILE));

            // Do the MD5 encoding on the serial number and place it in the <systemProps>.
            //
            String serialNum = systemProps.getProperty(Web4AllPropNames.SERIAL_NUMBER);
            if (serialNum != null)
            {
                // Do the MD5 encoding on the serial number.
                byte[] serialBytes = serialNum.getBytes();
                MessageDigest msgDigest = MessageDigest.getInstance ("MD5");
                msgDigest.update (serialBytes);
                String mdfString = bytesToHex(msgDigest.digest());
                
                if (DEBUG) System.out.println("Adding encoded property......");
                
                // Put the new encoding property into <systemProps>.
                systemProps.setProperty(Web4AllPropNames.SERIAL_ENCODING, mdfString);

                if (DEBUG) System.out.println("Added encoded property: " + mdfString);
            }
            
            // Create the CGI Url and add it to <systemProps>.
            //
            systemProps.setProperty (Web4AllPropNames.LAUNCH_URL, genCgiUrl());
            if (DEBUG) System.out.println("Added launch-url property: " + systemProps.getProperty (Web4AllPropNames.LAUNCH_URL));

        }
        catch (FileNotFoundException fnfe) {
            if (DEBUG) System.out.println("Can't find " + ControlHub.WEB4ALL_PROPS_FILE + " in Web4All home directory.");
        }
        catch (UnsupportedEncodingException uee) {
            if (DEBUG) System.out.println("Encoding " + ControlHub.DIGEST_ENCODING + " not supported.");
        }
        catch (IOException io) {
            if (DEBUG) System.out.println("Can't load " + ControlHub.WEB4ALL_PROPS_FILE + " into system properties object.");          
        }
        catch (MissingResourceException mre) {
            if (DEBUG) System.out.println("Can't find key " + mre.getKey() + " from " + mre.getClassName());
        }
        catch (NoSuchAlgorithmException nsae) {
            if (DEBUG) System.out.println("Can't load encoding algorithm.");
        }
        
        // Load the "Schema.properties".
        //
        try {
            theSchemaProps = ResourceBundle.getBundle ("ca.utoronto.atrc.web4all.Schema");
        }
        catch (MissingResourceException missingSchema) {
            if (DEBUG) System.out.println ("Can't load 'Schema.properties'");
        }
        
        // Load the "Applications.properties".
        //
        try {
            theXmlElements = ResourceBundle.getBundle ("ca.utoronto.atrc.web4all.Applications");
        }
        catch (MissingResourceException mre) {
            if (DEBUG) System.out.println ("Can't load 'Applications.properties'");
        }

        // Create the URL to the folder containing the 3rd party property files.
        //
        File thirdPartyDir = new File (theHomeDirectory, ControlHub.THIRD_PARTY_FOLDER);
        try {   
            the3rdPartyFolder = new URL ("file", null, thirdPartyDir.toString() + "/");
            if (DEBUG) {
                System.out.print ("Web4All():  File is '" + thirdPartyDir.toString() + "', URL is '" + the3rdPartyFolder.toString() + "'");
                System.out.println (", file portion of URL is '" + the3rdPartyFolder.getFile() + "'");
            }
        }
        
        catch (MalformedURLException mfue)
            {
                if (DEBUG) mfue.printStackTrace();
            }
        
        // Allocate the hashtables for the 3rd party properties files, and then
        // load them.
        //
        lookupByAppID = new Hashtable();
        lookupAppIDsByAppType = new Hashtable();
        load3rdPartyProps();
        if (DEBUG) dumpLookupTables();
        
        // Allocate the ConfigManager.
        //
        theConfigManager = new ConfigManager (this);
        
        // The system tray representation of Web-4-All.
        //
        initSysTray();
        
    }   // end ControlHub()
    
    /**
     * Create and initialize the system tray representation of Web-4-All.
     */
    private void initSysTray()
    {
        // Create the object, and add it to the property change listener list
        // for changes in locale and main window.
        // 
        theSysTray = new W4ASysTray (this);
        addPropertyChangeListener (theSysTray);
        
    }   // end initSysTray().

    /**
     * Create and return an array of option buttons to use in a JOptionPane.
     * @param   inButtonType    An int used to determine the number and type of buttons
     *                          to return; either Yes/No buttons or an OK button.
     *                          One of JOptionPane.QUESTION_MESSAGE or JOptionPane.ERROR_MESSAGE.
     * @return  An array of JButtons, properly labelled.  They have no ActionListeners attached.
     *
     * @see #configureOptionButtons(JButton[],JOptionPane)
     * @see #deconfigureOptionButtons(JButton[],ActionListener)
     */
    private JButton[] createOptionButtons (int inButtonType)
    {
        JButton[] result = null;
        try
            {
                // Get the label, etc. resources.  Note: this has to be done each time since the
                // preferred language can change.
                //
                ResourceBundle optionsRez = ResourceBundle.getBundle ("ca.utoronto.atrc.web4all.optionbuttons", getLocale());
            
                if (inButtonType == (JOptionPane.QUESTION_MESSAGE))
                    {
                        // Create Yes/No buttons.
                        //
                        result = new JButton[2];
                        result[0] = new JButton (optionsRez.getString (YES_BUTTON_LABEL));
                        result[0].setActionCommand (YES_BUTTON_CMD);
                        result[0].setMnemonic (optionsRez.getString (YES_BUTTON_ALT).charAt (0));
                        result[1] = new JButton (optionsRez.getString (NO_BUTTON_LABEL));
                        result[1].setActionCommand (NO_BUTTON_CMD);
                        result[1].setMnemonic (optionsRez.getString (NO_BUTTON_ALT).charAt (0));
                    }
                else
                    {
                        // Initialize <theOkButtons>.
                        //
                        result = new JButton[1];
                        result[0] = new JButton (optionsRez.getString (OK_BUTTON_LABEL));
                        result[0].setMnemonic (optionsRez.getString (OK_BUTTON_ALT).charAt (0));
                        result[0].setActionCommand (OK_BUTTON_CMD);
                    }
            }
        catch (MissingResourceException mre)   // can't happen.
            { mre.printStackTrace(); }
         
        return result;
    
    }   // end createOptionButtons().
    
    /**
     * Add an OptionButtonAction, which dismisses a JOptionPane, to the given buttons.
     * @param   ioButtons       The JButtons to add an ActionListener to.
     * @param   inOptionPane    The JOptionPane that the <code>ioButtons</code> interact with.
     * @return                  The ActionListener added to the <code>ioButtons</code>
     * @see #deconfigureOptionButtons(JButton[],ActionListener)
     * @see #createOptionButtons(int)
     */
    private ActionListener configureOptionButtons (JButton[] ioButtons, JOptionPane inOptionPane)
    {
        // Create the ActionListener.
        //
        OptionButtonAction action = new OptionButtonAction (inOptionPane);
        
        for (int i = 0; i < ioButtons.length; i++)
            ioButtons[i].addActionListener (action);
        
        return action;
        
    }   // end configureOptionButtons().
    
    /**
     * Remove the OptionButtonAction, whcih dismisses a JOptionPane, from the given buttons.
     * @param   ioButtons       The JButtons to add an ActionListener to.
     * @param   inAction        The OptionButtonAction to remove.
     * @see #configureOptionButtons(JButton[],JOptionPane)
     * @see #createOptionButtons(int)
     */
    private void deconfigureOptionButtons (JButton[] ioButtons, ActionListener inAction)
    {        
        for (int i = 0; i < ioButtons.length; i++)
            ioButtons[i].removeActionListener (inAction);
        
    }   // end deconfigureOptionButtons().
    
    /**
     * Default implementation of a procedure for generating the portal/cgi URL.
     * This is called from the constructor after all the other bits have been
     * put into the Web4All global properties data member.  This generates and
     * return the CGI URL as a String.
     * <p>
     * If the <code>PORTAL_HOST</code> property is absent, this returns the
     * emtpy string.</p>
     * <p>
     * If the SERIAL_NUMBER is absent, the URL consists of just the host.
     * <p>
     * Otherwise the URL is of the form:<br>
     * <code>http://&lt;PORTAL_HOST&gt;/&lt;CGI_SCRIPT_NAME&gt;?&lt;SERIAL_NUMBER_VAR&gt;=&lt;SERIAL_NUMBER&gt;&&lt;SERIAL_ENCODING_VAR&gt;=&lt;SERIAL_ENCODING&gt;</code>
     * @return      Full CGI URL as a String.
     */
    private String genCgiUrl()
    {
        // The default result is the empty string.
        //
        StringBuffer result = new StringBuffer();
        result.append ("");
        
        // Check for a portal host.  If there is one, create the "root" of the
        // cgi URL.
        //
        String aString = systemProps.getProperty (Web4AllPropNames.PORTAL_HOST);
        if ((aString != null) && (aString.length() != 0))
        {
            result.append ("http://");
            result.append (aString);
            
            // Check for a serial number.  If there is one, add the cgi script
            // and its arguments to the URL.
            //
            aString = systemProps.getProperty (Web4AllPropNames.SERIAL_NUMBER);
            if ((aString != null) && (aString.length() != 0))
            {
                result.append ("/");
                result.append (
                  systemProps.getProperty (Web4AllPropNames.CGI_SCRIPT_NAME)
                );
                result.append ("?");
                result.append (
                  systemProps.getProperty (Web4AllPropNames.SERIAL_NUMBER_VAR)
                );
                result.append ("=");
                result.append (aString);
                result.append ("&");
                result.append (
                  systemProps.getProperty (Web4AllPropNames.SERIAL_ENCODING_VAR)
                );
                result.append ("=");
                result.append (
                  systemProps.getProperty (Web4AllPropNames.SERIAL_ENCODING)
                );
            }
        }
        return (result.toString());
    
    }   // end genCgiUrl().
    
    /**
     * The main entry point that a preferences loader uses to engage the control hub.
     * @param   inPrefs         The XML preferences as a String.
     * @param   inPrefsLoader   The preferences loader -- implements interface
     *                          PrefsLoaderAPI.
     * @return                  Either new XML preferences, or a modified version.
     * @see #startWeb4All(String,PrefsLoaderAPI)
     * @see #stopIt()
     * @see PrefsLoaderAPI
     */
    public synchronized String kickIt (String inPrefs, PrefsLoaderAPI inPrefsLoader)
    {
        thePrefsStr = inPrefs;
        thePrefsLoader = inPrefsLoader;
        
        // Make sure that the splash screen is visible.
        //
        if (theMainWindow != null)
            theMainWindow.show();
        else
            showSplashScreen();         // creates <theMainWindow>...
        
        // Initialize the third party lookup tables.
        //
        load3rdPartyProps();
        if (DEBUG) dumpLookupTables();
        
        // Create the ConfigManager and PWM if they don't exist yet.
        //
        if (theConfigManager == null)
            theConfigManager = new ConfigManager (this);
                    
        // If there are preferences (<inPrefs> is not null nor empty), turn it into a DOM.
        // In any case, initialize <thePWM>.
        //
        if ((thePrefsStr != null) && (thePrefsStr.length() > 0))
            makePrefsDom (thePrefsStr);
        else
            thePrefsDOM = null;
        
        initPWM();

        // If there are preferences, configure the system.
        //
        if (enableConfig && thePrefsDOM != null) {
            // Update language to the user's preference.
            //
            String lang = getLanguageCodePref (thePrefsDOM);
            setLocale (thePWM.getLocaleFromString(lang));

            // Put up "configuring" status message.
            //
            theSplashScreen.updateStatusMessage (theSplashScreen.getLabel (SplashScreen.DOING_CONFIG));
            
            // If the "configure" button in the splash screen is currently "configure",
            // switch it to "cancel".
            //
            theConfigManager.doConfigure (thePrefsDOM);
            if (theSplashScreen.getCancelSense() == SplashScreen.CONFIG_ACTION)
                theSplashScreen.toggleCancelSense();
            
            // Delete the status message (we are done).
            //
            theSplashScreen.updateStatusMessage (null);
            iconifySplashScreen();
        }   
        
        // If there are no preferences, call up the PWM in a separate thread (see run()).
        // This will launch the PWM (modal) dialogues, saving user prefs to the card, and
        // configure the station.
        //
        else
            {                
                Thread aThread = new Thread (this, "New Prefs");
                aThread.start();
            }
        
        // !!! This should return the preferences as a String (ascii).
        //
        return "";
        
    }   // end kickIt().

    /**
     * Stop Web-4-All and return it to its initial state.  If possible, the work station is
     * re-configured to its default state.  Internal data is flushed. The only method
     * a caller should invoke after <code>stopIt()</code> is <code>kickIt()</code>.
     * @see #kickIt(String,PrefsLoaderAPI)
     * @see #stopWeb4All()
     */
    public synchronized void stopIt()
    {
        // First, dismiss any pending alert.  This can result in a launch of the PWM.
        // To give time for that, go to sleep briefly, so that the following call
        // to kill the PWM "takes".
        //
        updateStatusMessage (null);

        // In case the PWM is currently up, kill it.
        //
        if (thePWM != null)
            thePWM.kill();
            
        // Unconfigure the machine, if possible.  Then "forget" the Configuration Manager.
        //
        if (theConfigManager != null)
            {
                theSplashScreen.updateStatusMessage (theSplashScreen.getLabel (SplashScreen.CANCEL_CONFIGING));
                theConfigManager.doShutdown();
                theSplashScreen.toggleCancelSense();
                theSplashScreen.updateStatusMessage (null);
                deiconifySplashScreen();
            }       
        theConfigManager = null;
        
        // Reset the locale back to the system default.
        //
        updateLanguagePref (Locale.getDefault());
        
        // Get rid of any preferences, and the PWM.
        //
        thePrefsDOM = null;
        thePrefsStr = null;
        thePWM = null;
                
        // Get rid of third party info.
        //
        flushLookupTables();
    
    }   // end stopIt().

    /**
     * Alter the current status message within the main window.  Whatever
     * is passed in, including <code>null</code>, will replace any current status message. 
     * @param   inMessage       The status message itself.  If <code>null</code> or empty, any
     *                          current status is erased.
     * @see #updateStatusMessage(String,int)
     */
    public void updateStatusMessage (String inMessage)
    {
        // Get rid of any pending dialogue.  Side effect:  <theStatusOptionPane> is "null" when
        // this returns.
        //
        dismissStatusDialogue();
        
        // Update the status line in <theSplashScreen>.
        //      
        if (theSplashScreen != null)
            {
                deiconifySplashScreen();
                theSplashScreen.updateStatusMessage (inMessage);
            }

    }   // end updateStatusMessage (String inMessage)
    
    /**
     * Show either an alert modal dialogue or a confirmation modal dialogue containing the
     * given message.  The message is also used to update the status message in the main window.
     * @param   inMessage       The status message itself.  If <code>null</code> or empty, any
     *                          current status is erased.
     * @param   inMessageType   One of <code>JOptionPane.ERROR_MESSAGE</code>, or
     *                          <code>JOptionPane.QUESTION_MESSAGE</code>.  If the
     *                          former, <code>JOptionPane.showMessageDialog()</code> is used.
     *                          If the latter, <code>JOptionPane.showConfirmationDialog()</code>
     *                          is used.
     * @return                  If a confirmation dialogue is presented, the return value is
     *                          either <code>JOptionPane.YES_OPTION</code> or
     *                          <code>JOptionPane.NO_OPTION</code>.
     * @see #showOptionDialog(Component,String,String,int)
     * @see #updateStatusMessage(String)
     */
    public int updateStatusMessage (String inMessage, int inMessageType)
    {
        int statVal = JOptionPane.YES_OPTION;    // default return.
        
        // Put <inMessage> on the splash screen at least.  Note that this also clears any pending
        // dialogue, with the side effect that <theStatusProgDismissed> will be set to true
        // by the time "updateStatusMessage (inMessage)" returns.
        //
        updateStatusMessage (inMessage);
        
        // Choose the type of modal dialogue based on <inMessageType>.
        //
        JButton optionButtons[];
        ActionListener action;
        if (inMessageType == JOptionPane.QUESTION_MESSAGE)
            {
                optionButtons = createOptionButtons (JOptionPane.QUESTION_MESSAGE);
                theStatusOptionPane = new JOptionPane (inMessage, JOptionPane.QUESTION_MESSAGE, JOptionPane.YES_NO_OPTION, null /* icon */, optionButtons, optionButtons[0]);
                action = configureOptionButtons (optionButtons, theStatusOptionPane);
            }
        else
            {
                optionButtons = createOptionButtons (JOptionPane.ERROR_MESSAGE);
                theStatusOptionPane = new JOptionPane (inMessage, JOptionPane.ERROR_MESSAGE, JOptionPane.DEFAULT_OPTION, null /* icon */, optionButtons, optionButtons[0]);
                action = configureOptionButtons (optionButtons, theStatusOptionPane);
            }

        // Make the dialogue and show it.
        //
        JDialog modal = theStatusOptionPane.createDialog (theMainWindow, null);
        theStatusOptionPane.selectInitialValue();
        modal.show();
        
        // Get the value of <theStatusOptionPane>.  Note that <modal> may have been programmatically
        // dismissed elsewhere, in which case <theStatusProgDismissed> is "true", and the return value
        // is JOptionPane.CLOSED_OPTION.
        //
        if (theStatusProgDismissed)
            {
                statVal = JOptionPane.CLOSED_OPTION;
                theStatusProgDismissed = false;             // reset for next time.
            }
        
        // User dismissed <modal>?  Get the value of <theStatusOptionPane> "normally".
        // Note that at the beginning of this method, the default value of <statVal> is set to
        // JOptionPane.YES_OPTION, so we only need to set it if it's a confirmation dialogue
        // (alerts with just an OK button return "null" as their value).
        //
        else if (theStatusOptionPane != null)
            {
                Object val = theStatusOptionPane.getValue();
                if (val instanceof Integer)
                    statVal = ((Integer) val).intValue();
                else
                    statVal = JOptionPane.CLOSED_OPTION;
            }
        
        // At this point, <modal> probably has been disposed by someone, and is invalid.
        // Hence, <theStatusOptionPane> is fairly useless.
        //
        theStatusOptionPane = null;
        
        // Remove the action listener from the <optionButttons>.
        //
        deconfigureOptionButtons (optionButtons, action);

        return statVal;
    
    }   // end updateStatusMessage (String inMessage, int inMessageType).
    
    /**
     * Helper method to dismiss "programatically" any pending alert put up by
     * <code>updateStatusMessage()</code>.  When finished, this will reset the relevant data
     * members to <code>null</code>.
     * @see #updateStatusMessage
     */
    private synchronized void dismissStatusDialogue()
    {
        // Assume that if the <theStatusOptionPane> is non-null, there is a pending modal dialogue
        // to dismiss programatically.
        //
        if (theStatusOptionPane != null)
            {
                theStatusProgDismissed = true;
            
                // In Swing 1.1.1, JOptionPane.createDialog() adds a PropertyChangeListener for the
                // value of the option pane.  this.updateStatusMessage() created <theStatusDialogue>
                // using JOptionPane.createDialog().  When it fires, the PropertyChangeListener calls
                // dispose() on the JDialog that is displaying the option pane.  In this case, that
                // would be <theStatusDialogue>.  In other words, the following call to
                // JOptionPane.setValue() causes <theStatusDialogue> to be disposed -- it's
                // effectively null after the dialogue is dismissed.
                //
                theStatusOptionPane.setValue (null);            // dismisses the modal dialogue.
                theStatusOptionPane = null;
            }
        
    }   // end dismissStatusDialogue().
    
    /**
     * Inform the Web-4-All system of a change in language preference, including
     * notifying any property change listeners.
     * @param   inLocale    The new Locale.
     * @see #updateLanguagePref(Locale)
     * @see #getLocale()
     */
    public void setLocale (Locale inLocale)
    {
        // Get the current Locale
        //
        Locale currentLocale = getLocale();
        theLocale = inLocale;
      
        // Update <theMainWindow>'s UI, including its contents, aka
        // <theSplashScreen>
        //
        if (theSplashScreen != null)
            theSplashScreen.updateLocale (inLocale);
        theMainWindow.setTitle (theSplashScreen.getLabel(SPLASH_TITLE));
        theMainWindow.getAccessibleContext().setAccessibleDescription(
               theSplashScreen.getLabel(SPLASH_TITLE));
        
        // Fire a change event.
        //
        thePropChanges.firePropertyChange (LOCALE_PROP, currentLocale, inLocale);
    
    }   // end setLocale().

    /**
     * Inform the Web-4-All system of a change in language preference.
     * @param   inLocale    The new Locale.
     * @see #setLocale(Locale)
     * @see #getLocale()
     */
    public void updateLanguagePref (Locale inLocale)
    {
        setLocale (inLocale);
    
    }   // end updateLanguagePref().
    
    /**
     * Return current Locale in use by Web-4-All.  This can be the user's
     * preferred locale.  If no preferences set, this will default to the system
     * locale.
     * @return       The current Locale.
     */
    public Locale getLocale()
    {
        return theLocale;
    
    }   // end getLocale().

    /**
     * Utility method to get the language code out of the preferences document.  This
     * assumes that the language code is in the "context" element, and that the
     * relevant context is "web-4-all".
     * @param   inPrefs     The preferences document to look for the language code.
     * @returns             The lanugage code in <code>inDocument</code> if one can
     *                      be found, as a String.  If no language pref can be found,
     *                      the empty string is returned.
     */
    private String getLanguageCodePref (Document inPrefs)
    {
        String langCode = "";
        if (inPrefs != null)
            {
                try
                    {
                        String path = "//context[@" + getPrefElementName (CONTEXT_ID) + "='" + getGlobalProperty (ControlHub.CONTEXT_ID_VAL) + "']";
                        Element context = (Element) XPathAPI.selectSingleNode (inPrefs, path);
                        langCode = context.getAttribute (getPrefElementName (PREF_LANG));
                    }
                catch (TransformerException te)
                    {
                        ConfigManager.logException (te);
                    }
                catch (MissingResourceException mre)
                    {
                        ConfigManager.logException (mre);
                    }
            }
        return langCode;
    
    }   // end getLanguageCodePref().
    
    /**
     * Utility to determine if a third party application/technology exists on the system.
     * @param   inAppID     The application ID whose executable is checked for exsistence.
     * @return              <code>true</code> if the executable associated with
     *                      <code>inAppID</code> is on the system; <code>false</code>
     *                      otherwise.
     */
    public boolean thirdPartyAppExists (String inAppID)
    {
        boolean result = false;     // assume the worst.
        
        // Look for that ID in the Web4All's properties.
        //
        try
            {
                String appPath = get3rdPartyExecutable (inAppID);
                File execFile = new File (appPath);
                result = execFile.exists();
            }
        catch (MissingResourceException mre)
            {
                mre.printStackTrace();
                result = false;
            }
        return result;
    
    }   // end thirdPartyAppExists().
     

    /**
     * Minimize the main window.
     */
    protected void iconifySplashScreen() {
        if (iconify && theMainWindow != null) {
            theMainWindow.setState(Frame.ICONIFIED);
        }
    }


    /**
     * Deiconify the main window.
     */
    protected void deiconifySplashScreen() {
        if (iconify && theMainWindow != null) {
            theMainWindow.setState(Frame.NORMAL);
            theMainWindow.requestFocus();
        }
    }

    /**
     * Show the main window.  As a side effect, the main window is created, if it does
     * not exist.
     */
    protected void showSplashScreen()
    {
        // Make the splash screen, if it doesn't exist, but don't execute it yet.
        //
        if (theSplashScreen == null)
            {
                theSplashScreen = new SplashScreen (this);
                theSplashScreen.putClientProperty (Web4AllPropNames.ENABLE_CONFIG, new Boolean (enableConfig));
                String notifyVal = systemProps.getProperty (Web4AllPropNames.NOTIFY);
                theSplashScreen.putClientProperty (Web4AllPropNames.NOTIFY, Boolean.valueOf (notifyVal));
                theSplashScreen.init();
            }
        
        // Make the main window, if it doesn't exist.
        //
        if (theMainWindow == null)
            {
                theMainWindow = new JFrame();

                // Set the SplashScreen icon.
                //
                Class controlHubClass = this.getClass();
                ImageIcon logo = new ImageIcon(controlHubClass.getResource(ControlHub.WEB4ALL_LOGO_ICON));
                theMainWindow.setIconImage(logo.getImage());

                // Set the SplashScreen title.
                //
                theMainWindow.setTitle(theSplashScreen.getLabel(SPLASH_TITLE));

                // Exit on close b/c this is only a PWM demo.
                //
                theMainWindow.setDefaultCloseOperation (JFrame.DO_NOTHING_ON_CLOSE);
            
                // Put it all together.
                //
                theMainWindow.getContentPane().setLayout (new BorderLayout());
                theMainWindow.getContentPane().add (BorderLayout.CENTER, theSplashScreen);

                // Get the size of the screen to centre the splash frame.
                //
                Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
                int posX = (screenSize.width - SPLASH_WIDTH) / 2;
                int posY = (screenSize.height - SPLASH_HEIGHT) / 2;

                theMainWindow.pack();
                theMainWindow.setSize (SPLASH_WIDTH, SPLASH_HEIGHT);
                theMainWindow.setLocation (posX, posY);
                theMainWindow.setResizable (true);
                thePropChanges.firePropertyChange (MAIN_WINDOW_PROP, null, theMainWindow);

            }
        theMainWindow.show();       
        theMainWindow.requestFocus();

    }   // end showSplashScreen().
    
    /**
     * Parse the given XML ACCLIP string into a DOM.  The DOM is stored internally.
     * @param       inPrefsStr  The preferences as a String.
     */
    protected void makePrefsDom (String inPrefsStr)
    {
        // Don't do anything with a null or empty input.
        //
        if ((inPrefsStr != null) && (inPrefsStr.length() > 0))
            {
                // Place the XML argument string into an input stream, and that into an
                // InputSource.
                //
                StringReader inputString = new StringReader (inPrefsStr);
                InputSource iSource = new InputSource (inputString);
                        
                // Parse the profile and make a DOM, then make an instance of the ConfigManager
                // to walk the tree.
                //
                Document doc = null;
                try
                    {
                        DOMParser domParser = new DOMParser();

                        domParser.setErrorHandler(new ErrorHandler() {
                                public void error(SAXParseException exception) throws SAXParseException {
                                    ConfigManager.logDebugStatement("Error: Line " + exception.getLineNumber() + " " + exception.getMessage()); 
                                    throw exception;
                                }
                      
                                public void fatalError(SAXParseException exception) throws SAXParseException {
                                    ConfigManager.logDebugStatement("FatalError: Line " + exception.getLineNumber() + " "  + exception.getMessage());
                                    throw exception;
                                }
                      
                                public void warning(SAXParseException exception) throws SAXParseException {
                                    ConfigManager.logDebugStatement("Warning: Line " + exception.getLineNumber() + " " + exception.getMessage());

                                    // Do not throw an exception on warnings.
                                }
                            });
                      

                        domParser.setFeature("http://apache.org/xml/features/dom/defer-node-expansion", false);
                        domParser.setFeature("http://xml.org/sax/features/validation", true);
                        domParser.setFeature("http://apache.org/xml/features/validation/schema",true);
                        domParser.setFeature("http://xml.org/sax/features/namespaces", false);

                        domParser.parse(iSource);
                        doc = domParser.getDocument();

                        // normalize text representation
                        //
                        doc.getDocumentElement().normalize();
                        ConfigManager.logDebugStatement ("Root element of the doc is " + doc.getDocumentElement().getNodeName());
                    }
                catch (SAXParseException err)
                    {
                        ConfigManager.logDebugStatement ("** Parsing error" + ", line " + err.getLineNumber() + ", uri " + err.getSystemId());
                        ConfigManager.logDebugStatement ("   " + err.getMessage());
                        doc = null;
                    }
                catch (SAXException e)
                    {
                        Exception x = e.getException();
                        ConfigManager.logException (((x == null) ? e : x));
                        doc = null;
                    }
                catch (Throwable t)
                    {
                        ConfigManager.logException (t);
                        doc = null;
                    }
            
                // Notify the user if their preferences did not validate.
                //
                //            if (doc == null)
                //               updateStatusMessage (theSplashScreen.getLabel(INVALID_PREFS), JOptionPane.ERROR_MESSAGE);
            
        
                // Finally, record this DOM version of <inPrefsStr>.
                //
                thePrefsDOM = doc;
            }
    
    }   // end makePrefsDom()

    /**
     * Retrieve an ACCLIP preference element name given its key.  This can also be used to retrieve
     * some ACCLIP attribute names.  The keys are defined in the Web4AllConstants interface.
     * @param       inKey       The key to the element's name.
     * @return                  The element name, if found.
     * @exception               java.util.MissingResourceException
     * @see Web4AllConstants
     * @see #getPrefElementNameKey(String)
     */
    public String getPrefElementName (String inKey) throws MissingResourceException
    {       
        if (theXmlElements == null)
            throw new MissingResourceException ("Cannot get element name", "java.util.PropertyResourceBundle", inKey);

        return (theXmlElements.getString (inKey));
            
    }   // end getPrefElementName().
    
    /**
     * Retrieve a preference element name's key, given its ACCLIP name.  The keys are defined in
     * the Web4AllConstants interface.
     * @param       inElementName   The name of an element.
     * @return                      The element name's key, if found.
     * @exception               java.util.MissingResourceException
     * @see Web4AllConstants
     * @see #getPrefElementName(String)
     */
    public String getPrefElementNameKey (String inElementName) throws MissingResourceException
    {       
        if (theXmlElements == null)
            throw new MissingResourceException ("Cannot get element name key", "java.util.PropertyResourceBundle", inElementName);

        String retVal = null;
        Enumeration theKeys = theXmlElements.getKeys();
        while (theKeys.hasMoreElements())
            {
                String aKey = (String) theKeys.nextElement();
                String elName = theXmlElements.getString (aKey);
                if (elName.equals (inElementName))
                    retVal = aKey;
            }
        return retVal;
                    
    }   // end getPrefElementNameKey().
    
    /**
     * Retrieve the URL to the third party folder.
     * @return      The URL to the third party folder, or <code>null</code>, if unspecified.
     */
    protected URL get3rdPartyFolderUrl()
    {
        return the3rdPartyFolder;
    
    }   // end get3rdPartyFolderUrl().
    
    /**
     * Retrieve the full path to the home directory.  This is the directory in which Web-4-All
     * resides.
     * @return      The full path to the home directory, as a String.
     */
    public String getHomeDirectory()
    {
        return theHomeDirectory;
    
    }   // end getHomeDirectory().
    
    /**
     * Given an application type, return a list of application IDs for that type. This provides
     * identifiers of the technologies available on the system that have declared themselves as
     * of a certain type.  The return value is a clone of the types held internatlly.
     * @param       inAppType   The application type key (String).
     * @return                  A Vector of application ID's that correspond to the given
     *                          type, or <code>null</code> if no technology is of the given type.
     */
    public Vector get3rdPartyAppIds (String inAppType)
    {
        Vector idVector = (Vector) lookupAppIDsByAppType.get (inAppType);
        return ( idVector == null ? null : (Vector) idVector.clone() );

    }   // end get3rdPartyAppIds().
    
    /**
     * Given an application ID, return the application type codes for that ID, if any.  This
     * is done by searching the application types for that ID, and, if it is found,
     * adding the type to the returned Vector.  If none are found, a MissingResourceException is
     * thrown.
     * @param       inAppID     The application ID (String).
     * @return                  The application types as a Vector of String.
     * @exception               java.util.MissingResourceException
     */
    public Vector get3rdPartyAppTypes (String inAppID) throws MissingResourceException
    {
        Vector result = new Vector();
        
        // Get the keys in the <lookupByAppType> table.  Then loop to search each appType Vector
        // of application IDs for <inAppID>
        //
        Enumeration allTypes = lookupAppIDsByAppType.keys();
        while (allTypes.hasMoreElements())
            {
                String anAppType = (String) allTypes.nextElement();
                Vector ids = (Vector) lookupAppIDsByAppType.get (anAppType);
                if (ids.contains (inAppID))
                    result.add (anAppType);
            }
        
        // If nothing found, throw the exception.  Otherwise, return the Vector of types.
        //
        if (result.size() == 0)
            throw new MissingResourceException ("Cannot get application types", "java.util.PropertyResourceBundle", inAppID);
        
        return result;
        
    }   // end get3rdPartyAppTypes().
    
    /**
     * Given an application ID, return the class name of the preferences wizard plug-in for that application, if any.
     * This is done by first looking up the properties for that ID, and, if they are found,
     * looking up the preferences property within.  If either step fails, a 
     * MissingResourceException is thrown.
     * @param       inAppID     The application ID (String).
     * @return                  The full name of the wizard class as a String.
     * @exception               java.util.MissingResourceException Unrecognized ID, or no preferences wizard plug-in for that ID.
     * @see ThirdPartyPrefsWizard
     */
    public String get3rdPartyPrefsClass (String inAppID) throws MissingResourceException
    {
        String result = null;
        
        PropertyResourceBundle aBundle = (PropertyResourceBundle) lookupByAppID.get (inAppID);
        if (aBundle != null)
            result = aBundle.getString (inAppID + PREFS_CLASS_SUFFIX);
        else
            throw new MissingResourceException ("Cannot get wizard type", "java.util.PropertyResourceBundle", inAppID);
        
        return result;
        
    }   // end get3rdPartyPrefsClass().
    
    /**
     * Given an application ID, return the class name of the SetterLauncher for that application, if any.
     * This is accomplished by first looking up the properties for the given ID, and, if they are found,
     * looking up the configuration property within.  If either step fails, a 
     * MissingResourceException is thrown.
     * @param       inAppID     The application ID (String).
     * @return                  The full name of the configuration plug-in class as a String.
     * @exception               java.util.MissingResourceException Unrecognized ID, or no configuration plug-in for that ID.
     * @see SetterLauncher
     */
    public String get3rdPartyConfigClass (String inAppID) throws MissingResourceException
    {
        String result = null;
        
        PropertyResourceBundle aBundle = (PropertyResourceBundle) lookupByAppID.get (inAppID);
        if (aBundle != null)
            result = aBundle.getString (inAppID + CONFIG_CLASS_SUFFIX);
        else
            throw new MissingResourceException ("Cannot get configurator type", "java.util.PropertyResourceBundle", inAppID);
        
        return result;
        
    }   // end get3rdPartyConfigClass().
    
    /**
     * Given an application ID, return the full path to the exectuable for that application, if any.
     * This is done by first looking up the properties for the given ID, and, if they are found,
     * looking up the executable property within.  If either step fails,
     * a MissingResourceException is thrown.
     * @param       inAppID     The application ID (String).
     * @return                  The full name of the configurator class as a String.
     * @exception               java.util.MissingResourceException Unrecognized ID, or no executable for that ID.

    */
    public String get3rdPartyExecutable (String inAppID) throws MissingResourceException
    {
        String result = null;
        
        PropertyResourceBundle aBundle = (PropertyResourceBundle) lookupByAppID.get (inAppID);
        if (aBundle != null)
            result = aBundle.getString (inAppID + EXEC_SUFFIX);
        else
            throw new MissingResourceException ("Cannot get executable path", "java.util.PropertyResourceBundle", inAppID);
        
        return result;
        
    }   // end get3rdPartyExecutable().
    
    /**
     * Given an application ID, return the full path to the initialization file for
     * that application.  This is done by first looking up the properties for that ID, and, if they
     * are found,  looking up the ".ini" property.  If either step fails,
     * a MissingResourceException is thrown.
     * @param       inAppID     The application ID (String).
     * @return                  The path to the ".ini" file as a String.
     * @exception               java.util.MissingResourceException Unrecognized ID, or no ".ini" property for that ID.
     */
    public String get3rdPartyIni (String inAppID) throws MissingResourceException
    {
        String result = null;
        
        PropertyResourceBundle aBundle = (PropertyResourceBundle) lookupByAppID.get (inAppID);
        if (aBundle != null)
            result = aBundle.getString (inAppID + INI_SUFFIX);
        else
            throw new MissingResourceException ("Cannot get '.ini' path", "java.util.PropertyResourceBundle", inAppID);
        
        return result;
        
    }   // end get3rdPartyIni().
    
    /**
     * Given an application ID, retrieve the user-friendly string that provides a name for that
     * application.  This is done by first looking up the properties for that ID, and, if they are found,
     * looking up the product name property within.  If either step fails,
     * a MissingResourceException is thrown.
     * @param       inAppID     The application ID (String).
     * @return                  The product name as a String.
     * @exception               java.util.MissingResourceException Unrecognized ID, or no full product name for that ID.
     */
    public String get3rdPartyFullProductName (String inAppID)
    {
        String result = null;
        
        try
            {
                PropertyResourceBundle aBundle = (PropertyResourceBundle) lookupByAppID.get (inAppID);
                if (aBundle != null) {
                
                    // First, try and retrieve the product name in the PWM's Locale.
                    //
                    try
                        {
                            result = aBundle.getString (inAppID + PRODUCT_NAME_SUFFIX + "." + thePWM.getLocale().getLanguage());
        
                        }
                    // If there is no product name with the PWM's Locale, return the default.
                    //
                    catch (MissingResourceException mre1) 
                        {
                            result = aBundle.getString (inAppID + PRODUCT_NAME_SUFFIX);
                        }
                }
            }
        catch (MissingResourceException mre2)
            {
                if (DEBUG) mre2.printStackTrace();
                result = null;
            }
        
        return result;
    
    }   // end get3rdPartyFullName()

    /**
     * Given an application ID, return all of its properties.  These are read-only, and is provided
     * in order that third parties have access to whatever extra properties they placed into their
     * properties file.
     * @param       inAppID     The application ID (String).
     * @return                  The ResourceBundle requested; throws an exception if not found.
     * @exception               java.util.MissingResourceException Unknown ID.
     */
    public ResourceBundle get3rdPartyProperties (String inAppID) throws MissingResourceException
    {
        return (ResourceBundle) lookupByAppID.get (inAppID);

    }   // end get3rdPartyProperties().
    
    /**
     * Find and load all of the plug-in properties files.
     */
    protected void load3rdPartyProps()
    {
        // Make sure that all the look up tables are empty.
        //
        flushLookupTables();
        
        // Create a File object from <the3rdPartyFolder> URL.  If that is null, don't do anything.
        //
        if (the3rdPartyFolder != null)
            {
                File thirdPartyDir = new File (the3rdPartyFolder.getFile());
                ConfigManager.logDebugStatement ("load3rdPartyProps():  the File is '" + thirdPartyDir.toString() + "'");
                    
                // Loop thru all the files in this directory, and look for files ending in ".properties".
                // As they are found, load them.
                //
                String allFiles[] = thirdPartyDir.list();
                int fileCount = (allFiles == null ? 0 : allFiles.length);
                for (int i = 0; i < fileCount; i++)
                    {
                        String fileName = allFiles[i].toLowerCase();
                        ConfigManager.logDebugStatement ("load3rdPartyProps():  a file is '" + fileName + "'");
                        if (fileName.endsWith (".properties"))
                            {
                                ConfigManager.logDebugStatement ("\t...which ends in '.properties'");
                                try
                                    {
                                        URL propsUrl = new URL (the3rdPartyFolder, allFiles[i]);
                                        ConfigManager.logDebugStatement ("load3rdPartyProps():  URL to that file is:  '" + propsUrl.toString() + "'");
                                        PropertyResourceBundle aBundle = new PropertyResourceBundle (propsUrl.openStream());
                                        String appID = aBundle.getString (ControlHub.APP_ID);
                                        String appType = aBundle.getString (ControlHub.APP_TYPE);
                                        lookupByAppID.put (appID, aBundle);
                                        updateAppType2AppIDsTable (appType, appID);
                                    }
                                catch (MalformedURLException mfue1)
                                    {
                                        if (DEBUG) mfue1.printStackTrace();
                                    }
                                catch (IOException ioe) {
                                    if (DEBUG) ioe.printStackTrace();
                                }
                            }
                    }
                ConfigManager.logDebugStatement ("");
            }

    }   // end load3rdPartyProps().

    /**
     * Attempt to find <em>at least one</em> technology that matches the given type.  Use
     * this because other known applications do not exist on the system, and you are trying to
     * find one of the correct type.
     * <p>
     * This takes an application type and a list of applications.  It returns the first application
     * of that type that is not in the list <em>and</em> that exists on the system.  Otherwise, it
     * return <code>null</code>.  The application list is a list of application ID's.
     * The return value is an "application" Element as defined by the ACCLIP.  This element is
     * created and placed within a new mini-document that is separate from the user's main
     * preferences document.
     * @param       appType         The application type.
     * @param       appsNotLaunched A vector containing appID's of applications that are <em>not</em> on the system.
     * @return                      A third party application element for a technology that does exist on the system.
     *                              (e.g., &lt;application name="EpiScreen" priority="1"/&gt;)
     */
    public Element lastChance3rdPartyPrefs(String appType, Vector appsNotLaunched) {
        Element retVal = null;
        System.out.println ("lastChance3rdPartyPrefs():  <appType> is '" + (appType == null ? "null" : appType) + "'");
        try {
            // Switch <appType>'s value to be the dotted key that would normally be used to
            // look it up.
            //
            appType = getPrefElementNameKey (appType);
            System.out.println ("lastChance3rdPartyPrefs():  'dotted' <appType> is '" + (appType == null ? "null" : appType) + "'");
            Vector allAppIDs = get3rdPartyAppIds(appType);
            System.out.println((allAppIDs == null ? "null" : allAppIDs.toString()));
            String foundAppID = null;
          
            // Check all the known applications (<allAppIDs>), if any, for the right type.
            // (<appType).
            //
            if ((allAppIDs != null) && (allAppIDs.isEmpty() == false)) {
                // Loop through <allAppIDS> looking for the first one that (a) is not in
                // <appsNotLaunched> and (b) exists on the system.
                //
                for (int i = 0; i < allAppIDs.size(); i++) {
                    String anID = (String) allAppIDs.elementAt (i);
                
                    // Test (a):  if <anID> is a member of <appsNotLaunched>, get the next one.
                    //
                    if (appsNotLaunched != null) {
                        if (appsNotLaunched.indexOf (anID) != -1)
                            continue;
                    }
                
                    // Test (b):  if <anID> does not exists on the system, get the next one.
                    //
                    if (thirdPartyAppExists (anID) == false)
                        continue;
                
                    // Found one.
                    //
                    foundAppID = anID;
                    break;
                }
            }
          
            // If an application was found, create the third party element for it as the return
            // value.
            //
            if (foundAppID != null) {
                Document lastChance = new DocumentImpl();
                Element root = lastChance.createElement(theXmlElements.getString(APPLICATION));
                root.setAttribute(theXmlElements.getString(APP_NAME), foundAppID);
                retVal = root;
            }
        }
      
        // Could be thrown when looking up the dotted (key) version of <appType> by
        // "getPrefsElementNameKey()".  In that case, give up.
        //
        catch (MissingResourceException mre) {
            mre.printStackTrace();
            retVal = null;
        }
          
        return retVal;
    }

    /**
     * Write the preferences, if any, back to the storage medium.  The Preferences Loader is
     * invoked to do the actual work.
     * @see PrefsLoaderAPI
     */
    public void savePrefs()
    {
        ConfigManager.logDebugStatement ("Web4All.savePrefs() called, <thePrefsDOM> is '" + (thePrefsDOM == null ? "null" : "non-null") + "', <thePrefsLoader> is '" + (thePrefsLoader == null ? "null" : "non-null") + "'");
        
        // For now, dump indented prefs to a StringWriter, and then call <thePrefsLoader>
        // to handle it from there.
        //
        if ((thePrefsDOM != null) && (thePrefsLoader != null)) {
            try {
                thePrefsLoader.savePrefs (thePrefsDOM);
            }
            catch (Exception e) {
                ConfigManager.logException (e);
            }
        }
    
    }   // end savePrefs().

    /**
     * Given an application type and a corresponding application ID, add that ID to a Vector
     * keyed by that type. If the Vector does not exist, create it.
     * @param   inAppType   A "list" of application types to use as keys (String).  This assumed
     *                      to be a comma separated list, e.g. (screen.reader,screen.enhance).  A
     *                      single type with not commas is valid.
     * @param   inAppID     An associated application ID to store with a list of other ID's (String).
     */
    private void updateAppType2AppIDsTable (String inAppType, String inAppID)
    {
        // Tokenize the <inAppType> String.
        //
        StringTokenizer strTok = new StringTokenizer (inAppType, ",");
        while (strTok.hasMoreTokens()) {
            String anAppType = strTok.nextToken().trim();

            // First, attempt to find an existing Vector for <inAppType>.
            //
            Vector appIDs = (Vector) lookupAppIDsByAppType.get (anAppType);
            if (appIDs != null) {
                // Found it, add <inAppID> to the Vector.
                //
                appIDs.addElement (inAppID);
            }
            else {
                // Didn't find it.  Create a new Vector of ID's for this application type.
                //
                appIDs = new Vector();
                appIDs.addElement (inAppID);
                lookupAppIDsByAppType.put (anAppType, appIDs);
            }
        }
       
    }   // end updateAppType2AppIDsTable().

    /**
     * Flush the "appType" and "appID" lookup tables, and their contents.
     */
    protected void flushLookupTables()
    {
        // First the simple app ID lookup table.
        //
        Enumeration allKeys = lookupByAppID.keys();
        while (allKeys.hasMoreElements())
            lookupByAppID.remove (allKeys.nextElement());
        
        // Clear the lookup-by-appType table by first getting its Vector's our and clearing them.
        //
        allKeys = lookupAppIDsByAppType.keys();
        while (allKeys.hasMoreElements()) {
            Vector aVector = (Vector) lookupAppIDsByAppType.remove (allKeys.nextElement());
            aVector.removeAllElements();
        }
    
    }   // end flushLookupTables().
    
    /**
     * For debugging -- dump the contents of all the lookup tables.
     */
    private void dumpLookupTables()
    {
        // First the app ID lookup table.
        //
        System.out.println ("The appID lookup table:");
        System.out.println ("{");
        Enumeration allKeys = lookupByAppID.keys();
        while (allKeys.hasMoreElements()) {
            String appID = (String) allKeys.nextElement();
            PropertyResourceBundle aBundle = (PropertyResourceBundle) lookupByAppID.get (appID);
            System.out.println ("*** '" + appID + "' --> '" + aBundle.toString() + "'");
        }
        System.out.println ("} end appID lookup table");
                
        // Now the lookup-by-appType table, on Vector at a time.
        //
        System.out.println ("The appType list lookup table:");
        System.out.println ("{");
        allKeys = lookupAppIDsByAppType.keys();
        while (allKeys.hasMoreElements()) {
            String appType = (String) allKeys.nextElement();
            Vector aVector = (Vector) lookupAppIDsByAppType.get (appType);
            System.out.print ("*** '" + appType + "' --> [ ");
            for (int i = 0; i < aVector.size(); i++)
                {
                    String appID = (String) aVector.elementAt (i);
                    System.out.print (appID + ",");
                }
            System.out.println (" ]");
        }
        System.out.println ("} end appType list lookup table");
    
    }   // end dumpLookupTables().
    
    //================================
    // PropertyChangeSupport wrappers.
    //================================

    /**
     * Allow PropertyChangeListeners to add themselves.
     * @param   inListener  The PropertyChangeListener to add.
     */
    public void addPropertyChangeListener (PropertyChangeListener inListener)
    {
        thePropChanges.addPropertyChangeListener (inListener);
    
    }   // end addPropertyChangeListener().
     
    /**
     * Allow PropertyChangeListeners to remove themselves.
     * @param   inListener  The PropertyChangeListener to remove.
     */
    public void removePropertyChangeListener (PropertyChangeListener inListener)
    {
        thePropChanges.removePropertyChangeListener (inListener);
    
    }   // end removePropertyChangeListener().
     
    //===============================
    // ActionListener implementation.
    //===============================

    /**
     * Handle button presses on the splash screen.  If the the edit button is pressed, pass
     * control to the Preferences Wizard Manager.  If the cancel button is pressed, pass control
     * to the Configuration Manager, either to cancel the current configuration, or configure it
     * with the currrent preferences.  Finally, handle a shutdown command by passing control to
     * the preference loader to clean up and exit. 
     * @param   e       ActionEvent that called us.
     */
    public void actionPerformed (ActionEvent e)
    {
        String actionCmd = e.getActionCommand();
        
        // Deal with cancel button
        //
        if (enableConfig && (actionCmd == SplashScreen.CANCEL_ACTION || 
                             actionCmd == SplashScreen.CONFIG_ACTION)) {
            JButton button = (JButton) e.getSource();
            try {
                if (actionCmd == SplashScreen.CANCEL_ACTION) {
                    // Undo any configuration, and change the label on the button.
                    //
                    Runnable unconfig = new Runnable() {
                            public void run() {
                                theSplashScreen.updateStatusMessage (theSplashScreen.getLabel (SplashScreen.CANCEL_CONFIGING));
                                theConfigManager.doShutdown();
                                theSplashScreen.updateStatusMessage (null);
                                deiconifySplashScreen();
                            }
                        };
                    Thread aThread = new Thread (unconfig, "Reset Station");
                    aThread.start();
                    theSplashScreen.toggleCancelSense();
                }
                else {
                    // Undo any configuration, do new configuration, and change the label on the button.
                    //
                    Runnable reconfig = new Runnable() {
                            public void run() {
                                theSplashScreen.updateStatusMessage (theSplashScreen.getLabel (SplashScreen.DOING_CONFIG));
                                theConfigManager.doConfigure (thePrefsDOM);
                                theSplashScreen.updateStatusMessage (null);
                                iconifySplashScreen();
                            }
                        };
                    Thread aThread = new Thread (reconfig, "Configure Station");
                    aThread.start();
                    theSplashScreen.toggleCancelSense();
                }
            }
            
            catch (MissingResourceException mre) {
                mre.printStackTrace();      // can't happen...
            }
        }
        
        // Deal with edit button -- "unconfigure" the current system, then
        // launch the PWM.  Note the work is done in a separate thread.
        //
        else if (actionCmd == SplashScreen.EDIT_ACTION) {
        
            // Immediately disable the button such that it can't be
            // double-clicked. Then launch the prefs wizard in another thread.
            //
            ((JButton) e.getSource()).setEnabled (false);
            Thread aThread = new Thread (this, "Edit Prefs");
            aThread.start();
        }

        // Deal with "quit" command -- defer to <thePrefsLoader>.
        //
        else if (actionCmd == SplashScreen.QUIT_ACTION) {
            thePrefsLoader.shutdown();
        }
    
    }   // end actionPerformed().

    //=========================
    // Runnable implementation.
    //=========================

    /**
     * Run the built-in preferences wizard.  Because the wizard is modal, it must execute in a separate
     * thread when invoked from a user interface button press.  The sequence of events are:
     * <OL>
     * <LI>the Preference Wizard Manager presents the built-in preference wizard,</LI>
     * <LI>the new preferences are written via the Preferences Loader,</LI>
     * <LI>the Configuration Manager is invoked to configure the system with the new preferences.</LI>
     * </OL>
     * @see #actionPerformed(ActionEvent)
     */
    public void run()
    {
        // Only do this if the PWM exists.
        //
        if (thePWM != null) {
            // First check for a null <thePrefsDOM> and the reason for it.  If it's due to an invalid
            // set of preferences, say so before putting up the preferences wizard.  This state of affairs
            // arise in makePrefsDOM(), where there is a <thePresStr>, but it can't be made into a
            // DOM.  Before launching the PWM, warn the user as to why.
            //
            int editPrefs = JOptionPane.YES_OPTION;
            if ((thePrefsStr != null) && (thePrefsStr.length() > 0) && (thePrefsDOM == null))
                editPrefs = updateStatusMessage (theSplashScreen.getLabel(INVALID_PREFS), JOptionPane.ERROR_MESSAGE);
            
            if (editPrefs == JOptionPane.YES_OPTION) {
                // Temporary storage for current preferences, if the user cancels.
                //
                Document tempPrefs = null;
                theSplashScreen.updateStatusMessage (theSplashScreen.getLabel (SplashScreen.EDITING_PREFS));
                if (thePrefsDOM == null) {
                    thePrefsDOM = thePWM.newPreference();
                    theSplashScreen.setEditButtonEnable (true);
                }
                else {
                    tempPrefs = (Document) thePrefsDOM.cloneNode(true);
                    thePrefsDOM = thePWM.editPreference (thePrefsDOM);
                    theSplashScreen.setEditButtonEnable (true);
                }
                theSplashScreen.updateStatusMessage (null);
                
                // If there now are some preferences, save them to the card.  Otherwise, reset
                // them (possibly) to <tempPrefs>.
                //
                if (thePrefsDOM != null)
                    {
                        ConfigManager.logDebugStatement ("run():  calling 'savePrefs()'");
                        savePrefs();
                    }
                
                // If there were any preferences from the PWM, deconfigure first, then configure the machine 
                // according to them - unless the PWM was killed in a card removal.
                //
                if (enableConfig && thePrefsDOM != null && !thePWM.isKilled())
                    {
                        theSplashScreen.updateStatusMessage (theSplashScreen.getLabel (SplashScreen.CANCEL_CONFIGING));             
                        theConfigManager.doShutdown();
                        if (theSplashScreen.getCancelSense() == SplashScreen.CANCEL_ACTION)
                            theSplashScreen.toggleCancelSense();
                        theSplashScreen.updateStatusMessage (null);

                        theSplashScreen.updateStatusMessage (theSplashScreen.getLabel (SplashScreen.DOING_CONFIG));
                        theConfigManager.doConfigure (thePrefsDOM);
                        if (theSplashScreen.getCancelSense() == SplashScreen.CONFIG_ACTION)
                            theSplashScreen.toggleCancelSense();
                        theSplashScreen.updateStatusMessage (null);
                        iconifySplashScreen();
                    }

                // Reset the killed variable of the PWM.
                //
                thePWM.resetKilled();

                // If the PWM was canceled, set the thePrefsDOM to its original DOM (if any).
                //
                if (thePrefsDOM == null) {            
                    thePrefsDOM = tempPrefs;
                }
            }
        }
        
        // The edit button on the splash screen is disabled in actionPerformed()
        // above (so that it can't be double-clicked).  This following insures
        // that it is active, once again.
        //
        theSplashScreen.setEditButtonEnable (true);
            
    }   // end run()
    
    /**
     * Utility to create the Preferences Wizard Manager and it's main window.
     */
    protected void initPWM()
    {
        // Do this only if <thePWM> has not been set up already.
        //
        if (thePWM == null) {
            thePWM = new PreferenceManager(this, theMainWindow);
        }
    
    }   // end initPWM().
    
    /**
     * A main for running the Web-4-All system without using a smart card -- mostly for debugging.
     * It has two modes of operation.  In both modes, it reads/writes ACCLIP preferences to and
     * from the local hard drive.
     * <p>
     * For debugging the Web-4-All system, it takes all of its information from the command
     * line, optionally using the low-memory binding version of the preferences, optionally
     * displaying the properties of the specified configuration plug-in and optionally using
     * the name of the given file as the location of the preferences.  If the latter is not
     * provided, the file name defaults to "prefs.xml".
     * <p>
     * In "menu" mode, all the other arguments are ignored, a file menu is built and this
     * behaves like a traditional GUI app.  However, only the preferences wizard is ever
     * engaged to create/read/edit/save preferences files.
     * <p>
     * Which mode is used depends on the contents of Web4All.properties which can specify
     * a PrefsLoaderAPI object to use to load/save the preferences.  Currently, if the
     * class specified matches the MenuPrefsLoader, then Web-4-All is launched in menu mode.
     * Otherwise, Web-4-All is launched in debug mode.
     *
     * @param   args    usage: java ca.utoronto.atrc.web4all.ControlHub [-lowmem] [-appID id] [prefs_file]
     *                  <ul><li>lowmem: use low memory binding</li>
     *                  <li>appID: display information about the plug-in for the application identified by appID</li>
     *                  <li>prefs_file: name of the disk file to read/write</li></ul>
     */
    public static void main (String args[])
    {
        boolean useLowMemory = false;
        boolean lookUpAppID = false;
        String appID = null;
        String fileName = null;

        // Determine what the home directory is.  Then, launch Web4All using that directory.
        //
        String homeDir = System.getProperty ("user.dir");
        if (DEBUG) System.out.println ("main():  home folder is '" + homeDir + "'");

        // Interpret command line arguments.
        //
        if ((args != null) && (args.length != 0))
        {
            for (int i = 0; i < args.length; i++) {
                if (!(args[i].charAt(0) == '-')) {
                    if (lookUpAppID && appID == null)
                        appID = args[i];
                    else                            
                        fileName = args[i];
                }
                else if (args[i].equals("-lowmem"))
                    useLowMemory = true;
                else if (args[i].equals("-appID"))
                    lookUpAppID = true;
            }   
        }
        
        // Create the singleton ControlHub instance, thereby loading the Web4All
        // properties, and determine from that what the preferences loader is.
        // Note:  "true" means create Web4All instance if it doesn't exist.
        //
        ControlHub controlHub = ControlHub.getSharedInstance (true, homeDir);
        ControlHub.PRETTY_PRINT_FLAG = true;
        String prefsLoaderName = null;
        try
        {
            prefsLoaderName = controlHub.getGlobalProperty (
                Web4AllPropNames.PREFS_LOADER
            );
        }
        catch (MissingResourceException mre)
        {
            prefsLoaderName = null;
            mre.printStackTrace();
        }
        
        // If there is a pluggable preferences loader, start up using it.
        //
        if (prefsLoaderName != null)
        {
            // FIXME (JS): Special case:  if it's our own smart card prefs
            // loader, call its main. Our smart card prefs loader should be
            // made pluggable.
            //
            if (prefsLoaderName.equals ("ca.utoronto.atrc.web4all.CardControl"))
                CardControl.main (new String[0]);
            else
                pluggablePrefsLoaderStart (prefsLoaderName, controlHub, homeDir);
        }
            
        // If no preferences loader supplied, assume this is a
        // development/debug run using the DummyPrefsLoader.
        // 
        else
            dummyPrefsLoaderStart (controlHub, useLowMemory, appID, homeDir, fileName);
            
    }   // end main().
    
    /**
     * "Main" for running Web4All using the DummyPrefsLoader
     * @param   ioHub           Web4All instance acting as the control hub.
     * @param   inLoMem         Flag:  use low memory binding for preference file.
     * @param   inAppID         Display information about the plug-in for the application
     *                          identified.  This can be <code>null</code>.
     * @param   inPrefsFile     Base file name of a preferences file to load.  This can be
     *                          <code>null</code>.
     * @param   inHomeDir       The directory that Web4All lives in.
     * @see #main(String[])
     */
    private static void dummyPrefsLoaderStart (ControlHub ioHub, boolean inLoMem, String inAppID, String inPrefsFile, String inHomeDir)
    {
        // Create the prefs loader, initialize <ioHub>, and configure according to <inPrefsFile>.
        //
        DummyPrefsLoader dummyPrefsLoader = new DummyPrefsLoader(ioHub, inLoMem, ControlHub.PRETTY_PRINT_FLAG);
        ControlHub.startWeb4All (inHomeDir, dummyPrefsLoader);
        ioHub.kickIt (dummyPrefsLoader.getPrefs(inPrefsFile), dummyPrefsLoader);
            
        // Get the context global property.
        //
        try
        {
            System.out.println ("Context is: '" + ioHub.getGlobalProperty ("context.id.val") + "'");
        }
        catch (MissingResourceException mre)
        {
            mre.printStackTrace();
        }
        
        // Get out the specified <inAppID> properties.
        //
        if ((ioHub != null) && (inAppID != null))
        {
            System.out.println ("Getting info for '" + inAppID + "'");
            try
            {
                Vector types = ioHub.get3rdPartyAppTypes (inAppID);
                System.out.print ("\tappTypes are  --> [ ");
                for (int i = 0; i < types.size(); i++)
                {
                    String appType = (String) types.elementAt (i);
                    System.out.print (appType + ",");
                }
                System.out.println (" ]");
                
                String aProp = ioHub.get3rdPartyPrefsClass (inAppID);
                System.out.println ("\tprefs class is '" + aProp + "'");
                aProp = ioHub.get3rdPartyConfigClass (inAppID);
                System.out.println ("\tconfig class is '" + aProp + "'");
                aProp = ioHub.get3rdPartyExecutable (inAppID);
                System.out.println ("\tpath to executable is '" + aProp + "'");
                aProp = ioHub.get3rdPartyFullProductName (inAppID);
                System.out.println ("\tfull product name is '" + aProp + "'");
                aProp = ioHub.get3rdPartyIni (inAppID);
                System.out.println ("\tpath to '.ini' is '" + aProp + "'");
            }
            catch (MissingResourceException mre)
            {
                mre.printStackTrace();
            }
        }
    
    }   // end dummyPrefsLoaderStart().
    
    /**
     * Allocate and intialize the given preference loader, initialize Web4All's
     * GUI, and let the relevant event system take over.
     * @param   inPrefsLoaderName   Name of the preferences loader class.
     * @param   ioHub               ControlHub instance acting as the control hub.
     * @param   inHomeDir           The directory that Web4All lives in.
     * @see #main(String[])
     */
    private static void pluggablePrefsLoaderStart (String inPrefsLoaderName, ControlHub ioHub, String inHomeDir)
    {
        try
        {
            // Create the preferences loader using reflection.
            //
            Class prefsLoaderClass = Class.forName (inPrefsLoaderName);
            if (prefsLoaderClass != null)
            {
                PrefsLoaderAPI prefsLoader = (PrefsLoaderAPI) prefsLoaderClass.newInstance();
                prefsLoader.startup();
                ControlHub.startWeb4All (inHomeDir, prefsLoader);
            }
        }
        catch (Throwable t)
        {
            t.printStackTrace();
        }

    }   // end menuModeMain().

    /**
     * Utility for reading an XML file into memory.  The contents of the file are not parsed, but
     * simply retrieved and stored as a <code>java.lang.String</code>.
     *
     * @param  inFileName   The file name.  This can be a full or relative path to the file
     * @return              The contents of the file as a String.
     */
    public static String createXMLString(String inFileName) {
        StringBuffer xmlStringBuf = new StringBuffer();
        File aFile = new File (inFileName);
        try {
            BufferedReader aReader = new BufferedReader (new FileReader (aFile));
            while (true) {
                try {
                    String aLine = aReader.readLine();
                    if (aLine != null)
                        xmlStringBuf.append (aLine);
                    else
                        break;
                }
                catch (IOException ioe) {
                    ioe.printStackTrace();
                    break;
                }
            }
        }
        catch (FileNotFoundException fnf) {
            fnf.printStackTrace();
            return null;
        }

        return xmlStringBuf.toString();
    }

    /**
     * Convert an array of bytes into hexadecimal notation.
     *
     * @param    in_bytes    The array of bytes to convert.
     * @return               The hexadecimal string.
     */
    private static String bytesToHex(byte[] in_bytes) {
        StringBuffer hexBuffer = new StringBuffer(in_bytes.length * 2);

        for (int i = 0; i < in_bytes.length; i++) {

            // Get the high-order 4 bits by shifting the byte 4 to the right and AND it with 00001111.
            hexBuffer.append(Integer.toHexString(((int) (in_bytes[i] >> 4)) & 0x0f));

            // Get the low-order 4 bits by ANDing the byte with 00001111.
            hexBuffer.append(Integer.toHexString((int) (in_bytes[i] & 0x0f)));
        }

        return hexBuffer.toString();

    } // end method bytesToHex
    
}   // end class ControlHub.

