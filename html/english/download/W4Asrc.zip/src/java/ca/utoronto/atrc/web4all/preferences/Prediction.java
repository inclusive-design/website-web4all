/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.JLabel;
import javax.swing.JCheckBox;
import javax.swing.JSlider;
import javax.swing.JPanel;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JOptionPane;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import javax.swing.border.TitledBorder;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.FlowLayout;

import java.util.ResourceBundle;
import java.util.Hashtable;

import java.net.URL;
import java.net.MalformedURLException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

/**
 * Class which encapsulates the editing of a user's prediction preferences.
 *
 * @author David Weinkauf
 * @version $Revision: 1.5 $, $Date: 2006/03/28 16:31:10 $
 */
public class Prediction extends PWMEditPanel {

    private JCheckBox wordPrediction, wordCompletionPrediction, commandPrediction;

    private JLabel numChoicesLabel;

    private JSlider numChoicesSlider;

    private TitledBorder predictionTitle;

    private JCheckBox personalLexicon;

    private JTextField lexiconURL;

    private Document document;
	
    private Element generic;

    /**
     * Sole constructor. Initializes the panel and all its UI.
     *
     * @param  pm  the PreferenceManager
     * @param  root  the root element of the application type's XML document
     * @param  inAppType  the panel's application type
     */
    public Prediction (PreferenceManager pm, Element root, String inAppType) {
        super(pm, inAppType, inAppType + TITLE_SUFFIX);

        document = initDocument(root, xmlLabels.getString(PREDICTION), null);
        generic = document.getDocumentElement();
	
        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Prediction", pm.language);

        wordPrediction = new JCheckBox(labels.getString("word.predict"));
        wordPrediction.setMnemonic(labels.getString("word.predict.mnemonic").charAt(0));
        wordPrediction.setBackground(PANEL_BACKGROUND);
        wordPrediction.setSelected(false);

        wordCompletionPrediction = new JCheckBox(labels.getString("word.complete.predict"));
        wordCompletionPrediction.setMnemonic(labels.getString("word.complete.predict.mnemonic").charAt(0));
        wordCompletionPrediction.setBackground(PANEL_BACKGROUND);
        wordCompletionPrediction.setSelected(false);

        commandPrediction = new JCheckBox(labels.getString("command.predict"));
        commandPrediction.setMnemonic(labels.getString("command.predict.mnemonic").charAt(0));
        commandPrediction.setBackground(PANEL_BACKGROUND);
        commandPrediction.setSelected(false);

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel checkboxGridPanel = new JPanel();
        checkboxGridPanel.setBackground(PANEL_BACKGROUND);
        checkboxGridPanel.setLayout(gridbag);

        Insets insets = new Insets(0, INDENT_VALUE, 0, INDENT_VALUE);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        checkboxGridPanel.add(wordPrediction, c);

        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0.5;
        checkboxGridPanel.add(Box.createHorizontalStrut(1), c);

        c.gridx = 0;
        c.gridy = 1;
        c.weightx = 0.0;
        checkboxGridPanel.add(wordCompletionPrediction, c);

        c.gridx = 0;
        c.gridy = 2;
        c.weightx = 0.0;
        checkboxGridPanel.add(commandPrediction, c);

        JPanel checkboxPanel = new JPanel(new GridLayout(1, 1));
        checkboxPanel.setBackground(PANEL_BACKGROUND);
        checkboxPanel.add(checkboxGridPanel);

        Hashtable numChoicesHash = new Hashtable();
        JLabel hashLabel;
        for (int i = 1; i <= 20; i++) {
            hashLabel = new JLabel(String.valueOf(i));
            hashLabel.setForeground(TEXT_COLOUR);
            numChoicesHash.put(new Integer(i), hashLabel);
        }

        numChoicesSlider = new JSlider(SwingConstants.HORIZONTAL, 1, 20, 5);
        numChoicesSlider.setBackground(PANEL_BACKGROUND);
        numChoicesSlider.setForeground(TEXT_COLOUR);
        numChoicesSlider.setPaintLabels(true);
        numChoicesSlider.setLabelTable(numChoicesHash);
        numChoicesSlider.setMajorTickSpacing(1);
        numChoicesSlider.setSnapToTicks(true);
        numChoicesSlider.setPaintTicks(true);
    
        numChoicesLabel = new JLabel(labels.getString("num.choices"));
        numChoicesLabel.setDisplayedMnemonic(labels.getString("num.choices.mnemonic").charAt(0));
        numChoicesLabel.setLabelFor(numChoicesSlider);
        numChoicesLabel.setForeground(TEXT_COLOUR);
        numChoicesLabel.setFont(TEXT_FONT);


        personalLexicon = new JCheckBox(labels.getString("personal.lexicon"));
        personalLexicon.setMnemonic(labels.getString("personal.lexicon.mnemonic").charAt(0));
        personalLexicon.setBackground(PANEL_BACKGROUND);
        personalLexicon.setForeground(TEXT_COLOUR);

        lexiconURL = new JTextField("http://", 35);
	lexiconURL.getAccessibleContext().setAccessibleName(labels.getString("personal.lexicon"));
        lexiconURL.setFont(TEXT_FONT);

        ChangeListener lexiconListener = new ChangeListener() {
                public void stateChanged(ChangeEvent e) {
                    JCheckBox box = (JCheckBox) e.getSource();
                    if (box.isSelected()) {				
                        lexiconURL.setEnabled(true);
                    }
                    else {
                        lexiconURL.setEnabled(false);
                    }
                }
            };

        personalLexicon.addChangeListener(lexiconListener);
        personalLexicon.setSelected(false);

        gridbag = new GridBagLayout();
        c = new GridBagConstraints();
        JPanel infoGridPanel = new JPanel();
        infoGridPanel.setBackground(PANEL_BACKGROUND);
        infoGridPanel.setLayout(gridbag);

        insets = new Insets(0, INDENT_VALUE, 0, INDENT_VALUE);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        infoGridPanel.add(numChoicesLabel, c);

        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0.5;
        infoGridPanel.add(numChoicesSlider, c);

        c.gridx = 0;
        c.gridy = 1;
        c.weightx = 0.0;
        infoGridPanel.add(personalLexicon, c);

        c.gridx = 1;
        c.gridy = 1;
        c.weightx = 0.5;
        infoGridPanel.add(lexiconURL, c);

        JPanel infoPanel = new JPanel(new GridLayout(1, 1));
        infoPanel.setBackground(PANEL_BACKGROUND);
        infoPanel.add(infoGridPanel);

        predictionTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("prediction.title"));
        predictionTitle.setTitleColor(BORDER_TITLE_COLOUR);
        predictionTitle.setTitleFont(BORDER_TITLE_FONT);

        JPanel predictionPanel = new JPanel();
        predictionPanel.setLayout(new BoxLayout(predictionPanel, BoxLayout.Y_AXIS));
        predictionPanel.setBackground(PANEL_BACKGROUND);
        predictionPanel.setBorder(predictionTitle);
        predictionPanel.add(checkboxPanel);
        predictionPanel.add(infoPanel);

        AccessibleContext ac = wordPrediction.getAccessibleContext();
        ac.setAccessibleParent(predictionPanel);
        ac = wordCompletionPrediction.getAccessibleContext();
        ac.setAccessibleParent(predictionPanel);
        ac = commandPrediction.getAccessibleContext();
        ac.setAccessibleParent(predictionPanel);
        ac = numChoicesLabel.getAccessibleContext();
        ac.setAccessibleParent(predictionPanel);
        ac = numChoicesSlider.getAccessibleContext();
        ac.setAccessibleParent(predictionPanel);
        ac = personalLexicon.getAccessibleContext();
        ac.setAccessibleParent(predictionPanel);
        ac = lexiconURL.getAccessibleContext();
        ac.setAccessibleParent(predictionPanel);

        this.add(predictionPanel);
        this.add(Box.createVerticalGlue());

    }

    /**
     * Does the default UI settings.
     */
    protected void doDefault() {
        wordPrediction.setSelected(false);
        wordCompletionPrediction.setSelected(false);
        commandPrediction.setSelected(false);
        numChoicesSlider.setValue(5);
        lexiconURL.setText("http://");
        personalLexicon.setSelected(false);
    }

    /**
     * Sets the UI values their correct settings according to the application type's document.
     */
    protected void setDomValues() {
        Element temp = DOMUtil.getFirstChildElement(generic);

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(PREDICT_WORD))) {
            if (temp.getAttribute(VALUE).equals("true"))
                wordPrediction.setSelected(true);
            else
                wordPrediction.setSelected(false);

            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(PREDICT_WORD_COMPLETE))) {
            if (temp.getAttribute(VALUE).equals("true"))
                wordCompletionPrediction.setSelected(true);
            else
                wordCompletionPrediction.setSelected(false);

            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(PREDICT_COMMAND))) {
            if (temp.getAttribute(VALUE).equals("true"))
                commandPrediction.setSelected(true);
            else
                commandPrediction.setSelected(false);

            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(PREDICT_NUM_CHOICES))) {
            numChoicesSlider.setValue(Integer.parseInt(temp.getAttribute(VALUE)));

            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(PREDICT_PERSONAL_LEXICON))) {
            personalLexicon.setSelected(true);
            lexiconURL.setText(temp.getAttribute(VALUE));
            temp = DOMUtil.getNextSiblingElement(temp);
        }

    }

    /**
     * Gets the root element of this application type's document.
     */
    protected Element getRootElement() {
        Element temp;

        pm.removeAllChildren(generic);

        temp = document.createElement(xmlLabels.getString(PREDICT_WORD));
        if (wordPrediction.isSelected())
            temp.setAttribute(VALUE, "true");
        else
            temp.setAttribute(VALUE, "false");
        generic.appendChild(temp);
        
        temp = document.createElement(xmlLabels.getString(PREDICT_WORD_COMPLETE));
        if (wordCompletionPrediction.isSelected())
            temp.setAttribute(VALUE, "true");
        else
            temp.setAttribute(VALUE, "false");
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(PREDICT_COMMAND));
        if (commandPrediction.isSelected())
            temp.setAttribute(VALUE, "true");
        else
            temp.setAttribute(VALUE, "false");
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(PREDICT_NUM_CHOICES));
        temp.setAttribute(VALUE, String.valueOf(numChoicesSlider.getValue()));
        generic.appendChild(temp);

        if (personalLexicon.isSelected()) {
            temp = document.createElement(xmlLabels.getString(PREDICT_PERSONAL_LEXICON));
            temp.setAttribute(VALUE, String.valueOf(lexiconURL.getText()));
            generic.appendChild(temp);
        }

        return generic;
    }

    protected void doNext() {

        if (personalLexicon.isSelected()) {
            try {
                URL lexicon = new URL(lexiconURL.getText());
            }
            catch (MalformedURLException murle) {
                ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Prediction", pm.language);
                JOptionPane.showMessageDialog(this, labels.getString("malformed.url"),
                                              labels.getString("malformed.url.title"),
                                              JOptionPane.WARNING_MESSAGE);
                return;            
            }
        }

        super.doNext();
    }

    /**
     * Sets new labels for this panel.
     */
    protected void setNewLabels() {
        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Prediction", pm.language);
        
        wordPrediction.setText(newLabels.getString("word.predict"));
        wordPrediction.setMnemonic(newLabels.getString("word.predict.mnemonic").charAt(0));

        wordCompletionPrediction.setText(newLabels.getString("word.complete.predict"));
        wordCompletionPrediction.setMnemonic(newLabels.getString("word.complete.predict.mnemonic").charAt(0));

        commandPrediction.setText(newLabels.getString("command.predict"));
        commandPrediction.setMnemonic(newLabels.getString("command.predict.mnemonic").charAt(0));

        numChoicesLabel.setText(newLabels.getString("num.choices"));
        numChoicesLabel.setDisplayedMnemonic(newLabels.getString("num.choices.mnemonic").charAt(0));

        personalLexicon.setText(newLabels.getString("personal.lexicon"));
        personalLexicon.setMnemonic(newLabels.getString("personal.lexicon").charAt(0));
	lexiconURL.getAccessibleContext().setAccessibleName(newLabels.getString("personal.lexicon"));

        predictionTitle.setTitle(newLabels.getString("prediction.title"));

        setNewButtonLabels();

        revalidate();
        repaint();
        
    }

    /**
     * Gets the application type's document.
     */
    protected Document getAppTypeDoc() {
        return document;
    }

}
