/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:			ConfigPluginArgs.java
 *
 * Synopsis:		package ca.utoronto.atrc.web4all.configuration;
 * 
]*/

package ca.utoronto.atrc.web4all.configuration;

import java.util.Vector;
import org.w3c.dom.Element;

import ca.utoronto.atrc.web4all.*;

/**
 * Stores the preferences arguments for a specific configuration plugin as well as the relevant
 * SetterLauncher itself.  The preferences are stored as a list of AccLipInfoPackage objects,
 * one for each type of technology that the SetterLauncher is to configure/launch.
 *
 * @version $Id: ConfigPluginArgs.java,v 1.4 2006/03/28 21:17:27 clown Exp $
 * @author	Joseph Scheuhammer.
 *
 */
public class ConfigPluginArgs
{
	/** 
	 * A list of AccLipInfoPackage objects each containing a technology type, a set of generic
	 * preferences, and a set of specific preferences.
	 */
	private Vector theAccLipInfos;
	
	/**
	 * The configuration plugin to use (a SetterLauncher) with the above information.
	 */
    private SetterLauncher thePlugin;

    /**
     * Initialize with a known set of AccLipInfoPackage's, and a plugin.
     * @param   inAccLipInfoPackages    Vector of AccLipInfoPackage objects.
     * @param   inPlugin                 The SetterLauncher to use with the ACCLIP information.
     */
    public ConfigPluginArgs (Vector inAccLipInfoPackages, SetterLauncher inPlugin)
    {
        super();
        theAccLipInfos = inAccLipInfoPackages;
        thePlugin = inPlugin;
        
    }   // end ConfigPluginArgs (Vector inAccLipInfoPackages, SetterLauncher inPlugin).
	
    /**
     * Initialize with a given AccLipInfoPackage object, and a plugin (SetterLauncher).
     * @param   inAccLipInfoPackage     A single AccLipInfoPackage.
     * @param   inPlugin                The SetterLauncher to use with the above preferences.
     */
	public ConfigPluginArgs (AccLipInfoPackage inAccLipInfoPackage, SetterLauncher inPlugin)
	{
	    super();
	    theAccLipInfos = new Vector();
	    theAccLipInfos.addElement (inAccLipInfoPackage);
	    thePlugin = inPlugin;
	
	}   // end ConfigPluginArgs (AccLipInfoPackage inAccLipInfoPackage, SetterLauncher inPlugin).

    /**
     * Initialize with a technology type, generic preferences, specific preferences, and a
     * plugin.
     * @param   inAppType           The type (String) of technology that the following preferences
     *                              are for, taken from the ACCLIP.  For example, "screenReader".
     * @param   inGenericPrefs  	Generic preferences container.  For example, this could
     *                              contain a &lt;screenReaderGeneric&gt; Element.
     * @param   inSpecificPrefs 	Specific settings container.  This is an &lt;application&gt;
     *                              Element.
     * @param   inPlugin            The SetterLauncher to use with the above preferences.
     */
	public ConfigPluginArgs (String inAppType, Element inGenericPrefs, Element inSpecificPrefs, SetterLauncher inPlugin)
	{
	    this (new AccLipInfoPackage (inAppType, inGenericPrefs, inSpecificPrefs), inPlugin);
	
	}	// endConfigPluginArgs (String inAppType, Element inGenericPrefs, Element inSpecificPrefs, SetterLauncher inPlugin)
	
	/**
	 * Add to the list of AccLipInfoPackage objects.  This version allocates an AccLipInfoPackage
	 * based on the inputs, and adds that to the list.
     * @param   inAppType           The type (String) of technology that the following preferences
     *                              are for, taken from the ACCLIP.  For example, "screenReader".
     * @param   inGenericPrefs  	Generic preferences container.  For example, this could
     *                              contain a &lt;screenReaderGeneric&gt; Element.
     * @param   inSpecificPrefs 	Specific settings container.  This is an &lt;application&gt;
     *                              Element.
	 */
	public void addAccLipInfoPackage (String inAppType, Element inGenericPrefs, Element inSpecificPrefs)
	{
	    addAccLipInfoPackage (new AccLipInfoPackage (inAppType, inGenericPrefs, inSpecificPrefs));
	
	}   // end addAccLipInfoPackage (String inAppType, Element inGenericPrefs, Element inSpecificPrefs).
	
	/**
	 * Add the given AccLipInfoPackage instance to the list.
	 * @param inAccInfoLipPackage   The AccLipInfoPackage to add to the list.
	 */
	public void addAccLipInfoPackage (AccLipInfoPackage inAccLipInfoPackage)
	{
	    theAccLipInfos.addElement (inAccLipInfoPackage);
	
	}   // end addAccLipInfoPackage (AccLipInfoPackage inAccLipInfoPackage).
	
	/**
	 * Determine if <code>this</code> is using the same SetterLauncher as the one given.
	 * @param   inClassName     The fully qualified class name of the SetterLauncher that
	 *                          <code>this</code> instance is using.
	 * @return                  <code>true</code> if there is a match, <code>false</code> if
	 *                          there is no match, or if <code>this</code> has no SetterLauncher
	 *                          assigned.
	 */
	public boolean equalsSetterLauncher (String inClassName)
	{
	    boolean result = false;
	    if (thePlugin != null)
	        result = thePlugin.getClass().getName().equals (inClassName);
	    
	    return result;
	
	}   // end equalSetterLauncher().

	/**
	 * Clean up the list containing the the AccLipInfoPackage objects.
	 */
	public void flush()
	{
	    if (theAccLipInfos != null)
	        theAccLipInfos.removeAllElements();
	
	}   // end flush().
	
    /**
     * Wrapper for the <code>doSettings()</code> method of the embedded SetterLauncher.
     * @param       inControlHub        The ControlHub object that contains information about such as the
     *									location of the ".ini" file and/or the path to the
     *									executable.
     * @return                          A flag to indicate whether the SetterLauncher will
     *                                  attempt to launch a browser.
     */
    public boolean doSettings (ControlHub inControlHub)
    {
        boolean result = false;
        if (thePlugin != null)
            result = thePlugin.doSettings (theAccLipInfos, inControlHub);
        
        return result;
    
    }   // end doSettings().

    /**
     * Wrapper for the <code>doLaunch()</code> method of the embedded SetterLauncher.
     */
    public void doLaunch()
    {
        if (thePlugin != null)
            thePlugin.doLaunch();
    
    }   // end doLaunch().       

    /**
     * Wrapper for the <code>kill()</code> method of the embedded SetterLauncher.
     */
    public void kill()
    {
        if (thePlugin != null)
            thePlugin.kill();
            
    }   // end kill().        

}	// end class ConfigPluginArgs.

