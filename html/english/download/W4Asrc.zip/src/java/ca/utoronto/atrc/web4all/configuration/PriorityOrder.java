/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * 
 * File:        PriorityOrder.java
 *
 * Synopsis:    package ca.utoronto.atrc.web4all.configuration
 * 
]*/

package ca.utoronto.atrc.web4all.configuration;

import java.util.*;
import org.w3c.dom.Element;

/**
 * Comparator implementation for ordering &lt;application&gt; elements according to their
 * priority value.  The attribute values are compared, ultimately, using Integer.compareTo().
 *
 * @version $Id: PriorityOrder.java,v 1.2 2006/03/28 21:17:27 clown Exp $
 * @author	Joseph Scheuhammer
 */
public class PriorityOrder implements Comparator
{
    /**
     * The name of the attribute to use for priority.
     */
    private String thePriorityAttr;
    
    /**
     * Constructor -- pass in the attribute name used to find the priority value within an
     * element.
     * @param   inPriorityAttr  Name (String) of the priority attribute.
     */
    public PriorityOrder (String inPriorityAttr)
    {
        super();
        thePriorityAttr = inPriorityAttr;
    
    }   // end PriorityOrder();

//============================
// Comparator implementation.
//============================

    /**
     * Compare two &lt;application&gt; elements according to their priority values.  If the
     * first has a higher priority return 1.  If they are equal, return 0.  Finally, if the
     * second has a higher priority, return -1.
     * @param   inApp1  First application Element to use in the comparison, as an Object.
     * @param   inApp2  Second application ELement to use in the comparison, as an Object.
     * @return          1, 0, or -1 depending on the comparison.
     */
    public int compare (Object inApp1, Object inApp2)
    {
        Element appTag1 = (Element) inApp1;
        Element appTag2 = (Element) inApp2;
        
        // Get the priority values out of <appTag1> and <appTag2>, convert them to
        // Integer's, and compare them via Integer.compareTo().
        //
        Integer p1 = new Integer (appTag1.getAttribute (thePriorityAttr));
        Integer p2 = new Integer (appTag2.getAttribute (thePriorityAttr));
        return p1.compareTo (p2);
        
    }   // end compare().
    
}   // end class PriorityOrder
