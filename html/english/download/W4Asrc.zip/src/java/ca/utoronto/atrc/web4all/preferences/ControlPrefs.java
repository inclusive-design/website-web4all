/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.border.*;
import java.awt.*;
import java.net.URL;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

/**
 * Class ControlPrefs represents the user's Control Preferences dialog.
 * It contains a series of checkboxes with which the user selected their
 * preferred control settings.
 *
 * @author David Weinkauf
 * @version $Revision: 1.7 $, $Date: 2006/03/28 16:31:10 $
 */
public class ControlPrefs extends PWMEditPanel {

    private JCheckBox standardKeyboard, altKeyboard, onscreenKeyboard, 
        keyboardMouse, altMouse, codedInput, voice, prediction;            

    private Hashtable appTypeSelected;

    private Hashtable buttonToType;

    protected JButton saveButton;
    
    private TitledBorder altStdKbdTitle, altStdMouseTitle, altStdControlTitle;

    public ControlPrefs(PreferenceManager pm, String inAppType, 
                        Hashtable inAppTypeSelected) {

        super(pm, inAppType, inAppType + TITLE_SUFFIX);

        appTypeSelected = inAppTypeSelected;

        ResourceBundle labels = 
            ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.ControlPrefs", 
                                     pm.language);

        standardKeyboard = new JCheckBox(labels.getString("standard.keyboard"));
        standardKeyboard.setMnemonic(labels.getString("standard.keyboard.mnemonic").charAt(0));
        standardKeyboard.setBackground(PANEL_BACKGROUND);
        standardKeyboard.setFont(QUESTION_FONT);

        altKeyboard = new JCheckBox(labels.getString("alt.keyboard"));
        altKeyboard.setMnemonic(labels.getString("alt.keyboard.mnemonic").charAt(0));
        altKeyboard.setBackground(PANEL_BACKGROUND);
        altKeyboard.setFont(QUESTION_FONT);

        onscreenKeyboard = new JCheckBox(labels.getString("onscreen.keyboard"));
        onscreenKeyboard.setMnemonic(labels.getString("onscreen.keyboard.mnemonic").charAt(0));
        onscreenKeyboard.setBackground(PANEL_BACKGROUND);
        onscreenKeyboard.setFont(QUESTION_FONT);

        codedInput = new JCheckBox(labels.getString("coded.input"));
        codedInput.setMnemonic(labels.getString("coded.input.mnemonic").charAt(0));
        codedInput.setBackground(PANEL_BACKGROUND);
        codedInput.setFont(QUESTION_FONT);

        prediction = new JCheckBox(labels.getString("prediction"));
        prediction.setMnemonic(labels.getString("prediction.mnemonic").charAt(0));
        prediction.setBackground(PANEL_BACKGROUND);
        prediction.setFont(QUESTION_FONT);

        voice = new JCheckBox(labels.getString("voice"));
        voice.setMnemonic(labels.getString("voice.mnemonic").charAt(0));
        voice.setBackground(PANEL_BACKGROUND);
        voice.setFont(QUESTION_FONT);
        
        keyboardMouse = new JCheckBox(labels.getString("keyboard.mouse"));
        keyboardMouse.setMnemonic(labels.getString("keyboard.mouse.mnemonic").charAt(0));
        keyboardMouse.setBackground(PANEL_BACKGROUND);
        keyboardMouse.setFont(QUESTION_FONT);
        
        altMouse = new JCheckBox(labels.getString("alt.mouse"));
        altMouse.setMnemonic(labels.getString("alt.mouse.mnemonic").charAt(0));
        altMouse.setBackground(PANEL_BACKGROUND);
        altMouse.setFont(QUESTION_FONT);
        
        buttonToType = new Hashtable();
        buttonToType.put(standardKeyboard, KEYBOARD_ENHANCED);
        buttonToType.put(altKeyboard, ALT_KEYBOARD);
        buttonToType.put(onscreenKeyboard, ONSCREEN_KEYBOARD);
        buttonToType.put(keyboardMouse, MOUSE_EMULATION);
        buttonToType.put(altMouse, ALT_POINTING);
        buttonToType.put(codedInput, CODED_INPUT);
        buttonToType.put(prediction, PREDICTION);
        buttonToType.put(voice, VOICE_REC);

        checkNextButton();

        Enumeration keys = buttonToType.keys();
        String appType;
        JToggleButton checkBox;
        while (keys.hasMoreElements()) {
            checkBox = (JToggleButton) keys.nextElement();
            appType = (String) buttonToType.get(checkBox);
            if ( ((Boolean) appTypeSelected.get(appType)) == Boolean.TRUE )
                checkBox.setSelected(true);

        }
		
        AccessListener al = new AccessListener();

        standardKeyboard.addChangeListener(al);
        altKeyboard.addChangeListener(al);
        onscreenKeyboard.addChangeListener(al);
        codedInput.addChangeListener(al);
        prediction.addChangeListener(al);
        voice.addChangeListener(al);
        keyboardMouse.addChangeListener(al);
        altMouse.addChangeListener(al);

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel altStdKbdGridPanel = new JPanel();
        altStdKbdGridPanel.setBackground(PANEL_BACKGROUND);
        altStdKbdGridPanel.setLayout(gridbag);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.weighty = 0.5;
        c.gridheight = 1;

        Insets insets = new Insets(0, INDENT_VALUE, 0, 0);
        c.insets = insets;

        c.weightx = 0.0;
        c.gridx = 0;
        c.gridy = 0;
        altStdKbdGridPanel.add(standardKeyboard, c);

        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 0;
        altStdKbdGridPanel.add(Box.createHorizontalStrut(1), c);

        c.weightx = 0.0;
        c.gridx = 0;
        c.gridy = 1;
        altStdKbdGridPanel.add(onscreenKeyboard, c);

        c.gridx = 0;
        c.gridy = 2;
        altStdKbdGridPanel.add(altKeyboard, c);

        altStdKbdTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("alt.std.keyboard"));
        altStdKbdTitle.setTitleColor(BORDER_TITLE_COLOUR);
        altStdKbdTitle.setTitleFont(BORDER_TITLE_FONT);

        JPanel altStdKbdPanel = new JPanel(new GridLayout(1, 1));
        altStdKbdPanel.setBorder(altStdKbdTitle);
        altStdKbdPanel.setBackground(PANEL_BACKGROUND);
        altStdKbdPanel.add(altStdKbdGridPanel);

        AccessibleContext ac = standardKeyboard.getAccessibleContext();
        ac.setAccessibleParent(altStdKbdPanel);
        ac = onscreenKeyboard.getAccessibleContext();
        ac.setAccessibleParent(altStdKbdPanel);
        ac = altKeyboard.getAccessibleContext();
        ac.setAccessibleParent(altStdKbdPanel);

        this.add(altStdKbdPanel);

        gridbag = new GridBagLayout();
        c = new GridBagConstraints();
        JPanel altStdMouseGridPanel = new JPanel();
        altStdMouseGridPanel.setBackground(PANEL_BACKGROUND);
        altStdMouseGridPanel.setLayout(gridbag);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.weighty = 0.5;
        c.gridheight = 1;

        insets = new Insets(0, INDENT_VALUE, 0, 0);
        c.insets = insets;

        c.weightx = 0.0;
        c.gridx = 0;
        c.gridy = 0;
        altStdMouseGridPanel.add(keyboardMouse, c);

        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 0;
        altStdMouseGridPanel.add(Box.createHorizontalStrut(1), c);

        c.weightx = 0.0;
        c.gridx = 0;
        c.gridy = 1;
        altStdMouseGridPanel.add(altMouse, c);

        altStdMouseTitle = new TitledBorder(BORDER_TITLE_LINE, 
                                            labels.getString("alt.std.mouse"));
        altStdMouseTitle.setTitleColor(BORDER_TITLE_COLOUR);
        altStdMouseTitle.setTitleFont(BORDER_TITLE_FONT);

        JPanel altStdMousePanel = new JPanel(new GridLayout(1, 1));
        altStdMousePanel.setBorder(altStdMouseTitle);
        altStdMousePanel.setBackground(PANEL_BACKGROUND);
        altStdMousePanel.add(altStdMouseGridPanel);

        ac = keyboardMouse.getAccessibleContext();
        ac.setAccessibleParent(altStdMousePanel);
        ac = altMouse.getAccessibleContext();
        ac.setAccessibleParent(altStdMousePanel);

        this.add(Box.createVerticalGlue());
        this.add(altStdMousePanel);

        gridbag = new GridBagLayout();
        c = new GridBagConstraints();
        JPanel altControlGridPanel = new JPanel();
        altControlGridPanel.setBackground(PANEL_BACKGROUND);
        altControlGridPanel.setLayout(gridbag);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.weighty = 0.5;
        c.gridheight = 1;

        insets = new Insets(0, INDENT_VALUE, 0, 0);
        c.insets = insets;

        c.weightx = 0.0;
        c.gridx = 0;
        c.gridy = 0;
        altControlGridPanel.add(voice, c);

        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 0;
        altControlGridPanel.add(Box.createHorizontalStrut(1), c);

        c.weightx = 0.0;
        c.gridx = 0;
        c.gridy = 1;
        altControlGridPanel.add(codedInput, c);

        c.weightx = 0.0;
        c.gridx = 0;
        c.gridy = 2;
        altControlGridPanel.add(prediction, c);

        altStdControlTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("alt.std.control"));
        altStdControlTitle.setTitleColor(BORDER_TITLE_COLOUR);
        altStdControlTitle.setTitleFont(BORDER_TITLE_FONT);

        JPanel altControlPanel = new JPanel(new GridLayout(1, 1));
        altControlPanel.setBorder(altStdControlTitle);
        altControlPanel.setBackground(PANEL_BACKGROUND);
        altControlPanel.add(altControlGridPanel);

        this.add(Box.createVerticalGlue());
        this.add(altControlPanel);
        this.add(Box.createVerticalGlue());

        ac = voice.getAccessibleContext();
        ac.setAccessibleParent(altControlPanel);
        ac = codedInput.getAccessibleContext();
        ac.setAccessibleParent(altControlPanel);
        ac = prediction.getAccessibleContext();
        ac.setAccessibleParent(altControlPanel);

        ResourceBundle buttonLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Buttons", pm.language);			

        prevButton.setPreferredSize(LARGE_BUTTON_DIM);
        prevButton.setText(buttonLabels.getString("display.prev"));
        prevButton.setMnemonic(buttonLabels.getString("display.prev.mnemonic").charAt(0));

    }

    class AccessListener implements ChangeListener {
        public void stateChanged(ChangeEvent e) {
            JCheckBox box = (JCheckBox) e.getSource();
            String appType = (String) buttonToType.get(box);
            if (box.isSelected())
                appTypeSelected.put(appType, Boolean.TRUE);
            else
                appTypeSelected.put(appType, Boolean.FALSE);

            if (appType == ONSCREEN_KEYBOARD && !box.isSelected())
                pm.setUseCodedInput(false);

            checkNextButton();

        }
    }

    protected void setNewLabels() {
        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.ControlPrefs", pm.language);

        altStdKbdTitle.setTitle(newLabels.getString("alt.std.keyboard"));
        altStdMouseTitle.setTitle(newLabels.getString("alt.std.mouse"));
        altStdControlTitle.setTitle(newLabels.getString("alt.std.control"));

        standardKeyboard.setText(newLabels.getString("standard.keyboard"));
        standardKeyboard.setMnemonic(newLabels.getString("standard.keyboard.mnemonic").charAt(0));

        altKeyboard.setText(newLabels.getString("alt.keyboard"));
        altKeyboard.setMnemonic(newLabels.getString("alt.keyboard.mnemonic").charAt(0));

        onscreenKeyboard.setText(newLabels.getString("onscreen.keyboard"));
        onscreenKeyboard.setMnemonic(newLabels.getString("onscreen.keyboard.mnemonic").charAt(0));

        codedInput.setText(newLabels.getString("coded.input"));
        codedInput.setMnemonic(newLabels.getString("coded.input.mnemonic").charAt(0));

        prediction.setText(newLabels.getString("prediction"));
        prediction.setMnemonic(newLabels.getString("prediction.mnemonic").charAt(0));

        voice.setText(newLabels.getString("voice"));
        voice.setMnemonic(newLabels.getString("voice.mnemonic").charAt(0));

        keyboardMouse.setText(newLabels.getString("keyboard.mouse"));
        keyboardMouse.setMnemonic(newLabels.getString("keyboard.mouse.mnemonic").charAt(0));

        altMouse.setText(newLabels.getString("alt.mouse"));
        altMouse.setMnemonic(newLabels.getString("alt.mouse.mnemonic").charAt(0));

        setNewButtonLabels();

        revalidate();
        repaint();	
    }

    protected void doPrev() {
        pm.doPrevAppType(appType);
    }

    protected void doNext() {
        pm.doNextAppType(appType);
    }

    /**
     * Sets the usage of coded input to be mandatory or not.
     *
     * @param  inMandatory  is coded input mandatory or not
     * @param  isSetByOnscreenKeyboard  is this being set 
     *                                  solely by onscreen keyboard
     */
    protected void setMandatoryCodedInput(boolean inMandatory, 
                                          boolean isSetByOnscreenKeyboard) {
        if (inMandatory) {
            codedInput.setSelected(true);
            codedInput.setEnabled(false);
        }
        else {
            if (isSetByOnscreenKeyboard)
                codedInput.setSelected(false);			
         
            codedInput.setEnabled(true);
        }
    }

    protected void checkNextButton() {

        Enumeration elements = appTypeSelected.keys();
        String appType;
        while (elements.hasMoreElements()) {
            appType = (String) elements.nextElement();
            if ( appType != PreferenceManager.CONTROL_PREFS && 
                 appType != PreferenceManager.DISPLAY_PREFS &&
                 ((Boolean) appTypeSelected.get(appType)) == Boolean.TRUE ) {
                nextButton.setEnabled(true);
                saveButton.setEnabled(false);
                return;
            }
        }
		
        nextButton.setEnabled(false);
        saveButton.setEnabled(true);
    }

    /**
     * Clears all checkboxes.
     */
    protected void doDefault() {

        standardKeyboard.setSelected(false);
        altKeyboard.setSelected(false);
        onscreenKeyboard.setSelected(false);
        keyboardMouse.setSelected(false);
        altMouse.setSelected(false);
        codedInput.setSelected(false);
        voice.setSelected(false);
        prediction.setSelected(false);

    }

    /**
     * Initializes the button panel.
     */
    protected void initButtonPanel() {
        
        ResourceBundle buttonLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Buttons", pm.language);			
        ButtonListener buttonListener = new ButtonListener();
        
        defaultButton = new JButton(buttonLabels.getString("clear"));
        defaultButton.setActionCommand("default");
        defaultButton.setMnemonic(buttonLabels.getString("clear.mnemonic").charAt(0));
        defaultButton.addActionListener(buttonListener);
        defaultButton.setPreferredSize(LOWER_BUTTON_DIM);
        defaultButton.setBorder(BUTTON_BORDER);
        defaultButton.setBackground(BUTTON_BACKGROUND);
        
        nextButton = new JButton(buttonLabels.getString("next"));
        nextButton.setMnemonic(buttonLabels.getString("next.mnemonic").charAt(0));
        nextButton.setActionCommand("next");
        nextButton.addActionListener(buttonListener);
        nextButton.setBorder(BUTTON_BORDER);
        nextButton.setPreferredSize(LOWER_BUTTON_DIM);
        nextButton.setBackground(BUTTON_BACKGROUND);
        
        prevButton = new JButton(buttonLabels.getString("display.prev"));
        prevButton.setMnemonic(buttonLabels.getString("display.prev.mnemonic").charAt(0));
        prevButton.setActionCommand("prev");
        prevButton.addActionListener(buttonListener);
        prevButton.setBorder(BUTTON_BORDER);
        prevButton.setPreferredSize(LOWER_BUTTON_DIM);
        prevButton.setBackground(BUTTON_BACKGROUND);
        
        cancelButton = new JButton(buttonLabels.getString("cancel"));
        cancelButton.setMnemonic(buttonLabels.getString("cancel.mnemonic").charAt(0));
        cancelButton.setActionCommand("cancel");
        cancelButton.addActionListener(buttonListener);
        cancelButton.setBorder(BUTTON_BORDER);
        cancelButton.setPreferredSize(LOWER_BUTTON_DIM);
        cancelButton.setBackground(BUTTON_BACKGROUND);
        
        saveButton = new JButton(buttonLabels.getString("save"));
        saveButton.setActionCommand("next");
        saveButton.setMnemonic(buttonLabels.getString("save.mnemonic").charAt(0));
        saveButton.addActionListener(buttonListener);
        saveButton.setPreferredSize(LOWER_BUTTON_DIM);
        saveButton.setBorder(BUTTON_BORDER);
        saveButton.setBackground(BUTTON_BACKGROUND);
        
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        buttonPanel.add(Box.createHorizontalStrut(LEFT_BUTTON_INDENT));
        buttonPanel.add(defaultButton);
        buttonPanel.add(Box.createHorizontalGlue());
        buttonPanel.add(Box.createHorizontalGlue());
        buttonPanel.add(prevButton);
        buttonPanel.add(Box.createHorizontalStrut(INDENT_VALUE));
        buttonPanel.add(nextButton);
        buttonPanel.add(Box.createHorizontalStrut(INDENT_VALUE));
        buttonPanel.add(saveButton);
        buttonPanel.add(Box.createHorizontalStrut(INDENT_VALUE));
        buttonPanel.add(cancelButton);
        buttonPanel.add(Box.createHorizontalStrut(LEFT_BUTTON_INDENT));
        
    }

    /**
     * Sets the new labels for the buttons for the current locale.
     */
    protected void setNewButtonLabels() {
        ResourceBundle buttonLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Buttons", pm.language);			
        
        prevButton.setText(buttonLabels.getString("display.prev"));
        prevButton.setMnemonic(buttonLabels.getString("display.prev.mnemonic").charAt(0));

        nextButton.setText(buttonLabels.getString("next"));
        nextButton.setMnemonic(buttonLabels.getString("next.mnemonic").charAt(0));
        
        defaultButton.setText(buttonLabels.getString("clear"));
        defaultButton.setMnemonic(buttonLabels.getString("clear.mnemonic").charAt(0));
        
        cancelButton.setText(buttonLabels.getString("cancel"));
        cancelButton.setMnemonic(buttonLabels.getString("cancel.mnemonic").charAt(0));
    
        saveButton.setText(buttonLabels.getString("save"));
        saveButton.setMnemonic(buttonLabels.getString("save.mnemonic").charAt(0));
    
        buttonPanel.repaint();
        
    }
    
}
