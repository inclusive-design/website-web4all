/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            PrefsJChooser.java
 *
 * Synoposis:       package ca.utoronto.atrc.web4all.prefschooser;
 *
]*/

package ca.utoronto.atrc.web4all.prefschooser;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;

import org.w3c.dom.*;
import org.xml.sax.*;

import ca.utoronto.atrc.web4all.*;
import ca.utoronto.atrc.web4all.binding.XMLBindingAdaptor;

/**
 * Class for loading/saving preferences using a standard file menu backed by
 * a class derived from swing's JFileChooser (WFileChooser)
 *
 * @version $Id: PrefsJChooser.java,v 1.9 2006/03/28 21:17:27 clown Exp $
 * @author  Joseph Scheuhammer.
 */
public class PrefsJChooser extends PrefsChooser implements PrefsLoaderAPI
{
    /**
     * The WFileChooser users use to choose files.
     */
    private WFileChooser theFileChooser;
    
    /**
     * Web4All control hub.
     */
    private ControlHub theControlHub;

    /**
     * The XML filter.
     */
    private javax.swing.filechooser.FileFilter xmlFilter;

    /**
     * The default file names to save as.
     */
    private String defaultFileName;
    
    /**
     * Initializes the prefs loader.
     */
    public PrefsJChooser()
    {
        super();
        MenuSpeaker.getSharedInstance();
        theFileChooser = new WFileChooser();
        theFileChooser.setFileSelectionMode (JFileChooser.FILES_ONLY);
        theFileChooser.setMultiSelectionEnabled (false);

        xmlFilter = new javax.swing.filechooser.FileFilter() {
                public boolean accept (File inFile) {
                    if ((inFile.getName().endsWith(".xml")) ||
                        (inFile.isDirectory())) {
                        return true;
                    }
                    else
                        return false;
                }
                public String getDescription() {
                    return ".xml";
                }
            };
        
    }   // end PrefsJChooser().
        
    /**
     * Open an existing preferences file.
     * @return      Whether the user chose a file (<code>true</code>) or cancelled
     *              (<code>false</code>).  
     */
    protected boolean openPrefsFile()
    {
        boolean chosen = false;     // return value.
                
        // Put up a file chooser to allow user to choose a file.
        //
        ChooserSpeaker speaker = ChooserSpeaker.getSharedInstance (
            theFileChooser, theControlHub.getLocale()
        );
        theFileChooser.setFileFilter (xmlFilter);
        int chooseResult = theFileChooser.showOpenDialog (getMainWindow());
        if (chooseResult == JFileChooser.APPROVE_OPTION)
        {
            // User did not cancel the file chooser dialog.  Record <theFile>.
            //
            File aFile = theFileChooser.getSelectedFile();
            
            if ((aFile != null) && (aFile.exists()))
            {
                setPrefsFile (aFile);
                chosen = true;
            }
            else
            {
                setPrefsFile (null);
                chosen = false;
            }
        }
        return chosen;
    
    }   // end openPrefsFile.

    /**
     * Update the speaker to the new Locale.  This overrides the base class
     * method, but still calls it first.
     * @param   inLocale    The new Locale
     */
    protected void updateLocale (Locale inLocale)
    {
        super.updateLocale (inLocale);
        MenuSpeaker.getSharedInstance().setLocale (inLocale);
        ChooserSpeaker.getSharedInstance (theFileChooser, inLocale).updateLocale (inLocale);
    
    }   // end updateLocale().
                        
//==========================
// interface PrefsLoaderAPI.
//==========================

    /**
     * Main entry point of intializing this preferences loader.  Set the locale
     * of the menu speaker, at least, to the default, for the present.
     */
    public void startup()
    {
        super.startup();
        theControlHub = ControlHub.getSharedInstance();
        MenuSpeaker.getSharedInstance().setLocale (Locale.getDefault());
        
    }   // end startup()

    /**
     * Allows a client of the preferences loader to pass it a XML Document to write the preferences
     * to some storage medium.
     * @param		doc 	The data (XML Document) to write (save).
     */
    public void savePrefs (Document doc)
    {
        // Don't do anything if there is nothing to write.
        //
        if (doc != null)
        {
            // Put up a file chooser dialog.
            //
            File prefsFile = getPrefsFile();
            if (prefsFile != null)
                theFileChooser.setCurrentDirectory (prefsFile); // aChooser = new WFileChooser (prefsFile);
            else
                theFileChooser.setCurrentDirectory (null); // aChooser = new WFileChooser();
            theFileChooser.setFileFilter (xmlFilter);
            ChooserSpeaker speaker = ChooserSpeaker.getSharedInstance (
                theFileChooser, theControlHub.getLocale()
            );
            String fileName = defaultFileName;              
            if (prefsFile != null)
            {
                theFileChooser.setSelectedFile (prefsFile);
                fileName = prefsFile.getName();
            }
            int chooseResult = theFileChooser.showSaveDialog (getMainWindow());
            if (chooseResult == JFileChooser.APPROVE_OPTION)
            {
                // User did not cancel the file chooser dialog.  Serialize
                // <doc> into <prefs> (Note: "true" below means "pretty
                // print".  Write <prefs> to <theFile>.
                //
                prefsFile = theFileChooser.getSelectedFile();
                setPrefsFile (prefsFile);
                String prefs = XMLBindingAdaptor.serializeXML (doc, true);
                saveSerializedPrefs (prefsFile, prefs);
            }
            
            // Make sure that certain menu items are enabled/disabled as
            // appropriate.
            //
            updateEnabledMenuItems();
        }
    
    }   // end savePrefs().

    /**
     * Gracefully clean up everything, and exit the JVM.
     */
    public void shutdown()
    {
        // Let Web4All clean up.
        //
        ControlHub.stopWeb4All();	        
    
        // Make everything go away.  Any non-zero exit code forces W4A to
        // completely quit.  Zero will cause a re-start.
        //
        System.exit (-1);
    
    }   // end shutdown

}   // end inner class PrefsChooser.
