/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 */   
package ca.utoronto.atrc.web4all;

import ca.utoronto.atrc.web4all.web4AllCardService.*;
import java.util.*;
import opencard.core.*;
import opencard.core.service.*;
import opencard.core.event.*;
import opencard.core.terminal.*;
import opencard.core.terminal.CardTerminalRegistry;
import opencard.core.util.*;
import opencard.opt.util.*;
import opencard.opt.iso.fs.*;
import javax.swing.*;
import org.w3c.dom.*;

/**
  * A class to perform the processing needed when a card is inserted. This class
  * has the following responsibilities:
  *   1. determine if the card is one that we support.
  *   2. determine if the card has been initialized for the Web4All application.
  *   3. read the preferences from the card.
  *   4. pass the preferences to the Web4All application.
  *   5. write a new set of preferences to the card.
*/   
public class InsertProcessor implements PrefsLoaderAPI, Runnable {
	SmartCard theCard;			// OCF object representing the card.
	Web4AllCardService w4acs;   // OCF object providing Web4All services.
	CardControl theCC;			// Class which starts OCF and this object.
	ControlHub w4a;				// Object which communicates with user and configures system.
	private Properties prefsLoaded;	// "lookup table" for use by PrefsLoaderAPI clients.
	
	public InsertProcessor(CardControl cc) {
		super();
		theCC = cc;
		prefsLoaded = new Properties();
	}
	
/**	
  *  Set the SmartCard to use for subsequent processing.
*/  
	public synchronized void setCard(SmartCard sc) {
		theCard = sc; 
	}
	
/**
  * Allows a client of the preferences loader to retrieve a Properties object containing
  * key/value pairs.
  * @return	the Properties object. 
*/   
	
	public Properties getPrefsLoadedProperties() {
		return prefsLoaded;
	}
	
/**	
  * Thread's run method. 
*/   
	public synchronized void run() {
		String preferences;		// User preferences string.
        // Coordinate with cardControl.
        synchronized (theCC) {
            theCC.notify();	// Tell CardControl we're ready for work.
        }
		
		while (true) {
            // This code block controls whether we continue running or not.
			try {
                if (Thread.currentThread().interrupted()) {  // interrupt is our signal to stop.
                    SmartCardLogFile.writeLog("InsertProcessor detected interrupt.", SmartCardLogFile.LOG_DEBUG);
                    break;
                }
                SmartCardLogFile.writeLog("InsertProcessor is beginning its wait.", SmartCardLogFile.LOG_DEBUG);
				this.wait();	// wait until CardControl tells us a card is available.
                SmartCardLogFile.writeLog("InsertProcessor has exited its wait.", SmartCardLogFile.LOG_DEBUG);
			}
			catch (InterruptedException ie) {
                SmartCardLogFile.writeLog("InsertProcessor caught InterruptedException.", SmartCardLogFile.LOG_DEBUG);
				break; // interrupt is our signal to stop.
			}
            
			theCC.setw4aStatus(false); // Tell CardControl that Web4All isn't running.
			w4a = theCC.getWeb4All();  // Get the ControlHub object.  
            
			// get a Web4AllCardService
			try {
				w4acs = (Web4AllCardService) theCard.getCardService(Web4AllCardService.class, true);
				w4acs.initLowMemoryBind(w4a, theCC.useLowMemory());
				if (w4acs instanceof GandDWeb4AllCardService) {
					SmartCardLogFile.writeLog("GandDWeb4AllCardService is running", SmartCardLogFile.LOG_DEBUG);
				}
				else {
					if (w4acs instanceof SiemensWeb4AllCardService) {
						SmartCardLogFile.writeLog("SiemensWeb4AllCardService is running", SmartCardLogFile.LOG_DEBUG);
					}
					else {  // shouldn't happen.
                        throw new Web4AllCardServiceException("Unknown CardService is running");
					}
				}
                
                try {
                    if (w4acs.validCard()) {	// Is this card ready for our use?
                        // This card is ready for our use.
                        // Initialization not required. Web4ALL needs to know.
                        prefsLoaded.put(preferencesMediaInitializedQueryKey, Boolean.FALSE);
                        preferences = w4acs.readPreferences();  // Read preferences.
                        theCC.setw4aStatus(true);  // Tell CardControl we've started web4all.
                        w4a.kickIt(preferences, this);  // Start Web4All running.
                    }
                    else {
                        // Can't use card as is. 
                        if (w4acs.canInitialize()) { // are we allowed to initialize?
                            // Allowed to - ask user's permission.
                            int ans = w4a.updateStatusMessage(theCC.lookup("CC.initialize"), JOptionPane.QUESTION_MESSAGE);
                            switch (ans) {
                                case JOptionPane.YES_OPTION: 
                                    try {
                                        w4acs.initializeCard();	// try to initialize.
                                        // store successful initialization indicator.
                                        prefsLoaded.put(preferencesMediaInitializedQueryKey, Boolean.TRUE);  
                                        SmartCardLogFile.writeLog("Initialized smart card at user's request.");
                                        preferences = w4acs.readPreferences();  // Read preferences.
                                        theCC.setw4aStatus(true);  // Tell CardControl we've started web4all.
                                        w4a.kickIt(preferences, this);  // Start Web4All running.
                                    }
                                    catch (W4ACardServiceException cse) {	// failure - tell the user.
                                        SmartCardLogFile.writeLog("Couldn't initialize a smart card.");
                                        SmartCardLogFile.logException(cse);
                                        w4a.updateStatusMessage(theCC.lookup("CC.initFailed"), JOptionPane.ERROR_MESSAGE);
                                    }
                                    break;
                                case JOptionPane.NO_OPTION: 
                                    if (theCC.isCardPresent()) {
                                        w4a.updateStatusMessage(theCC.lookup("CC.pleaseRemove"), JOptionPane.ERROR_MESSAGE);
                                    }
                                    SmartCardLogFile.writeLog("User declined smart card initialization.");
                                    break;
                                case JOptionPane.CLOSED_OPTION: 
                                    SmartCardLogFile.writeLog("Smart card initialization dialog programatically closed.");
                                    break;
                                default:
                            }    
                            /*if (ans == JOptionPane.YES_OPTION) {
                                try {
                                    w4acs.initializeCard();	// try to initialize.
                                    // store successful initialization indicator.
                                    prefsLoaded.put(preferencesMediaInitializedQueryKey, Boolean.TRUE);  
                                    SmartCardLogFile.writeLog("Initialized smart card at user's request.");
                                    preferences = w4acs.readPreferences();  // Read preferences.
                                    theCC.setw4aStatus(true);  // Tell CardControl we've started web4all.
                                    w4a.kickIt(preferences, this);  // Start Web4All running.
                                }
                                catch (W4ACardServiceException cse) {	// failure - tell the user.
                                    SmartCardLogFile.writeLog("Couldn't initialize a smart card.");
                                    SmartCardLogFile.logException(cse);
                                    w4a.updateStatusMessage(theCC.lookup("CC.initFailed"), JOptionPane.ERROR_MESSAGE);
                                }
                            }
                            else {
                                if (theCC.isCardPresent()) {
                                    w4a.updateStatusMessage(theCC.lookup("CC.pleaseRemove"), JOptionPane.ERROR_MESSAGE);
                                }
                                SmartCardLogFile.writeLog("User declined smart card initialization.");
                            }*/
                        }
                        else {	// not permitted to try to initialize this card.
                            w4a.updateStatusMessage(theCC.lookup("CC.initNotPermitted"), JOptionPane.ERROR_MESSAGE);
                            SmartCardLogFile.writeLog("Initialization required on un-initializable card.");
                        }
                    }
                }
                catch (Exception e) {
                    SmartCardLogFile.logException(e);
                    if (theCC.errorShutdown()) {  // should we shutdown on errors?
                        if (theCC.isCardPresent()) {
                            // card is still in terminal
                            SmartCardLogFile.writeLog("InsertProcessor has requested shutdown on remove.");
                            theCC.requestShutdownOnRemove(); // this should be done BEFORE user removes card.
                            // send message to user.
                            w4a.updateStatusMessage(theCC.lookup("CC.severeError"), JOptionPane.ERROR_MESSAGE);
                            break;
                        }
                        else {
                            // card has been removed.
                            SmartCardLogFile.writeLog("InsertProcessor is initiating shutdown.");
                            theCC.shutDown();
                            break;
                        }
                    }
                    else {
                        if (theCC.isCardPresent()) {
                            // send message to user.
                            w4a.updateStatusMessage(theCC.lookup("CC.severeError"), JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
			}
			catch (ClassNotFoundException cnf) {
				SmartCardLogFile.writeLog("Unsupported card was inserted.");
				w4a.updateStatusMessage(theCC.lookup("CC.unsupportedCard"), JOptionPane.ERROR_MESSAGE);
			}
			catch (Exception e) {
				SmartCardLogFile.writeLog("An Exception occurred in getCardService.");
				SmartCardLogFile.logException(e);
                if (theCC.errorShutdown()) { // should we shut down ?
                    if (theCC.isCardPresent()) {
                        SmartCardLogFile.writeLog("InsertProcessor has requested shutdown on remove.");
                        theCC.requestShutdownOnRemove(); // this should be done BEFORE user removes card.
                        // send message to user.
                        w4a.updateStatusMessage(theCC.lookup("CC.severeError"), JOptionPane.ERROR_MESSAGE);
                        break;
                    }
                    else {
                        SmartCardLogFile.writeLog("InsertProcessor is initiating shutdown.");
                        theCC.shutDown();
                        break;
                    }
                }
                else {
                    // send message to user if a card is still in the reader.
                    if (theCC.isCardPresent()) {
                        w4a.updateStatusMessage(theCC.lookup("CC.severeError"), JOptionPane.ERROR_MESSAGE);
                    }
                }
			}
			// Unless we're handling multiple sessions, we're done.
			if (! theCC.multipleSessions()) {
				break;
			}
		}
		SmartCardLogFile.writeLog("InsertProcessor is finished");
	}
    
/**    
  * A method to shutdown web4All when the system administrator requests it. The
  * actual work is done by CardControl.
*/   
    public void shutdown() {
        theCC.processShutdownRequest();
    }
    
    /**
     * No-op to satisfy PrefsLoaderAPI.
     */
    public void startup() {
        ;
    }
				
	
	public synchronized void savePrefs(Document doc) {
		try {
			w4a = theCC.getWeb4All();  // Get the Web4All object.  
			w4acs.writePreferences(doc);
		}
		catch (Exception e) {
			SmartCardLogFile.logException(e);
			w4a.updateStatusMessage(theCC.lookup("CC.cantSave"), JOptionPane.ERROR_MESSAGE);
            if (theCC.errorShutdown()) { // should we shut down ?
                if (theCC.isCardPresent()) {
                    SmartCardLogFile.writeLog("InsertProcessor (savePrefs) has requested shutdown on remove.");
                    theCC.requestShutdownOnRemove(); // this should be done BEFORE user removes card.
                    // send message to user.
                    w4a.updateStatusMessage(theCC.lookup("CC.severeError"), JOptionPane.ERROR_MESSAGE);
                }
                else {
                    SmartCardLogFile.writeLog("InsertProcessor (savePrefs) is initiating shutdown.");
                    theCC.shutDown();
                }
            }
            else {
                // send message to user if a card is still in the reader.
                if (theCC.isCardPresent()) {
                    w4a.updateStatusMessage(theCC.lookup("CC.severeError"), JOptionPane.ERROR_MESSAGE);
                }
            }
		}
	}
		
}
	
	

