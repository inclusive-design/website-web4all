/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.net.URL;
import java.net.MalformedURLException;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

/**
 * Voice recognition preference editor panel.
 *
 * @author David Weinkauf
 * @version $Revision: 1.6 $, $Date: 2006/03/28 16:31:10 $
 */
public class VoiceRec extends PWMEditPanel {

    private Document document;

    private Element generic;

    private JSlider micGainSlider;

    private JCheckBox controlsWindow, feedback, mouse;

    private JComboBox vocabularyComboBox;

    private ComboBoxItem[] vocabularyItems;

    private ComboBoxItem context, natural;

    private JCheckBox voiceProfileBox;

    private JTextField voiceProfileField;

    private JLabel micGainLabel, vocabularyLabel;

    private JLabel lowLabel, mediumLabel, highLabel;

    private TitledBorder generalTitle, commandControlTitle;

    /**
     * The constructor initializes all the components in the dialog and displays them accordingly.
     */
    public VoiceRec(PreferenceManager pm, Element root, String inAppType) {
        super(pm, inAppType, inAppType + TITLE_SUFFIX);

        document = initDocument(root, xmlLabels.getString(VOICE_REC), xmlLabels.getString(VR_GENERIC));
        generic = DOMUtil.getFirstChildElement(document.getDocumentElement());

        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.VoiceRec", pm.language);
        ResourceBundle hashLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.HashTables", pm.language);
	
        Hashtable micGainHash = new Hashtable();
        lowLabel = new JLabel(hashLabels.getString("low"));
        lowLabel.setForeground(Color.black);
        mediumLabel = new JLabel(hashLabels.getString("medium"));
        mediumLabel.setForeground(Color.black);
        highLabel = new JLabel(hashLabels.getString("high"));
        highLabel.setForeground(Color.black);
        micGainHash.put(new Integer(0), lowLabel);
        micGainHash.put(new Integer(5), mediumLabel);
        micGainHash.put(new Integer(10), highLabel);

        micGainSlider = new JSlider(SwingConstants.HORIZONTAL, 0, 10, 5);
        micGainSlider.setPaintLabels(true);
        micGainSlider.setBackground(Color.white);
        micGainSlider.setLabelTable(micGainHash);
        micGainSlider.setMajorTickSpacing(1);
        micGainSlider.setSnapToTicks(true);
        micGainSlider.setPaintTicks(true);
        micGainSlider.setForeground(Color.black);

        micGainLabel = new JLabel(labels.getString("mic.gain"));
        micGainLabel.setDisplayedMnemonic(labels.getString("mic.gain.mnemonic").charAt(0));
        micGainLabel.setLabelFor(micGainSlider);
        micGainLabel.setFont(TEXT_FONT);
        micGainLabel.setForeground(Color.black);

        JPanel micGainPanel = new JPanel();
        micGainPanel.setLayout(new BoxLayout(micGainPanel, BoxLayout.X_AXIS));
        micGainPanel.setBackground(Color.white);
        micGainPanel.add(Box.createHorizontalStrut(INDENT_VALUE));
        micGainPanel.add(micGainLabel);
        micGainPanel.add(Box.createHorizontalStrut(SPACING_VALUE));
        micGainPanel.add(micGainSlider);
        micGainPanel.add(Box.createHorizontalStrut(SPACING_VALUE));

        controlsWindow = new JCheckBox(labels.getString("controls.window"));
        controlsWindow.setMnemonic(labels.getString("controls.window.mnemonic").charAt(0));
        controlsWindow.setBackground(Color.white);
        controlsWindow.setFont(TEXT_FONT);
        controlsWindow.setSelected(true);

        JPanel controlsWindowPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        controlsWindowPanel.setBackground(PANEL_BACKGROUND);
        controlsWindowPanel.add(controlsWindow);

        voiceProfileBox = new JCheckBox(labels.getString("voice.profile"));
        voiceProfileBox.setMnemonic(labels.getString("voice.profile.mnemonic").charAt(0));
        voiceProfileBox.setBackground(PANEL_BACKGROUND);
        voiceProfileBox.setForeground(TEXT_COLOUR);
        voiceProfileBox.addChangeListener(new VoiceProfileListener());

        voiceProfileField = new JTextField("http://", 35);
	voiceProfileField.getAccessibleContext().setAccessibleName(labels.getString("voice.profile"));
        voiceProfileField.setFont(TEXT_FONT);
        voiceProfileField.setEnabled(false);

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel voiceProfilePanel = new JPanel();
        voiceProfilePanel.setBackground(PANEL_BACKGROUND);
        voiceProfilePanel.setLayout(gridbag);

        Insets insets = new Insets(0, INDENT_VALUE, 0, 0);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        voiceProfilePanel.add(voiceProfileBox, c);

        insets = new Insets(0, 0, 0, INDENT_VALUE);
        c.insets = insets;
        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0.5;
        voiceProfilePanel.add(voiceProfileField, c);

        JPanel voiceGridPanel = new JPanel(new GridLayout(1, 1));
        voiceGridPanel.setBackground(PANEL_BACKGROUND);
        voiceGridPanel.add(voiceProfilePanel);

        generalTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("general.title"));
        generalTitle.setTitleColor(BORDER_TITLE_COLOUR);
        generalTitle.setTitleFont(BORDER_TITLE_FONT);

        JPanel generalPanel = new JPanel();
        generalPanel.setLayout(new BoxLayout(generalPanel, BoxLayout.Y_AXIS));
        generalPanel.setBorder(generalTitle);
        generalPanel.setBackground(PANEL_BACKGROUND);
        generalPanel.add(controlsWindowPanel);
        generalPanel.add(micGainPanel);
        generalPanel.add(voiceGridPanel);

        AccessibleContext ac = controlsWindow.getAccessibleContext();
        ac.setAccessibleParent(generalPanel);
        ac = micGainLabel.getAccessibleContext();
        ac.setAccessibleParent(generalPanel);
        ac = micGainSlider.getAccessibleContext();
        ac.setAccessibleParent(generalPanel);
        ac = voiceProfileBox.getAccessibleContext();
        ac.setAccessibleParent(generalPanel);
        ac = voiceProfileField.getAccessibleContext();
        ac.setAccessibleParent(generalPanel);
		
        this.add(generalPanel);
        this.add(Box.createVerticalGlue());

        context = new ComboBoxItem(labels.getString("context"), "context");
        natural = new ComboBoxItem(labels.getString("natural"), "natural");

        ComboBoxItem[] tempVocabularyItems = { context, natural };
        vocabularyItems = tempVocabularyItems;

        vocabularyComboBox = new JComboBox(vocabularyItems);
        vocabularyComboBox.setForeground(Color.black);
        vocabularyComboBox.setFont(TEXT_FONT);
        vocabularyComboBox.setBackground(Color.white);		
        vocabularyComboBox.setSelectedIndex(0);

        vocabularyLabel = new JLabel(labels.getString("vocabulary"));
        vocabularyLabel.setDisplayedMnemonic(labels.getString("vocabulary.mnemonic").charAt(0));
        vocabularyLabel.setLabelFor(vocabularyComboBox);
        vocabularyLabel.setFont(TEXT_FONT);
        vocabularyLabel.setForeground(Color.black);

        JPanel vocabularyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        vocabularyPanel.setBackground(Color.white);		
        vocabularyPanel.add(vocabularyLabel);
        vocabularyPanel.add(vocabularyComboBox);

        feedback = new JCheckBox(labels.getString("feedback"));
        feedback.setMnemonic(labels.getString("feedback.mnemonic").charAt(0));
        feedback.setBackground(Color.white);
        feedback.setFont(TEXT_FONT);
        feedback.setSelected(true);

        JPanel feedbackPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        feedbackPanel.setBackground(PANEL_BACKGROUND);
        feedbackPanel.add(feedback);

        mouse = new JCheckBox(labels.getString("mouse"));
        mouse.setMnemonic(labels.getString("mouse.mnemonic").charAt(0));
        mouse.setBackground(Color.white);
        mouse.setFont(TEXT_FONT);
        mouse.setSelected(true);

        JPanel mousePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        mousePanel.setBackground(PANEL_BACKGROUND);
        mousePanel.add(mouse);

        commandControlTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("command.control.title"));
        commandControlTitle.setTitleColor(BORDER_TITLE_COLOUR);
        commandControlTitle.setTitleFont(BORDER_TITLE_FONT);

        JPanel commandControlPanel = new JPanel();
        commandControlPanel.setLayout(new BoxLayout(commandControlPanel, BoxLayout.Y_AXIS));
        commandControlPanel.setBorder(commandControlTitle);
        commandControlPanel.setBackground(PANEL_BACKGROUND);
        commandControlPanel.add(vocabularyPanel);
        commandControlPanel.add(feedbackPanel);
        commandControlPanel.add(mousePanel);		

        ac = vocabularyLabel.getAccessibleContext();
        ac.setAccessibleParent(commandControlPanel);
        ac = vocabularyComboBox.getAccessibleContext();
        ac.setAccessibleParent(commandControlPanel);
        ac = feedback.getAccessibleContext();
        ac.setAccessibleParent(commandControlPanel);
        ac = mouse.getAccessibleContext();
        ac.setAccessibleParent(commandControlPanel);

        this.add(commandControlPanel);
        this.add(Box.createVerticalGlue());

    }

    protected void doDefault() {
        micGainSlider.setValue(5);
        controlsWindow.setSelected(true);
        feedback.setSelected(true);
        mouse.setSelected(true);
        vocabularyComboBox.setSelectedItem(context);				
        voiceProfileField.setText("http://");
        voiceProfileBox.setSelected(false);
    }


    protected Element getRootElement() {
        Element temp;

        PreferenceManager.removeAllChildren(generic);

        temp = document.createElement(xmlLabels.getString(VR_GENERIC_MIC_GAIN));
        temp.setAttribute(VALUE, String.valueOf(micGainSlider.getValue() / 10.0));
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(VR_GENERIC_CONTROLS_WINDOW));
        if (controlsWindow.isSelected())
            temp.setAttribute(VALUE, "true");
        else
            temp.setAttribute(VALUE, "false");
        generic.appendChild(temp);
	
        temp = document.createElement(xmlLabels.getString(VR_GENERIC_DICTATION));
        generic.appendChild(temp);

        if (voiceProfileBox.isSelected()) {
            Element voiceProfile = document.createElement(xmlLabels.getString(VR_GENERIC_VOICE_PROFILE_EXT));
            voiceProfile.setAttribute(VALUE, voiceProfileField.getText().trim());
            temp.appendChild(voiceProfile);
        }
			
        Element commandControl = document.createElement(xmlLabels.getString(VR_GENERIC_COMMAND_CONTROL));
        generic.appendChild(commandControl);
		
        temp = document.createElement(xmlLabels.getString(VR_GENERIC_VOCABULARY));
        ComboBoxItem vocabularyItem = (ComboBoxItem) vocabularyComboBox.getSelectedItem();
        temp.setAttribute(VALUE, vocabularyItem.value);
        commandControl.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(VR_GENERIC_FEEDBACK));
        if (feedback.isSelected())
            temp.setAttribute(VALUE, "true");
        else
            temp.setAttribute(VALUE, "false");
        commandControl.appendChild(temp);
	
        temp = document.createElement(xmlLabels.getString(VR_GENERIC_MOUSE));
        if (mouse.isSelected())
            temp.setAttribute(VALUE, "true");
        else
            temp.setAttribute(VALUE, "false");
        commandControl.appendChild(temp);	
	
        return document.getDocumentElement();
    }

    protected void setDomValues() {
        Element temp = DOMUtil.getFirstChildElement(generic);

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(VR_GENERIC_MIC_GAIN))) {
            micGainSlider.setValue( (int) (Float.parseFloat(temp.getAttribute(VALUE)) * 10) );
            temp = DOMUtil.getNextSiblingElement(temp);
        }
		
        if (temp != null && temp.getTagName().equals(xmlLabels.getString(VR_GENERIC_CONTROLS_WINDOW))) {
            if (temp.getAttribute(VALUE).equals("true"))
                controlsWindow.setSelected(true);
            else
                controlsWindow.setSelected(false);
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(VR_GENERIC_DICTATION))) {
            Element dictChild = DOMUtil.getFirstChildElement(temp);
            if (dictChild != null && dictChild.getTagName().equals(xmlLabels.getString(VR_GENERIC_VOICE_PROFILE_EXT))) {
                voiceProfileBox.setSelected(true);
                voiceProfileField.setText(dictChild.getAttribute(VALUE));
            }
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(VR_GENERIC_COMMAND_CONTROL))) {

            Element ccChild = DOMUtil.getFirstChildElement(temp);

            if (ccChild != null && ccChild.getTagName().equals(xmlLabels.getString(VR_GENERIC_VOCABULARY))) {
                vocabularyComboBox.setSelectedItem( findItem(vocabularyItems, ccChild.getAttribute(VALUE)));
                ccChild = DOMUtil.getNextSiblingElement(ccChild);
            }

            if (ccChild != null && ccChild.getTagName().equals(xmlLabels.getString(VR_GENERIC_FEEDBACK))) {
                if (ccChild.getAttribute(VALUE).equals("true"))
                    feedback.setSelected(true);
                else
                    feedback.setSelected(false);
                ccChild = DOMUtil.getNextSiblingElement(ccChild);
            }

            if (ccChild != null && ccChild.getTagName().equals(xmlLabels.getString(VR_GENERIC_MOUSE))) {
                if (ccChild.getAttribute(VALUE).equals("true"))
                    mouse.setSelected(true);
                else
                    mouse.setSelected(false);
                ccChild = DOMUtil.getNextSiblingElement(ccChild);
            }

        }


    }

    class VoiceProfileListener implements ChangeListener {
        public void stateChanged(ChangeEvent e) {
            JCheckBox box = (JCheckBox) e.getSource();
            if (box.isSelected()) {				
                voiceProfileField.setEnabled(true);
            }
            else {
                voiceProfileField.setEnabled(false);
            }
        }
    }

    protected void setNewLabels() {
        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.VoiceRec", pm.language);
        ResourceBundle newHashLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.HashTables", pm.language);
		
        generalTitle.setTitle(newLabels.getString("general.title"));
        commandControlTitle.setTitle(newLabels.getString("command.control.title"));

        context.name = newLabels.getString("context");
        natural.name = newLabels.getString("natural");
		
        micGainLabel.setText(newLabels.getString("mic.gain"));
        micGainLabel.setDisplayedMnemonic(newLabels.getString("mic.gain.mnemonic").charAt(0));

        lowLabel.setText(newHashLabels.getString("low"));
        mediumLabel.setText(newHashLabels.getString("medium"));
        highLabel.setText(newHashLabels.getString("high"));

        vocabularyLabel.setText(newLabels.getString("vocabulary"));
        vocabularyLabel.setDisplayedMnemonic(newLabels.getString("vocabulary.mnemonic").charAt(0));

        controlsWindow.setText(newLabels.getString("controls.window"));
        controlsWindow.setMnemonic(newLabels.getString("controls.window.mnemonic").charAt(0));

        feedback.setText(newLabels.getString("feedback"));
        feedback.setMnemonic(newLabels.getString("feedback.mnemonic").charAt(0));

        voiceProfileBox.setText(newLabels.getString("voice.profile"));
        voiceProfileBox.setMnemonic(newLabels.getString("voice.profile.mnemonic").charAt(0));
	voiceProfileField.getAccessibleContext().setAccessibleName(newLabels.getString("voice.profile"));

        mouse.setText(newLabels.getString("mouse"));
        mouse.setMnemonic(newLabels.getString("mouse.mnemonic").charAt(0));

        setNewButtonLabels();

        revalidate();
        repaint();
    }
    
    protected void doNext() {
        
        if (voiceProfileBox.isSelected()) {
            try {
                URL lexicon = new URL(voiceProfileField.getText());
            }
            catch (MalformedURLException murle) {
                ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.VoiceRec", pm.language);
                JOptionPane.showMessageDialog(this, labels.getString("malformed.url"),
                                              labels.getString("malformed.url.title"),
                                              JOptionPane.WARNING_MESSAGE);
                return;            
            }
        }

        super.doNext();
    }

    protected Document getAppTypeDoc() {
        return document;
    }

}
