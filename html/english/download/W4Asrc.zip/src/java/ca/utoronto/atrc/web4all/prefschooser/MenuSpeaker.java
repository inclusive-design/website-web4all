/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            MenuSpeaker.java
 *
 * Synopsis:        package ca.utoronto.atrc.web4all.prefschooser;
 * 
]*/

package ca.utoronto.atrc.web4all.prefschooser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import java.util.Vector;

/**
 * Responds to GUI events within the menu system.
 *
 * @version $Id: MenuSpeaker.java,v 1.4 2006/03/28 21:17:27 clown Exp $
 * @author  Joseph Scheuhammer.
 *
 */
public class MenuSpeaker extends Speaker 
    implements ChangeListener, ActionListener
{
    /**
     * For creating modified keystrokes.
     */
    public final static int CNTL_SHIFT_MASK =
        InputEvent.CTRL_MASK | InputEvent.SHIFT_MASK;
    
    /**
     * Singleton instance of this class to be shared by all.
     */
    private static MenuSpeaker sharedInstance;
    
    /**
     * Speeches vector for accumulating strings to be spoken.
     */
    private Vector theSpeeches;
    
    /**
     * Acquire or create and acquire the single shared instance of this class.
     * @return  The global shared instance of the ChooserSpeaker.
     */
    public static MenuSpeaker getSharedInstance()
    {
        if (sharedInstance == null)
            sharedInstance = new MenuSpeaker();

        return sharedInstance;
    
    }   // end getSharedInstance()
    
    /**
     * Convert any "hot key" (accelerator) to a speech..
     * @param   inMenuItem  JMenuItem that may have a hotKey activator.
     * @return              A String to speak.  This is the empty string if
     *                      <code>inMenuItem</code> has no accelerator key.
     */
    public static String hotKey2Speech (JMenuItem inMenuItem)
    {
        String result = "";     // default.
        if (inMenuItem != null)
        {
            KeyStroke hotKey = inMenuItem.getAccelerator();
            if (hotKey != null)
            {
                StringBuffer hotKeySpeech = new StringBuffer (", ");
                
                // Handle the modifier key.
                //
                String mods =
                    KeyEvent.getKeyModifiersText (hotKey.getModifiers());
                if ((mods != null) && (mods.length() > 0))
                {
                    hotKeySpeech.append (mods);
                    hotKeySpeech.append ("+");
                }                
                hotKeySpeech.append (KeyEvent.getKeyText (hotKey.getKeyCode()));
                result = hotKeySpeech.toString();
            }
        }
        return result;
        
    }   // end hotKey2String().

    /**
     * Initialize the menu speaker.
     */
    public MenuSpeaker()
    {
        super();
        theSpeeches = new Vector();
        MenuSelectionManager.defaultManager().addChangeListener (this);
   
    }   // end MenuSpeaker()

    /**
     * Add/remove a key press event listener to speak menu item tooltips.  It
     * is added if the given menu is selected; removed otherwise.
     * @param   ioMenu   The JMenu to add the listener to.
     */
    public void addRemoveSpeakTooltipsHandler (JMenu ioMenu)
    {
        if (ioMenu.isSelected())
        {
            ioMenu.registerKeyboardAction (
                this,
                KeyStroke.getKeyStroke (KeyEvent.VK_T, CNTL_SHIFT_MASK, false),
                JComponent.WHEN_IN_FOCUSED_WINDOW
            );
        }
        else
        {
            ioMenu.unregisterKeyboardAction (
                KeyStroke.getKeyStroke (KeyEvent.VK_T, CNTL_SHIFT_MASK, false)
            );
        }
    
    }   // end addSpeakTooltipsHander().

//==========================
// interface ChangeListener.
//==========================

    /**
     * Speak the currently selected menu/menuitem as the users arrows among
     * the menus and their items.
     * @param   inEvent   The ChangeEvent that called us.
     */
    public void stateChanged (ChangeEvent inEvent)
    {
        theSpeeches.clear();
        MenuSelectionManager manager = MenuSelectionManager.defaultManager();
        MenuElement[] selection = manager.getSelectedPath();
        
        // Search the <selection> for the last JMenuItem, skipping menubar,
        // separators, etc., and record the index of that last one.  The search
        // capitalizes on the fact that JMenu is derived from JMenuItem;
        // that is, JMenu objects are JMenuItem objects.
        //
        int i = 0;
        JMenuItem item; 
        for (i = 0; i < selection.length; i++)
        {
            MenuElement el = selection[i];
            if (el instanceof JMenuItem)
            {
                item = (JMenuItem) el;
                
                // If the menu/menu-item is the last one, get its accelerator.
                //
                if (i == (selection.length - 1))
                {
                    theSpeeches.add (item.getText());
                    theSpeeches.add (MenuSpeaker.hotKey2Speech (item));                    
                }
                else
                {
                    theSpeeches.add (item.getText());
                    theSpeeches.add (", ");
                }
                
                // If <item> isa JMenu, add the tooltip speaker to it.
                //
                if (item instanceof JMenu)
                    addRemoveSpeakTooltipsHandler ((JMenu) item);
            }
        }
        speak (theSpeeches);
 
    }   // end stateChanged().
    
//==========================
// interface ActionListener.
//==========================

    /**
     * Speak the menu item's tool tip, if any.
     * @param   inActionEvent   The ActionEvent that invoked this.
     */
    public void actionPerformed (ActionEvent inActionEvent) 
    {
        // Get the currently displayed menu item -- last in the menu selection.
        //
        MenuSelectionManager manager = MenuSelectionManager.defaultManager();
        MenuElement[] selection = manager.getSelectedPath();
        MenuElement item = selection[selection.length - 1];
        
        String tooltip = null;
        if (item instanceof JMenuItem)
 			tooltip = ((JMenuItem) item).getToolTipText();

        if (tooltip != null)
            speak (tooltip);
        else
            Toolkit.getDefaultToolkit().beep();
            
    }   // end actionPerformed().

}   // end class MenuSpeaker.
