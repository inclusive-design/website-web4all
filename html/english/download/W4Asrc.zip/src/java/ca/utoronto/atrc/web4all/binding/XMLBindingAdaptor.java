/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 */
package ca.utoronto.atrc.web4all.binding;

import java.util.*;
import java.io.*;

import org.w3c.dom.*;
import org.xml.sax.*;
import org.apache.xerces.parsers.*;
import org.apache.xerces.dom.*;
import org.apache.xml.serialize.*;
import org.apache.xerces.util.DOMUtil;

import javax.xml.parsers.*;

/**
 * XMLBindingAdaptor is responsible for creating binded XML Documents. The conversion is based on a 
 * Hashtable of key/value pairs. The adaptor converts elements and attribute names only; values are not changed.
 *
 * @author  David Weinkauf
 * @version $Revision: 1.11 $, $Date: 2006/03/28 21:17:27 $
 */
public class XMLBindingAdaptor {

    /**
     * The shared instance of this class.
     */
    private static XMLBindingAdaptor sharedInstance;

    /**
     * Document to return upon failure, so the use gets a warning message.
     */
    private static Document failDocument;

    /**
     * Gets the shared instance of this class and initializes the 'fail' document.
     */
    public static synchronized XMLBindingAdaptor getSharedInstance() {
        if (sharedInstance == null) {
            sharedInstance = new XMLBindingAdaptor();
		
            try {
				
                DOMImplementation impl = new DOMImplementationImpl();
				
                failDocument = impl.createDocument(null, "fail", null);
                Element root = failDocument.getDocumentElement();
                root.setAttribute("xsi:schemaLocation", "fail");
							
            }
            catch (FactoryConfigurationError e) { 
                System.out.println("Could not locate a DOMImplementation class."); 
            }
			
        }

        return sharedInstance;

    } // end getSharedInstance

    /**
     * Creates a XML string from the XML binding defined and the input String.
     * Catches any exceptions thrown and returns a failed document. This is done 
     * only on this method (and not on the <code>createBindingFromHash</code>
     * which returns a <code>document</code>) b/c this is the method reading from
     * the preferences (not writing to) and so must return a document and not 
     * hang on an error.
     *
     * @param  xmlString  the XML string
     * @param  bindingTable  the table of converted binding values
     * @param  indent  'pretty print' the XML or not
     * @return  a newly binding XML string
     */
    public String createBindingFromHash(String xmlString, Hashtable bindingTable, boolean indent) {

        Document doc = parseXML(xmlString);
        Document bindDoc = null;

        if (doc != null) {
            try {
                bindDoc = createBindingFromHash(doc, bindingTable);
            }
            catch (Exception e) {
                e.printStackTrace();
                bindDoc = failDocument;
            }
        }
        else {
            bindDoc = failDocument;
        }

        return serializeXML(bindDoc, indent);

    }

    /**
     * Creates a Document from the XML binding defined in the hashtable and the root element.
     *
     * @param  doc  the Document we are binding _from_
     * @param  bindingTable  the table of converted binding values
     * @return       a newly binded XML document
     */
    public Document createBindingFromHash(Document doc, Hashtable bindingTable) {

        Element root = doc.getDocumentElement();
		
        DOMImplementationImpl domImpl = new DOMImplementationImpl();

        if (bindingTable.get(root.getTagName()) == null) {
            System.out.println("Unrecognized root element " + root.getTagName() 
                               + " in creating low memory bind. Returning failing document.");
            return failDocument;
        }
			
        Document bindingDoc = domImpl.createDocument(null, (String) bindingTable.get(root.getTagName()), null);
		
        Element bindingRoot = bindingDoc.getDocumentElement();
		
        NamedNodeMap rootAttrs = root.getAttributes();
        Attr attr, bindAttr;
        String bindAttrName;
	
        for (int i = 0; i < rootAttrs.getLength(); i++) {
            attr = (Attr) rootAttrs.item(i);
            bindAttrName = (String) bindingTable.get(attr.getName());

            if (bindAttrName != null)
                bindAttr = bindingDoc.createAttribute(bindAttrName);
            else {
                // System.out.println("Null attr value (should be namespace prefixed): " + attr.getName() + "->" + bindAttrName);
                bindAttr = bindingDoc.createAttribute(attr.getName());
            }

            bindAttr.setValue( attr.getValue() );
            bindingRoot.setAttributeNode(bindAttr);
        }

        NodeList childNodes = root.getChildNodes();
	Text text, bindText;
        Node node;
        int type;
        for (int i = 0; i < childNodes.getLength(); i++) {
            node = childNodes.item(i);
            type = node.getNodeType();

            if (type == Node.TEXT_NODE) {
                text = (Text) node;
                bindText = bindingDoc.createTextNode(text.getNodeValue().trim());
                bindingRoot.appendChild(bindText);
            }
            else if (type == Node.ELEMENT_NODE) {
                doRecBindGen( (Element) node, bindingRoot, bindingDoc, bindingTable);
            }                

        }

        return bindingDoc;

    } // end createBindingFromHash


    /**
     * Does a recursive traversal of a DOM creating the new XML binding.
     *
     * @param  currentMirror  the current element we are at in the mirror Document we are binding _from_
     * @param  parentBinding  the parent element for the binded element we create based on currentMirror
     * @param  bindingDoc     the binding XML document we are recursively creating.
     * @param  bindingTable   the table of converted binding values
     */
    private void doRecBindGen (Element currentMirror, Element parentBinding, 
                               Document bindingDoc, Hashtable bindingTable) {

        if (currentMirror == null)
            return;
        
        System.out.println("Current element: " + currentMirror.getTagName());
        System.out.println("Binding table result: " + (String) bindingTable.get(currentMirror.getTagName()));
        Element bindEl = bindingDoc.createElement( (String) bindingTable.get(currentMirror.getTagName()) );

        parentBinding.appendChild(bindEl);

        NamedNodeMap attrs = currentMirror.getAttributes();
        Attr attr, bindAttr;
        String bindAttrName;
        for (int i = 0; i < attrs.getLength(); i++) {
            
            attr = (Attr) attrs.item(i);
            bindAttrName = (String) bindingTable.get(attr.getName());

            if (bindAttrName != null)
                bindAttr = bindingDoc.createAttribute(bindAttrName);
            else {
                // System.out.println("Null attr value (should be namespace prefixed): " + attr.getName() + "->" + bindAttrName);
                bindAttr = bindingDoc.createAttribute(attr.getName());
            }
            
            bindAttr.setValue( attr.getValue() );
            bindEl.setAttributeNode(bindAttr);
        }


        NodeList childNodes = currentMirror.getChildNodes();
	Text text, bindText;
        Node node;
        int type;
        for (int i = 0; i < childNodes.getLength(); i++) {
            node = childNodes.item(i);
            type = node.getNodeType();

            if (type == Node.TEXT_NODE) {
                text = (Text) node;
                bindText = bindingDoc.createTextNode(text.getNodeValue().trim());
                bindEl.appendChild(bindText);
            }
            else if (type == Node.ELEMENT_NODE) {
                doRecBindGen( (Element) node, bindEl, bindingDoc, bindingTable);
            }                

        }

    }  // end doRecBindGen

    /**
     * Parses an XML string with no validation and returns its DOM representation.
     *
     * @param  inXMLString  the XML string to parse
     * @return  the parsed string's DOM
     */
    public static Document parseXML(String inXMLString) {

        StringReader inputString = new StringReader (inXMLString);
        InputSource iSource = new InputSource (inputString);

        DOMParser domParser = null;
        try {
            domParser = new DOMParser();
			
            domParser.setFeature("http://apache.org/xml/features/dom/defer-node-expansion", false);
            domParser.setFeature("http://xml.org/sax/features/namespaces", false);
			
            domParser.parse(iSource);
        }
        catch (SAXParseException err) {
            System.out.println("** Parsing error" + ", line " + err.getLineNumber() + ", uri " + err.getSystemId());
            System.out.println("   " + err.getMessage());
            return null;
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        return domParser.getDocument();

    }

    /**
     * Serializes a XML document into a string.
     *
     * @param  doc  the XML document
     * @param  indent  'pretty print' the output or not
     * @return  the serialized XML document
     */
    public static String serializeXML(Document doc, boolean indent) {
        if (doc == null)
            return null;

        OutputFormat out = new OutputFormat(doc, null, indent);
        StringWriter xmlString = new StringWriter();
        XMLSerializer serializer = new XMLSerializer(xmlString, out);

        try {
            serializer.serialize(doc);
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
            return null;
        }
		
        return xmlString.toString();
    }

}
