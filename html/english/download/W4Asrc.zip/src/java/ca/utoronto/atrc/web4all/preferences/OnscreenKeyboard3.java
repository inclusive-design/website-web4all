/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.net.URL;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

/**
 * Class which encapsulates the third dialog of onscreen keyboard preferences.
 *
 * @author David Weinkauf
 * @version $Revision: 1.11 $, $Date: 2006/03/28 16:31:10 $
 */
public class OnscreenKeyboard3 extends PWMEditPanel {
    
    /**
     * The directional buttons.
     */
    private JButton prevButton, nextButton, defaultButton, cancelButton;

    /**
     * The key width slider.
     */
    private JSlider keyWidthSlider;

    /**
     * The key height slider.
     */
    private JSlider keyHeightSlider;

    /**
     * The key spacing slider.
     */
    private JSlider keySpacingSlider;

    /**
     * The slider labels.
     */
    private JLabel keyWidthLabel, keyHeightLabel, keySpacingLabel;

    /**
     * The keyboard layout title label.
     */
    private TitledBorder keyTitle, feedbackTitle;

    /**
     * The reference to the second dialog.
     */
    private OnscreenKeyboard2 onscreenKeyboard2;  
    
    private KeyLayoutFeedback aLayoutFeedback;
    
    /**
     * Sole constructor. Initializes all the components in the dialog and displays them accordingly.
     *
     * @param  pm  the reference to the PreferenceManagaer
     * @param  inOnscreenKeyboard2  the reference to the second onscreen keyboard dialog
     * @param  inAppType  the application type
     * @param  inTitleKey  the title key
     */
    public OnscreenKeyboard3(PreferenceManager pm, OnscreenKeyboard2 inOnscreenKeyboard2, String inAppType, String inTitleKey) {
        super(pm, inAppType, inTitleKey);

        this.onscreenKeyboard2 = inOnscreenKeyboard2;

        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.OnscreenKeyboard", pm.language);

        Hashtable keyWidthTable = new Hashtable();
        JLabel width;
        for (int i = KeyLayoutFeedback.KEY_WIDTH_MIN; i <= KeyLayoutFeedback.KEY_WIDTH_MAX; i += KeyLayoutFeedback.PERCENT_MULTIPLIER) {
            width = new JLabel(String.valueOf((int) (i/KeyLayoutFeedback.PERCENT_MULTIPLIER)));
            width.setForeground(TEXT_COLOUR);
            keyWidthTable.put(new Integer(i), width);
        }

        keyWidthSlider = new JSlider(SwingConstants.HORIZONTAL, KeyLayoutFeedback.KEY_WIDTH_MIN, KeyLayoutFeedback.KEY_WIDTH_MAX, KeyLayoutFeedback.KEY_WIDTH_DEFAULT);
        keyWidthSlider.setPaintLabels(true);
        keyWidthSlider.setBackground(PANEL_BACKGROUND);
        keyWidthSlider.setForeground(TEXT_COLOUR);
        keyWidthSlider.setLabelTable(keyWidthTable);
        keyWidthSlider.setSnapToTicks(false);
        keyWidthSlider.setMajorTickSpacing((int) KeyLayoutFeedback.PERCENT_MULTIPLIER);
        keyWidthSlider.setPaintTicks(true);
                
        Hashtable keyHeightTable = new Hashtable();
        JLabel height;
        for (int i = KeyLayoutFeedback.KEY_HEIGHT_MIN; i <= KeyLayoutFeedback.KEY_HEIGHT_MAX; i += KeyLayoutFeedback.PERCENT_MULTIPLIER) {
            height = new JLabel(String.valueOf((int) (i/KeyLayoutFeedback.PERCENT_MULTIPLIER)));
            height.setForeground(TEXT_COLOUR);
            keyHeightTable.put(new Integer(i), height);
        }

        keyHeightSlider = new JSlider(SwingConstants.HORIZONTAL, KeyLayoutFeedback.KEY_HEIGHT_MIN, KeyLayoutFeedback.KEY_HEIGHT_MAX, KeyLayoutFeedback.KEY_HEIGHT_DEFAULT);
        keyHeightSlider.setPaintLabels(true);
        keyHeightSlider.setBackground(PANEL_BACKGROUND);
        keyHeightSlider.setForeground(TEXT_COLOUR);
        keyHeightSlider.setSnapToTicks(false);
        keyHeightSlider.setLabelTable(keyHeightTable);
        keyHeightSlider.setMajorTickSpacing((int) KeyLayoutFeedback.PERCENT_MULTIPLIER);
        keyHeightSlider.setPaintTicks(true);

        Hashtable keySpacingTable = new Hashtable();
        JLabel spacing;
        for (int i = KeyLayoutFeedback.KEY_SPACING_MIN; i <= KeyLayoutFeedback.KEY_SPACING_MAX; i += KeyLayoutFeedback.PERCENT_MULTIPLIER) {
            spacing = new JLabel(String.valueOf((int) (i/KeyLayoutFeedback.PERCENT_MULTIPLIER)));
            spacing.setForeground(TEXT_COLOUR);
            keySpacingTable.put(new Integer(i), spacing);
        }
        
        keySpacingSlider = new JSlider(SwingConstants.HORIZONTAL, KeyLayoutFeedback.KEY_SPACING_MIN, KeyLayoutFeedback.KEY_SPACING_MAX, KeyLayoutFeedback.KEY_SPACING_DEFAULT);
        keySpacingSlider.setPaintLabels(true);
        keySpacingSlider.setBackground(PANEL_BACKGROUND);
        keySpacingSlider.setForeground(TEXT_COLOUR);
        keySpacingSlider.setSnapToTicks(false);
        keySpacingSlider.setLabelTable(keySpacingTable);
        keySpacingSlider.setMajorTickSpacing((int) KeyLayoutFeedback.PERCENT_MULTIPLIER);
        keySpacingSlider.setPaintTicks(true);

        keyWidthLabel = new JLabel(labels.getString("key.width"));
        keyWidthLabel.setDisplayedMnemonic(labels.getString("key.width.mnemonic").charAt(0));
        keyWidthLabel.setLabelFor(keyWidthSlider);
        keyWidthLabel.setFont(TEXT_FONT);
        keyWidthLabel.setForeground(TEXT_COLOUR);
        
        keyHeightLabel = new JLabel(labels.getString("key.height"));
        keyHeightLabel.setDisplayedMnemonic(labels.getString("key.height.mnemonic").charAt(0));
        keyHeightLabel.setLabelFor(keyHeightSlider);
        keyHeightLabel.setFont(TEXT_FONT);
        keyHeightLabel.setForeground(TEXT_COLOUR);
        
        keySpacingLabel = new JLabel(labels.getString("key.spacing"));
        keySpacingLabel.setDisplayedMnemonic(labels.getString("key.spacing.mnemonic").charAt(0));
        keySpacingLabel.setLabelFor(keySpacingSlider);
        keySpacingLabel.setFont(TEXT_FONT);
        keySpacingLabel.setForeground(TEXT_COLOUR);

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel keyGridPanel = new JPanel();
        keyGridPanel.setBackground(PANEL_BACKGROUND);
        keyGridPanel.setLayout(gridbag);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;
        c.insets = new Insets(2, INDENT_VALUE, 2, SPACING_VALUE);

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        keyGridPanel.add(keyWidthLabel, c);

        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0.5;
        keyGridPanel.add(keyWidthSlider, c);

        c.gridx = 0;
        c.gridy = 1;
        c.weightx = 0.0;
        keyGridPanel.add(keyHeightLabel, c);

        c.gridx = 1;
        c.gridy = 1;
        c.weightx = 0.5;
        keyGridPanel.add(keyHeightSlider, c);

        c.gridx = 0;
        c.gridy = 2;
        c.weightx = 0.0;
        keyGridPanel.add(keySpacingLabel, c);

        c.gridx = 1;
        c.gridy = 2;
        c.weightx = 0.5;
        keyGridPanel.add(keySpacingSlider, c);


        keyTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("key.size.title"));
        keyTitle.setTitleColor(BORDER_TITLE_COLOUR);
        keyTitle.setTitleFont(BORDER_TITLE_FONT);        

        JPanel keyPanel = new JPanel(new GridLayout(1, 1));
        keyPanel.setBackground(PANEL_BACKGROUND);
        keyPanel.setBorder(keyTitle);
        keyPanel.add(keyGridPanel);

        aLayoutFeedback = new KeyLayoutFeedback (new Dimension (keyWidthSlider.getValue(), keyHeightSlider.getValue()), keySpacingSlider.getValue());
        aLayoutFeedback.addWidthListener (keyWidthSlider);
        aLayoutFeedback.addHeightListener (keyHeightSlider);
        aLayoutFeedback.addSpacingListener (keySpacingSlider);
        aLayoutFeedback.setBackground(PANEL_BACKGROUND);
        aLayoutFeedback.setPreferredSize(new Dimension(DIALOG_WIDTH, DIALOG_HEIGHT / 2));
        aLayoutFeedback.getAccessibleContext().setAccessibleName(labels.getString("preview"));

        feedbackTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("preview"));
        feedbackTitle.setTitleFont(BORDER_TITLE_FONT);
        feedbackTitle.setTitleColor(BORDER_TITLE_COLOUR);

        JPanel feedbackPanel = new JPanel(new GridLayout(0, 1));
        feedbackPanel.setBackground(PANEL_BACKGROUND);
        feedbackPanel.setBorder(feedbackTitle);
        feedbackPanel.add(aLayoutFeedback);
		
        AccessibleContext ac = keyWidthLabel.getAccessibleContext();
        ac.setAccessibleParent(keyPanel);
        ac = keyWidthSlider.getAccessibleContext();
        ac.setAccessibleParent(keyPanel);
        ac = keyHeightLabel.getAccessibleContext();
        ac.setAccessibleParent(keyPanel);
        ac = keyHeightSlider.getAccessibleContext();
        ac.setAccessibleParent(keyPanel);
        ac = keySpacingLabel.getAccessibleContext();
        ac.setAccessibleParent(keyPanel);
        ac = keySpacingSlider.getAccessibleContext();
        ac.setAccessibleParent(keyPanel);

        this.add(keyPanel);
        this.add(Box.createVerticalGlue());
        this.add(feedbackPanel);
        this.add(Box.createVerticalGlue());
        
    }

    /**
     * Sets all the UI widgets to their correct values associated with the user preferences.
     *
     * @param  onscreen  the user onscreen keyboard preferences
     */
    protected void setDomValues(Document onscreen) {
        Element generic = DOMUtil.getFirstChildElement(onscreen.getDocumentElement());
        Element temp = DOMUtil.getFirstChildElement(generic);
        if (temp != null && (temp.getTagName().equals(xmlLabels.getString(ALPHA_LAYOUT_INTERNAL)) ||
                             temp.getTagName().equals(xmlLabels.getString(ALPHA_LAYOUT_EXTERNAL)))) 
            temp = DOMUtil.getNextSiblingElement(temp);

        // Pass through selection method.
        temp = DOMUtil.getNextSiblingElement(temp);

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(OK_GENERIC_KEY_HEIGHT))) {
            keyHeightSlider.setValue( (int) (Float.parseFloat(temp.getAttribute(VALUE)) * (KeyLayoutFeedback.PERCENT_MULTIPLIER * 100.0f)));
            temp = DOMUtil.getNextSiblingElement(temp);
        }
		
        if (temp != null && temp.getTagName().equals(xmlLabels.getString(OK_GENERIC_KEY_WIDTH))) {
            keyWidthSlider.setValue( (int) (Float.parseFloat(temp.getAttribute(VALUE)) * (KeyLayoutFeedback.PERCENT_MULTIPLIER * 100.0f)));
            temp = DOMUtil.getNextSiblingElement(temp);
        }
		
        if (temp != null && temp.getTagName().equals(xmlLabels.getString(OK_GENERIC_KEY_SPACING))) {
            keySpacingSlider.setValue( (int) (Float.parseFloat(temp.getAttribute(VALUE)) * (KeyLayoutFeedback.PERCENT_MULTIPLIER * 100.0f)));
            temp = DOMUtil.getNextSiblingElement(temp);
        }

    }

    /**
     * Adds elements to the XML sub-tree for keyboard setup according to the user's current selections.
     *
     * @param  onscreen  the onscreen keyboard XML preferences
     */
    protected void addElementsTo(Document onscreen) {        
        Element generic = DOMUtil.getFirstChildElement(onscreen.getDocumentElement());
		
        Element temp = onscreen.createElement(xmlLabels.getString(OK_GENERIC_KEY_HEIGHT));
        temp.setAttribute(VALUE, String.valueOf(keyHeightSlider.getValue() / (KeyLayoutFeedback.PERCENT_MULTIPLIER * 100.0f)));
        generic.appendChild(temp);
		
        temp = onscreen.createElement(xmlLabels.getString(OK_GENERIC_KEY_WIDTH));
        temp.setAttribute(VALUE, String.valueOf(keyWidthSlider.getValue() / (KeyLayoutFeedback.PERCENT_MULTIPLIER * 100.0f)));
        generic.appendChild(temp);
		
        temp = onscreen.createElement(xmlLabels.getString(OK_GENERIC_KEY_SPACING));
        temp.setAttribute(VALUE, String.valueOf(keySpacingSlider.getValue() / (KeyLayoutFeedback.PERCENT_MULTIPLIER * 100.0f)));
        generic.appendChild(temp);
				
    }

    /**
     * Set all the JPanel labels to the current PreferenceManager.language value.
     */
    protected void setNewLabels() {

        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.OnscreenKeyboard", pm.language);

        feedbackTitle.setTitle(newLabels.getString("preview"));
        aLayoutFeedback.getAccessibleContext().setAccessibleName(newLabels.getString("preview"));

        keyTitle.setTitle(newLabels.getString("key.size.title"));

        keyWidthLabel.setText(newLabels.getString("key.width"));
        keyWidthLabel.setDisplayedMnemonic(newLabels.getString("key.width.mnemonic").charAt(0));
		
        keyHeightLabel.setText(newLabels.getString("key.height"));
        keyHeightLabel.setDisplayedMnemonic(newLabels.getString("key.height.mnemonic").charAt(0));

        keySpacingLabel.setText(newLabels.getString("key.spacing"));
        keySpacingLabel.setDisplayedMnemonic(newLabels.getString("key.spacing.mnemonic").charAt(0));

        setNewButtonLabels();

        revalidate();
        repaint();
    }
    
    /**
     * Sets the UI widgets to their default values.
     */
    protected void doDefault() {
        keyWidthSlider.setValue(KeyLayoutFeedback.KEY_WIDTH_DEFAULT);
        keyHeightSlider.setValue(KeyLayoutFeedback.KEY_HEIGHT_DEFAULT);
        keySpacingSlider.setValue(KeyLayoutFeedback.KEY_SPACING_DEFAULT);
    }

    /**
     * Shows the previous dialog.
     */
    protected void doPrev() {
        if (onscreenKeyboard2.isSwitchUsed())
            pm.showPanel(onscreenKeyboard2);
        else
            onscreenKeyboard2.doPrev();
    }

    /**
     * Gets the first edit panel for this app type.
     */ 
    protected PWMEditPanel getFirstPanel() {
        return onscreenKeyboard2.getFirstPanel();
    }


}
