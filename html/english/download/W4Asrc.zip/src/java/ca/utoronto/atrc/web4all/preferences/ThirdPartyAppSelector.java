/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

import org.apache.xpath.*;
import javax.xml.transform.TransformerException;

/**
 * Class which encapsulates all functionality for third party preference editing.
 *
 * @author David Weinkauf
 * @version $Revision: 1.30 $, $Date: 2006/03/28 16:31:10 $
 */
public class ThirdPartyAppSelector extends PWMEditPanel {

    /**
     * Array of all the applications.
     */
    private ThirdPartyComboBoxItem[] apps;

    /**
     * Array of all the application combo boxes.
     */
    private JComboBox[] appComboBoxes;

    /**
     * Array of all the selected application IDs.
     */
    private String[] selectedAppIDs;

    /**
     * The default "Select this" item.
     */
    private ThirdPartyComboBoxItem theSelectThisItem;

    /**
     * The item to display if no applications are on the system.
     */
    private ThirdPartyComboBoxItem noAppsOnSystem;

    /**
     * The number of combo boxes.
     */
    private static final int NUM_COMBO_BOX = 5;

    /**
     * The resource for UI labels.
     */
    private ResourceBundle labels;

    /**
     * The application type document.
     */
    private Document doc;

    /**
     * The launch third party wizard button.
     */
    private JButton wizardButton;

    /**
     * The third party wizard combo box.
     */
    private JComboBox wizardComboBox;

    /**
     * The third party prefs wizard class.
     */
    private ThirdPartyPrefsWizard tppw;

    /**
     * The application selection title.
     */
    private TitledBorder appTitle;

    /**
     * Sole constructor.
     */
    public ThirdPartyAppSelector (PreferenceManager pm, String inTitle) {
        super(pm, null, inTitle);
    }
   
    /**
     * Sets up the panel corresponding to the give application type.
     *
     * @param  appType  the application type
     */
    public void setUpPanel(String appType) {

        this.removeAll();
        this.appType = appType;

        labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.ThirdPartyAppSel", pm.language);

        doc = pm.getAppTypeDoc(appType);

        Vector allAppIDs = pm.get3rdPartyAppIds(appType);

        theSelectThisItem = new ThirdPartyComboBoxItem(labels.getString("select"), null, null);

        noAppsOnSystem = new ThirdPartyComboBoxItem(labels.getString("no.apps"), null, null);

        wizardComboBox = new JComboBox();
        wizardComboBox.addItem(theSelectThisItem);

        Vector tempApps = null;
        Vector appsNotOnSystem = null;		
		

        try {
            tempApps = getApps(allAppIDs, pm);

            appsNotOnSystem = getAppsNotOnSystem(allAppIDs, doc, labels.getString("not.on.system"));
            for (int i = 0; i < appsNotOnSystem.size(); i++) {
                tempApps.add( appsNotOnSystem.elementAt(i) );
            }

            if (tempApps.size() != 0) 
                tempApps.insertElementAt(theSelectThisItem, 0);
            else 
                tempApps.addElement(noAppsOnSystem);

        }
        catch (TransformerException te) {
            te.printStackTrace();
        }

        apps = new ThirdPartyComboBoxItem[tempApps.size()];
        tempApps.toArray(apps);

        // Subtract one b/c of "Select This" or "No apps available" items
        //
        int numApps = apps.length - 1;

        ThirdPartyItemListener thirdPartyListener = new ThirdPartyItemListener();
        appComboBoxes = new JComboBox[NUM_COMBO_BOX];
        selectedAppIDs = new String[NUM_COMBO_BOX];
        for (int i = 0; i < NUM_COMBO_BOX; i++) {
            appComboBoxes[i] = new JComboBox(apps);
            appComboBoxes[i].setForeground(TEXT_COLOUR);
            appComboBoxes[i].setFont(TEXT_FONT);
            appComboBoxes[i].setBackground(PANEL_BACKGROUND);
            appComboBoxes[i].setSelectedItem(theSelectThisItem);
            appComboBoxes[i].addItemListener(thirdPartyListener);
            selectedAppIDs[i] = null;
			
            if (i != 0 && numApps <= i)
                appComboBoxes[i].setEnabled(false);
        }

        try {
            setComboBoxSelectedItems(appComboBoxes, apps, doc);
        }
        catch (TransformerException te) {
            te.printStackTrace();
        }

		
        TitledBorder appTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("app.title"));
        appTitle.setTitleFont(BORDER_TITLE_FONT);
        appTitle.setTitleColor(BORDER_TITLE_COLOUR);

        JPanel appPanel = new JPanel();
        appPanel.setBackground(PANEL_BACKGROUND);
        appPanel.setLayout(new BoxLayout(appPanel, BoxLayout.Y_AXIS));
        appPanel.setBorder(appTitle);

        JLabel comboBoxLabel;
        JPanel comboBoxPanel;

        comboBoxLabel = new JLabel(labels.getString("choice.0"));
        comboBoxLabel.setDisplayedMnemonic(labels.getString("choice.0.mnemonic").charAt(0));
        comboBoxLabel.setLabelFor(appComboBoxes[0]);
        comboBoxLabel.setFont(TEXT_FONT);
        comboBoxLabel.setForeground(TEXT_COLOUR);
        comboBoxPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        comboBoxPanel.setBackground(PANEL_BACKGROUND);
        comboBoxPanel.add(comboBoxLabel);
        appPanel.add(comboBoxPanel);

        comboBoxPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        comboBoxPanel.setBackground(PANEL_BACKGROUND);
        comboBoxPanel.add(Box.createHorizontalStrut(15));
        comboBoxPanel.add(appComboBoxes[0]);
        appPanel.add(comboBoxPanel);

        appPanel.add(Box.createVerticalGlue());

        AccessibleContext ac = comboBoxLabel.getAccessibleContext();
        ac.setAccessibleParent(appPanel);
        ac = appComboBoxes[0].getAccessibleContext();
        ac.setAccessibleParent(appPanel);

        comboBoxLabel = new JLabel(labels.getString("choice.explanation.line1"));
        comboBoxLabel.setForeground(TEXT_COLOUR);
        comboBoxLabel.setFont(TEXT_FONT);

        comboBoxPanel = new JPanel();
        comboBoxPanel.setBackground(PANEL_BACKGROUND);
        comboBoxPanel.setLayout(new BoxLayout(comboBoxPanel, BoxLayout.X_AXIS));
        comboBoxPanel.add(Box.createHorizontalStrut(INDENT_VALUE));
        comboBoxPanel.add(comboBoxLabel);
        comboBoxPanel.add(Box.createHorizontalGlue());

        appPanel.add(comboBoxPanel);

        ac = comboBoxLabel.getAccessibleContext();
        ac.setAccessibleParent(appPanel);

        comboBoxLabel = new JLabel(labels.getString("choice.explanation.line2"));
        comboBoxLabel.setForeground(TEXT_COLOUR);
        comboBoxLabel.setFont(TEXT_FONT);

        comboBoxPanel = new JPanel();
        comboBoxPanel.setLayout(new BoxLayout(comboBoxPanel, BoxLayout.X_AXIS));
        comboBoxPanel.setBackground(PANEL_BACKGROUND);
        comboBoxPanel.add(Box.createHorizontalStrut(INDENT_VALUE));
        comboBoxPanel.add(comboBoxLabel);
        comboBoxPanel.add(Box.createHorizontalGlue());

        appPanel.add(comboBoxPanel);

        ac = comboBoxLabel.getAccessibleContext();
        ac.setAccessibleParent(appPanel);
		
        appPanel.add(Box.createVerticalGlue());

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel appGridPanel = new JPanel();
        appGridPanel.setBackground(PANEL_BACKGROUND);
        appGridPanel.setLayout(gridbag);

        Insets insets1 = new Insets(3, 25, 0, 5);
        Insets insets2 = new Insets(3, 0, 0, 5);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;

        for (int i = 1; i < NUM_COMBO_BOX; i++) {

            comboBoxLabel = new JLabel(labels.getString("choice." + i));
            comboBoxLabel.setDisplayedMnemonic(labels.getString("choice." + i + ".mnemonic").charAt(0));
            comboBoxLabel.setLabelFor(appComboBoxes[i]);
            comboBoxLabel.setFont(TEXT_FONT);
            comboBoxLabel.setForeground(TEXT_COLOUR);
            if (numApps <= i) {
                comboBoxLabel.setEnabled(false);
            }

            c.gridx = 0;
            c.gridy = i - 1;
            c.weightx = 0.0;
            c.insets = insets1;
            appGridPanel.add(comboBoxLabel, c);
			
            c.gridx = 1;
            c.gridy = i - 1;
            c.weightx = 0.0;
            c.insets = insets2;
            appGridPanel.add(appComboBoxes[i], c);
			
            if (i == 1) {
                c.gridx = 2;
                c.gridy = i - 1;
                c.weightx = 0.5;
                appGridPanel.add(Box.createHorizontalStrut(1), c);
            }

            ac = comboBoxLabel.getAccessibleContext();
            ac.setAccessibleParent(appPanel);
            ac = appComboBoxes[i].getAccessibleContext();
            ac.setAccessibleParent(appPanel);
        
        }

        JPanel appComboPanel = new JPanel(new GridLayout(1, 1));
        appComboPanel.setBackground(PANEL_BACKGROUND);
        appComboPanel.add(appGridPanel);

        appPanel.add(appComboPanel);

        appPanel.add(Box.createVerticalGlue());

        wizardComboBox.setForeground(TEXT_COLOUR);
        wizardComboBox.setFont(TEXT_FONT);
        wizardComboBox.setBackground(PANEL_BACKGROUND);		
        wizardComboBox.setSelectedItem(theSelectThisItem);
        wizardComboBox.addItemListener(new WizardItemListener());

        JLabel wizardLabel = new JLabel(labels.getString("wizard.explanation.line1"));
        wizardLabel.setDisplayedMnemonic(labels.getString("wizard.explanation.mnemonic").charAt(0));
        wizardLabel.setLabelFor(wizardComboBox);
        wizardLabel.setForeground(TEXT_COLOUR);
        wizardLabel.setFont(TEXT_FONT);

        JPanel wizardLabelPanel = new JPanel();
        wizardLabelPanel.setBackground(PANEL_BACKGROUND);
        wizardLabelPanel.setLayout(new BoxLayout(wizardLabelPanel, BoxLayout.X_AXIS));
        wizardLabelPanel.add(Box.createHorizontalStrut(INDENT_VALUE));
        wizardLabelPanel.add(wizardLabel);
        wizardLabelPanel.add(Box.createHorizontalGlue());

        JLabel wizardLabel2 = new JLabel(labels.getString("wizard.explanation.line2"));
        wizardLabel2.setForeground(TEXT_COLOUR);
        wizardLabel2.setFont(TEXT_FONT);

        JPanel wizardLabelPanel2 = new JPanel();
        wizardLabelPanel2.setLayout(new BoxLayout(wizardLabelPanel2, BoxLayout.X_AXIS));
        wizardLabelPanel2.setBackground(PANEL_BACKGROUND);
        wizardLabelPanel2.add(Box.createHorizontalStrut(INDENT_VALUE));
        wizardLabelPanel2.add(wizardLabel2);
        wizardLabelPanel2.add(Box.createHorizontalGlue());


        wizardButton = new JButton(labels.getString("edit"));
        wizardButton.setMnemonic(labels.getString("edit.mnemonic").charAt(0));
        wizardButton.addActionListener(new WizardButtonListener());
        wizardButton.setBackground(BUTTON_BACKGROUND);
        wizardButton.setEnabled(false);

        JPanel comboBoxButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        comboBoxButtonPanel.setBackground(PANEL_BACKGROUND);
        comboBoxButtonPanel.add(wizardComboBox);
        comboBoxButtonPanel.add(wizardButton);

        TitledBorder wizardTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("wizard.title"));
        wizardTitle.setTitleFont(BORDER_TITLE_FONT);
        wizardTitle.setTitleColor(BORDER_TITLE_COLOUR);

        JPanel wizardPanel = new JPanel();
        wizardPanel.setLayout(new BoxLayout(wizardPanel, BoxLayout.Y_AXIS));
        wizardPanel.setBorder(wizardTitle);
        wizardPanel.setBackground(PANEL_BACKGROUND);
        wizardPanel.add(wizardLabelPanel);
        wizardPanel.add(wizardLabelPanel2);
        wizardPanel.add(comboBoxButtonPanel);

        ac = wizardLabel.getAccessibleContext();
        ac.setAccessibleParent(wizardPanel);        
        ac = wizardComboBox.getAccessibleContext();
        ac.setAccessibleParent(wizardPanel);        
        ac = wizardLabel2.getAccessibleContext();
        ac.setAccessibleParent(wizardPanel);        
        ac = wizardComboBox.getAccessibleContext();
        ac.setAccessibleParent(wizardPanel);        

        this.add(appPanel);
        this.add(wizardPanel);
        this.add(Box.createVerticalGlue());

        if (pm.isLastApp(appType)) {
            setLastButtonText();
        }

        ResourceBundle buttonLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Buttons", pm.language);			

        defaultButton.setText(buttonLabels.getString("clear"));
        defaultButton.setMnemonic(buttonLabels.getString("clear.mnemonic").charAt(0));

    }

    /**
     * Place all combo boxes to index 0.
     */
    protected void doDefault() {
        
        for (int i = 0; i < appComboBoxes.length; i++) {
            appComboBoxes[i].setSelectedIndex(0);
        }

        wizardComboBox.setSelectedIndex(0);

    }

    /**
     * Shows the previous dialog.
     */
    protected void doPrev() {
        finalize3rdPartyXml();

        if ( pm.isLastApp(appType)) {
            ResourceBundle buttonLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Buttons", pm.language);			
            nextButton.setPreferredSize(LOWER_BUTTON_DIM);
            nextButton.setText(buttonLabels.getString("next"));
            nextButton.setMnemonic(buttonLabels.getString("next.mnemonic").charAt(0));
        }

        pm.doPrevThirdPartySelector(appType);
    }

    /**
     * Shows the next dialog.
     */
    protected void doNext() {
        finalize3rdPartyXml();
        pm.doNextThirdPartySelector(appType);
    }

    /**
     * Listener for the third party wizard button.
     */
    class WizardButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {			
            ThirdPartyComboBoxItem item = (ThirdPartyComboBoxItem) wizardComboBox.getSelectedItem();
            start3rdPartyPrefsDialog(item);           
        }
    }


    /**
     * Calls the selected application's ThirdPartyPrefsWizard `doPreferences' method.
     *
     * @param  item  the third party application item
     */
    private void start3rdPartyPrefsDialog(ThirdPartyComboBoxItem item) {
        String appID = item.value;
        Class thirdPartyPrefsDialog = null;
        try {
            String prefsClassName = pm.get3rdPartyPrefsClass(appID);
            thirdPartyPrefsDialog = null;
            thirdPartyPrefsDialog = Class.forName(prefsClassName);
        }
        catch (ClassNotFoundException e) {
            System.out.println("Third Party Wizard Launch button enabled for class which does not exist for application " + appID);
            return;
        }

        try {
            tppw = (ThirdPartyPrefsWizard) thirdPartyPrefsDialog.newInstance();	    
            Document tempAppDoc = (Document) item.application.cloneNode(true);
            int error = tppw.doPreferences (tempAppDoc, pm.language);

            if (error == 0) {
                if (isValidApplicationDoc(tempAppDoc))
                    item.application = tempAppDoc;
                else {
                    System.out.println("Third party wizard for " + item.value + " output invalidate document. Removing all its children.");
                    pm.removeAllChildren(item.application.getDocumentElement());
                }
				
                Element app = item.application.getDocumentElement();
                app.setAttribute(xmlLabels.getString(APP_NAME), appID);
            }

            tppw = null;
        }
        catch (Throwable t) {
            tppw = null;
            t.printStackTrace();
            return;
        }
		
    }

    /**
     * Checks if the edited third party preference document is valid.
     *
     * @param  application  the third party preferenc document
     * @return  true if valid, false otherwise
     */
    private boolean isValidApplicationDoc(Document application) {

        if (application == null || application.getDocumentElement() == null)
            return false;

        Element root = application.getDocumentElement();
        if (!root.getTagName().equals(xmlLabels.getString(APPLICATION)))
            return false;

        NamedNodeMap attrs = root.getAttributes();
        if (attrs.getLength() > 3)
            return false;

        Attr attr;
        for (int i = 0; i < attrs.getLength(); i++) {
            attr = (Attr) attrs.item(i);
            if (!attr.getName().equals(xmlLabels.getString(APP_NAME)) && !attr.getName().equals(xmlLabels.getString(APP_PRIORITY)) && !attr.getName().equals(xmlLabels.getString(APP_VERSION)))
                return false;			
        }

        Element child = DOMUtil.getFirstChildElement(root);
		
        while (child != null) {

            if (!child.getTagName().equals(xmlLabels.getString(PARAMETER)))
                return false;

            if (DOMUtil.getFirstChildElement(child) != null)
                return false;

            attrs = child.getAttributes();
            if (attrs.getLength() > 2)
                return false;

            for (int i = 0; i < attrs.getLength(); i++) {
                attr = (Attr) attrs.item(i);
                if (!attr.getName().equals(xmlLabels.getString(PARAM_NAME)) && !attr.getName().equals(xmlLabels.getString(PARAM_VALUE)))
                    return false;			
            }

            child = DOMUtil.getNextSiblingElement(child);
        }
		
        return true;

    }

    /**
     * Gets all the application items from applications on the system 
     * and initializes them to the user's preferences.
     *
     * @param  allAppIDs  all the application IDs on the system
     * @param  pm  the PreferenceManager
     * @return  all the application items
     */
    private Vector getApps(Vector allAppIDs, PreferenceManager pm) throws TransformerException {
        if (allAppIDs == null)
            return new Vector();

        Vector tempApps = new Vector();

        ThirdPartyComboBoxItem appItem;
        String name, id;
        Document application;

        for (int i = 0; i < allAppIDs.size(); i++) {
            id = (String) allAppIDs.elementAt(i);
            name = pm.get3rdPartyFullProductName(id);

            if ( !pm.thirdPartyAppExists (id) )
                name += " (" + labels.getString("product.unavailable") + ")";
				
            application = getApplicationParamDoc(id);

            if (application == null) {
                application = new DocumentImpl();
                Element app = application.createElement(xmlLabels.getString(APPLICATION));
                app.setAttribute(xmlLabels.getString(APP_NAME), id);
                application.appendChild(app);
            }

            appItem = new ThirdPartyComboBoxItem(name, id, application);
            tempApps.addElement(appItem);
        }
		
        return tempApps;

    }

    /**
     * Gets all the application items from applications NOT on the system.
     *
     * @param  allAppIDs  all the application IDs on the system
     * @param  appTypeDoc  the application type's document
     * @param  noOnSystem  the "Not on System" string for labels
     * @return  all the application items not on the system
     */
    private Vector getAppsNotOnSystem(Vector allAppIDs, Document appTypeDoc, String notOnSystem) throws TransformerException {
        Vector apps = new Vector();
        Element application = (Element) XPathAPI.selectSingleNode(appTypeDoc, "//application");
        ThirdPartyComboBoxItem item;
        String appID;
        Document appParamDoc;

        while (application != null) {
            appID = application.getAttribute(xmlLabels.getString(APP_NAME));
            if (allAppIDs == null || !allAppIDs.contains(appID)) {

                appParamDoc = new DocumentImpl();
                appParamDoc.appendChild((Element) appParamDoc.importNode(application, true));

                item = new ThirdPartyComboBoxItem(appID + " (" + notOnSystem + ")", appID, appParamDoc);
                apps.add(item);
            }
			
            application = DOMUtil.getNextSiblingElement(application);
        }

        return apps;
    }

    /**
     * Sets the combo boxes to the user selected applications.
     *
     * @param  comboBoxes  the array of combo boxes
     * @param  items  the third party combo box items
     * @param  appTypeDoc  the application type's document
     */
    private void setComboBoxSelectedItems(JComboBox[] comboBoxes, ThirdPartyComboBoxItem[] items, Document appTypeDoc) throws TransformerException {

        int priority = 1;
        Element application = (Element) XPathAPI.selectSingleNode(appTypeDoc, "//application[@priority='" + priority + "']");
		
        while (application != null) {
			
            ThirdPartyComboBoxItem appItem = (ThirdPartyComboBoxItem) findItem(items, application.getAttribute(xmlLabels.getString(APP_NAME)));			
            comboBoxes[priority - 1].setSelectedItem(appItem);

            priority++;
            application = (Element) XPathAPI.selectSingleNode(appTypeDoc, "//application[@priority='" + priority + "']");

        }

    }

    /**
     * Finalizes the application type's document to the user-selected third party applications.
     */
    private void finalize3rdPartyXml() {
        Document appTypeDoc = pm.getAppTypeDoc(appType);
	
        Element appTypeRoot = appTypeDoc.getDocumentElement();
        Element generic = DOMUtil.getFirstChildElement(appTypeRoot);

        if (generic == null)
            return;

        Element application = DOMUtil.getNextSiblingElement(generic);

        cleanUpApplications(application);

        int priority = 1;
        JComboBox comboBox;
        ThirdPartyComboBoxItem thirdPartyItem;
        Element app;
        for (int i = 0; i < NUM_COMBO_BOX; i++) {
            comboBox = appComboBoxes[i];
            thirdPartyItem = (ThirdPartyComboBoxItem) comboBox.getSelectedItem();

            if (thirdPartyItem == theSelectThisItem || thirdPartyItem == noAppsOnSystem)
                continue;

            app = thirdPartyItem.application.getDocumentElement();

            if (insertParamTagsInOtherMATA(thirdPartyItem))
                pm.removeAllChildren(app);

            app.setAttribute(xmlLabels.getString(APP_PRIORITY), String.valueOf(priority));
            priority++;
			
            appTypeRoot.appendChild((Element) appTypeDoc.importNode(app, true));
        }

    }

    /**
     * Cleans the third party application XML up in terms of multi-type adaptive technologies and deselection.
     *
     * @param  application  the application to clean up
     */
    private void cleanUpApplications(Element application) {
        if (application == null)
            return;

        Element parent = (Element) application.getParentNode();
        String appID, type;
        Document appTypeDoc = null;
        Element otherApplication = null;
        while (application != null) {
            appID = application.getAttribute(xmlLabels.getString(APP_NAME));
			
            if (!isAppSelected(appID) && DOMUtil.getFirstChildElement(application) != null) {

                // CHECK IF THE APPLICATION HAS ANY PARAM TAGS. IF SO, SEE IF THERE'S ANOTHER APPLICATION 
                // WITH SAME NAME THAT CAN TAKE THEM.
                //
                Vector appTypes = pm.get3rdPartyAppTypes(appID);
		
                if (appTypes != null && appTypes.size() > 1) {
				
                    for (int i = 0; i < appTypes.size(); i++) {
                        type = (String) appTypes.get(i);
					
                        if (type.equals(appType))
                            continue;
					
                        appTypeDoc = pm.getAppTypeDoc(type);
						
                        try {
                            otherApplication = (Element) XPathAPI.selectSingleNode(appTypeDoc, "//application[@name='" + appID + "']");
                        }
                        catch (TransformerException te) {
                            te.printStackTrace();
                        }
						
                        if (otherApplication != null)
                            break;
                    }

                    if (otherApplication != null) {
                        Element child = DOMUtil.getFirstChildElement(application);
                        while (child != null) {
                            otherApplication.appendChild((Element) appTypeDoc.importNode(child, true));
                            child = DOMUtil.getNextSiblingElement(child);
                        }
						
                    }

                    otherApplication = null;
                }
            }

            Element remove = application;
            application = DOMUtil.getNextSiblingElement(application);
            parent.removeChild(remove);
        }

    }

    /**
     * Checks whether or not an application with a given ID is selected.
     *
     * @param  appID  the application ID
     * @return  true if application is selected, false otherwise
     */
    private boolean isAppSelected(String appID) {
        for (int i = 0; i < selectedAppIDs.length; i++) {
            if (selectedAppIDs[i] != null && selectedAppIDs[0].equals(appID))
                return true;
        }
		
        return false;
    }

    /**
     * Kills the third party preference wizard.
     */
    protected void cleanUp() {
        if (tppw != null)
            tppw.kill();		
    }


    /**
     * Revalidates the third party wizard's combo box.
     */
    private void revalidateWizardComboBox() {
        wizardComboBox.revalidate();
        wizardComboBox.repaint();
    }

    /**
     * Listener for the application combo boxes. Makes sure no conflicts happen in application selection.
     */
    class ThirdPartyItemListener implements ItemListener {
        public void itemStateChanged(ItemEvent e) {
            ThirdPartyComboBoxItem item = (ThirdPartyComboBoxItem) e.getItem();

            if (item == theSelectThisItem)
                return;
            else if (e.getStateChange() == ItemEvent.DESELECTED) {
                wizardComboBox.removeItem(item);
                revalidateWizardComboBox();
                return;
            }

            wizardComboBox.addItem(item);
            revalidateWizardComboBox();

            JComboBox comboBox = (JComboBox) e.getItemSelectable();

            ThirdPartyComboBoxItem otherItem;
            for (int i = 0; i < appComboBoxes.length; i++) {

                if (appComboBoxes[i] == comboBox)
                    continue;
				
                otherItem = (ThirdPartyComboBoxItem) appComboBoxes[i].getSelectedItem();
                if (otherItem == item)
                    appComboBoxes[i].setSelectedItem(theSelectThisItem);
            }

        }
    }

    /**
     * Listener for the third party wizard combo box. Checks if the application has a ThirdPartyPrefsWizard
     * and enables the wizard button, if it does.
     */
    class WizardItemListener implements ItemListener {

        public void itemStateChanged(ItemEvent e) {
            ThirdPartyComboBoxItem item = (ThirdPartyComboBoxItem) e.getItem();

            if (e.getStateChange() == ItemEvent.DESELECTED)
                return;

            if (item == theSelectThisItem) {
                wizardButton.setEnabled(false);
                return;
            }

            if (is3rdPartyWizard(item.value))
                wizardButton.setEnabled(true);
            else
                wizardButton.setEnabled(false);

        }
    }

    /**
     * Checks to see if a third party wizard exists for a given application ID.
     */
    private boolean is3rdPartyWizard(String appID) { 
        try {
            String prefsClassName = pm.get3rdPartyPrefsClass(appID);
            Class thirdPartyPrefsDialog = Class.forName(prefsClassName);
        }
        catch (Exception e) { 
            return false;
        }

        return true;
    }

    /**
     * Gets a Document consisting of the <application> element with the appID with <param> children.
     *
     * @param  appID  the application ID
     * @return        the <application> as a Document.
     */
    protected Document getApplicationParamDoc(String appID) {
        Document appParamDoc = null;
        Element application = null;
        Document appTypeDoc = null;
        String type;
        Vector appTypes = pm.get3rdPartyAppTypes(appID);
		
        for (int i = 0; i < appTypes.size(); i++) {
            type = (String) appTypes.get(i);
            appTypeDoc = pm.getAppTypeDoc(type);
            application = getApplicationWithParam(appTypeDoc, appID);

            if (application != null)
                break;
        }

        // Last chance to find an empty <application>
        //
        if (application == null) {
            try {
                application = (Element) XPathAPI.selectSingleNode(appTypeDoc, "//application[@name='" + appID + "']");
            }
            catch (TransformerException te) {
                te.printStackTrace();
            }
        }

        if (application != null) {
            appParamDoc = new DocumentImpl();
            appParamDoc.appendChild((Element) appParamDoc.importNode(application, true));
        }

        return appParamDoc;
    }

    /**
     * Gets the <application> element with the param elements.
     *
     * @param  appTypeDoc  the assistive-tech type document branch
     * @param  appID       the application ID
     * @return             the <application> element with appID and <param> children
     */
    private Element getApplicationWithParam(Document appTypeDoc, String appID) {
        Element param = null;
        try {
            param = (Element) XPathAPI.selectSingleNode(appTypeDoc, "//application[@name='" + appID + "']/param");
        }
        catch (TransformerException te) {
            te.printStackTrace();
        }

        if (param != null)
            return (Element) param.getParentNode();

        return null;
    }


    /**
     * Inserts the application param tags in the other tech-type if this is a MATA
     * and the other tech-type already has param-tags.
     *
     * @param  item  the third party item
     * @return  true if tags were inserted in other tech-type, false otherwise
     */
    private boolean insertParamTagsInOtherMATA(ThirdPartyComboBoxItem item) {

        Element application = null;
        Document appTypeDoc = null;
        String type;
        Vector appTypes = pm.get3rdPartyAppTypes(item.value);
		
        if (appTypes == null || appTypes.size() == 1)
            return false;

        for (int i = 0; i < appTypes.size(); i++) {
            type = (String) appTypes.get(i);

            if (type.equals(appType))
                continue;

            appTypeDoc = pm.getAppTypeDoc(type);
            application = getApplicationWithParam(appTypeDoc, item.value);

            if (application != null)
                break;
        }

        if (application == null)
            return false;

        PreferenceManager.removeAllChildren(application);
		
        Element thirdPartyDocRootElement = item.application.getDocumentElement();
        Element child;
        if (thirdPartyDocRootElement != null) {
            child = DOMUtil.getFirstChildElement(thirdPartyDocRootElement);
            while (child != null) {
                application.appendChild((Element) appTypeDoc.importNode(child, true));
                child = DOMUtil.getNextSiblingElement(child);
            }
        }

        return true;
    }

    /**
     * Sets the `next' button to the last button, or `Save and Exit' button.
     */
    private void setLastButtonText() {
        ResourceBundle buttonLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Buttons", pm.language);			

        nextButton.setPreferredSize(LARGE_BUTTON_DIM);
        nextButton.setText(buttonLabels.getString("save"));
        nextButton.setMnemonic(buttonLabels.getString("save.mnemonic").charAt(0));
    }

    /**
     * Class which encapsulates an application item.
     */
    class ThirdPartyComboBoxItem extends ComboBoxItem {

        public Document application;

        public ThirdPartyComboBoxItem(String inName, String inID, Document inApplication) {
            super(inName, inID);

            application = inApplication;

        }

        public String toString() {
            return name;
        }

    }


		
}
