/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.net.URL;
import java.awt.event.*;
import java.util.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

/**
 * Class which encapsulates the Text Reading with Highlight preferences.
 *
 * @author David Weinkauf
 * @revision $Revision: 1.9 $, $Date: 2006/03/28 16:31:10 $
 */
public class TextHighlight extends PWMEditPanel {
  
    /**
     * The voice volume slider.
     */
    private JSlider voiceVolumeSlider;

    /**
     * The voice pitch slider.
     */
    private JSlider voicePitchSlider;

    /**
     * The words per minute field.
     */
    private RangedTextField wpmField;

    /**
     * Check box to enable/disable speaking of alt text.
     */
    private JCheckBox speakAltText;

    /**
     * Check box to enable/disable speaking of links.
     */
    private JCheckBox speakLinks;

    /**
     * The voice pitch slider low, medium, and high labels.
     */
    private JLabel pitchLow, pitchMedium, pitchHigh;
	
    /**
     * The voice volume slider soft, medium and loud labels.
     */
    private JLabel volumeSoft, volumeMedium, volumeLoud;

    /**
     * The four title labels for the differenct sections.
     */
    private JLabel voiceSpeedLabel, voicePitchLabel, voiceVolumeLabel;

    /**
     * The voice title.
     */
    private TitledBorder voiceTitle;

    /**
     * The speech title.
     */
    private TitledBorder speechTitle;

    /**
     * The text highlight title.
     */
    private TitledBorder textHighlightTitle;

    /**
     * The reading unit and highlight combo box.
     */
    private JComboBox readingUnit, highlight;

    /**
     * The reading unit items.
     */
    private ComboBoxItem word, line, sentence, paragraph;

    /**
     * Array of reading unit items.
     */
    private ComboBoxItem[] units, highlights;

    /**
     * The reading unit label.
     */
    private JLabel readingUnitLabel;

    /**
     * All the title labels in the panel.
     */
    private JLabel highlightLabel;

    /**
     * The XML Docuement sub-tree this dialog produces in a user's preferences.
     */
    private Document document;

    /**
     * The generic element of text highlight.
     */
    private Element generic;

    /**
     * The constructor initializes all the components in the dialog and displays them accordingly.
     * @param    pm                     The reference to the PreferenceManagaer.
     * @param    root                   The root of the screen enhance XML sub-tree - that is, 
     *                                  the <text_reading_highlight> Element.
     */
    public TextHighlight(PreferenceManager pm, Element root, String inAppType) {
        super(pm, inAppType, inAppType + TITLE_SUFFIX);

        document = initDocument(root, xmlLabels.getString(TEXT_READING_HIGHLITE), xmlLabels.getString(TR_GENERIC));
        generic = DOMUtil.getFirstChildElement(document.getDocumentElement());
    
        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.TextHighlight",pm.language);
        ResourceBundle voiceLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Voice", pm.language);
        ResourceBundle hashLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.HashTables", pm.language);
    
        // Setup the panel!!!
		
        JTextField textField = new JTextField(5);
        textField.setFont(TEXT_FONT);
    
        wpmField = new RangedTextField(new Integer(1), new Integer(1000), textField);
        wpmField.setText("160");

        voiceSpeedLabel = new JLabel(voiceLabels.getString("voice.speed"));
        voiceSpeedLabel.setDisplayedMnemonic(voiceLabels.getString("voice.speed.mnemonic").charAt(0));
        voiceSpeedLabel.setLabelFor(wpmField.textField);
        voiceSpeedLabel.setForeground(TEXT_COLOUR);
        voiceSpeedLabel.setFont(TEXT_FONT);

        JPanel wpmPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        wpmPanel.setBackground(PANEL_BACKGROUND);
        wpmPanel.add(voiceSpeedLabel);
        wpmPanel.add(wpmField.textField);
		    
        Hashtable voicePitchHash = new Hashtable();
        pitchLow = new JLabel(hashLabels.getString("low"));
        pitchLow.setForeground(TEXT_COLOUR);
        pitchMedium = new JLabel(hashLabels.getString("medium"));
        pitchMedium.setForeground(TEXT_COLOUR);
        pitchHigh = new JLabel(hashLabels.getString("high"));
        pitchHigh.setForeground(TEXT_COLOUR);
        voicePitchHash.put(new Integer(0), pitchLow);
        voicePitchHash.put(new Integer(5), pitchMedium);
        voicePitchHash.put(new Integer(10), pitchHigh);
    
        voicePitchSlider = new JSlider(SwingConstants.HORIZONTAL, 0, 10, 5);
        voicePitchSlider.setBackground(PANEL_BACKGROUND);
        voicePitchSlider.setForeground(TEXT_COLOUR);
        voicePitchSlider.setPaintLabels(true);
        voicePitchSlider.setLabelTable(voicePitchHash);
        voicePitchSlider.setMajorTickSpacing(5);
        voicePitchSlider.setMinorTickSpacing(1);
        voicePitchSlider.setSnapToTicks(true);
        voicePitchSlider.setPaintTicks(true);
    
        voicePitchLabel = new JLabel(voiceLabels.getString("voice.pitch"));
        voicePitchLabel.setDisplayedMnemonic(voiceLabels.getString("voice.pitch.mnemonic").charAt(0));
        voicePitchLabel.setLabelFor(voicePitchSlider);
        voicePitchLabel.setForeground(TEXT_COLOUR);
        voicePitchLabel.setFont(TEXT_FONT);
    
        Hashtable voiceVolumeHash = new Hashtable();
        volumeSoft = new JLabel(hashLabels.getString("soft"));
        volumeSoft.setForeground(TEXT_COLOUR);
        volumeMedium = new JLabel(hashLabels.getString("medium"));
        volumeMedium.setForeground(TEXT_COLOUR);
        volumeLoud = new JLabel(hashLabels.getString("loud"));
        volumeLoud.setForeground(TEXT_COLOUR);
        voiceVolumeHash.put(new Integer(0), volumeSoft);
        voiceVolumeHash.put(new Integer(5), volumeMedium);
        voiceVolumeHash.put(new Integer(10), volumeLoud);
    
        voiceVolumeSlider = new JSlider(SwingConstants.HORIZONTAL, 0, 10, 5);
        voiceVolumeSlider.setBackground(PANEL_BACKGROUND);
        voiceVolumeSlider.setForeground(TEXT_COLOUR);
        voiceVolumeSlider.setPaintLabels(true);
        voiceVolumeSlider.setLabelTable(voiceVolumeHash);
        voiceVolumeSlider.setMajorTickSpacing(5);
        voiceVolumeSlider.setMinorTickSpacing(1);
        voiceVolumeSlider.setSnapToTicks(true);
        voiceVolumeSlider.setPaintTicks(true);
    
        voiceVolumeLabel = new JLabel(voiceLabels.getString("voice.volume"));
        voiceVolumeLabel.setDisplayedMnemonic(voiceLabels.getString("voice.volume.mnemonic").charAt(0));
        voiceVolumeLabel.setLabelFor(voiceVolumeSlider);
        voiceVolumeLabel.setForeground(TEXT_COLOUR);
        voiceVolumeLabel.setFont(TEXT_FONT);
    

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel voiceGridPanel = new JPanel();
        voiceGridPanel.setBackground(PANEL_BACKGROUND);
        voiceGridPanel.setLayout(gridbag);

        Insets insets = new Insets(5, 5, 5, 5);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 1;
        c.weightx = 0.0;
        voiceGridPanel.add(voicePitchLabel, c);

        c.gridx = 1;
        c.gridy = 1;
        c.weightx = 0.5;
        voiceGridPanel.add(voicePitchSlider, c);

        c.gridx = 0;
        c.gridy = 2;
        c.weightx = 0.0;
        voiceGridPanel.add(voiceVolumeLabel, c);

        c.gridx = 1;
        c.gridy = 2;
        c.weightx = 0.5;
        voiceGridPanel.add(voiceVolumeSlider, c);

        voiceTitle = new TitledBorder(BORDER_TITLE_LINE, voiceLabels.getString("voice.title"));
        voiceTitle.setTitleFont(BORDER_TITLE_FONT);
        voiceTitle.setTitleColor(BORDER_TITLE_COLOUR);

        JPanel voiceSliderPanel = new JPanel(new GridLayout(1, 1));
        voiceSliderPanel.setBackground(PANEL_BACKGROUND);
        voiceSliderPanel.add(voiceGridPanel);

        JPanel voicePanel = new JPanel();
        voicePanel.setLayout(new BoxLayout(voicePanel, BoxLayout.Y_AXIS));
        voicePanel.setBorder(voiceTitle);
        voicePanel.setBackground(PANEL_BACKGROUND);
        voicePanel.add(wpmPanel);
        voicePanel.add(voiceSliderPanel);

        AccessibleContext ac = voiceSpeedLabel.getAccessibleContext();
        ac.setAccessibleParent(voicePanel);
        ac = wpmField.textField.getAccessibleContext();
        ac.setAccessibleParent(voicePanel);
        ac = voicePitchLabel.getAccessibleContext();
        ac.setAccessibleParent(voicePanel);
        ac = voicePitchSlider.getAccessibleContext();
        ac.setAccessibleParent(voicePanel);
        ac = voiceVolumeLabel.getAccessibleContext();
        ac.setAccessibleParent(voicePanel);
        ac = voiceVolumeSlider.getAccessibleContext();
        ac.setAccessibleParent(voicePanel);

        this.add(voicePanel);
        this.add(Box.createVerticalGlue());
    
        speakAltText = new JCheckBox(labels.getString("speak.alt.text"));
        speakAltText.setMnemonic(labels.getString("speak.alt.text.mnemonic").charAt(0));
        speakAltText.setBackground(PANEL_BACKGROUND);
        speakAltText.setSelected(true);
        speakAltText.setFont(TEXT_FONT);
    
        JPanel speakAltPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        speakAltPanel.setBackground(PANEL_BACKGROUND);
        speakAltPanel.add(speakAltText);

        speakLinks = new JCheckBox(labels.getString("speak.links.when.tabbing"));
        speakLinks.setMnemonic(labels.getString("speak.links.when.tabbing.mnemonic").charAt(0));
        speakLinks.setBackground(PANEL_BACKGROUND);
        speakLinks.setSelected(true);
        speakLinks.setFont(TEXT_FONT);
    
        JPanel speakLinksPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        speakLinksPanel.setBackground(PANEL_BACKGROUND);
        speakLinksPanel.add(speakLinks);
    
        speechTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("speech.title"));
        speechTitle.setTitleFont(BORDER_TITLE_FONT);
        speechTitle.setTitleColor(BORDER_TITLE_COLOUR);

        word = new ComboBoxItem(labels.getString("word"), "word");
        line = new ComboBoxItem(labels.getString("line"), "line");
        sentence = new ComboBoxItem(labels.getString("sentence"), "sentence");
        paragraph = new ComboBoxItem(labels.getString("paragraph"), "paragraph");

        ComboBoxItem[] tempUnits = {word, line, sentence, paragraph};
        units = tempUnits;

        readingUnit = new JComboBox(units);
        readingUnit.setBackground(PANEL_BACKGROUND);
        readingUnit.setForeground(TEXT_COLOUR);
        readingUnit.setFont(TEXT_FONT);

        readingUnitLabel = new JLabel(labels.getString("reading.unit"));
        readingUnitLabel.setFont(TEXT_FONT);
        readingUnitLabel.setBackground(PANEL_BACKGROUND);
        readingUnitLabel.setForeground(TEXT_COLOUR);
        readingUnitLabel.setLabelFor(readingUnit);
        readingUnitLabel.setDisplayedMnemonic(labels.getString("reading.unit.mnemonic").charAt(0));

        JPanel readingUnitPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        readingUnitPanel.setBackground(PANEL_BACKGROUND);
        readingUnitPanel.add(readingUnitLabel);
        readingUnitPanel.add(readingUnit);

        JPanel speechPanel = new JPanel(new GridLayout(2, 2));
        speechPanel.setBorder(speechTitle);
        speechPanel.setBackground(PANEL_BACKGROUND);
        speechPanel.add(speakAltPanel);
        speechPanel.add(readingUnitPanel);
        speechPanel.add(speakLinksPanel);

        ac = speakAltText.getAccessibleContext();
        ac.setAccessibleParent(speechPanel);
        ac = speakLinks.getAccessibleContext();
        ac.setAccessibleParent(speechPanel);
        ac = readingUnitLabel.getAccessibleContext();
        ac.setAccessibleParent(speechPanel);
        ac = readingUnit.getAccessibleContext();
        ac.setAccessibleParent(speechPanel);

        this.add(speechPanel);    
        this.add(Box.createVerticalGlue());

        highlights = tempUnits;

        highlight = new JComboBox(units);
        highlight.setBackground(PANEL_BACKGROUND);
        highlight.setForeground(TEXT_COLOUR);
        highlight.setFont(TEXT_FONT);
        
        highlightLabel = new JLabel(labels.getString("highlight"));
        highlightLabel.setBackground(PANEL_BACKGROUND);
        highlightLabel.setForeground(TEXT_COLOUR);
        highlightLabel.setFont(TEXT_FONT);
        highlightLabel.setLabelFor(highlight);
        highlightLabel.setDisplayedMnemonic(labels.getString("highlight.mnemonic").charAt(0));
		
        JPanel highlightButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        highlightButtonPanel.setBackground(PANEL_BACKGROUND);
        highlightButtonPanel.add(highlightLabel);
        highlightButtonPanel.add(highlight);

        textHighlightTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("text.highlight.title"));
        textHighlightTitle.setTitleFont(BORDER_TITLE_FONT);
        textHighlightTitle.setTitleColor(BORDER_TITLE_COLOUR);

        JPanel highlightPanel = new JPanel();
        highlightPanel.setLayout(new BoxLayout(highlightPanel, BoxLayout.Y_AXIS));
        highlightPanel.setBorder(textHighlightTitle);
        highlightPanel.setBackground(PANEL_BACKGROUND);
        highlightPanel.add(highlightButtonPanel);
    
        ac = highlightLabel.getAccessibleContext();
        ac.setAccessibleParent(highlightPanel);
        ac = highlight.getAccessibleContext();
        ac.setAccessibleParent(highlightPanel);

        this.add(highlightPanel);    
        this.add(Box.createVerticalGlue());    	

    }

    /**
     * Set all the JPanel labels to the current PreferenceManager.language value.
     */
    protected void setNewLabels() {
        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.TextHighlight", pm.language);
        ResourceBundle newHashLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.HashTables", pm.language);
        ResourceBundle newVoiceLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Voice", pm.language);
    
        voiceSpeedLabel.setText(newVoiceLabels.getString("voice.speed"));
        voiceSpeedLabel.setDisplayedMnemonic(newVoiceLabels.getString("voice.speed.mnemonic").charAt(0));
        pitchLow.setText(newHashLabels.getString("low"));
        pitchMedium.setText(newHashLabels.getString("medium"));
        pitchHigh.setText(newHashLabels.getString("high"));
        voicePitchLabel.setText(newVoiceLabels.getString("voice.pitch"));
        voicePitchLabel.setDisplayedMnemonic(newVoiceLabels.getString("voice.pitch.mnemonic").charAt(0));
        volumeSoft.setText(newHashLabels.getString("soft"));
        volumeMedium.setText(newHashLabels.getString("medium"));
        volumeLoud.setText(newHashLabels.getString("loud"));
        voiceVolumeLabel.setText(newVoiceLabels.getString("voice.volume"));
        voiceVolumeLabel.setDisplayedMnemonic(newVoiceLabels.getString("voice.volume.mnemonic").charAt(0));
		
        readingUnitLabel.setText(newLabels.getString("reading.unit"));
        readingUnitLabel.setDisplayedMnemonic(newLabels.getString("reading.unit.mnemonic").charAt(0));

        word.name = newLabels.getString("word");
        line.name = newLabels.getString("line");
        sentence.name = newLabels.getString("sentence");
        paragraph.name = newLabels.getString("paragraph");

        voiceTitle.setTitle(newVoiceLabels.getString("voice.title"));
        speechTitle.setTitle(newLabels.getString("speech.title"));
        textHighlightTitle.setTitle(newLabels.getString("text.highlight.title"));

        speakAltText.setText(newLabels.getString("speak.alt.text"));
        speakAltText.setMnemonic(newLabels.getString("speak.alt.text.mnemonic").charAt(0));
        speakLinks.setText(newLabels.getString("speak.links.when.tabbing"));
        speakLinks.setMnemonic(newLabels.getString("speak.links.when.tabbing.mnemonic").charAt(0));

        highlightLabel.setText(newLabels.getString("highlight"));
        highlightLabel.setDisplayedMnemonic(newLabels.getString("highlight.mnemonic").charAt(0));

        wpmField.reformat();

        setNewButtonLabels();
    
        revalidate();
        repaint();
    
    }

    /**
     * Does the default settings for the UI.
     */
    protected void doDefault() {
        wpmField.setText("160");
        voicePitchSlider.setValue(5);
        voiceVolumeSlider.setValue(5);
        speakAltText.setSelected(true);
        speakLinks.setSelected(true);
        highlight.setSelectedItem(word);
        readingUnit.setSelectedItem(word);
    }

    /**
     * Sets all the JPanel's components to their correct values corresponding to 
     * the user's XML preferences passed in through the constructor.
     */
    protected void setDomValues() {
        Element temp = DOMUtil.getFirstChildElement(generic);

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(TR_GENERIC_SPEECH_RATE))) {
            wpmField.setText(temp.getAttribute(VALUE));
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(TR_GENERIC_PITCH))) {
            voicePitchSlider.setValue( (int) (Float.parseFloat(temp.getAttribute(VALUE)) * 10) );
            temp = DOMUtil.getNextSiblingElement(temp);
        }
			
        if (temp != null && temp.getTagName().equals(xmlLabels.getString(TR_GENERIC_VOLUME))) {
            voiceVolumeSlider.setValue( (int) (Float.parseFloat(temp.getAttribute(VALUE)) * 10) );
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(TR_GENERIC_HIGHLITE))) {
            highlight.setSelectedItem(findItem(highlights, temp.getAttribute(VALUE)));
            temp = DOMUtil.getNextSiblingElement(temp);
        }
		
        if (temp != null && temp.getTagName().equals(xmlLabels.getString(TR_GENERIC_ALT))) {
            if (temp.getAttribute(VALUE).equals("true"))
                speakAltText.setSelected(true);
            else if (temp.getAttribute(VALUE).equals("false"))
                speakAltText.setSelected(false);
			
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(TR_GENERIC_TABBING))) {
            if (temp.getAttribute(VALUE).equals("true"))
                speakLinks.setSelected(true);
            else if (temp.getAttribute(VALUE).equals("false"))
                speakLinks.setSelected(false);
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(TR_GENERIC_READING_UNIT))) {
            readingUnit.setSelectedItem(findItem(units, temp.getAttribute(VALUE)));
        }
    }

    /**
     * Constructs the XML sub-tree for keyboard setup according to the user's current selections.
     *
     * @return    Element    The root element of the new XML sub-tree created.
     */
    protected Element getRootElement() {
        Element temp;
    
        PreferenceManager.removeAllChildren(generic);

        temp = document.createElement(xmlLabels.getString(TR_GENERIC_SPEECH_RATE));
        temp.setAttribute(VALUE, wpmField.getValue());
        generic.appendChild(temp);
    
        temp = document.createElement(xmlLabels.getString(TR_GENERIC_PITCH));
        temp.setAttribute(VALUE, String.valueOf(voicePitchSlider.getValue() / 10.0));
        generic.appendChild(temp);
    
        temp = document.createElement(xmlLabels.getString(TR_GENERIC_VOLUME));
        temp.setAttribute(VALUE, String.valueOf(voiceVolumeSlider.getValue() / 10.0));
        generic.appendChild(temp);
    
        temp = document.createElement(xmlLabels.getString(TR_GENERIC_HIGHLITE));
        ComboBoxItem highlightItem = (ComboBoxItem) highlight.getSelectedItem();
        temp.setAttribute(VALUE, highlightItem.value);

        generic.appendChild(temp);
    
        temp = document.createElement(xmlLabels.getString(TR_GENERIC_ALT));
        if (speakAltText.isSelected())
            temp.setAttribute(VALUE, "true");
        else
            temp.setAttribute(VALUE, "false");

        generic.appendChild(temp);
    
        temp = document.createElement(xmlLabels.getString(TR_GENERIC_TABBING));
        if (speakLinks.isSelected())
            temp.setAttribute(VALUE, "true");
        else
            temp.setAttribute(VALUE, "false");
        generic.appendChild(temp);


        temp = document.createElement(xmlLabels.getString(TR_GENERIC_READING_UNIT));
        ComboBoxItem readingItem = (ComboBoxItem) readingUnit.getSelectedItem();
        temp.setAttribute(VALUE, readingItem.value);

        generic.appendChild(temp);

        return document.getDocumentElement();
    }

    /**
     * Shows the next panel.
     */
    protected void doNext() {
        ResourceBundle voiceLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Voice", pm.language);

        if (!wpmField.isInsideRange())
            pm.doRangeWarning(wpmField.getLowValue(), 
                              wpmField.getHighValue(), 
                              voiceLabels.getString("voice.speed"));
        else
            super.doNext();
    }

    /**
     * Shows the previous panel.
     */
    protected void doPrev() {
        pm.doPrevAppType(appType);
    }
 
    /**
     * Gets AT type's document.
     */
    protected Document getAppTypeDoc() {
        return document;
    }
 
}
