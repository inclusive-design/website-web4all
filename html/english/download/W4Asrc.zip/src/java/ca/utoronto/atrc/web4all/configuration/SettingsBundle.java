/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 *
 * File:        SettingsBundle.java
 *
 * Synoposis:   package ca.utoronto.atrc.web4all.configuration;
 *
]*/

package ca.utoronto.atrc.web4all.configuration;

import java.util.ListResourceBundle;
import java.util.Enumeration;

/**
 * Specialized ResourceBundle that is identified based on an ACCLIP technology type,
 * and that contains a look up table of ParameterState objects.  This class remains
 * abstract since it does not implement the <code>getContents()</code> method of ResourceBundle.
 * @version $Id: SettingsBundle.java,v 1.3 2006/03/28 21:17:27 clown Exp $
 * @author Joseph Scheuhammer
 */
public abstract class SettingsBundle extends ListResourceBundle
{
    /**
     * The type of technology, as specified in the ACCLIP, that this bundle is for.
     */
    private String theTechType;
    
    /**
     * Initialize a SettingsBundle with the given ACCLIP technology type.
     * @param   inTechType  The type of technology (e.g. "screenReader") that this bundle
     *                      of settings is for.
     */
    public SettingsBundle (String inTechType)
    {
        super();
        theTechType = inTechType;
        
    }   // end SettingsBundle().

    /**
     * Return the type of technology that this bundle of settings is for.  This type is
     * taken from the ACCLIP vocabulary.
     * @return      An ACCLIP technology type (String).
     */
    public String getTechType()
    {
        return theTechType;
    
    }   // end getTechType().

    /**
     * Utility for setting the "parameter written" state to false for all of the ParameterState
     * instances contained in this bundle.
     */
    public void clearWrittenState()
    {
        Enumeration keys = getKeys();
        while (keys.hasMoreElements())
        {
            ParameterState aParamState = (ParameterState) getObject ((String) keys.nextElement());
            aParamState.setSetState (false);
        }
        
    }   // end clearWrittenState().

}   // end class SettingsBundle.
