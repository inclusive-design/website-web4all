/**
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 */   
package ca.utoronto.atrc.web4all;

import ca.utoronto.atrc.web4all.web4AllCardService.*;
import java.util.*;
import opencard.core.*;
import opencard.core.service.*;
import opencard.core.event.*;
import opencard.core.terminal.*;
import opencard.core.terminal.CardTerminalRegistry;
import opencard.core.util.*;
import opencard.opt.util.*;
import opencard.opt.iso.fs.*;
import javax.swing.*;

/**
  * A class to perform the processing needed when a card is removed. This class
  * has the following responsibilities:
*/   
public class RemoveProcessor implements Runnable {
	private CardControl theCC;			// Class which starts OCF and this object.
	private ControlHub w4a;				// Object which communicates with user and configures system.
	
	public RemoveProcessor(CardControl cc) {
		super();
		theCC = cc;
	}
	
/**	
  * Thread's run method. 
*/   
	public synchronized void run() {
        synchronized (theCC) {
            theCC.notify();	// Tell CardControl we're ready for work.
        }
		
		while (true) {
			try {
                SmartCardLogFile.writeLog("RemoveProcessor is beginning its wait.", SmartCardLogFile.LOG_DEBUG);
				this.wait();	// wait until CardControl tells us a card has been removed.
                SmartCardLogFile.writeLog("RemoveProcessor has ended its wait.", SmartCardLogFile.LOG_DEBUG);
			}
			catch (InterruptedException ie) {
                SmartCardLogFile.writeLog("RemoveProcessor caught InterruptedException.", SmartCardLogFile.LOG_DEBUG);
                Thread.currentThread().interrupt(); // Set our interrupted status.
			}
			if (! theCC.reset()) {
				SmartCardLogFile.writeLog("Reset failed");
				//FIXME do something here...
			} 
			// shutdown web4All if it's running.
			if (theCC.getw4aStatus()) {
				w4a = theCC.getWeb4All();  // Get the ControlHub object.  
				SmartCardLogFile.writeLog("Sending stop to ControlHub.");
				w4a.stopIt();
				SmartCardLogFile.writeLog("Stop has been sent to ControlHub.");
			}
			else {
				SmartCardLogFile.writeLog("Web4All not started; stop not needed.");
			}
            // Check for shutdown signal.
            if (Thread.currentThread().isInterrupted()) {
                break; // we're done.
            }
			// Unless we're handling multiple sessions, shut the entire application down.
			if (! theCC.multipleSessions()) {
				SmartCardLogFile.writeLog("RemoveProcessor is initiating shutdown.");
				ControlHub.stopWeb4All();
				theCC.shutDown();
				break;
			}
			else {
				w4a = theCC.getWeb4All();  // Get the ControlHub object.  
    			w4a.updateStatusMessage(theCC.lookup("CC.waitForInsert"));
			}
		}
		SmartCardLogFile.writeLog("RemoveProcessor is finished.");
	}
}
	
	

