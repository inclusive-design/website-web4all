/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * 
 * File:        SetterLauncher.java
 *
 * Synoposis:   package ca.utoronto.atrc.web4all.configuration;
 *
]*/

package ca.utoronto.atrc.web4all.configuration;

import java.util.Vector;
import ca.utoronto.atrc.web4all.*;    // for ControlHub.

/**
 * Interface that defines the configuration plug-in API.
 *
 * @version $Id: SetterLauncher.java,v 1.6 2006/03/28 21:17:27 clown Exp $
 * @author Joseph Scheuhammer
 */

public interface SetterLauncher
{
    /**
     * Configure an application/technology based on the given ACCLIP preferences.
     * The preferences are given as a list of AccLipInfoPackage objects.  Each AccLipInfoPackage
     * is identified as a specific kind of technology (e.g., a screen reader), and contains
     * a set of generic and specific settings for that technology.  The type and settings
     * use the vocabulary of the ACCLIP schema.
     * @param       inAccLipInfoPackages    A Vector of AccLipInfoPackage instances.
     * @param       inControlHub            The ControlHub object that contains information about the technology
     *                                      such as the location of an ".ini" file and the path to the
     *                                      executable.
     * @return                              A flag indicating whether this SetterLauncher launches
     *                                      a browser.
     * @see AccLipInfoPackage
     * @see ControlHub
     */
    public boolean doSettings (Vector inAccLipInfoPackages, ControlHub inControlHub);

    /**
     * Launch the technology.  <code>doSettings()</code> should
     * be called first to configure the technology prior to launching it.
     * @see #doSettings(Vector,ControlHub)
     */
    public void doLaunch();

    /**
     * Reset the technology to its standard configuration, and exit the process launched by <code>doLaunch()</code>.
     * @see #doLaunch()
     */
    public void kill();

    /**
     * Used to initialize any of the plug-in's local properties.
     * @return      A flag that indicates sucesss or failure.
     */
    public boolean initLocalProps();

}   // end interface SetterLauncher.
