/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:			ConfigPluginInfo.java
 *
 * Synopsis:		package ca.utoronto.atrc.web4all.configuration;
 * 
]*/

package ca.utoronto.atrc.web4all.configuration;

import org.w3c.dom.*;
import org.apache.xpath.XPathAPI;
import javax.xml.transform.TransformerException;

import ca.utoronto.atrc.web4all.*;

/**
 * Class that contains information about a configuration plugin.
 *
 * @version $Id: ConfigPluginInfo.java,v 1.4 2006/03/28 21:17:27 clown Exp $
 * @author	Joseph Scheuhammer.
 */
	
public class ConfigPluginInfo
{
    /**
     * Special priority denoting that the plugin was picked not chosen by the user, but
     * was picked up from the system.
     */
    public final static int NO_PRIORITY =   0;
    
    /**
     * Constant "suffix" for generic settings.
     */
    public final static String GENERIC  =   "Generic";
    
	/** 
	 * The application name.
	 */
	private String theAppName;
	
	/**
	 * The &lt;application&gt; element, if any, from  the &lt;accessForAll&gt; user preferences that
	 * was used to choose <code>thePluginName</code>.
	 */
	private Element theAppTag;
	
	/**
	 * The &lt;application&gt;'s "parent" Element from the &lt;accessForAll&gt; user preferences.
	 * This may be the actual parent, or, if <code>theAppTag</code> was created outside of the
	 * preferences document, the parent Element it would have if it were part of that document.
	 */
	private Element theAppTagParent;
	
	/** 
	 * The priority associated with the plugin as taken, for example, from the <accessForAll>
	 * preferences.
	 */
	private Integer thePriority;
	
    /**
     * No argument constructor. Initialize the instance with "null" values.
     */
	public ConfigPluginInfo()
	{
	    super();
	    theAppName = null;
	    theAppTag = null;
	    theAppTagParent = null;
	    thePriority = new Integer (0);
	
	}	// end ConfigPluginInfo()

    /**
     * Constructor that initializes the instance with values from a preferences document, and, in
     * particular, an application Element with a declared priority.  (Note: if the application 
     * Element does not have a priority attribute, it is set to NO_PRIORITY herein, and assumed
     * to mean that it's not part of the preferences document, but a "stand-alone" Element).
     * @param   inAppName       The application name for this plugin. 
     * @param   inAppTag        The &lt;application&gt; tag that was used to choose
     *                          the SetterLauncher.  This can be <code>null</code>, in which
     *                          case the assumed priority of the application is zero.
     * @param   inParent        The Element that is the parent of <code>inAppTage></code>.  If
     *                          <code>inAppTag</code> is embedded within a larger preferences
     *                          document, this is its actual parent Element.  If
     *                          <code>inAppTag</code> is a "stand alone" element, this is the
     *                          parent it would have if it were part of the preferences document.
     * @param   inConfigInfo    Contains information about application plugins.
     */
	public ConfigPluginInfo (String inAppName, Element inAppTag, Element inParent, ControlHub inConfigInfo)
	{
	    this();
	    theAppName = inAppName;
	    theAppTag = inAppTag;
	    theAppTagParent = inParent;
	    
	    // If no <application> element, assume a priority of zero (done in zero-arg
	    // constructor).  If there is an <application> tag, get its priority out.
	    //
	    if (theAppTag != null)
	    {
	        String attrName = inConfigInfo.getPrefElementName (Web4AllConstants.APP_PRIORITY);
	        String priorityAttr = inAppTag.getAttribute (attrName);
	        if (priorityAttr.length() == 0)
	            thePriority = new Integer (ConfigPluginInfo.NO_PRIORITY);
	        else
	            thePriority = new Integer (priorityAttr);
	    }
	    
	}   // end ConfigPluginInfo().

    /**
     * Retrieve the plugin (SetterLauncher) name in this configuration plugin information package.
     *.@return      The fully qualified name of the SetterLauncher, if any.
     */
    public String getAppName()
    {
        return theAppName;
    
    }   // end getAppName().
	
    /**
     * Retrieve the &lt;application&gt; start tag associated with the plugin.
     *.@return      The &lt;application&gt; Element, if any.
     */
    public Element getAppTag()
    {
        return theAppTag;
    
    }   // end getAppTag().
	
    /**
     * Retrieve the priority for this application.  Note that this is usually the user's
     * preferred priority.  If this plugin was chosen some other way, then its priority
     * can be zero.
     *.@return      The priority of this application.
     */
    public int getPriority()
    {
        return thePriority.intValue();
    
    }   // end getPriority().

    /**
     * Based on the application's parent Element, determine the type of assistive technology
     * technology this plugin is for.  In essence, this returns the name of that parent Element.
     *.@return      The name of the parent Element, if any.  If there is no parent,
     *              <code>null</code> is returned.
     * @see #getParentPrefElementNameKey
     */
    public String getAppTypeFromParent()
    {
        String result = null;       // return value.
        
        // Get the name of that parent.
        //
        if (theAppTagParent != null)
            result = theAppTagParent.getTagName();
        
        return result;
    
    }   // end getAppTypeFromParent().
    
    /**
     * Return the generic settings associated with this plugin.  This uses the application's
     * parent Element to find those generic settings.  If that parent is <code>null</code>, or
     * if it has no generic children, a TransformerException is thrown.
     * @return      The Element that contains the generic settings, e.g., "screenReaderGeneric".
     * @exception   javax.xml.transform.TransformerException
     */
    public Element getGenericSettings() throws javax.xml.transform.TransformerException
    {
        Element result = null;
        if (theAppTagParent == null)
            throw new TransformerException ("No technology parent for application tag");

        String genericTagName = theAppTagParent.getTagName() + ConfigPluginInfo.GENERIC;
        return ( (Element) XPathAPI.selectSingleNode (theAppTagParent, genericTagName) );
    
    }   // end getGenericSettings().
	
}	// end class ConfigPluginInfo.

