/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:			SplashScreen.java
 *
 * Synoposis:		package ca.utoronto.atrc.web4all;
 * 
 * Description:		Panel for displaying the Web4All splash screen.
 * 
]*/

package ca.utoronto.atrc.web4all;

import java.awt.*;
import java.awt.event.*;
import java.net.*;				// for URL, etc.
import java.util.*;				// for ResourceBundle, etc.
import java.io.*;				// for IOException.

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import javax.swing.text.html.*;
import javax.swing.border.*;

/**
 * Contents of the Web4All splash screen.
 *
 * @version $Revision: 1.9 $
 * @author Joseph Scheuhammer.
 * @author David Weinkauf
 */
	
public class SplashScreen extends JPanel implements MouseListener
{

	/**
	 * The key to the Web-4-All info logo.
	 */
	private final static String W4A_SPLASH_ICON = "w4a.splash.icon";
	
	/**
	 * Suffix for the key to the alt text for the icons.
	 */
	private final static String ALT_SUFFIX	=	".alt";

	/**
	 * The label on the "edit preferences" button -- key to resources.
	 */
	public final static String EDIT_PREFS		=	"edit.prefs";

	/**
	 * The mnemonic on the "edit preferences" button -- key to resources.
	 */
	public final static String EDIT_MNEMONIC	=	"edit.mnemonic";

	/**
	 * The statis message for "editing preferences" -- key to resources.
	 */
	public final static String EDITING_PREFS	=	"editing.prefs";

	/**
	 * The action commad for the "edit preferences" button.
	 */
	public final static String EDIT_ACTION		=	"edit";

	/**
	 * The label on the "cancel" button -- key to resource.
	 */
	public final static String CANCEL_CONFIG 	=	"config.cancel";

	/**
	 * The mnemonic on the "cancel" button -- key to resources.
	 */
	public final static String CANCEL_MNEMONIC	=	"cancel.mnemonic";

	/**
	 * The status message when "cancelling the configuration"  -- key to resource.
	 */
	public final static String CANCEL_CONFIGING	=	"configing.cancel";

	/**
	 * The label on the "cancel" button, when it is in the configure state.
	 */
	public final static String DO_CONFIG		=	"config.sys";

	/**
	 * The mnemonic on the "cancel" button, when it is in the configure state.
	 */
	public final static String CONFIG_MNEMONIC	=	"config.mnemonic";

	/**
	 * The action commad for the "cancel" button, when it is in the cancel state.
	 */
	public final static String CANCEL_ACTION	=	"cancel";

	/**
	 * The action commad for the "cancel" button, when it is in the configuration state.
	 */
	public final static String CONFIG_ACTION	=	"config";

	/**
	 * The status message when "configuring the system"  -- key to resource.
	 */
	public final static String DOING_CONFIG		=	"configing.sys";

	/**
	 * The message to display in the are-you-sure-you-want-to-quit confirmation dialogue.
	 */
	public final static String CONFIRM_QUIT		=	"confirm.quit";

	/**
	 * The action command for the quit operation
	 */
	public final static String QUIT_ACTION      =	"quit";

	/**
	 * The edge buffer in pixels for the ATRC credit and status message.
	 */
	private final static int EDGE_BUFFER = 3;

	/**
	 * The preferred button width for the splash screen buttons.
	 */
	private final static int BUTTON_WIDTH = (int) ((ControlHub.SPLASH_WIDTH / 2) - (ControlHub.SPLASH_WIDTH / 8));

	/**
	 * The preferred button height for the splash screen buttons.
	 */
	private final static int BUTTON_HEIGHT = 25;

	/**
	 * Panel for showing "Welcome..." messages and pictures.
	 */
	private JPanel theWelcomePane;
		
	/**
	 * For status messages.
	 */
	private JLabel theStatusMsg;
		
	/**
	 * The control panel.
	 */
	private JPanel theControlPanel;
	
	/**
	 * The edit preferences button.
	 */
	private JButton theEditButton;
	
	/**
	 * The cancel button.
	 */
	private JButton theCancelButton;
	
	/**
	 * The ActionListener for the above buttons.
	 */
	private ActionListener theActionListener;
		
	/**
	 * The labels for the buttons.
	 */
	private ResourceBundle theLabels;
	
	/**
	 * The current Locale.
	 */
	private Locale theLocale;
	
	/**
	 * The main splash screen Web-4-All label.
	 */
	private JLabel w4aInfoLabel;
    
    /**
     * Audio feedback for configuring/resetting.
     */
    private ProminentNotificator theAudioFeedback;

    /**
     * Constructor -- call super().
     * @param	inActionListener	An ActionListener to attach to the buttons in the GUI.
     */
    
    public SplashScreen (ActionListener inActionListener)
    {
    	super();
    	theActionListener = inActionListener;
    	theStatusMsg = null;		// set in updateStatusMessage().
    	theLocale = Locale.getDefault();
        theAudioFeedback = null;    // set in init().
    	
    }	// end SplashScreen().


    /**
     * Initialize the panel -- create the GUI and put it together.
     */
	public void init() {

		// Get the resources for the splash screen.
    	//
    	try
    	{
    		theLabels = ResourceBundle.getBundle ("ca.utoronto.atrc.web4all.Splash");
    	}
    	catch (MissingResourceException mre)
    	{
    		mre.printStackTrace();		// shouldn't happen...
    	}
     	theLocale = Locale.getDefault();
   	
		// Change the layout of the panel's content to BoxLayout.
		//
		setLayout (new BoxLayout (this, BoxLayout.Y_AXIS));

		// Create the welcome panel.
		//
	    theWelcomePane = new JPanel();

		theWelcomePane.setLayout (new BoxLayout (theWelcomePane, BoxLayout.Y_AXIS));
		theWelcomePane.setBackground (Color.white);

		Class splashClass = getClass();

		// Create the Web-4-All info panel
		ImageIcon w4aInfoIcon = new ImageIcon (splashClass.getResource ( theLabels.getString(W4A_SPLASH_ICON)), theLabels.getString(W4A_SPLASH_ICON + ALT_SUFFIX) );

		w4aInfoLabel = new JLabel(w4aInfoIcon, JLabel.CENTER);
                w4aInfoLabel.getAccessibleContext().setAccessibleName(
                    theLabels.getString(W4A_SPLASH_ICON + ALT_SUFFIX));

		JPanel w4aInfoPanel = new JPanel();
		w4aInfoPanel.setBackground(Color.white);
		w4aInfoPanel.setLayout (new BoxLayout(w4aInfoPanel, BoxLayout.X_AXIS));
		w4aInfoPanel.add(Box.createHorizontalGlue());
		w4aInfoPanel.add(w4aInfoLabel);
		w4aInfoPanel.add(Box.createHorizontalGlue());

		theWelcomePane.add(Box.createVerticalGlue());
		theWelcomePane.add(w4aInfoPanel);
		theWelcomePane.add(Box.createVerticalGlue());
		
	    // Create the status message panel.
	    //
	    JPanel statusPanel = new JPanel ();

		statusPanel.setLayout(new BoxLayout(statusPanel, BoxLayout.X_AXIS));
	    statusPanel.setBackground (Color.white);

	    theStatusMsg = new JLabel (" ", JLabel.LEFT);	// space.
	    theStatusMsg.setForeground (Color.black);

		// Push the status message to the bottom of the panel.
		JPanel innerStatusPanel = new JPanel();

		innerStatusPanel.setLayout(new BoxLayout(innerStatusPanel, BoxLayout.Y_AXIS));
		innerStatusPanel.setBackground(Color.white);
		innerStatusPanel.add(Box.createVerticalGlue());
		innerStatusPanel.add(theStatusMsg);

		statusPanel.add (Box.createHorizontalStrut(EDGE_BUFFER));
	    statusPanel.add (innerStatusPanel);
		statusPanel.add (Box.createHorizontalGlue());

		theWelcomePane.add (statusPanel);
	    		
		add(theWelcomePane);

		// Create the control panel.  Set <theCancelButton> enabled state according to
		// the "enable-config" client property, if there is one.
		//
		createControlPanel();
		Boolean enableProp = (Boolean) getClientProperty (Web4AllPropNames.ENABLE_CONFIG);
		if (enableProp != null)
		{
		    // Insure that the label on the button is "Configure..." when it is disabled.
		    //
		    if (enableProp.booleanValue() == false)
		        toggleCancelSense();

		    theCancelButton.setEnabled (enableProp.booleanValue());
		}
		add (theControlPanel);
		
		// Add the quit mouse gesture.
		//
		addMouseListener (this);
        
        // Allocate the audio feed back for configuring/resetting if needed.
        //
        Boolean notify = (Boolean) getClientProperty (Web4AllPropNames.NOTIFY);
	    if ((notify != null) && (notify.booleanValue() == true))
        {
            theAudioFeedback = new ProminentNotificator();
        }
        
	} // end init()


	/**
	 * Accessor for getting labels for buttons.
	 * @param	inKey	Key for the label sought (String).
	 * @return			The label corresponding to <code>inKey</code>.
	 * @exception		java.util.MissingResourceException
	 */
	public String getLabel (String inKey) throws MissingResourceException
	{
		return theLabels.getString (inKey);
	
	}	// end getLabel().

	/**
	 * If the locale "changes" during running, this will switch the labels of the buttons
	 * to the new locale, if it can.
	 * @param	inLocale	The new Locale.  If this is the same as the current Locale,
	 *						nothing happens.
	 */
	public void updateLocale (Locale inLocale)
	{
		// Do nothing if this is not a new locale.
		//
		if (!(theLocale.equals (inLocale)))
		{
			try
			{
				theLocale = inLocale;

				// First the buttons.
				//
    			theLabels = ResourceBundle.getBundle ("ca.utoronto.atrc.web4all.Splash", inLocale);
    			if (theEditButton != null)
    			{
    				theEditButton.setText (getLabel (EDIT_PREFS));
    				theEditButton.setMnemonic (getLabel (EDIT_MNEMONIC).charAt (0));
    			}
    			if (theCancelButton != null)
    			{
    				if (getCancelSense() == CANCEL_ACTION)
    				{
    					theCancelButton.setText (getLabel (CANCEL_CONFIG));
    					theCancelButton.setMnemonic (getLabel (CANCEL_MNEMONIC).charAt (0));
    				}
    				else
    				{
    					theCancelButton.setText (getLabel (DO_CONFIG));
    					theCancelButton.setMnemonic (getLabel (CONFIG_MNEMONIC).charAt (0));
    				}
    			}
    			
				// Then the main splash screen image.
				//
				Class splashClass = getClass();
				ImageIcon w4aInfoIcon = new ImageIcon (splashClass.getResource ( theLabels.getString(W4A_SPLASH_ICON)), theLabels.getString(W4A_SPLASH_ICON + ALT_SUFFIX) );
				w4aInfoLabel.setIcon(w4aInfoIcon);

    			// When changing languages, just "flush" the status message.
    			//
    			updateStatusMessage (null);
    		}
    		catch (MissingResourceException mre)
    		{
				mre.printStackTrace();		// can't happen.
    		}
		}
			
	}	// end updateLocale().

	/**
	 * Accessor to allow clients to change the sense of the configuration button.  Whatever
	 * its current label and action, this changes it to the other.  For example, if it is
	 * set to "Configure system", then calling this method would change it to
	 * "Cancel configuration"; and vice versa.  Call this from within an event handler
	 * such as an action listener, where it is known that the system is just about to be
	 * configured or "de-configured", and this button's label should therefore change.
	 * @see #getCancelSense().
	 */
	public void toggleCancelSense()
	{
		// Don't do anything if <theCancelButton> is non-existent.
		//
		if (theCancelButton != null)
		{
			try
			{
				// Handle "configure system" state.
				//
				if (theCancelButton.getActionCommand().equals (CONFIG_ACTION))
				{
					theCancelButton.setText (getLabel (CANCEL_CONFIG));
					theCancelButton.setActionCommand (CANCEL_ACTION);
    				theCancelButton.setMnemonic (getLabel (CANCEL_MNEMONIC).charAt (0));
				}
				
				// Handle "de-configure" state.
				//
				else if (theCancelButton.getActionCommand().equals (CANCEL_ACTION))
				{
					theCancelButton.setText (getLabel (DO_CONFIG));
					theCancelButton.setActionCommand (CONFIG_ACTION);
    				theCancelButton.setMnemonic (getLabel (CONFIG_MNEMONIC).charAt (0));
				}
			}
			catch (MissingResourceException mre)
			{
				mre.printStackTrace();		// can't happen.
			}
		}

	}	// end toggleCancelSense().

	/**
	 * Accessor to allow clients to query the sense of the configuration button.  This returns
	 * the current action command of that button -- one of <code>CANCEL_ACTION</code> or
	 * <code>CONFIG_ACTION</code>.
	 * its current label and action, this changes it to the other.  For example, if it is
	 * @see #toggleCancelSense(), #CANCEL_ACTION, #CONFIG_ACTION.
	 */
	public String getCancelSense()
	{
		if (theCancelButton != null)
			return theCancelButton.getActionCommand();
		else
			return CONFIG_ACTION;		// default...
	
	}	// end getCancelSense().
    
    /**
     * Disable or enable the edit button.
     * @param   inFlag  Boolean to indicate whether to enable or disable
     *                  the edit button.
     */
    void setEditButtonEnable (boolean inFlag)
    {
        theEditButton.setEnabled (inFlag);
    
    }   // end setEditButtonEnable().

	/**
	 * Allow clients to specify the current status message within the splash
     * screen.  Whatever is passed in replaces any current status message.  If
     * the message is "configuring" or "resetting", the appropriate audio
     * feedback is also played.
	 * @param	inMessage	The status message to display as a String.  If that
     *                      message matches either the String keyed by
     *                      <code>SplashScreen.DOING_CONFIG</code> or
     *                      <code>SplashScreen.CANCEL_CONFIGING</code>, the
     *                      relevant audio is played. If <ocde>inMessage</code>
     *                      is <code>null</code> or empty, any current status
     *                      message is erased from the display.
	 */
	public void updateStatusMessage (String inMessage)
	{
        //  Handle "clear" directive.
        //
		if ((inMessage == null) || (inMessage.length() == 0))
        {
            inMessage = " ";    // space.
        }
        
        // Put the message up on screen.
        //
		theStatusMsg.setText (inMessage);
				
        // Handle audio feedback, if any.
        //
        if (theAudioFeedback != null)
        {
            if (inMessage.equals (getLabel (SplashScreen.DOING_CONFIG)))
                theAudioFeedback.notifyForConfig();
            
            else if (inMessage.equals (getLabel (SplashScreen.CANCEL_CONFIGING)))
                theAudioFeedback.notifyForDeconfig (false);
        }
            
	}	// end updateStatusMessage().
	
	/**
	 * Create the control panel and its buttons.
	 */
	private void createControlPanel()
	{
		theControlPanel = new JPanel();
		theControlPanel.setLayout(new BoxLayout(theControlPanel, BoxLayout.Y_AXIS));

		JPanel buttonPanel = new JPanel();
		try
		{

			// The edit button.
			//
			theEditButton = new JButton (theLabels.getString (EDIT_PREFS));
			theEditButton.setActionCommand (EDIT_ACTION);
			theEditButton.setBackground (Color.white);
			theEditButton.setBorder (new LineBorder(Color.red, 2));
			theEditButton.setPreferredSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));
			theEditButton.setMnemonic (theLabels.getString (EDIT_MNEMONIC).charAt (0));
			if (theActionListener != null)
				theEditButton.addActionListener (theActionListener);
			buttonPanel.add (theEditButton);
			
			// The cancel button -- starts off as "cancel configuration".
			//
			theCancelButton = new JButton (theLabels.getString (CANCEL_CONFIG));
			theCancelButton.setActionCommand (CANCEL_ACTION);
			theCancelButton.setBackground (Color.white);
			theCancelButton.setBorder (new LineBorder(Color.red, 2));
			theCancelButton.setPreferredSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));
			theCancelButton.setMnemonic (theLabels.getString (CANCEL_MNEMONIC).charAt (0));
			if (theActionListener != null)
				theCancelButton.addActionListener (theActionListener);
			buttonPanel.add (theCancelButton);
		}
		catch (MissingResourceException mre)
		{
			mre.printStackTrace();		// can't happen.
		}	
		theControlPanel.add(Box.createVerticalGlue());
		theControlPanel.add(buttonPanel);
		theControlPanel.add(Box.createVerticalGlue());
	
	}	// end createControlPanel().

//==============================
// MouseListener implementation.
//==============================
    
    /**
     * When the mouse is double-clicked with the control, shift, and alt keys down, ask the
     * use if they want to quit.  If so, initiate the shutdown procedure.
     * @param   inMouseEvent    The MouseEvent to examine for a shutdown gesture.
     */
    public void mouseClicked (MouseEvent inMouseEvent)
    {
        // Pay attention only to double-clicks with a shift, control and alt keys down.
        //
        if (    (inMouseEvent.getClickCount() == 2) &&
                (inMouseEvent.isShiftDown()) &&
                (inMouseEvent.isControlDown()) &&
                (inMouseEvent.isAltDown())              )
        {
            try
            {
                int quit = ControlHub.showOptionDialog (this, theLabels.getString (CONFIRM_QUIT), null, JOptionPane.QUESTION_MESSAGE);
                if (quit == JOptionPane.YES_OPTION)
                    theActionListener.actionPerformed (new ActionEvent (this, ActionEvent.ACTION_PERFORMED, QUIT_ACTION));
            }             
    		catch (MissingResourceException mre)
    		{
    			mre.printStackTrace();		// can't happen.
    		}	
        }
    
    }   // end mouseClicked().

    /**
     * No-op
     * @param inMouseEvent  ignored.
     */
    public void mouseEntered (MouseEvent inEvent)
    {
    
    }   // end mouseEntered().

    /**
     * No-op.
     * @param inMouseEvent  ignored.
     */
    public void mouseExited (MouseEvent inEvent)
    {
    
    }   // end mouseExited().

    /**
     * No-op.
     * @param inMouseEvent  ignored.
     */
    public void mousePressed (MouseEvent inEvent)
    {
    
    }   // end mousePressed().

    /**
     * No-op
     * @param inMouseEvent  ignored.
     */
    public void mouseReleased (MouseEvent inEvent)
    {
    
    }   // end mouseReleased().

}	// end class SplashScreen.
