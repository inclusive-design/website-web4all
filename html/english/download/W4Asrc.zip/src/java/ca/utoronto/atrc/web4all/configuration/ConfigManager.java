/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * 
 * File:        ConfigManager.java
 *
 * Synopsis:    package ca.utoronto.atrc.web4all.configuration;
 *
 ]*/

package ca.utoronto.atrc.web4all.configuration;

import java.io.*;
import java.net.*;
import java.util.*;
import java.text.*;			// for time stamps.

import org.w3c.dom.*;
import org.xml.sax.*;
import org.apache.xpath.XPathAPI;
import javax.xml.transform.TransformerException;
import org.apache.xerces.util.DOMUtil;

import org.apache.xerces.parsers.*;     // for debugging (temporary).
import org.apache.xml.serialize.*;      // for debugging (temporary)

import ca.utoronto.atrc.web4all.*;

/**
 * Configuration Central relay for:
 * <OL>
 * <LI>Examining the preferences and handling the settings for various adaptive technologies.</LI>
 * <LI>Launching those adaptive technologies.</LI>
 * <LI>Resetting and exiting those adaptive technologies.</LI>
 * </OL>
 *
 * @version $Id: ConfigManager.java,v 1.12 2006/03/28 21:17:27 clown Exp $
 * @author	Joseph Scheuhammer
 *
 */
	
public class ConfigManager
{
    /**
     * Static for debugging.
     */
    protected final static boolean DEBUG = true;

    /**
     * Static for outputting time stamps to the log file.
     */
    private static SimpleDateFormat dateFormatter = new SimpleDateFormat ("yyyy-MMM-dd HH:mm:ss.sss");

    /**
     * Name of the log file written.
     */
    public static String LOG_FILE_NAME = "ConfigManager.log";

    /**
     * Static for the ConfigManager itself.
     */
    private static ConfigManager sharedInstance = null;

    /**
     * Static for the home directory.
     */
    private static String HOME_DIR = null;

    /**
     * "Local" copy of the user preferences as a DOM.
     */
    private Document thePrefs;

    /**
     * "Local" copy of the ControlHub object.
     */
    private ControlHub theControlHub;
    
    /**
     * The Comparator for comparing application elements vis-a-vis their priority.
     */
    private PriorityOrder thePriorityOrder;
    
    /**
     * Vector for storing information about the plugins chosen to realize the preferences.
     */
    private volatile Vector thePluginInfo;

    /**
     * Vector for storing objects that are used for setting up adaptive technologies and
     * launching them.
     */
    private Vector theSetters;

    /**
     * A way of recording whether one of <code>theSetters</code> will launch a browser.
     */
    private boolean theBrowserLaunchFlag;

    /**
     * Reference (flag) to the ever-so-special IE setter/launcher object.
     */
    private ConfigPluginArgs theIELauncher;
    
    /**
     * The FileWriter to write debug output to.  It will be written
     * to the <code>HOME_DIR</code>.
     */
    private static PrintWriter theLog = null;

    /**
     * Static method for getting the home directory String..
     * @return  The directory that the ConfigManager resides in.
     */
    public static String getHomeDir()
    {
    	return HOME_DIR;

    }	// end getHomeDir().

    /**
     * Create the log file.
     * @param		A String naming the file.
     * @return		A FileWriter for the file.  <code>null</code> if something went
     *        		wrong.
     */
    protected static PrintWriter createLog (String inFileName)
    {
        PrintWriter printWriter = null;

        // Clean up any old output.
        //
        closeLog();

        // Get the ConfigManager directory and create the file in that folder.
        //
        try
        {
            String dirSep = System.getProperty ("file.separator");
            File aFile = new File (ConfigManager.getHomeDir() + dirSep + inFileName);
            if (aFile != null)
                printWriter = new PrintWriter (new FileWriter (aFile), true);
        }

        catch (IOException ioe)
        {
            ioe.printStackTrace();
            printWriter = null;
        }

        // Assign the (new) output file.
        //
        theLog = printWriter;
        return theLog;

    }  // end createLog().

    /**
     * Flush and close the current output file -- release the resources.
     */
    protected static void closeLog()
    {
        if (theLog != null)
        {
            theLog.flush();
            theLog.close();
            theLog = null;
        }

    }  // end closeLog().

    /*
     * Write a debug statement to the log file.
     * @param   inStatement     The debug statement to write to the log file.
     */
    public static void logDebugStatement(String inStatement)
    {
        if (theLog != null)
        {
            theLog.println(dateFormatter.format(new Date()) + ": " + inStatement);
        }
	
    }   // end logDebugStatement().
	
	/*
	 * Write an exception stack trace to the log file
         * @param   inT     The Throwable to be dumped to the log file.
	 */
    public static void logException(Throwable inT)
    {
        if (theLog != null)
        {
            theLog.println(dateFormatter.format(new Date()));
            inT.printStackTrace(theLog);
        }

    }   // end logException().
	
    /**
     * Constructor - pass in a back reference to the ControlHub instance that will allow this
     * to pull out the ConfigManager class for each application in the preferences.
     * @param	inControlHub	The ControlHub object that contains information about the ConfigManager
     *                          classes.
     */
    public ConfigManager (ControlHub inControlHub)
    {
        super();
        thePrefs = null;
        theControlHub = inControlHub;
        thePriorityOrder = new PriorityOrder (theControlHub.getPrefElementName (Web4AllConstants.APP_PRIORITY));
        thePluginInfo = new Vector();
        theSetters = new Vector();
        theBrowserLaunchFlag = false;	// set by calling various SetterLaunchers.doSettings().
        theIELauncher = null;			// set when allocated.

        // Allocate the ConfigManager log based on the home directory given in <theControlHub>.
        //
        ConfigManager.HOME_DIR = theControlHub.getHomeDirectory();
        createLog (ConfigManager.LOG_FILE_NAME);
        
    }	// end ConfigManager().

    /**
     * Convenience method that does the two steps:
     * <ol>
     * <li><code>doSettings (Document inPrefs)</code></li>
     * <li><code>doLaunch()</code></li>
     * </ol>
     * @param	inPrefs		The preferences to use to effect the configuration (a Document).
     * @see #doSettings, #doLaunch
     */
    public synchronized void doConfigure (Document inPrefs)
    {
        doSettings (inPrefs);
        doLaunch();
    	
    }	// end doConfigure().

    /**
     * Main relay for handling the settings of various applications in the preferences.  This
     * version takes a preferences Document as input.  Note that this first calls
     * <code>doInstanceShutdown()</code> before doing the new settings to "unconfigure" the
     * machine.
     * @param   inPrefs     The preferences to use to effect the configuration (a Document).
     * @see	#doInstanceShutdown
     */
    public synchronized void doSettings (Document inPrefs)
    {
        // Kill any current settings.
        //
        doShutdown();

        // Given the "new" <inPrefs>, do the settings based on them.
        //
        thePrefs = inPrefs;
        doSettings();

    }	// end doSettings (Document inPrefs).

    /**
     * Main relay for handling the settings of various applications in the preferences.
     */
    public synchronized void doSettings()
    {
        // Do nothing if there are no preferences
        //
        if (thePrefs != null)
        {
            // Logging info.
            //
            ConfigManager.logDebugStatement ("ConfigManager.doSettings(): <thePrefs> is:");
            serializeElement2Log (thePrefs.getDocumentElement(), "accessForAll");
                    
            // Find the context whose ID is "Web-4-All".  If there is none, give up.
            //
            try
            {
                Element context = (Element) XPathAPI.selectSingleNode (thePrefs, "//context[@identifier='Web-4-All']");
                if (context != null)
                {
                    // First pass at selecting plugins.  Do once for each of the <display> and
                    // <control> branches of the preferences.
                    //
                    selectDisplayPlugins (context);
                    selectControlPlugins (context);
        
                    // "Combine" plugins where a single plugin will handle more than one set
                    // of <display> and/or <control> preferences.
                    //
                    coalescePlugins();
        
                    // Loop to handle the "setting" phase for each plugin.
                    //
                    for (int i = 0; i < theSetters.size(); i++)
                    {
                        ConfigPluginArgs anSL = (ConfigPluginArgs) theSetters.elementAt (i);
                        boolean launchBrowser = anSL.doSettings (theControlHub);
                        theBrowserLaunchFlag = (theBrowserLaunchFlag ? theBrowserLaunchFlag : launchBrowser);
                    }
                }
                else
                    ConfigManager.logDebugStatement ("ConfigManager.doSettings(): can't find //context[@identifier='Web-4-All']");
        
                // Having created all <theSetters>, check to see if any of them launch a browser.
                // If not, allocate one for IE.
                //
                if ((theBrowserLaunchFlag == false) && (theIELauncher == null))
                {
                    try
                    {
                        theIELauncher = createSettingsObject ("ca.utoronto.atrc.web4all.configuration.IELauncher", null, null, "thirdPartyAppClass");
                        if (theIELauncher != null)
                        {
                            theIELauncher.doSettings (theControlHub);
                            ConfigManager.logDebugStatement ("Created <theIELauncher>");
                        }
                        else
                            ConfigManager.logDebugStatement ("Failed to create <theIELauncher>");

                    }
                    catch (ClassNotFoundException cnfe)
                    {
                        ConfigManager.logException(cnfe);
                    }
                    catch (InstantiationException ie)
                    {
                        ConfigManager.logException(ie);
                    }
                    catch (IllegalAccessException iae)
                    {
                        ConfigManager.logException(iae);
                    }
                }
            }

            // Couldn't find a <context identifier='Web-4-All'> Element in the prefs document.  Nothing to do...
            //
            catch (TransformerException te)
            {
                ConfigManager.logException (te);
            }
        }
        
    }   // end doSettings()

	/**
	 * Launch the technologies.  Do this only after they have been set up via
	 * <code>doSettings()</code>.
	 * @see #doSettings
	 */
    public synchronized void doLaunch()
    {
        for (int i = 0; i < theSetters.size(); i++)
        {
            ConfigPluginArgs anSL = (ConfigPluginArgs) theSetters.elementAt (i);
            anSL.doLaunch();
        }
	
    }	// end doLaunch().
	
	/**
	 * Reset any configuration and shut down any technologies that were launched.  Also,
	 * reset the IE launcher flag.
	 * @see #doSettings, #doConfigure
	 */
    public synchronized void doShutdown()
    {
        if (theSetters != null)
        {
            for (int i = 0; i < theSetters.size(); i++)
            {
                ConfigPluginArgs anSL = (ConfigPluginArgs) theSetters.elementAt (i);
                anSL.kill();
                anSL.flush();
            }
            theSetters.removeAllElements();
        }
        theIELauncher = null;
        theBrowserLaunchFlag = false;
		
        // Clean up <thePluginInfo> list, if necessary.
        //
        thePluginInfo.removeAllElements();
			
    }	// end doShutdown().
	
	/**
	 * Given the Web-4-All context, loop thru the <display> sub-tree, choosing
	 * configuration plugins for the display preferences.  This is a first pass
	 * at selecting plugins.  Later, they should be compared to remove duplicates, etc.
	 * @param   inContext   The <context> element within the preferences whose
	 *                      identifier is "Web-4-All".
	 * @see #selectControlPlugins, #selectPlugins, #coalescePlugins
	 */
    protected void selectDisplayPlugins (Element inContext)
    {
        // Look for the "display" sub-tree.
        //
        selectPlugins (inContext, "display");
    
    }   // end selectDisplayPlugins().
    
	/**
	 * Given the Web-4-All context, loop thru the <control> sub-tree, choosing
	 * configuration plugins for the control preferences.  This is a first pass
	 * at selecting plugins.  Later, they should be compared to remove duplicates, etc.
	 * @param   inContext   The <context> element within the preferences whose
	 *                      identifier is "Web-4-All".
	 * @see #selectDisplayPlugins, #selectPlugins, #coalescePlugins
	 */
    protected void selectControlPlugins (Element inContext)
    {
        // Look for the "control" sub-tree.
        //
        selectPlugins (inContext, "control");
    
    }   // end selectControlPlugins().
    
 	/**
	 * Given the Web-4-All context, loop thru the named sub-tree, choosing
	 * configuration plugins for the technology preferences in that sub-tree.  This is a first pass
	 * at selecting plugins.  Later, they should be compared to remove duplicates, etc.
	 * @param   inContext       The <context> element within the preferences whose
	 *                          identifier is "Web-4-All".
	 * @param   inXPath         The XPath search string to use to the subtree whose preferences
	 *                          are to be handled.  For example, the "display"
	 *                          sub-tree/preferences.
	 * @see #selectDisplayPlugins, #selectControlPlugins, #coalescePlugins
	 */
    protected void selectPlugins (Element inContext, String inXPath)
    {
        // Look for the <inXPath> sub-tree.
        //
        try
	    {
	        Element technologies = (Element) XPathAPI.selectSingleNode (inContext, inXPath);
	        serializeElement2Log (technologies, inXPath);	    
	        
	        // Loop thru the immediate children of <prefsSubtree>, looking for <application>
	        // elements.
	        //
	        if (technologies != null)
            {
                Element aTechnology = DOMUtil.getFirstChildElement (technologies);
                while (aTechnology != null)
                {
                    String techName = aTechnology.getNodeName();
        
                    // Retrieve all the <application> sub-elements.  Then, loop thru them from
                    // highest to lowest priority looking to find the application of highest
                    // priority that is, in fact, available.
                    //
                    NodeList appTags = XPathAPI.selectNodeList (aTechnology, ".//application");
                    ConfigManager.logDebugStatement ("ConfigManager.selectPlugins(): got " + appTags.getLength() + " <application>'s");
                    SortedSet prioritizedAppTags = orderByPriority (appTags);
                    Vector appNames = new Vector();
                    Element appTagToUse = null;
                    Iterator appTagsIter = prioritizedAppTags.iterator();
                    while (appTagsIter.hasNext())
                    {
                        // Check to see that the application associated with this 3rd party
                        // exists.  If it does, record its plugin-info in <thePluginInfo> and quit
                        // the loop.
                        //
                        Element anAppTag = (Element) appTagsIter.next();
                        serializeElement2Log (anAppTag, new String (techName + ".application"));
                        String appName = thirdPartyAppExists (anAppTag, appNames);
                        if (appName != null)
                        {
                            appTagToUse = anAppTag;
                            serializeElement2Log (anAppTag, "USING");
                            ConfigPluginInfo pluginInfo = new ConfigPluginInfo (appName, appTagToUse, aTechnology, theControlHub);
                            thePluginInfo.addElement (pluginInfo);
                            break;
                        }
                    }
        
                    // Either looped thru all the application elements and found no matching plugin, or found
                    // at least one match.  If no match was found, try to find something that fits.
                    //
                    if (appTagToUse == null)
                    {
                        appTagToUse = theControlHub.lastChance3rdPartyPrefs (techName, appNames);
                        if (appTagToUse != null)
                        {
                            serializeElement2Log (appTagToUse, "USING (LAST CHANCE)");
                            String attrName = theControlHub.getPrefElementName (Web4AllConstants.APP_NAME);
                            String appName = appTagToUse.getAttribute (attrName);
                            ConfigPluginInfo pluginInfo = new ConfigPluginInfo (appName, appTagToUse, aTechnology, theControlHub);
                            thePluginInfo.addElement (pluginInfo);
                        }
                    }
        
                    // Clean up.
                    //
                    appNames.removeAllElements();
                    prioritizedAppTags.clear();
                    aTechnology = DOMUtil.getNextSiblingElement (aTechnology);
                }
            }
        }
        catch (TransformerException te)
        {
            ConfigManager.logException (te);
        }
    
    }   // end selectPlugins().
    
    /**
     * Make a sorted copy of a NodeList of <application> elements, sorting by priority.  Applications
     * with higher priority (lower number value) are placed earlier into the returned value.
     * @param   inAppTags   A NodeList of <application> Elements to sort.
     * @return              A SortedSet of the same Elements ordered by priority.  If
     *                      <code>inNodeList</code> is <code>null</code> or empty, then the returned
     *                      SortedSet is empty.  Note that the return value is the synchronized
     *                      version of SortedSet (via Collections.synchronizedSortedSet(()).
     */
    private SortedSet orderByPriority (NodeList inAppTags)
    {
        SortedSet result = Collections.synchronizedSortedSet (new TreeSet (thePriorityOrder));
        
        // Loop thru the Elements in <inAppTags> and add them to <result>.  They should be ordered
        // correctly via the PRIORITY_ORDER Comparator.
        //
        for (int i = 0; i < inAppTags.getLength(); i++)
            result.add (inAppTags.item (i));
        
        return result;
    
    }   // end orderByPriority().

    /**
     * Determine if the given third party application exists on the system.  If it does,
     * return that application's appName.
     * @param   inAppElement    The 3rd party application tag.
     * @param   ioAppIDs        A Vector in which to record all the application IDs looked at
     *                          (whether they exist or not).
     * @return                  The application ID string for the application, if that
     *                          application exists.  If not, <code>null</code> is returned.
     */
    private String thirdPartyAppExists (Element inAppElement, Vector ioAppIDs)
    {
        String result = null;

        // Get the application ID from the <inAppElement>.
        //
        if (inAppElement != null)
        {
            String attrName = theControlHub.getPrefElementName (Web4AllConstants.APP_NAME);
            String appName = inAppElement.getAttribute (attrName);
            ConfigManager.logDebugStatement ("thirdPartyAppExists():");
            serializeElement2Log (inAppElement, appName);
            ioAppIDs.addElement (appName);
                    
            // Look for that ID in the Web4All's properties.
            //
            if (theControlHub.thirdPartyAppExists (appName))
                result = appName;
            else
                result = null;
        }
        ConfigManager.logDebugStatement ("thirdPartyAppExists():  <result> is '" + (result == null ? "null" : result) + "'");
        return result;
	
    }	// end thirdPartyAppExists().

    /**
     * Method to take the list of plugins, remove duplicates, and set up a list of 
     * SetterLaunchers based on the final list.
     */
    public void coalescePlugins()
    {
        // First, for debugging, look for duplicate application types in the plugins.  This
        // should never happen.
        //
        logDuplicatePluginTypes();
        
        // Next, search for multiple occurrences of the same application name within the list
        // <thePluginInfo>.
        //
        for (int i = 0; i < thePluginInfo.size(); i++)
        {
            ConfigPluginInfo aPluginInfo = (ConfigPluginInfo) (thePluginInfo.elementAt (i));
        
            // Assume we are going to use <aPluginInfo>.  Set up the corresponding
            // ConfigPluginArgs.
            //
            try
            {
                String configClass = theControlHub.get3rdPartyConfigClass (aPluginInfo.getAppName());
        
                // Get the generic settings.  If there are none, give up on this plugin, and 
                // continue the loop.
                //
                Element generics = null;
                try
                {
                    generics = aPluginInfo.getGenericSettings();
                }
                catch (TransformerException te)
                {
                    ConfigManager.logException (te);
                    continue; 
                }
        
                // Create the SetterLaunncher, and its associated ConfigPluginArgs.
                //
                createSettingsObject (configClass, generics, aPluginInfo, null);
            }
        
            // All these are thrown by createSettingsObject()...shouldn't happen.
            //
            catch (ClassNotFoundException cnfe)
            {
                ConfigManager.logException(cnfe);
            }
            catch (InstantiationException ie)
            {
                ConfigManager.logException(ie);
            }
            catch (IllegalAccessException iae)
            {
                ConfigManager.logException(iae);
            }
        }
        
        // Done with <thePluginInfo> list.  Clean up.
        //
        thePluginInfo.removeAllElements();
            
    }   // end coalescePlugins().

    /**
     * Private method for debugging duplicate technologies within the list of ConfigPluginInfo's.
     */
    private void logDuplicatePluginTypes()
    {
        for (int i = 0; i < thePluginInfo.size(); i++)
        {
            // Get a plugin, it's type, and then search the rest of the list for the same
            // type.
            //
            ConfigPluginInfo cpi = (ConfigPluginInfo) (thePluginInfo.elementAt (i));
            String appType = cpi.getAppTypeFromParent();
            for (int j = (i+1); j < thePluginInfo.size(); j++)
            {
                ConfigPluginInfo cpi2 = (ConfigPluginInfo) (thePluginInfo.elementAt (j));
                if (appType.equals (cpi2.getAppTypeFromParent()))
                {
                    // Two plugins of the same type -- report it.
                    //
                    String msg = "ConfigManager: plugins '" + cpi.getAppName() + "' and '" + cpi2.getAppName() + "' are of the same type (" + appType + ")";
                    System.out.println (msg);
                    ConfigManager.logDebugStatement (msg);
                }
            }
        }
    
    }   // end logDuplicatePluginTypes().

 	/**
	 * Create and store a ConfigPluginArgs object.  Before storing, find the currently stored
	 * one and add to it.
	 * @param	inClassName		    The fully qualified class name of the SetterLauncher object.
	 * @param   inGenericElement    The Element that contains the generic settings.  This can
	 *                              be <code>null</code>, in which case either nothing is added
	 *                              to an existent ConfigPluginArgs, or an empty Vector is
	 *                              created for a new ConfigPluginArgs.
	 * @param   inPluginInfo        Used to fetch the specific preferences (XML) that the
	 *                              SetterLauncher will use, and the type of technology these
	 *                              preferences are for.  If <code>null</code> either no
	 *                              specific preferences are added to an existent ConfigPluginArgs,
	 *                              or an empty set of specific preferences is added to a new
	 *                              ConfigPluginArgs; and, the type is determined by the next
	 *                              argument.
	 * @param   inAppType           Consulted only if <code>inPluginInfo</code> is
	 *                              <code>null</code>, this declares the type of technology that
	 *                              the given preferences are for.
	 * @return					    The relevant ConfigPluginArgs instance.  Either one created
	 *                              on a previous call, or a new one.
	 * @exception				    ClassNotFoundException, InstantiationException, IllegalAccessException
	 */
    private ConfigPluginArgs createSettingsObject (String inClassName, Element inGenericElement, ConfigPluginInfo inPluginInfo, String inAppType) throws ClassNotFoundException, InstantiationException, IllegalAccessException
    {
        ConfigPluginArgs result = null;     // return value.

        String debugStr = "createSettingsObject():  <className> is '" + (inClassName == null ? "null" : inClassName) + "'";
        System.out.println (debugStr);
        ConfigManager.logDebugStatement (debugStr);

        // Handle a null <inPluginInfo>.
        //
        Element appTag = null;
        String appType = inAppType;
        if (inPluginInfo != null)
        {
            appTag = inPluginInfo.getAppTag();
            appType = inPluginInfo.getAppTypeFromParent();
        }
        
        // Look for the ConfigPluginArgs instance in <theSetters>.
        //
        for (int i = 0; i < theSetters.size(); i++)
        {
            ConfigPluginArgs anSL = (ConfigPluginArgs) theSetters.elementAt (i);
            if (anSL.equalsSetterLauncher (inClassName))
            {
                // Found the ConfigPluginArgs.  Add the application type, generic, and specific settings to it.
                //
                anSL.addAccLipInfoPackage (appType, inGenericElement, appTag);
                result = anSL;
                break;
            }
        }
		
        // If no ConfigPluginArgs was found, create a new one.
        //
        if (result == null)
        {
            Class slClass = Class.forName (inClassName);
            SetterLauncher setterLauncher = (SetterLauncher) slClass.newInstance();
             
            result = new ConfigPluginArgs (appType, inGenericElement, appTag, setterLauncher);
            theSetters.addElement (result);
        }
        return result;
	
    }	// end createSettingsObject().
	
    /**
     * Private debugging routine to see that XPath searches are formed correctly.
     * @param   inElement   The Element to output debugging information on.
     * @param   inName      The name of <code>inElement</code> in case it is <code>null</code>.
     */
    private void serializeElement2Log (Element inElement, String inName)
    {
        // If a 'null' Element was passed in, say so.
        //
        if (inElement == null)
            ConfigManager.logDebugStatement ("ConfigManager.serializeElement2Log(): <null> Element for '" +  inName + "'");
        
        // Got an Element, serialize it.
        //
        else
        {
            ConfigManager.logDebugStatement ("ConfigManager.serializeElement2Log() <" + inName + ">:");
            OutputFormat out = new OutputFormat (thePrefs, null, true);
            XMLSerializer serializer = new XMLSerializer(theLog, out);
            try
            {
                serializer.serialize (inElement);		
            }
            catch (IOException ioe)
            {
                ConfigManager.logException (ioe);
            }
        }
    }   // end serializeElement2Log
	

	/**
	 * A main for debugging.
	 */
    public static void main (String args[])
    {
    	// Determine what the home directory is.  Then, launch Web4All using that directory.
    	//
    	String homeDir = System.getProperty ("user.dir");
    	if (DEBUG) System.out.println ("main():  home folder is '" + homeDir + "'");

    	// Load a preferences file from the home directory, and "turn it" into a string.
    	//
    	String file = null;
        String xmlString = null;
        if ((args == null) || (args.length == 0))
            file = "prefs.xml";
        else
            file = args[0];

    	StringBuffer xmlStringBuf = new StringBuffer();
        String dirSep = System.getProperty ("file.separator");
    	File aFile = new File (homeDir + dirSep, file);
    	try
        {
            BufferedReader aReader = new BufferedReader (new FileReader (aFile));
            while (true)
            {
                try
                {
                    String aLine = aReader.readLine();
                    if (aLine != null)
                        xmlStringBuf.append (aLine);
                    else
                        break;
                }
                catch (IOException ioe)
                {
                    ioe.printStackTrace();
                    break;
                }
            }
            xmlString = xmlStringBuf.toString();
        }
        catch (FileNotFoundException fnf)
	    {
	    	fnf.printStackTrace();
	    	xmlString = null;
	    }
		
        //*** Make a DOM ***
        // Don't do anything with a null or empty input.
        //
        Document doc = null;
        if ((xmlString != null) && (xmlString.length() > 0))
        {
            // Place the XML argument string into an input stream, and that into an
            // InputSource.
            //
            StringReader inputString = new StringReader (xmlString);
            InputSource iSource = new InputSource (inputString);
                    
            // Parse the profile and make a DOM, then make an instance of the ConfigManager
            // to walk the tree.
            //
            try
            {
                DOMParser domParser = new DOMParser();

                domParser.setErrorHandler(new ErrorHandler() {
                    public void error(SAXParseException exception) throws SAXParseException {
                        System.out.println("Error: Line " + exception.getLineNumber() + " " + exception.getMessage()); 
                        System.exit(1);
                    }
              
                    public void fatalError(SAXParseException exception) throws SAXParseException {
                        System.out.println("FatalError: Line " + exception.getLineNumber() + " "  + exception.getMessage());
                        System.exit(1);
                    }
              
                    public void warning(SAXParseException exception) throws SAXParseException {
                        System.out.println("Warning: Line " + exception.getLineNumber() + " " + exception.getMessage());
                        System.exit(1);
                    }
                });

                domParser.setFeature("http://apache.org/xml/features/dom/defer-node-expansion", false);
                domParser.setFeature("http://xml.org/sax/features/validation", true);
                domParser.setFeature("http://apache.org/xml/features/validation/schema",true);
                domParser.setFeature("http://xml.org/sax/features/namespaces", false);

                domParser.parse(iSource);
                doc = domParser.getDocument();

                // normalize text representation
                //
                doc.getDocumentElement().normalize();
                ConfigManager.logDebugStatement ("Root element of the doc is " + doc.getDocumentElement().getNodeName());
            }
            catch (SAXParseException err)
            {
                ConfigManager.logDebugStatement ("** Parsing error" + ", line " + err.getLineNumber() + ", uri " + err.getSystemId());
                ConfigManager.logDebugStatement ("   " + err.getMessage());
                doc = null;
            }
            catch (SAXException e)
            {
                Exception x = e.getException();
                ConfigManager.logException (((x == null) ? e : x));
                doc = null;
            }
            catch (Throwable t)
            {
                ConfigManager.logException (t);
                doc = null;
            }
        }
	
        // Play with the DOM
        //
        if (doc != null)
	    {
        	ControlHub web4All = ControlHub.getSharedInstance(true, homeDir);
    		DummyPrefsLoader aPrefsLoader = new DummyPrefsLoader(web4All, false, true);
        	ControlHub.startWeb4All (homeDir, aPrefsLoader);
        	web4All.kickIt (xmlString, aPrefsLoader);
	        ConfigManager aConfigMan = new ConfigManager (web4All);
	        aConfigMan.doConfigure (doc);
	    }
        else
	    {
	        System.out.println ("ConfigManager.main(): can't get a document");
	    }
	
    }   // end main().
		
}   // end class ConfigManager.

