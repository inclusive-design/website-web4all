/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File: ProminentNotification.java
 * 
]*/

package ca.utoronto.atrc.web4all;

import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;
import java.util.ResourceBundle;
import java.util.Locale;
import java.net.URL;

/**
 * The Web4All system configuration's prominent notification class. 
 * This class "prominently notifies" the user of when the system is 
 * configuring and deconfiguring.
 *
 * @author David Weinkauf
 * @version $Revision: 1.5 $, $Date: 2006/03/28 21:17:27 $
 */
public class ProminentNotificator implements Notification {

    /** URL to configuration sound file */
    private URL configSoundUrl;

    /** URL to deconfiguration sound file */
    private URL deconfigSoundUrl;

    /**
     * The size of the external audio buffer. In the current implementation,
     * this must be larger than any of the sound files.
     */
    private int external_buffer_size;
		
    /**
     * Instantiate the configure and deconfigure sound file URLs.
     */
    public ProminentNotificator() {
        ResourceBundle audioFiles = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.Notification");

		
        /* Get the sound buffer size from properties file. If not there, 
           set to default of 10K.*/        
        try {
            external_buffer_size = Integer.parseInt(audioFiles.getString("external.buffer.size"));
            if (ControlHub.DEBUG) {
                System.out.println("Sound buffer size is " +
                     audioFiles.getString("external.buffer.size") + " bytes.");
            }
        } catch (Exception e) {
            if (ControlHub.DEBUG) {
                System.out.println("Sound buffer size not specified or " +
                                   "ill-formatted. Defaulting to 10K");
            }

            external_buffer_size = 10240;
        }

        Class notificatorClass = getClass();
        configSoundUrl = notificatorClass.getResource(
                audioFiles.getString("config.audio.file"));
        deconfigSoundUrl = notificatorClass.getResource(
                audioFiles.getString("deconfig.audio.file"));
    }

    public static void main(String[] args) throws Exception {
        ProminentNotificator pn = new ProminentNotificator();

        pn.notifyForConfig();
        Thread.sleep(1000);
        pn.notifyForDeconfig(false);
        Thread.sleep(5000);
        pn.notifyForConfig();
        Thread.sleep(2000);
        System.exit(0);
    }

    /**
     * Play configuration notification.
     */
    public boolean notifyForConfig() {
        if (ControlHub.DEBUG) {
            System.out.println("Notification: Configuration started...");
        }
        return playBack(configSoundUrl, false);
    }

    /**
     * Play deconfiguration notification.
     */
    public boolean notifyForDeconfig(boolean wait) {
        if (ControlHub.DEBUG) {
            System.out.println("Notification: Deconfiguration started...");
        }
        return playBack(deconfigSoundUrl, wait);
    }

    /**
     * Play back a message to the user when the system is configuring 
     * or deconfiguring. This method is synchronized so as we do not have 
     * concurrent playbacks of prominent notifications.
     *
     * @param soundURL the URL of the sound file to play back
     * @param wait whether to wait 0.5 seconds before play back
     * @return did the sound play or not.
     */
    private synchronized boolean playBack(URL soundUrl, boolean wait) {

        AudioInputStream ais = null;

        try {
            ais = AudioSystem.getAudioInputStream(soundUrl);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

        AudioFormat audioFormat = ais.getFormat();		
        DataLine.Info lineInfo = new DataLine.Info(SourceDataLine.class,
                                                   audioFormat);		
        SourceDataLine line = null;
		
        if (wait) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException ie) {;}
        }

        // Configure a SourceDataLine. Return false if the line is busy.
        //			
        try {
            line = (SourceDataLine) AudioSystem.getLine(lineInfo);
            line.open(audioFormat);
        } catch (LineUnavailableException e) {
            System.out.println("Caught LineUnavailableException in " + 
                               "ProminentNotificator. Not playing sound.");
            if (line != null) {
                line.close();
            }
            return false;
        } catch (Exception e) {
            System.out.println("Caught Exception in ProminentNotificator. " + 
                               "Not playing sound.");
            if (line != null) {
                line.close();
            }
            return false;
        }

        line.start();
		
        /* Play back the data retrieved from the audioInputStream to the user.
           At this point, the external_buffer_size must be larger than the 
           played back file b/c of my use of reset() on the file. */
        int nBytesRead = 0;
        byte[] abData = new byte[external_buffer_size];

        /* Don't loop when retrieving the sound bytes b/c we have a mark set at
           the <external_buffer_size> and can not go passed it.*/
        try {
            nBytesRead = ais.read(abData, 0, abData.length);
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (nBytesRead >= 0) {
            int	nBytesWritten = line.write(abData, 0, nBytesRead);
        }
		
        /* Clean up the SourceDataLine.*/
        line.drain();
        line.close();		

        return true;
    }

}
