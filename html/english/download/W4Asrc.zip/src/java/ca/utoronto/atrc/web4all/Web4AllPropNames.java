/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:        Web4AllPropNames.java
 *
 ]*/

package ca.utoronto.atrc.web4all;

/**
 * Class of constants that defines the names of the global Web4All properties, and which
 * is used in conjunction with <code>Web4All.getGlobalProperty()</code> to get the property's
 * value.  Note that this is (obviously) up-to-date with respect to the date of the latest
 * revision.
 *
 * @author Joseph Scheuhammer
 * @author David Weinkauf
 * @version $Revision: 1.4 $, $Date: 2006/03/28 21:17:27 $
 */
public class Web4AllPropNames
{
    /** 
     * Property name for the URL to go to when launching a web browser.
     */
    final static public String  LAUNCH_URL      =   "ca.utoronto.atrc.smartcard.launch.url";
	
    /** 
     * Property name for the serial number of the CAP station.
     */
    final static public String  SERIAL_NUMBER   =   "ca.utoronto.atrc.smartcard.cap.serial.number";
	
    /** 
     * Property name for the encoded serial number.
     */
    final static public String  SERIAL_ENCODING    =   "ca.utoronto.atrc.smartcard.cap.encoded";
	
    /** 
     * Property name for the portal host the url visits.
     */
    final static public String  PORTAL_HOST     =   "ca.utoronto.atrc.smartcard.portal.host";
	
    /**
     * Property name for the CGI script name.
     */
    final static public String  CGI_SCRIPT_NAME = "ca.utoronto.atrc.smartcard.cgi.script.name";

    /**
     * Property name for the CGI variable to contain the serial number.
     */
    final static public String  SERIAL_NUMBER_VAR = "ca.utoronto.atrc.smartcard.cap.serial.var";

    /**
     * Property name for the CGI variable to contain the encoded serial number.
     */
    final static public String  SERIAL_ENCODING_VAR = "ca.utoronto.atrc.smartcard.cap.encoded.var";

    /** The 'iconify' property key value.*/
    public static final String ICONIFY = "iconify";
    
    /** The 'notify' property key value.*/
    public static final String NOTIFY = "notify";
    
    /** The 'enableConfiguration' property key value.*/
    public static final String ENABLE_CONFIG = "enable.config";

    /** The 'Preferences Loader' property key value.*/
    public static final String PREFS_LOADER = "prefs.loader";

} // end class Web4AllPropNames.

