/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

/**
 * Class to represent the settings for the coded input application type.
 *
 * @author David Weinkauf
 * @revision $Revision: 1.7 $, $Date: 2006/03/28 16:31:10 $
 */
public class CodedInput extends PWMEditPanel {

    private ComboBoxItem[] switches;

    private JLabel switchInputLabel;

    private JComboBox switchInputType;

    private ComboBoxItem mouse, game, serial, usb, firewire, infrared, bluetooth;

    private ComboBoxItem morse, quartering, eightCell, chordic;

    private ComboBoxItem[] codes;

    private JComboBox codeComboBox;

    private JLabel codeLabel;

    private TitledBorder codedInputTitle;

    private RangedTextField codeSwitchField;

    private JLabel codeSwitchLabel;

    private JCheckBox timeTermination;

    private RangedTextField timeTerminationField;

    private ComboBoxItem pointAndClick, pointAndDwell;

    private ComboBoxItem[] selectionMethods;

    private JComboBox selectionMethodComboBox;

    private JLabel selectionMethodLabel;

    private Document document;
	
    private Element generic;

    /**
     * Sole constructor. Initializes the panel and all its UI.
     *
     * @param  pm  the PreferenceManager
     * @param  root  the root element of the application type's XML document
     * @param  inAppType  the panel's application type
     */
    public CodedInput(PreferenceManager pm, Element root, String inAppType) {
        super(pm, inAppType, inAppType + TITLE_SUFFIX);

        document = initDocument(root, xmlLabels.getString(CODED_INPUT), null);
        generic = document.getDocumentElement();
	
        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.CodedInput", pm.language);

        morse = new ComboBoxItem(labels.getString("morse"), "morse");
        quartering = new ComboBoxItem(labels.getString("quartering"), "quartering");
        eightCell = new ComboBoxItem(labels.getString("eight.cell"), "eightCell");
        chordic = new ComboBoxItem(labels.getString("chordic"), "chordic");

        ComboBoxItem[] tempCodes = {morse, quartering, eightCell, chordic};
        codes = tempCodes;

        codeComboBox = new JComboBox(codes);
        codeComboBox.setForeground(TEXT_COLOUR);
        codeComboBox.setFont(TEXT_FONT);
        codeComboBox.setBackground(PANEL_BACKGROUND);		
        codeComboBox.setSelectedIndex(0);

        codeLabel = new JLabel(labels.getString("code"));
        codeLabel.setDisplayedMnemonic(labels.getString("code.mnemonic").charAt(0));
        codeLabel.setLabelFor(codeComboBox);
        codeLabel.setFont(TEXT_FONT);
        codeLabel.setForeground(TEXT_COLOUR);

        JTextField textField = new JTextField(5);
        textField.setFont(TEXT_FONT);

        codeSwitchField = new RangedTextField(new Integer(1), new Integer(150), textField);
        codeSwitchField.setText("10");

        codeSwitchLabel = new JLabel(labels.getString("code.switch"));
        codeSwitchLabel.setDisplayedMnemonic(labels.getString("code.switch.mnemonic").charAt(0));
        codeSwitchLabel.setLabelFor(codeSwitchField.textField);
        codeSwitchLabel.setFont(TEXT_FONT);
        codeSwitchLabel.setForeground(TEXT_COLOUR);
		
        textField = new JTextField(5);
        textField.setFont(TEXT_FONT);

        timeTerminationField = new RangedTextField(new Float(0.5), new Float(20.0), textField);
        timeTerminationField.textField.getAccessibleContext().setAccessibleName(labels.getString("time.termination"));
        timeTerminationField.setText("10.0");

        timeTermination = new JCheckBox(labels.getString("time.termination"));
        timeTermination.setMnemonic(labels.getString("time.termination.mnemonic").charAt(0));
        timeTermination.setBackground(PANEL_BACKGROUND);
        timeTermination.addChangeListener(new TimeTerminationListener());
        timeTermination.setSelected(false);
		
        pointAndClick = new ComboBoxItem(labels.getString("point.click"), "pointAndClick");
        pointAndDwell = new ComboBoxItem(labels.getString("point.dwell"), "pointAndDwell");

        ComboBoxItem[] tempSelectionMethods = { pointAndClick, pointAndDwell };
        selectionMethods = tempSelectionMethods;

        selectionMethodComboBox = new JComboBox(selectionMethods);
        selectionMethodComboBox.setForeground(TEXT_COLOUR);
        selectionMethodComboBox.setFont(TEXT_FONT);
        selectionMethodComboBox.setBackground(PANEL_BACKGROUND);		
        selectionMethodComboBox.setSelectedItem(pointAndClick);

        selectionMethodLabel = new JLabel(labels.getString("select.method"));
        selectionMethodLabel.setDisplayedMnemonic(labels.getString("select.method.mnemonic").charAt(0));
        selectionMethodLabel.setLabelFor(selectionMethodComboBox);
        selectionMethodLabel.setFont(TEXT_FONT);
        selectionMethodLabel.setForeground(TEXT_COLOUR);

        mouse = new ComboBoxItem(labels.getString("mouse"), "mouse");
        game = new ComboBoxItem(labels.getString("game"), "game");
        serial = new ComboBoxItem(labels.getString("serial"), "serial");
        usb = new ComboBoxItem(labels.getString("usb"), "usb");
        firewire = new ComboBoxItem(labels.getString("firewire"), "firewire");
        infrared = new ComboBoxItem(labels.getString("infrared"), "infrared");
        bluetooth = new ComboBoxItem(labels.getString("bluetooth"), "bluetooth");

        ComboBoxItem[] tempSwitches = {mouse, game, serial, usb, firewire, infrared, bluetooth};
        switches = tempSwitches;

        switchInputType = new JComboBox(switches);
        switchInputType.setForeground(TEXT_COLOUR);
        switchInputType.setFont(TEXT_FONT);
        switchInputType.setBackground(PANEL_BACKGROUND);		
        switchInputType.setSelectedItem(mouse);
		
        switchInputLabel = new JLabel(labels.getString("switch.input"));
        switchInputLabel.setFont(TEXT_FONT);
        switchInputLabel.setForeground(TEXT_COLOUR);
        switchInputLabel.setLabelFor(switchInputType);
        switchInputLabel.setDisplayedMnemonic(labels.getString("switch.input.mnemonic").charAt(0));

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel gridPanel = new JPanel();
        gridPanel.setBackground(PANEL_BACKGROUND);
        gridPanel.setLayout(gridbag);

        Insets insets = new Insets(5, INDENT_VALUE, 5, 5);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;
        c.insets = insets;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        gridPanel.add(codeLabel, c);

        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0.0;
        gridPanel.add(codeComboBox, c);

        c.gridx = 2;
        c.gridy = 0;
        c.weightx = 0.5;
        gridPanel.add(Box.createHorizontalStrut(1), c);

        c.gridx = 0;
        c.gridy = 1;
        c.weightx = 0.0;
        gridPanel.add(codeSwitchLabel, c);

        c.gridx = 1;
        c.gridy = 1;
        c.weightx = 0.0;
        gridPanel.add(codeSwitchField.textField, c);

        c.gridx = 0;
        c.gridy = 2;
        c.weightx = 0.0;
        gridPanel.add(switchInputLabel, c);

        c.gridx = 1;
        c.gridy = 2;
        c.weightx = 0.0;
        gridPanel.add(switchInputType, c);

        c.gridx = 0;
        c.gridy = 3;
        c.weightx = 0.0;
        gridPanel.add(timeTermination, c);

        c.gridx = 1;
        c.gridy = 3;
        c.weightx = 0.0;
        gridPanel.add(timeTerminationField.textField, c);

        c.gridx = 0;
        c.gridy = 4;
        c.weightx = 0.0;
        gridPanel.add(selectionMethodLabel, c);

        c.gridx = 1;
        c.gridy = 4;
        c.weightx = 0.0;
        gridPanel.add(selectionMethodComboBox, c);

        codedInputTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("coded.input.title"));
        codedInputTitle.setTitleFont(BORDER_TITLE_FONT);
        codedInputTitle.setTitleColor(BORDER_TITLE_COLOUR);

        JPanel codedInputPanel = new JPanel(new GridLayout(1, 1));
        codedInputPanel.setBorder(codedInputTitle);
        codedInputPanel.setBackground(PANEL_BACKGROUND);
        codedInputPanel.add(gridPanel);

        AccessibleContext ac = codeLabel.getAccessibleContext();
        ac.setAccessibleParent(codedInputPanel);
        ac = codeComboBox.getAccessibleContext();
        ac.setAccessibleParent(codedInputPanel);
        ac = codeSwitchLabel.getAccessibleContext();
        ac.setAccessibleParent(codedInputPanel);
        ac = codeSwitchField.textField.getAccessibleContext();
        ac.setAccessibleParent(codedInputPanel);
        ac = switchInputLabel.getAccessibleContext();
        ac.setAccessibleParent(codedInputPanel);
        ac = switchInputType.getAccessibleContext();
        ac.setAccessibleParent(codedInputPanel);
        ac = timeTermination.getAccessibleContext();
        ac.setAccessibleParent(codedInputPanel);
        ac = timeTerminationField.textField.getAccessibleContext();
        ac.setAccessibleParent(codedInputPanel);
        ac = selectionMethodLabel.getAccessibleContext();
        ac.setAccessibleParent(codedInputPanel);
        ac = selectionMethodComboBox.getAccessibleContext();
        ac.setAccessibleParent(codedInputPanel);

        this.add(codedInputPanel);
        this.add(Box.createVerticalGlue());

    }

    /**
     * Listener to enable/disable the time termination field.
     */
    class TimeTerminationListener implements ChangeListener {
        public void stateChanged(ChangeEvent e) {
            JCheckBox box = (JCheckBox) e.getSource();
            if (box.isSelected())
                timeTerminationField.textField.setEnabled(true);
            else
                timeTerminationField.textField.setEnabled(false);
        }
    }

    /**
     * Does the default UI settings.
     */
    protected void doDefault() {
        codeComboBox.setSelectedItem(morse);
        codeSwitchField.setText("10");
        timeTermination.setSelected(false);
        timeTerminationField.setText("10.0");
        selectionMethodComboBox.setSelectedItem(pointAndClick);
        switchInputType.setSelectedItem(mouse);
    }

    /**
     * Sets the UI values their correct settings according to the application type's document.
     */
    protected void setDomValues() {
        Element temp = DOMUtil.getFirstChildElement(generic);

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(CI_CODE))) {
            ComboBoxItem codeItem = (ComboBoxItem) findItem(codes, temp.getAttribute(VALUE));
            codeComboBox.setSelectedItem(codeItem);
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(CI_CODE_SWITCH_NUM))) {
            codeSwitchField.setText(temp.getAttribute(VALUE));
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(CI_CODE_TERM))) {
            if (temp.getAttribute(VALUE).equals("switch"))
                timeTermination.setSelected(false);
            else if (temp.getAttribute(VALUE).equals("timed")) {
                timeTermination.setSelected(true);
                Element child = DOMUtil.getFirstChildElement(temp);
                if (child != null && child.getTagName().equals(xmlLabels.getString(CI_CODE_RATE))) {
                    timeTerminationField.setText(child.getAttribute(VALUE));
                }
            }
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(CI_CODE_SELECT))) {
            ComboBoxItem selectItem = (ComboBoxItem) findItem(selectionMethods, temp.getAttribute(VALUE));
            selectionMethodComboBox.setSelectedItem(selectItem);
            temp = DOMUtil.getNextSiblingElement(temp);
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(CI_SWITCH_TYPE))) {
            ComboBoxItem switchItem = (ComboBoxItem) findItem(switches, temp.getAttribute(VALUE));
            switchInputType.setSelectedItem(switchItem);
        }
			
    }

    /**
     * Gets the root element of this application type's document.
     */
    protected Element getRootElement() {
        Element temp;

        pm.removeAllChildren(generic);

        temp = document.createElement(xmlLabels.getString(CI_CODE));
        ComboBoxItem codeItem = (ComboBoxItem) codeComboBox.getSelectedItem();
        temp.setAttribute(VALUE, codeItem.value);
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(CI_CODE_SWITCH_NUM));
        temp.setAttribute(VALUE, codeSwitchField.getValue());
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(CI_CODE_TERM));
        if (timeTermination.isSelected()) {			
            temp.setAttribute(VALUE, "timed");
            generic.appendChild(temp);

            Element time = document.createElement(xmlLabels.getString(CI_CODE_RATE));
            time.setAttribute(VALUE, timeTerminationField.getValue());
            temp.appendChild(time);
        }
        else {
            temp.setAttribute(VALUE, "switch");
            generic.appendChild(temp);
        }

        temp = document.createElement(xmlLabels.getString(CI_CODE_SELECT));
        ComboBoxItem selectItem = (ComboBoxItem) selectionMethodComboBox.getSelectedItem();
        temp.setAttribute(VALUE, selectItem.value);
        generic.appendChild(temp);

        temp = document.createElement(xmlLabels.getString(CI_SWITCH_TYPE));
        ComboBoxItem switchItem = (ComboBoxItem) switchInputType.getSelectedItem();
        temp.setAttribute(VALUE, switchItem.value);
        generic.appendChild(temp);

        return document.getDocumentElement();

    }

    /**
     * Sets new labels for this panel.
     */
    protected void setNewLabels() {
        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.CodedInput", pm.language);

        morse.name = newLabels.getString("morse");
        quartering.name = newLabels.getString("quartering");
        eightCell.name = newLabels.getString("eight.cell");
        chordic.name = newLabels.getString("chordic");

        codeLabel.setText(newLabels.getString("code"));
        codeLabel.setDisplayedMnemonic(newLabels.getString("code.mnemonic").charAt(0));

        codedInputTitle.setTitle(newLabels.getString("coded.input.title"));

        codeSwitchLabel.setText(newLabels.getString("code.switch"));
        codeSwitchLabel.setDisplayedMnemonic(newLabels.getString("code.switch.mnemonic").charAt(0));

        timeTermination.setText(newLabels.getString("time.termination"));
        timeTermination.setMnemonic(newLabels.getString("time.termination").charAt(0));
        timeTerminationField.textField.getAccessibleContext().setAccessibleName(newLabels.getString("time.termination"));

        pointAndClick.name = newLabels.getString("point.click");
        pointAndDwell.name = newLabels.getString("point.dwell");

        selectionMethodLabel.setText(newLabels.getString("select.method"));
        selectionMethodLabel.setDisplayedMnemonic(newLabels.getString("select.method.mnemonic").charAt(0));

        switchInputLabel.setText(newLabels.getString("switch.input"));
        switchInputLabel.setDisplayedMnemonic(newLabels.getString("switch.input.mnemonic").charAt(0));
        mouse.name = newLabels.getString("mouse");
        game.name = newLabels.getString("game");
        serial.name = newLabels.getString("serial");
        usb.name = newLabels.getString("usb");
        firewire.name = newLabels.getString("firewire");
        infrared.name = newLabels.getString("infrared");
        bluetooth.name = newLabels.getString("bluetooth");

        codeSwitchField.reformat();
        timeTerminationField.reformat();

        setNewButtonLabels();

        revalidate();
        repaint();	
		
    }

    /**
     * Shows the next panel or warns the user about any invalid settings values.
     */
    protected void doNext() {

        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.CodedInput", pm.language);

        if (!codeSwitchField.isInsideRange())
            pm.doRangeWarning(codeSwitchField.getLowValue(), 
                              codeSwitchField.getHighValue(), 
                              labels.getString("code.switch"));
        else if (timeTermination.isSelected() && !timeTerminationField.isInsideRange())
            pm.doRangeWarning(timeTerminationField.getLowValue(), 
                              timeTerminationField.getHighValue(), 
                              labels.getString("time.termination"));			
        else
            super.doNext();			

    }

    /**
     * Gets the application type's document.
     */
    protected Document getAppTypeDoc() {
        return document;
    }

}
