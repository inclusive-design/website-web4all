/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.border.*;
import java.awt.*;
import java.net.URL;
import javax.accessibility.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;

public class DisplayPrefs extends PWMEditPanel {

    private JCheckBox screenEnhance, textHighlight, screenReader, braille, visualAlert;

    private Hashtable appTypeSelected;

    private Hashtable buttonToType;

    private TitledBorder displayTitle;

    public DisplayPrefs(PreferenceManager pm, String inAppType, Hashtable inAppTypeSelected) {
        super(pm, inAppType, inAppType + TITLE_SUFFIX);

        appTypeSelected = inAppTypeSelected;

        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.DisplayPrefs", pm.language);

        screenEnhance = new JCheckBox(labels.getString("screen.enhance"));
        screenEnhance.setMnemonic(labels.getString("screen.enhance.mnemonic").charAt(0));
        screenEnhance.setBackground(PANEL_BACKGROUND);
        screenEnhance.setFont(QUESTION_FONT);

        textHighlight = new JCheckBox(labels.getString("text.highlight"));
        textHighlight.setMnemonic(labels.getString("text.highlight.mnemonic").charAt(0));
        textHighlight.setBackground(PANEL_BACKGROUND);
        textHighlight.setFont(QUESTION_FONT);

        screenReader = new JCheckBox(labels.getString("screen.reader"));
        screenReader.setMnemonic(labels.getString("screen.reader.mnemonic").charAt(0));
        screenReader.setBackground(PANEL_BACKGROUND);
        screenReader.setFont(QUESTION_FONT);

        braille = new JCheckBox(labels.getString("braille"));
        braille.setMnemonic(labels.getString("braille.mnemonic").charAt(0));
        braille.setBackground(PANEL_BACKGROUND);
        braille.setFont(QUESTION_FONT);
        
        visualAlert = new JCheckBox(labels.getString("visual.alert"));
        visualAlert.setMnemonic(labels.getString("visual.alert.mnemonic").charAt(0));
        visualAlert.setBackground(PANEL_BACKGROUND);
        visualAlert.setFont(QUESTION_FONT);
		        
        buttonToType = new Hashtable();
        buttonToType.put(screenEnhance, SCREEN_ENHANCE);
        buttonToType.put(textHighlight, TEXT_READING_HIGHLITE);
        buttonToType.put(screenReader, SCREEN_READER);
        buttonToType.put(braille, BRAILLE);
        buttonToType.put(visualAlert, VISUAL_ALERT);

        AccessListener al = new AccessListener();

        Enumeration keys = buttonToType.keys();
        String appType;
        JToggleButton checkBox;
        while (keys.hasMoreElements()) {
            checkBox = (JToggleButton) keys.nextElement();
            appType = (String) buttonToType.get(checkBox);
            if ( ((Boolean) appTypeSelected.get(appType)) == Boolean.TRUE )
                checkBox.setSelected(true);

            checkBox.addChangeListener(al);
        }
		
        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel displayGridPanel = new JPanel();
        displayGridPanel.setBackground(PANEL_BACKGROUND);
        displayGridPanel.setLayout(gridbag);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.weighty = 0.5;
        c.gridheight = 1;

        Insets insets = new Insets(0, INDENT_VALUE, 0, 0);
        c.insets = insets;

        c.weightx = 0.0;
        c.gridx = 0;
        c.gridy = 0;
        displayGridPanel.add(screenEnhance, c);

        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 0;
        displayGridPanel.add(Box.createHorizontalStrut(1), c);

        c.weightx = 0.0;

        c.gridx = 0;
        c.gridy = 1;
        displayGridPanel.add(textHighlight, c);

        c.gridx = 0;
        c.gridy = 2;
        displayGridPanel.add(screenReader, c);

        c.gridx = 0;
        c.gridy = 3;
        displayGridPanel.add(braille, c);

        c.gridx = 0;
        c.gridy = 4;
        displayGridPanel.add(visualAlert, c);

        displayTitle = new TitledBorder(BORDER_TITLE_LINE, 
                                        labels.getString("alt.std.display"));
        displayTitle.setTitleColor(BORDER_TITLE_COLOUR);
        displayTitle.setTitleFont(BORDER_TITLE_FONT);

        JPanel displayPanel = new JPanel(new GridLayout(1, 1));        
        displayPanel.setBorder(displayTitle);
        displayPanel.setBackground(PANEL_BACKGROUND);
        displayPanel.add(displayGridPanel);

        this.add(displayPanel);
        this.add(Box.createVerticalGlue());

        AccessibleContext ac = screenEnhance.getAccessibleContext();
        ac.setAccessibleParent(displayPanel);
        ac = textHighlight.getAccessibleContext();
        ac.setAccessibleParent(displayPanel);
        ac = screenReader.getAccessibleContext();
        ac.setAccessibleParent(displayPanel);
        ac = braille.getAccessibleContext();
        ac.setAccessibleParent(displayPanel);
        ac = visualAlert.getAccessibleContext();
        ac.setAccessibleParent(displayPanel);

        ResourceBundle buttonLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Buttons", pm.language);			

        nextButton.setPreferredSize(LARGE_BUTTON_DIM);
        nextButton.setText(buttonLabels.getString("control"));
        nextButton.setMnemonic(buttonLabels.getString("control.mnemonic").charAt(0));

        defaultButton.setText(buttonLabels.getString("clear"));
        defaultButton.setMnemonic(buttonLabels.getString("clear.mnemonic").charAt(0));
    }

    class AccessListener implements ChangeListener {
        public void stateChanged(ChangeEvent e) {
            JCheckBox box = (JCheckBox) e.getSource();
            String appType = (String) buttonToType.get(box);
            if (box.isSelected())
                appTypeSelected.put(appType, Boolean.TRUE);
            else
                appTypeSelected.put(appType, Boolean.FALSE);

        }
    }

    protected void doDefault() {

        screenEnhance.setSelected(false);
        textHighlight.setSelected(false);
        screenReader.setSelected(false);
        braille.setSelected(false);
        visualAlert.setSelected(false);

    }

    protected void setNewLabels() {
        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.DisplayPrefs", pm.language);

        displayTitle.setTitle(newLabels.getString("alt.std.display"));

        screenEnhance.setText(newLabels.getString("screen.enhance"));
        screenEnhance.setMnemonic(newLabels.getString("screen.enhance.mnemonic").charAt(0));
        
        textHighlight.setText(newLabels.getString("text.highlight"));
        textHighlight.setMnemonic(newLabels.getString("text.highlight.mnemonic").charAt(0));
        
        screenReader.setText(newLabels.getString("screen.reader"));
        screenReader.setMnemonic(newLabels.getString("screen.reader.mnemonic").charAt(0));
        
        braille.setText(newLabels.getString("braille"));
        braille.setMnemonic(newLabels.getString("braille.mnemonic").charAt(0));

        visualAlert.setText(newLabels.getString("visual.alert"));
        visualAlert.setMnemonic(newLabels.getString("visual.alert.mnemonic").charAt(0));

        setNewButtonLabels();

        revalidate();
        repaint();	
    }

    /**
     * Sets the new labels for the buttons for the current locale.
     */
    protected void setNewButtonLabels() {
        ResourceBundle buttonLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.Buttons", pm.language);			

        prevButton.setText(buttonLabels.getString("prev"));
        prevButton.setMnemonic(buttonLabels.getString("prev.mnemonic").charAt(0));

        nextButton.setText(buttonLabels.getString("control"));
        nextButton.setMnemonic(buttonLabels.getString("control.mnemonic").charAt(0));

        defaultButton.setText(buttonLabels.getString("clear"));
        defaultButton.setMnemonic(buttonLabels.getString("clear.mnemonic").charAt(0));

        cancelButton.setText(buttonLabels.getString("cancel"));
        cancelButton.setMnemonic(buttonLabels.getString("cancel.mnemonic").charAt(0));

        buttonPanel.repaint();

    }

    protected void doPrev() {
        pm.doPrevAppType(appType);
    }

    protected void doNext() {
        pm.doNextAppType(appType);
    }
    
        
}

