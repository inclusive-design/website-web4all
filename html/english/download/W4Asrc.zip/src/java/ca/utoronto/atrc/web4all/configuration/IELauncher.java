/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            IELauncher.java
 *
 * Synoposis        package ca.utoronto.atrc.web4all.configuration;
 *
]*/

package ca.utoronto.atrc.web4all.configuration;

import java.util.*;
import java.io.IOException;

import org.w3c.dom.Element;

import ca.utoronto.atrc.web4all.*;

/**
 * A "setter/launcher" that simply launches IE.  This is used by the configuration manager to
 * insure that only one copy of IE is launched and/or shutdown.
 *
 * @version $Id: IELauncher.java,v 1.5 2006/03/28 21:17:27 clown Exp $
 * @author Joseph Scheuhammer
 */
	
public class IELauncher implements SetterLauncher
{
    /** 
     * The application ID for IE.  Kind of a cheat.
     */
    private final static String APP_ID		=	"MSIE";

    /** 
     * The full path to the IE executable.
     */
    private String theIEExec;

    /** 
     * The process that represents IE.
     */
    private Process theIEProcess;

    /** 
     * The URL to go to when launching IE.
     */
    private String theLaunchUrl;

    /**
     * Constructor -- no argument; calls super().
     */
    public IELauncher()
    {
    	super();
    	theIEExec = null;
    	theIEProcess = null;
    	theLaunchUrl = "";

    }  // end theIEProcess().

    /**
     * This method is a no-op, with respect to the preferences document, since there is nothing to
     * set; however, this does retrieve the executable and the global launch url from the
     * ControlHub instance.
     * @param       inAccLipInfoPackages    Vector of AccLipInfoPackage instances (ignored).
     * @param       inControlHub            The ControlHub object used to find the path to the
     *                                      executable, and the launch URL.
     * @return                              <code>true</code> to indicate that this will launch
     *                                      MSIE -- a browser.
     */
	public boolean doSettings (Vector inAccLipInfoPackages, ControlHub inControlHub)
	{
		try
		{
			theIEExec = inControlHub.get3rdPartyExecutable (IELauncher.APP_ID);
			theLaunchUrl = inControlHub.getGlobalProperty (Web4AllPropNames.LAUNCH_URL);
		}
		
		catch (MissingResourceException mre)
		{
			ConfigManager.logException (mre);
		}
		return true;
	
	}	// end doSettings().
	
	/**
     * Startup IE.
     */
	public void doLaunch()
	{
		try
		{
ConfigManager.logDebugStatement ("IELauncher.doLaunch(), <theIEExec> is '" + (theIEExec == null ? "null" : theIEExec) + "'");
			if (theIEExec != null)
				theIEProcess = Runtime.getRuntime().exec (theIEExec + " " + theLaunchUrl);
			else
				ConfigManager.logDebugStatement ("IELauncher:  No path to MSIE executable");
		}

		catch (IOException ioe)
		{
			ConfigManager.logException(ioe);
		}
		
	}	// end doLaunch().
	
	/**
     * Shutdown IE.
     */
	public void kill()
	{
	    if (theIEProcess != null)
	    {
	      theIEProcess.destroy();
	      theIEProcess = null;
	    }
	
	}	// end kill().

	/**
     * Since IE has no local properties, this is a no-op that returns <code>true</code>.
     * @return      <code>true</code>.
     */
	public boolean initLocalProps()
	{
	    return true;
	
	}   // end initLocalProps().

}	// end class IELauncher.

