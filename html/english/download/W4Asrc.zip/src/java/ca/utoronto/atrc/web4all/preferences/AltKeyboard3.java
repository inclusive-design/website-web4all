/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

package ca.utoronto.atrc.web4all.preferences;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.net.URL;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.util.DOMUtil;

import org.apache.xpath.*;
import javax.xml.transform.TransformerException;
import org.apache.xerces.util.DOMUtil;
import javax.accessibility.AccessibleContext;

/**
 * Class which represents the third panel in editing alternative keyboard settings.
 *
 * @author David Weinkauf
 * @version $Revision: 1.7 $, $Date: 2006/03/28 16:31:09 $
 */
public class AltKeyboard3 extends PWMEditPanel {

    /**
     * The three keyboard key text fields.
     */
    protected RangedTextField keyWidthField, keyHeightField, keySpacingField;

    /**
     * The checkbox to denote if resizable keys are enabled.
     */
    private JCheckBox resizableKeys;

    /**
     * The border title for keys.
     */
    private TitledBorder keyTitle;
	
    /**
     * The three keyboard key labels.
     */
    protected JLabel keyWidthLabel, keyHeightLabel, keySpacingLabel;

    /**
     * The previous panel.
     */
    private PWMEditPanel previousDialog;

    /**
     * Sole constructor. Initializes the panel.
     *
     * @param  pm  the PreferenceManager
     * @param  inAltKeyboard2  the previous alternative keyboard panel
     * @param  inAppType  the panel's application type
     * @param  inTitleKey  the panel's title key
     */
    public AltKeyboard3(PreferenceManager pm, AltKeyboard2 inAltKeyboard2, String inAppType, String inTitleKey) {
        super(pm, inAppType, inTitleKey);
		
        previousDialog = inAltKeyboard2;

        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.AltKeyboard", pm.language);

        resizableKeys = new JCheckBox(labels.getString("resizable.keys"));
        resizableKeys.setMnemonic(labels.getString("resizable.keys.mnemonic").charAt(0));
        resizableKeys.setBackground(PANEL_BACKGROUND);
		
        JPanel resizableKeyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        resizableKeyPanel.setBackground(PANEL_BACKGROUND);
        resizableKeyPanel.add(resizableKeys);

        JTextField textField = new JTextField(5);
        textField.setFont(TEXT_FONT);

        Integer low = new Integer(1);
        Integer high = new Integer(100);
        keyWidthField = new RangedTextField(low, high, textField);
        keyWidthField.setText("10");
		
        textField = new JTextField(5);
        textField.setFont(TEXT_FONT);

        keyHeightField = new RangedTextField(low, high, textField);
        keyHeightField.setText("10");

        low = new Integer(0);
        textField = new JTextField(5);
        textField.setFont(TEXT_FONT);

        keySpacingField = new RangedTextField(low, high, textField);
        keySpacingField.setText("0");

        keyWidthLabel = new JLabel(labels.getString("key.width"));
        keyWidthLabel.setDisplayedMnemonic(labels.getString("key.width.mnemonic").charAt(0));
        keyWidthLabel.setLabelFor(keyWidthField.textField);
        keyWidthLabel.setFont(TEXT_FONT);
        keyWidthLabel.setForeground(TEXT_COLOUR);
        
        keyHeightLabel = new JLabel(labels.getString("key.height"));
        keyHeightLabel.setDisplayedMnemonic(labels.getString("key.height.mnemonic").charAt(0));
        keyHeightLabel.setLabelFor(keyHeightField.textField);
        keyHeightLabel.setFont(TEXT_FONT);
        keyHeightLabel.setForeground(TEXT_COLOUR);
        
        keySpacingLabel = new JLabel(labels.getString("key.spacing"));
        keySpacingLabel.setDisplayedMnemonic(labels.getString("key.spacing.mnemonic").charAt(0));
        keySpacingLabel.setLabelFor(keySpacingField.textField);
        keySpacingLabel.setFont(TEXT_FONT);
        keySpacingLabel.setForeground(TEXT_COLOUR);

        resizableKeys.addChangeListener(new ResizableKeyListener());
        resizableKeys.setSelected(true);
        
        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel keyGridPanel = new JPanel();
        keyGridPanel.setBackground(PANEL_BACKGROUND);
        keyGridPanel.setLayout(gridbag);

        c.fill = GridBagConstraints.HORIZONTAL; 
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weighty = 0.5;

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.0;
        c.insets = new Insets(2, INDENT_VALUE, 2, 2);;
        keyGridPanel.add(resizableKeys, c);

        c.gridx = 0;
        c.gridy = 1;
        c.weightx = 0.0;
        keyGridPanel.add(keyWidthLabel, c);

        c.gridx = 1;
        c.gridy = 1;
        c.weightx = 0.0;
        keyGridPanel.add(keyWidthField.textField, c);

        c.gridx = 2;
        c.gridy = 1;
        c.weightx = 0.5;
        keyGridPanel.add(Box.createHorizontalStrut(1), c);

        c.gridx = 0;
        c.gridy = 2;
        c.weightx = 0.0;
        keyGridPanel.add(keyHeightLabel, c);

        c.gridx = 1;
        c.gridy = 2;
        c.weightx = 0.0;
        keyGridPanel.add(keyHeightField.textField, c);

        c.gridx = 0;
        c.gridy = 3;
        c.weightx = 0.0;
        keyGridPanel.add(keySpacingLabel, c);

        c.gridx = 1;
        c.gridy = 3;
        c.weightx = 0.0;
        keyGridPanel.add(keySpacingField.textField, c);

        keyTitle = new TitledBorder(BORDER_TITLE_LINE, labels.getString("key.title"));
        keyTitle.setTitleColor(BORDER_TITLE_COLOUR);
        keyTitle.setTitleFont(BORDER_TITLE_FONT);        

        JPanel keySliderPanel = new JPanel(new GridLayout(1, 1));
        keySliderPanel.setBackground(PANEL_BACKGROUND);
        keySliderPanel.setBorder(keyTitle);
        keySliderPanel.add(keyGridPanel);

        AccessibleContext ac = resizableKeys.getAccessibleContext();
        ac.setAccessibleParent(keySliderPanel);
        ac = keyWidthLabel.getAccessibleContext();
        ac.setAccessibleParent(keySliderPanel);
        ac = keyWidthField.textField.getAccessibleContext();
        ac.setAccessibleParent(keySliderPanel);
        ac = keyHeightLabel.getAccessibleContext();
        ac.setAccessibleParent(keySliderPanel);
        ac = keyHeightField.textField.getAccessibleContext();
        ac.setAccessibleParent(keySliderPanel);
        ac = keySpacingLabel.getAccessibleContext();
        ac.setAccessibleParent(keySliderPanel);
        ac = keySpacingField.textField.getAccessibleContext();
        ac.setAccessibleParent(keySliderPanel);

        this.add(keySliderPanel);
        this.add(Box.createVerticalGlue());
    }

    /**
     * Listens for enabling/disabling of resizable keys.
     */
    class ResizableKeyListener implements ChangeListener {
        public void stateChanged(ChangeEvent e) {
            JCheckBox box = (JCheckBox) e.getSource();
            if (box.isSelected()) {
                keyWidthLabel.setEnabled(true);
                keyHeightLabel.setEnabled(true);
                keySpacingLabel.setEnabled(true);
                keyWidthField.textField.setEnabled(true);
                keyHeightField.textField.setEnabled(true);
                keySpacingField.textField.setEnabled(true);
            }
            else {
                keyWidthLabel.setEnabled(false);
                keyHeightLabel.setEnabled(false);
                keySpacingLabel.setEnabled(false);
                keyWidthField.textField.setEnabled(false);
                keyHeightField.textField.setEnabled(false);
                keySpacingField.textField.setEnabled(false);
            }
        }
    }

    /**
     * Gets the first panel for this application type.
     */
    protected PWMEditPanel getFirstPanel() {
        return previousDialog.getFirstPanel();
    }

    /**
     * Shows the previous dialog.
     */
    protected void doPrev() {
        pm.showPanel(previousDialog);
    }

    /**
     * Shows the next dialog or warns the user that a value is out of range.
     */
    protected void doNext() {

        ResourceBundle labels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.AltKeyboard", pm.language);
	   
        if (resizableKeys.isSelected() && !keyWidthField.isInsideRange())
            pm.doRangeWarning(keyWidthField.getLowValue(), 
                              keyWidthField.getHighValue(), 
                              labels.getString("key.width"));
        else if (resizableKeys.isSelected() && !keyHeightField.isInsideRange())
            pm.doRangeWarning(keyHeightField.getLowValue(), 
                              keyHeightField.getHighValue(), 
                              labels.getString("key.height"));
        else if (resizableKeys.isSelected() && !keySpacingField.isInsideRange())
            pm.doRangeWarning(keySpacingField.getLowValue(), 
                              keySpacingField.getHighValue(), 
                              labels.getString("key.spacing"));
        else
            super.doNext();

    }

    /**
     * Sets the UI values to their correct setting as demonstrated in the passed generic element.
     *
     * @param  generic  the generic element for this application type's document
     */
    protected void setDomValues(Element generic) {

        Element temp = null;

        try {
            temp = (Element) XPathAPI.selectSingleNode(generic, "//" + xmlLabels.getString(AK_GENERIC_RESIZABLE_KEYS));
        }
        catch (TransformerException te) {
            te.printStackTrace();
        }

        if (temp != null && temp.getTagName().equals(xmlLabels.getString(AK_GENERIC_RESIZABLE_KEYS))) {
            if (temp.getAttribute(VALUE).equals("false"))
                resizableKeys.setSelected(false);
            else {
                resizableKeys.setSelected(true);
                temp = DOMUtil.getFirstChildElement(temp);
				
                if (temp != null && temp.getTagName().equals(xmlLabels.getString(OK_GENERIC_KEY_HEIGHT))) {
                    keyHeightField.setText(temp.getAttribute(VALUE));
                    temp = DOMUtil.getNextSiblingElement(temp);
                }
				
                if (temp != null && temp.getTagName().equals(xmlLabels.getString(OK_GENERIC_KEY_WIDTH))) {
                    keyWidthField.setText(temp.getAttribute(VALUE));
                    temp = DOMUtil.getNextSiblingElement(temp);
                }
				
                if (temp != null && temp.getTagName().equals(xmlLabels.getString(OK_GENERIC_KEY_SPACING))) {
                    keySpacingField.setText(temp.getAttribute(VALUE));
                }
            }
        }
    }

    /**
     * Adds elements to application type's XML document according to the UI values set by the user.
     *
     * @param  document  the application type's XML document
     */
    protected void addElementsTo(Document document) {
        Element temp;
        Element generic = DOMUtil.getFirstChildElement(document.getDocumentElement());

        temp = document.createElement(xmlLabels.getString(AK_GENERIC_RESIZABLE_KEYS));
        generic.appendChild(temp);
		
        if (!resizableKeys.isSelected())
            temp.setAttribute(VALUE, "false");		
        else {
            temp.setAttribute(VALUE, "true");		

            Element child;
			
            child = document.createElement(xmlLabels.getString(OK_GENERIC_KEY_HEIGHT));
            child.setAttribute(VALUE, keyHeightField.getValue());
            temp.appendChild(child);
			
            child = document.createElement(xmlLabels.getString(OK_GENERIC_KEY_WIDTH));
            child.setAttribute(VALUE, keyWidthField.getValue());
            temp.appendChild(child);
			
            child = document.createElement(xmlLabels.getString(OK_GENERIC_KEY_SPACING));
            child.setAttribute(VALUE, keySpacingField.getValue());
            temp.appendChild(child);
        }

    }

    /**
     * Sets new labels for a new locale.
     */
    protected void setNewLabels() {
		
        ResourceBundle newLabels = ResourceBundle.getBundle("ca.utoronto.atrc.web4all.preferences.AltKeyboard", pm.language);

        resizableKeys.setText(newLabels.getString("resizable.keys"));
        resizableKeys.setMnemonic(newLabels.getString("resizable.keys.mnemonic").charAt(0));

        keyWidthLabel.setText(newLabels.getString("key.width"));
        keyWidthLabel.setDisplayedMnemonic(newLabels.getString("key.width.mnemonic").charAt(0));
        keyHeightLabel.setText(newLabels.getString("key.height"));
        keyHeightLabel.setDisplayedMnemonic(newLabels.getString("key.height.mnemonic").charAt(0));
        keySpacingLabel.setText(newLabels.getString("key.spacing"));
        keySpacingLabel.setDisplayedMnemonic(newLabels.getString("key.spacing.mnemonic").charAt(0));
        keyTitle.setTitle(newLabels.getString("key.title"));

        keyWidthField.reformat();
        keyHeightField.reformat();
        keySpacingField.reformat();

        setNewButtonLabels();

        revalidate();
        repaint();	

    }

    /**
     * Sets UI values to their default value.
     */
    protected void doDefault() {
        keyWidthField.setText("10");
        keyHeightField.setText("10");
        keySpacingField.setText("0");
        resizableKeys.setSelected(true);
    }
		
}
