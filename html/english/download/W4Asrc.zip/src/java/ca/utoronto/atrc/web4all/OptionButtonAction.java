/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:			OptionButtonAction.java
 *
 * Synopsis:		package ca.utoronto.atrc.web4all;
* 
]*/

package ca.utoronto.atrc.web4all;

import java.awt.event.*;
import javax.swing.JOptionPane;

/**
 * ActionListener for handling the option buttons for ControlHub's custom JOptionPanes.
 *
 * @version $Id: OptionButtonAction.java,v 1.3 2006/03/28 21:17:27 clown Exp $
 * @author	Joseph Scheuhammer.
 */
public class OptionButtonAction implements ActionListener
{
    /**
     * The JOptionPane that we are dismissin.
     */
    private JOptionPane theOptionPane;
    
    /**
     * Constructor -- record the relevant JOptionPane.
     * @param   inOptionPane    The JOptionPane that the button that this is an ActionListener
     *                          for is attached to.
     */
    public OptionButtonAction (JOptionPane inOptionPane)
    {
        super();
        theOptionPane = inOptionPane;
    
    }   // end OptionButtonAction().
	
    /**
     * Handle the button press by setting the value of the "parent" JOptionPane.
     * @param		inActionEvent	The ActionEvent.  Used to determine which button
     *                              was pressed.
     */
	public void actionPerformed (ActionEvent inActionEvent)
	{
	    // If there is not JOptionPane, do nothing.
	    //
	    if (theOptionPane != null)
	    {
	        // Determine which button, and, therefore, the value.  Default is "Yes".
	        //
	        Integer value;
	        if (inActionEvent.getActionCommand() == ControlHub.YES_BUTTON_CMD)
	            value = new Integer (JOptionPane.YES_OPTION);
	            
	        else if (inActionEvent.getActionCommand() == ControlHub.NO_BUTTON_CMD)
	            value = new Integer (JOptionPane.NO_OPTION);
	        
	        else if (inActionEvent.getActionCommand() == ControlHub.OK_BUTTON_CMD)
	            value = new Integer (JOptionPane.OK_OPTION);
	        
	        else
	            value = new Integer (JOptionPane.YES_OPTION);
	        
	        // Dismiss the JOptionPane dialogue.
	        //
	        theOptionPane.setValue (value);
	    }
	
	}	// end actionPerformed()
	
}	// end class OptionButtonAction.

