/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 *
 * File:            SimpleSpeech.java
 *
 * Synoposis:       package ca.utoronto.atrc.web4all.tts;
 *
 */

package ca.utoronto.atrc.web4all.tts;

import java.util.Locale;
import java.util.logging.Logger;


/**
 * Web-4-All Windows Native Speech Wrapper.
 * This class provides API to perform speech in different languages.
 * @version $Id: SimpleSpeech.java,v 1.4 2006/03/28 21:17:27 clown Exp $
 * @author  David Bolter.
 */
public class SimpleSpeech {

    public Logger theLogger;
    private boolean systemOK = false;
    private static String nativeLibrary = "NativeSpeech";
    private String language = "english";

    /**
     * Note this will attempt to load the windows TTS DLL
     * and initialize the native TTS system.
     * Logging is done in a "WindowsTTS" logger.
     */
    public SimpleSpeech () {
        theLogger = Logger.getLogger("NativeSpeech");
        theLogger.info("Creating Windows TTS...");
        try {
            systemOK = true;
            System.loadLibrary(nativeLibrary);
        }
        catch (UnsatisfiedLinkError e) {
            systemOK = false;
            theLogger.warning("could not load library.");
        }
        if (systemOK) {
            theLogger.info("Native TTS library " + nativeLibrary + " loaded");
            switch (initialize()) {
                case 0:
                    theLogger.info("Both English and French voices located. SimpleSpeech is happy.");
                    break;
                case 1:
                    theLogger.warning(nativeLibrary + " could not find any French TTS voice.");
                    theLogger.warning("SimpleSpeech TTS may have an English accent.");
                    break;
                case 2:
                    theLogger.warning(nativeLibrary + " could not find any English TTS voice.");
                    theLogger.warning("SimpleSpeech TTS may have a French accent.");
                    break;
                case 3:
                default:
                    theLogger.warning(nativeLibrary + " could not find any English or French TTS voice.");
                    theLogger.warning("SimpleSpeech will fail.");
                    systemOK = false;
                break;
            }
        }

        // Set the locale to the default, initially.
        //
        setLocale (Locale.getDefault());
    }

    /**
     * If false, TTS will not work as something very bad has happened.
     * Check the WindowsTTS log for details.
     */
    public boolean getStatus () {
        return systemOK;
    }

    /**
     * Sets or Changes the language "mode" such that TTS output will be in a voice
     * that matches the Locale language.
     * <code>inLocale</code> is currently assumed to be french or english.
     * Terribly important implementation detail: anything not "fr", "fr_CA",
     * or "fr_FR" is assumed to be english.
     * @param   inLocale
     */
    public void setLocale (Locale inLocale) {
        if (systemOK) {
            /* this check is safer in case getLanguage return value changes in future */
            if (inLocale.getLanguage().equals(new Locale("fr", "", "").getLanguage()) ||
                inLocale.getLanguage().equals(new Locale("fr_CA", "", "").getLanguage()) ||
                inLocale.getLanguage().equals(new Locale("fr_FR", "", "").getLanguage()) ) {
                french();
                language = "french";
            }
            else {
                english();
                language = "english";
            }
        }
        else {
            theLogger.warning("SimpleSpeech can't change locale.");
        }
    }

    // fix speech oddities as they crop up
    private String fixString (String inString) {
        String returnString = inString;
        if (language.equals("english")) {
            if (inString.equals(".")) {
                returnString = "dot";
            }
        }
        return returnString;
    }

    /**
     * note this will purge any current speaking.
     */
    public void speak (String inString) {
        if (systemOK) {
            say (fixString(inString));
        }
    }

    /**
     * note this will purge any current speaking.
     */
    public void speak (char inChar) {
        if (systemOK) {
            say (String.valueOf(inChar));
        }
    }

    /**
     * stops/purges all speaking.
     */
    public void stopSpeaking () {
        if (systemOK) {
            silence ();
        }
    }

    /* NOTE
       native method "initialize" return codes:
        0 : french and english voices found.
        1 : only english
        2 : only french
        3 : no voices
    */
    private native int initialize (); // set up tts system and find french and english voices

    private native int french (); // set current voice to french

    private native int english (); // set current voice to english

    private native int say (String inSayable);

    private native int silence (); // purge any speaking

}
