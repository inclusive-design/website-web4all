/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * 
 * File:			AccLipInfoPackage.java
 *
 * Synopsis:		package ca.utoronto.atrc.web4all.configuration;
 * 
]*/

package ca.utoronto.atrc.web4all.configuration;

import org.w3c.dom.Element;

/**
 * A package of information based on the contents of an ACCLIP preferences document, and
 * individuated by a type of technology (e.g., a screen reader).  Thus, an association is
 * made between a type of technology and preferences for it. The package contains
 * two sets of preferences, namely, the generic preferences and preferences specific for
 * an application (e.g., JAWS).  All the information is taken from a document
 * based on the ACCLIP schema, however, it may come from multiple such documents.
 *
 * @version $Id: AccLipInfoPackage.java,v 1.4 2006/03/28 21:17:27 clown Exp $
 * @author	Joseph Scheuhammer
 */

public class AccLipInfoPackage
{
    /** 
     * The type of technology as given by the preferences document; for example,
     * "screenReader".  This name is taken from an Element within the ACCLIP schema.
     */
    private String theAppType;
	
    /** 
     * The container Element for the generic preferences sub-tree.
     */
    private Element theGenericPrefs;
	
    /** 
     * The container Element for the specific settings.  This is the &lt;application&gt;
     * Element associated with this type of technology.  This Element usually is part of
     * the same Document as <code>theGenericPrefs</code> but need not be.
     */
    private Element theSpecificPrefs;
	
    /**
     * Instantiate the package based on the given type and preferences sets.
     * @param   inAppType           The type of application from the preferences
     *                              document/schema associated with the two sets of preferences.
     * @param   inGenericPrefs      The generic preferences from the document for this
     *                              type of technology. 
     * @param   inSpecificPrefs     The &lt;application&gt; Element for this type of
     *                              technology.  Note that this Element may come from the
     *                              same preferences document as <code>inGenericPrefs</code>,
     *                              but it may not -- it may be a "stand-alone" Element.
     */
	public AccLipInfoPackage (String inAppType, Element inGenericPrefs, Element inSpecificPrefs)
	{
	    super();
	    theAppType = inAppType;
	    theGenericPrefs = inGenericPrefs;
	    theSpecificPrefs = inSpecificPrefs;
	
	}	// end AccLipInfoPackage().
	
	/**
	 * Retrieve the type of technology.
	 * @return      The application type as a String.  This is one of the technology types defined in the
	 *              ACCLIP schema.
	 */
	public String getAppType()
	{
	    return theAppType;
	
	}   // end getAppType().
	
	/**
	 * Retrieve the generic preferences container Element.
	 * @return      The Element, from an ACCLIP document, that contains the generic
	 *              preferences.
	 */
	public Element getGenericPrefs()
	{
	    return theGenericPrefs;
	    
	}   // end getGenericPrefs().
	
	/**
	 * Retrieve the specific preferences container Element.  Note that this is an &lt;application&gt;
	 * Element, and may be part of the same document as the generic preferences, but can be
	 * a "stand-alone" Element.
	 * @return      The Element that contains the specific preferences.
	 */
	public Element getSpecificPrefs()
	{
	    return theSpecificPrefs;
	
	}   // end getSpecificPrefs().
	
}	// end class AccLipInfoPackage.

