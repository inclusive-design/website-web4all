/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            KensingtonApiSettings.java
 *
 * Synoposis:       package ca.utoronto.atrc.web4all.thirdparty;
 * 
]*/

package ca.utoronto.atrc.web4all.thirdparty;

import java.io.*;
import java.util.*;
import org.w3c.dom.*;
import org.apache.xerces.util.DOMUtil;

import ca.utoronto.atrc.web4all.*;
import ca.utoronto.atrc.web4all.configuration.*;

/**
 * Class that configures Kensington trackball based on the settings in the ACCLIP.  It makes use of
 * Kensington's Mouseworks programmable API.
 *
 * @version $Id: KensingtonApiSettings.java,v 1.9 2006/03/28 22:07:54 clown Exp $
 * @author Joseph Scheuhammer.
 */
    
public class KensingtonApiSettings extends AbstractSetterLauncher
{
    /**
     * Last argument to "tball.exe" which means "do not write to stdout".
     */
    public final static String  DONT_WRITE          = "0";
    
    /**
     * Left vs. right-handed name.
     */
    private final static String HANDEDNESS_NAME     = "Handedness";
    
    /**
     * Left vs. right-handed default (right).
     */
    private final static String HANDEDNESS_DEFAULT  = "1";
    
    /**
     * Double click speed parameter name.
     */
    private final static String DBL_CLICK_NAME       = "DblClickSpeed";
    
    /**
     * Default double click speed.
     */
    private final static String DBL_CLICK_DEFAULT   = "500";
    
    /**
     * The slope of the linear transform for a double click speed less than an ACCLIP value of
     * 6.0.
     */
    private final static float DBL_CLICK_SLOPE1     =  840.0f;
    
    /**
     * The intercept of the linear transform for a double click speed less than an ACCLIP value of
     * 6.0.
     */
    private final static float DBL_CLICK_CEPT1      =  80.0f;
    
    /**
     * The slope of the linear transform for a double click speed greater than or equal
     * to an ACCLIP value of 6.0.
     */
    private final static float DBL_CLICK_SLOPE2     =  600.0f;
    
    /**
     * The intercept of the linear transform for a double click speed greater than or equal
     * to an ACCLIP value of 6.0.
     */
    private final static float DBL_CLICK_CEPT2      =  200.0f;
    
    /**
     * Pointer speed name.
     */
    private final static String SPEED_NAME          = "Speed";
    
    /**
     * Default Pointer speed (of the trackball).
     */
    private final static String SPEED_DEFAULT       = "500";
    
    /**
     * Pointer acceleration name.
     */
    private final static String ACCEL_NAME          = "Accel";

    /**
     * Default Pointer acceleration.
     */
    private final static String ACCEL_DEFAULT       = "500";

    /**
     * Slope for linear transform of speed and acceleration.
     */
    private final static float SPEED_ACCEL_SLOPE    = 1000.0f;
    
    /**
     * Intercept for linear transform of speed and acceleration.
     */
    private final static float SPEED_ACCEL_CEPT     = 0.0f;
    
    /**
     * The ACCLIP technologies and their preferences that this Kensington trackball plug-in handles.
     */
    private final static SettingsBundle PARAMS_HANDLED[] = {
        new KensingtonApiSettings.MouseworksSettings()
    };
    
    /**
     * The value map chooser.
     */
    private final static KensingtonApiSettings.ValueMapChooser VALUE_MAP_CHOOSER = new KensingtonApiSettings.ValueMapChooser();

    /**
     * The array of default positional parameters to the Kensington settings executable.
     */
    private final static String DEFAULT_ARGS[] = {
        SPEED_DEFAULT, ACCEL_DEFAULT, HANDEDNESS_DEFAULT, DBL_CLICK_DEFAULT
    };

    /**
     * Lookup table for mapping Mousework settings to their position in the command line argument.
     */
    private final static KensingtonApiSettings.ArgIndexMap ARG_INDICES = new KensingtonApiSettings.ArgIndexMap();

    /**
     * The executable for making changes to the Kensington trackball.
     */
    private String theKensingtonExec;

    /**
     * Constructor -- no argument.
     */
    public KensingtonApiSettings()
    {
        super();    

    }  // end KensingtonApiSettings().

    /**
     * Class specific initialization -- override to avoid creating the output file, and allocate the positional
     * parameter array.
     */
    protected void init()
    {
        setUpParameters (KensingtonApiSettings.PARAMS_HANDLED, KensingtonApiSettings.VALUE_MAP_CHOOSER);
        setArgsArray (new String[KensingtonApiSettings.DEFAULT_ARGS.length]);
        setArgsIndexMap (KensingtonApiSettings.ARG_INDICES);
        theKensingtonExec = null;
        createReadProcessIStreams();
    
    }   // end init().

    /**
     * Translate the ACCLIP preferences for alternative pointing device to the values that Kensington's
     * Mouseworks understands, "outputting" them to a String array.  Then execute the command line utility
     * with that array as its command line arguments.  The command line utility sets the appropriate
     * Mouseworks parameters with the desired values.
     * @param   inAccLipInfoPackages    A Vector of AccLipInfoPackage objects that contain
     *                                  preferences for different types of technologies.  This
     *                                  handles only the "alternatePointingDevice" type.
     * @param   inControlHub            The ControlHub instance that contains information about the location
     *                                  of the command line utility.
     * @return                          <code>false</code> indicating that this does not launch a browser.
     */
    public boolean doSettings (Vector inAccLipInfoPackages, ControlHub inControlHub)
    {
        // Get the name of the ACCLIP Element that is for alternative pointing devices.  This is the only
        // technology type that "KensingtonApiSettings" handles.
        //
        String altPointingElName = inControlHub.getPrefElementName (Web4AllConstants.ALT_POINTING);
        
        // Loop thru the ACCLIP info looking for <altPointingElName>.
        //
        for (int i = 0; i < inAccLipInfoPackages.size(); i++)
        {
            // Skip any AccLipInfoPackage that is not for the "alternativePointing" type.
            //
            AccLipInfoPackage anAccLipInfo = (AccLipInfoPackage) inAccLipInfoPackages.elementAt (i);
            if (anAccLipInfo.getAppType().equals (altPointingElName) == false)
                continue;

            // Record the parent Element in the ACCLIP that contains both the generic settings and
            // specific settings.  Record, also, the ControlHub instance.  Get the application name
            // from <anAccLipInfo>'s specific preferences container.
            //
            Element prefsParentElement = (Element) anAccLipInfo.getGenericPrefs().getParentNode();
            setAppSettings (prefsParentElement);
            setControlHub (inControlHub);
            setAppID (anAccLipInfo.getSpecificPrefs());

            // Get our local properties.
            //
            boolean worked = setLocalData();
                
            // Machinery intialized: start processing the preferences.
            //
            if ((prefsParentElement != null) && worked)
            {           
                // (Re)Initialize the argument collector to default values.
                //
                String[] args = getArgsArray();
                System.arraycopy (KensingtonApiSettings.DEFAULT_ARGS, 0, args, 0, args.length);
                
                // Loop thru the children of <inPrefs>, looking for values.
                //
                loopThruGenerics (altPointingElName, anAccLipInfo.getGenericPrefs());

                // Call the utility that passes the settings to Mouseworks..
                //
                try
                {
                    // First, the command.
                    //
                    StringBuffer command = new StringBuffer (theKensingtonExec);
                    command.append (" ");       // space.
                    
                    // Now the arguments
                    //
                    for (int j = 0; j < args.length; j++)
                    {
                        command.append (args[j]);
                        command.append (" ");   // space.
                    }
 //                   command.append (DONT_WRITE);
                    
                    ConfigManager.logDebugStatement ("Command:  '" + command.toString() + "'");
                    Process nativeSetup = Runtime.getRuntime().exec (command.toString());
                    try
                    {
                        handleProcessIStreams (nativeSetup, true);
                        nativeSetup.waitFor();
                    }
                    catch (InterruptedException ie)
                    {
                        ConfigManager.logException(ie);
                    }
                }
                catch (IOException ioe)
                {
                    ConfigManager.logException(ioe);
                }
            }
        }
        return false;       // we do not launch a browser.

    }  // end doSettings().

    /**
     * Given a technology type and a preference for that type, determine if it is one that
     * we handle.  If so, write out its value.  This override is to take into account the
     * heirarchical nature of the relative pointing settings.
     * @param   inTechType      The type of technology this preference is for, as taken from the
     *                          ACCLIP. If it is not "alternativePointing", this does nothing.
     * @param   inPref          The preferences Element that represent a single trackball setting.
     * @param   isGeneric       Is <code>inPref</code> from the generic section of the preferences?
     */
    protected void handlePref (String inTechType, Element inPref, boolean isGeneric)
    {
        // Get the attributes, and look to see if it is one we handle.
        //
        String prefName = inPref.getTagName();
        
        // Dispatch to the relative pointing method if <prefName> is "relativePointing".  If "absolutePointing",
        // do nothing (the default arguments should be present).
        //
        if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.AP_GENERIC_REL_POINT)))
            handlePointingPref (inTechType, inPref);
        
        else if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.AP_GENERIC_ABS_POINT)))
            return;
                
        // Nothing special -- let the super class handle it.
        //
        else
            super.handlePref (inTechType, inPref, isGeneric);

    }  // end handlePref().
    
    /**
     * Handle the "relativePointing" sub-tree from the ACCLIP preferences.
     * @param   inTechType      The type for technology from the ACCLIP.  This SetterLauncher
     *                          handles only "alternativePointing".
     * @param   inPref          The pointing preference from the ACCLIP document.
     * #see handlePref
     */
    private void handlePointingPref (String inTechType, Element inPref)
    {
        // Loop through the children of <inPref>.
        //
        Element aChild = DOMUtil.getFirstChildElement (inPref);
        while (aChild != null)
        {
            String childName = aChild.getNodeName();
                        
            // The AbstractSettingLauncher handles this case.
            //
            super.handlePref (inTechType, aChild, true);    // "true" means generic pref.
            aChild = DOMUtil.getNextSiblingElement (aChild);
         }        
            
    }   // end handlePointingPref().

    /**
     * Map the value retrieved from the preferences document to the actual value to output.
     * This is an override since many of the Trackball preferences are calculated based on the
     * ACCLIP preference value, while some still remain simple lookups.
     * @param  inParam      The parameter of interest.  This is expressed using the technology's
     *                      vocabulary.
     * @param  inValue      The value from the ACCLIP as a String.
     * @return              The value to output, as a String.
     */
    protected String mapValue (String inParam, String inValue)
    {
        String result = null;       // return value.
        
        // Handle speed and acceleration as a straight linear transform.
        //        
        if ( (inParam.equals (KensingtonApiSettings.SPEED_NAME)) || (inParam.equals (KensingtonApiSettings.ACCEL_NAME)) )
        {
            int techVal = (int) linearCalcTechVal (inValue, KensingtonApiSettings.SPEED_ACCEL_SLOPE, KensingtonApiSettings.SPEED_ACCEL_CEPT);
            result = Integer.toString (techVal);
        }
        
        // Handle double click speed.  The slope of the transfromation is different for ACCLIP
        // values less than 6.0.
        //
        else if (inParam.equals (KensingtonApiSettings.DBL_CLICK_NAME))
        {
            float accLipVal = Float.parseFloat (inValue);
            int techVal;
            if (accLipVal < 6.0)
                techVal = (int) linearCalcTechVal (inValue, KensingtonApiSettings.DBL_CLICK_SLOPE1, KensingtonApiSettings.DBL_CLICK_CEPT1);
            else
                techVal = (int) linearCalcTechVal (inValue, KensingtonApiSettings.DBL_CLICK_SLOPE2, KensingtonApiSettings.DBL_CLICK_CEPT2);
             
             result = Integer.toString (techVal);
        }
        
        // All other handled by lookup tables.
        //
        else
            result = super.mapValue (inParam, inValue);

        ConfigManager.logDebugStatement ("For (" + inParam + "," + inValue + "), result is '" + result + "'");
        return result;
            
    }   // end mapValue().
    
    /**
     * Write the setting to the command line argument array.
     * @param  inParameter  String representing the Mouseworks setting of interest.
     * @param  inValue      String representing that setting's value.
     */
    protected void doWriteSetting (String inParameter, String inValue)
    {
        addArgToArray (inParameter, inValue);
    
    }   // end writeSetting().
    
    /**
     * Method for acquiring the path to the Kensington settings executable.
     * object.
     * @return            Did this method successfully get the path?
     */
    protected boolean setLocalData()
    {
        boolean success = false;
        
        // Get the local properties, and then the things we want from them.
        //
        try
        {
            ResourceBundle kensingtonProperties = getControlHub().get3rdPartyProperties (getAppID());
            theKensingtonExec = getControlHub().get3rdPartyExecutable (getAppID());
            ConfigManager.logDebugStatement ("KensingtonApiSettings.setLocalData():  <theKensingtonExec> is '" + (theKensingtonExec == null ? "null" : theKensingtonExec) + "'");
            success = true;
        }
        catch (MissingResourceException mre)
        {
            ConfigManager.logDebugStatement ("KensingtonApiSettings.setLocalData():  can't get local properties");
            ConfigManager.logException (mre);
            theKensingtonExec = null;
            success = false;
        }
        return success;
    
    }   // end setLocalData().

    /**
     * This SetterLauncher does not actually launch anything.  No-op implementation.
     */
    public void doLaunch()
    {
    
    }   // end doLaunch().
    
    /**
     * "Kill" the process created by <code>doLaunch()</code>.  Since nothing is actually launched, all this
     * does is reset the trackball back to default values.
     */
    public void kill()
    {
        // Don't do anything if there is no command to execute.
        //
        if (theKensingtonExec != null)
        {
            try
            {
                // Run the command.
                //
                ConfigManager.logDebugStatement ("Command:  '" + theKensingtonExec + "'");
                Process nativeSetup = Runtime.getRuntime().exec (theKensingtonExec);
                try
                {
                    handleProcessIStreams (nativeSetup, true);
                    nativeSetup.waitFor();
                }
                catch (InterruptedException ie)
                {
                    ConfigManager.logException(ie);
                }
            }
            catch (IOException ioe)
            {
                ConfigManager.logException(ioe);
            }
        }

    }  // end kill().

    /**
     * Nested class to map the ACCLIP preference name to the Kensignton trackball settings.
     * The settings are stored as a table of ParameterState objects.
     */
    private static class MouseworksSettings extends SettingsBundle
    {
        /**
         * Record the fact that these settings are of type "alternativePointing".
         */
        public MouseworksSettings()
        {
            super ("alternativePointing");
        
        }   // end VDKonscreenKeyboardSettings().
        
        public Object[][] getContents()
        {
            return contents;
        }
        
        /**
         * The lookup table.  The left side is an element name from the ACCLIP.  The right side
         * is the name of the trackball setting, whether the trackball requires that setting, and its default
         * value (as specified by the Kensington Mouseworks).
         */
        final Object[][] contents = {
        
            // ACCLIP allows for relative pointing and absolute pointing devices.  Trackball *is* a relative
            // pointing device, and supports only those settings.  If "absolute" in the ACCLIP, it is ignored
            // and the default settings for Mouseworks (speed and acceleration) is used.
            //
            { "speed", new ParameterState (KensingtonApiSettings.SPEED_NAME, true, new Integer (SPEED_DEFAULT)) },
            { "acceleration", new ParameterState (KensingtonApiSettings.ACCEL_NAME, true, new Integer (ACCEL_DEFAULT)) },
            
            // ...and the rest...
            //
            { "handedness", new ParameterState (KensingtonApiSettings.HANDEDNESS_NAME, true, new Integer (HANDEDNESS_DEFAULT)) },
            { "doubleClickSpeed", new ParameterState (KensingtonApiSettings.DBL_CLICK_NAME, true, new Integer (DBL_CLICK_DEFAULT)) }
        
        };
        
    }  // end nested class MouseworksSettings.

    /**
     * Nested class for mapping prefs handedness values to Kensington's.
     */
    private static class HandMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<value from prefs>,<trackball value>})
         */
        final Object[][] contents = {
            { "left", "0" },
            { "right", "1" }
        };

    }  // end inner class HandMap.
        
    /**
     * Nested class for mapping prefs values to the Kensington values maps.
     */
    private static class ValueMapChooser extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table (Mouseworks name, our map})
         */
        final Object[][] contents = {
            { KensingtonApiSettings.HANDEDNESS_NAME,  new HandMap() }
        };

    }  // end inner class ValueMapChooser.

    /**
     * Nested class for mapping Mousework settings to its position in the command line argument.
     */
    private static class ArgIndexMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table (Mousework setting, argument index})
         */
        final Object[][] contents = {
            { KensingtonApiSettings.SPEED_NAME, new Integer (0) },
            { KensingtonApiSettings.ACCEL_NAME, new Integer (1) },
            { KensingtonApiSettings.HANDEDNESS_NAME, new Integer (2) },
            { KensingtonApiSettings.DBL_CLICK_NAME, new Integer (3) }
        };

    }  // end inner class ArgIndexMap.

    
}   // end class KensingtonApiSettings.

