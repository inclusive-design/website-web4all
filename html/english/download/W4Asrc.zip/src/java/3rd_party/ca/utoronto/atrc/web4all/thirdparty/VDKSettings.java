/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:        VDKSettings.java
 *
 * Synoposis:   package ca.utoronto.atrc.web4all.thirdparty;
 *
]*/

package ca.utoronto.atrc.web4all.thirdparty;

import java.io.*;
import java.util.*;
import java.awt.*;

import org.w3c.dom.*;
import org.apache.xerces.util.DOMUtil;

import ca.utoronto.atrc.web4all.*;
import ca.utoronto.atrc.web4all.configuration.*;

/**
 * Writes out a textual "VDK.ini" file to set the preferences for the VDK, and launches the VDK.
 * Later, it shuts down the VDK.
 *
 * @version $Id: VDKSettings.java,v 1.14 2006/03/28 22:07:54 clown Exp $
 * @author Joseph Scheuhammer
 * @author David Bolter
 */
public class VDKSettings extends AbstractSetterLauncher
{
    /**
     * Constants that are output to the .ini file.  These come in groups -- the first is
     * the name of the setting, and the rest of the group are its values.
     */
    public final static String  KEY_WIDTH_NAME                      = "KeyWidth";
    public final static int     KEY_WIDTH_MIN                       = 10;
    public final static int     KEY_WIDTH_MAX                       = 200;
    public final static int     KEY_WIDTH_DEFAULT                   = 60;

    public final static String  KEY_HEIGHT_NAME                     = "KeyHeight";
    public final static int     KEY_HEIGHT_MIN                      = 10;
    public final static int     KEY_HEIGHT_MAX                      = 100;
    public final static int     KEY_HEIGHT_DEFAULT                  = 35;

    public final static String  KEY_SPACING_NAME                    = "KeySpacing";
    public final static int     KEY_SPACING_MIN                     = 0;
    public final static int     KEY_SPACING_MAX                     = 25;
    public final static int     KEY_SPACING_DEFAULT                 = 0;

    public final static String  KEY_SOUND_NAME                      = "SoundFlag";
    public final static String  KEY_SOUND_ON                        = "TRUE";
    public final static String  KEY_SOUND_OFF                       = "FALSE";
    public final static String  KEY_SOUND_DEFAULT                   = "FALSE";

    public final static String  ALPHA_LAYOUT_NAME                   = "AlphanumKeybrd";
    public final static int     ALPHA_LAYOUT_QWERTY                 = 0;
    public final static int     ALPHA_LAYOUT_SEQUENTIAL             = 1;
    public final static int     ALPHA_LAYOUT_FREQUENCY              = 2;
    public final static int     ALPHA_LAYOUT_DEFAULT                = 0;

    public final static String  SELECTION_METHOD_NAME               = "AccessMethod";
    public final static int     SELECTION_METHOD_DIRECT             = 0;
    public final static int     SELECTION_METHOD_DWELL              = 1;
    public final static int     SELECTION_METHOD_AUTO               = 2;
    public final static int     SELECTION_METHOD_DIRECTED           = 3;
    public final static int     SELECTION_METHOD_INVERSE            = 4;
    public final static int     SELECTION_METHOD_DEFAULT            = 0;
    public final static String  ACCLIP_POINT_CLICK_NAME             = "pointAndClick";

    public final static String  SWITCH_DELAY_NAME                   = "CLICK_SwitchDelay";
    public final static int     SWITCH_DELAY_MIN                    = 0;
    public final static int     SWITCH_DELAY_MAX                    = 25;
    public final static int     SWITCH_DELAY_DEFAULT                = 0;
    public final static int     SWITCH_DELAY_INCREMENT              = 25;       // msec.

    public final static String  DWELL_TIME_NAME                     = "DwellTime";
    public final static int     DWELL_TIME_MIN                      = 1;
    public final static int     DWELL_TIME_MAX                      = 99;
    public final static int     DWELL_TIME_DEFAULT                  = 50;
    public final static int     DWELL_TIME_INCREMENT                = 20;       // msec.
    public final static int     DWELL_TIME_BASE                     = 100;      // msec.
    
    /**
     * Scanning speed:  the VDK uses an integer in the range [1,99], which maps to [2080, 120] msec.
     * That is, "1" is a slow scan, and 99 is the fastest.  The increment and base values are
     * actually 20 and 100 msec, respectively, but since the mapping is inverted, the
     * following uses -20 and 2100 msec.
     */

    public final static String  AUTO_SCAN_SPEED_NAME                = "AUTO_ScanSpeed";
    public final static int     AUTO_SCAN_SPEED_MIN                 = 1;
    public final static int     AUTO_SCAN_SPEED_MAX                 = 99;
    public final static int     AUTO_SCAN_SPEED_DEFAULT             = 50;
    public final static int     AUTO_SCAN_SPEED_INCREMENT           = -20;       // msec.
    public final static int     AUTO_SCAN_SPEED_BASE                = 2100;      // msec.

    public final static String  AUTO_SCAN_INIT_DELAY_NAME           = "AUTO_InitialDelay";
    public final static int     AUTO_SCAN_INIT_DELAY_MIN            = 0;
    public final static int     AUTO_SCAN_INIT_DELAY_MAX            = 25;
    public final static int     AUTO_SCAN_INIT_DELAY_DEFAULT        = 10;
    public final static int     AUTO_SCAN_INIT_DELAY_INCREMENT      = 10;       // msec.

    public final static String  AUTO_SCAN_SWITCH_DELAY_NAME         = "AUTO_SwitchDelay";
    public final static int     AUTO_SCAN_SWITCH_DELAY_MIN          = 0;
    public final static int     AUTO_SCAN_SWITCH_DELAY_MAX          = 25;
    public final static int     AUTO_SCAN_SWITCH_DELAY_DEFAULT      = 25;
    public final static int     AUTO_SCAN_SWITCH_DELAY_INCREMENT    = 25;       // msec.

    public final static String  AUTO_SCAN_REPEAT_NAME               = "AUTO_RepeatCycles";
    public final static int     AUTO_SCAN_REPEAT_MIN                = 1;
    public final static int     AUTO_SCAN_REPEAT_MAX                = 7;
    public final static int     AUTO_SCAN_REPEAT_DEFAULT            = 5;

    public final static String  DIRECTED_SCAN_SPEED_NAME            = "5SWITCH_ScanSpeed";
    public final static int     DIRECTED_SCAN_SPEED_MIN             = 1;
    public final static int     DIRECTED_SCAN_SPEED_MAX             = 99;
    public final static int     DIRECTED_SCAN_SPEED_DEFAULT         = 50;

    public final static String  DIRECTED_SCAN_SWITCH_DELAY_NAME     = "5SWITCH_SwitchDelay";
    public final static int     DIRECTED_SCAN_SWITCH_DELAY_MIN      = 0;
    public final static int     DIRECTED_SCAN_SWITCH_DELAY_MAX      = 25;
    public final static int     DIRECTED_SCAN_SWITCH_DELAY_DEFAULT  = 0;

    public final static String  INVERSE_SCAN_SPEED_NAME             = "INVERSE_ScanSpeed";
    public final static int     INVERSE_SCAN_SPEED_MIN              = 1;
    public final static int     INVERSE_SCAN_SPEED_MAX              = 99;
    public final static int     INVERSE_SCAN_SPEED_DEFAULT          = 50;

    public final static String  INVERSE_SCAN_SWITCH_DELAY_NAME      = "INVERSE_SwitchDelay";
    public final static int     INVERSE_SCAN_SWITCH_DELAY_MIN       = 0;
    public final static int     INVERSE_SCAN_SWITCH_DELAY_MAX       = 25;
    public final static int     INVERSE_SCAN_SWITCH_DELAY_DEFAULT   = 0;
    public final static int     INVERSE_SCAN_SWITCH_DELAY_INCREMENT = 25;       // msec.

    // Not used?  Here for completness.
    //
    public final static String  INPUT_TYPE_NAME         = "InputType";
    public final static int     INPUT_TYPE_MOUSE        = 0;
    public final static int     INPUT_TYPE_SERIAL       = 1;
    public final static int     INPUT_TYPE_GAMEPORT     = 2;
    public final static int     INPUT_TYPE_DEFAULT      = 0;

    // Word predictor settings -- not used; here for completeness.
    //
    public final static String  WORD_PRED_NAME          = "WordPredictionOnOff";
    public final static String  WORD_PRED_ON            = "TRUE";
    public final static String  WORD_PRED_OFF           = "FALSE";
    public final static String  WORD_PRED_DEFAULT       = "FALSE";

    public final static String  ADD_WORDS_NAME          = "bAddWordsToDict";
    public final static String  ADD_WORDS_TRUE          = "TRUE";
    public final static String  ADD_WORDS_FALSE         = "FALSE";
    public final static String  ADD_WORDS_DEFAULT       = "FALSE";

    public final static String  NUM_PREDS_NAME          = "NumOfPredictions";
    public final static int     NUM_PREDS_MIN           = 1;
    public final static int     NUM_PREDS_MAX           = 10;
    public final static int     NUM_PREDS_DEFAULT       = 10;

    // A bunch of settings that are simply defaulted.
    //
    public final static String  ADD_WORD_LENGTH_NAME    = "AddDictWordLength";
    public final static int     ADD_WORD_LENGTH_DEFAULT = 5;

    public final static String  EDIT_WORDSET_NAME       = "EditDictWordSet";
    public final static String  EDIT_WORDSET_TRUE       = "TRUE";
    public final static String  EDIT_WORDSET_FALSE      = "FALSE";
    public final static String  EDIT_WORDSET_DEFAULT    = "FALSE";

    public final static String  AUTO_POSITION_NAME      = "bAutoPosition";
    public final static String  AUTO_POSITION_TRUE      = "TRUE";
    public final static String  AUTO_POSITION_FALSE     = "FALSE";
    public final static String  AUTO_POSITION_DEFAULT   = "FALSE";

    public final static String  SCAN_DIRECTION_NAME     = "bScanLeftToRight";
    public final static String  SCAN_DIRECTION_L2R      = "TRUE";
    public final static String  SCAN_DIRECTION_R2L      = "FALSE";
    public final static String  SCAN_DIRECTION_DEFAULT  = "TRUE";

    public final static String  KEYBOARD_CENTRE_X_NAME      = "KeyboardCentreX";
    public final static int     KEYBOARD_CENTRE_X_DEFAULT   = 512;
    public final static String  KEYBOARD_CENTRE_Y_NAME      = "KeyboardCentreY";
    public final static int     KEYBOARD_CENTRE_Y_DEFAULT   = 384;

    public final static String  PORT_ADDRESS_NAME           = "SerialPortAddress";
    public final static String  PORT_ADDRESS_NAME_DEFAULT   = "0x3f8";
    
    /**
     * ACCLIP name for scanning speed (regardless of selection method).
     */
    public final static String  ACCLIP_SCAN_SPEED           = "scanSpeed";
    
    /**
     * ACCLIP name for scanning switch delay (regardless of selection method).
     */
    public final static String  ACCLIP_SCAN_SWITCH_DELAY    = "scanSwitchDelay";

    /**
     * The ACCLIP technologies and their preferences that this VDK SetterLauncher handles.
     */
    private final static SettingsBundle PARAMS_HANDLED[] = {
        new VDKSettings.VDKonscreenKeyboardSettings()
    };
    
    /**
     * The value map chooser.
     */
    private final static VDKSettings.ValueMapChooser VAL_MAP_CHOOSER = new VDKSettings.ValueMapChooser();
    
    /**
     * The output file (".ini") itself.
     */
    private PrintWriter theLocalOutput;

    /**
     * Constructor -- no argument.
     */
    public VDKSettings()
    {
        super();
        theLocalOutput = null;

    }  // end VDKSettings().

    /**
     * Class specific initialization -- override.
     */
    protected void init()
    {
        setUpParameters (VDKSettings.PARAMS_HANDLED, VDKSettings.VAL_MAP_CHOOSER);
    
    }   // end init().

    /**
     * Create the "VDKSetting.ini" from the onscreen keyboard preferences in the ACCLIP.  This
     * plug-in is intereseted only in onscreen keyboard settings, and ignores all others.
     *
     * @param   inAccLipInfoPackages    A Vector of AccLipInfoPackage objects that contain
     *                                  preferences for different types of technologies.  This
     *                                  handles only the "onscreenKeyboard" type.
     * @param   inControlHub            The ControlHub that contains information about the ".ini"
     *                                  file and the path to the executable
     * @return                          <code>false</code> indicating that this does not launch a browser.
     */
    public boolean doSettings (Vector inAccLipInfoPackages, ControlHub inControlHub)
    {
        // Get the name of the ACCLIP Element that is for onscreen keyboards.  This is the only
        // technology type that "VDKSettings" handles.
        //
        String onscreenKeyboardElName = inControlHub.getPrefElementName (Web4AllConstants.ONSCREEN_KEYBOARD);
        
        // Loop thru the ACCLIP info looking for <onscreenKeyboardElName>.
        //
        for (int i = 0; i < inAccLipInfoPackages.size(); i++)
        {
            // Skip any AccLipInfoPackage that is not for the "onscreenKeyboard" type.
            //
            AccLipInfoPackage anAccLipInfo = (AccLipInfoPackage) inAccLipInfoPackages.elementAt (i);
            if (anAccLipInfo.getAppType().equals (onscreenKeyboardElName) == false)
                continue;
        
            // Record the parent Element in the ACCLIP that contains both the generic settings and
            // specific settings.  Record, also, the ControlHub instance.  Get the application name
            // from <anAccLipInfo>'s specific preferences container. Finally create the output file.
            //
            Element prefsParentElement = (Element) anAccLipInfo.getGenericPrefs().getParentNode();
            setAppSettings (prefsParentElement);
            setControlHub (inControlHub);
            setAppID (anAccLipInfo.getSpecificPrefs());
            theLocalOutput = createOutput (getControlHub().getHomeDirectory(), getControlHub().get3rdPartyIni (getAppID()), false);

            // Machinery intialized: start processing the preferences.
            //
            if (prefsParentElement != null)
            {
                // Clear the <theParamsWritten> array.
                //
                clearParamsWritten (onscreenKeyboardElName);

                // Loop thru the generic preferences within <prefsParentElement>.
                //
                loopThruGenerics (onscreenKeyboardElName, anAccLipInfo.getGenericPrefs());

                // Now, go through the <VDKSettings.PARAMS_WRITTEN>, and for each one that is not written,
                // write its default.
                //
                handleUnwrittenParams (onscreenKeyboardElName);

                // Finally, write out the standard defaults.
                //
                writeUnusedDefaults();

                // Close the output, the ".ini" file is done.
                //
                closeOutput();
            }
        }
        return false;       // we do not launch a browser.

    }  // end doSettings().

    /**
     * Given a technology type and a preference for that type, determine if it is one that
     * we handle.  If so, write out its value.  This override is to take into account the
     * hiearchical nature of the keyboard layout and selection method settings.
     * @param   inTechType      The type of technology this preference is for, as taken from the
     *                          ACCLIP. If it is not "onscreenKeyboard", this does nothing.
     * @param   inPref          The preferences Element that represent a single VDK setting.
     * @param   isGeneric       Is <code>inPref</code> from the default section of the preferences?
     * @see #handleLayoutPrefs
     * @see #handleSelMethodPrefs
     */
    protected void handlePref (String inTechType, Element inPref, boolean isGeneric)
    {
        // Map <inPref> to a VDK parameter, and see if that parameter is either layout or
        // selection method.  Dispatch to other methods as appropriate.
        //
        ParameterState paramState = findParameter (inTechType, inPref.getTagName(), true /* generic pref */);
        if (paramState != null)
        {
            if (paramState.getParamName() == SELECTION_METHOD_NAME)
                handleSelMethodPrefs (inTechType, inPref, paramState);
            
            // Nothing special -- let the super class handle it.
            //
            else
                super.handlePref (inTechType, inPref, isGeneric);
        }
 
    }  // end handlePref().
    
    /**
     * Handle the "selection method" sub-tree from the ACCLIP preferences.
     * @param   inTechType      The type for technology from the ACCLIP.
     * @param   inPref          The selection method container element from the ACCLIP document.
     * @param   inParamState    The ParameterState found for <code>inPref</code>.
     * @see #handlePref
     */
    private void handleSelMethodPrefs (String inTechType, Element inPref, ParameterState inParamState)
    {
        // Record the actual selection method as understood by the VDK.
        //
        String value = inPref.getTagName();
        String selMethod = mapValue (inParamState.getParamName(), value);
        int selectionMethod = Integer.parseInt (selMethod);
        ConfigManager.logDebugStatement ("selectionMethod: '" + selectionMethod + "' (" + value + ")");
        doWriteSetting (inParamState.getParamName(), selMethod);
        inParamState.setSetState (true);
        
        // Need to cancel the default writing of the point and click selection method.
        //
        ParameterState pointClickParamState = findParameter (inTechType, ACCLIP_POINT_CLICK_NAME, true /* generic pref */);
        if (pointClickParamState != null)
            pointClickParamState.setSetState (true);
        
        // <inPref> is a container element that contains the settings for the selection
        // method that <inPref> names.  Loop thru those settings.
        //
        Element aChild = DOMUtil.getFirstChildElement (inPref);
        while (aChild != null)
        {
            String prefName = aChild.getNodeName();
                        
            // Based on the selection method, handle scan speed and switch delay
            // differently for inverse and directed scanning.
            //            
            if (prefName.equals (ACCLIP_SCAN_SPEED))
            {
                if (selectionMethod == SELECTION_METHOD_INVERSE)
                    prefName = INVERSE_SCAN_SPEED_NAME;
                    
                else if (selectionMethod == SELECTION_METHOD_DIRECTED)
                    prefName = DIRECTED_SCAN_SPEED_NAME;
            }
            
            else if (prefName.equals (ACCLIP_SCAN_SWITCH_DELAY))
            {
                if (selectionMethod == SELECTION_METHOD_INVERSE)
                    prefName = INVERSE_SCAN_SWITCH_DELAY_NAME;
                    
                else if (selectionMethod == SELECTION_METHOD_DIRECTED)
                    prefName = DIRECTED_SCAN_SWITCH_DELAY_NAME;
            }
            
            // <prefName> properly set up.  Handle special cases of inverse or
            // directed scanning.
            //
            if ((selectionMethod == SELECTION_METHOD_INVERSE) || (selectionMethod == SELECTION_METHOD_DIRECTED))
            {
                ConfigManager.logDebugStatement ("For '" + inTechType + "' *generic* pref '" + prefName + "'");
                ParameterState paramState = findParameter (inTechType, prefName, true);
                if (paramState != null)
                {
                    String paramName = paramState.getParamName();
                    ConfigManager.logDebugStatement (paramName);
                    value = getValueValue ((Element) aChild);
                    String paramValue = mapValue (paramName, value);
                    doWriteSetting (paramName, paramValue);
                    paramState.setSetState (true);
                    ConfigManager.logDebugStatement ("wrote " + paramName);
                }
                else
                    ConfigManager.logDebugStatement ("don't handle '" + prefName + "'");
                    
                ConfigManager.logDebugStatement ("");   // new line.
            }
            
            // For all other selection methods, handle normally.
            //
            else
                super.handlePref (inTechType, aChild, true /* generic pref */);
            
            // Get next child.
            //
            aChild = DOMUtil.getNextSiblingElement (aChild);
        
        }   // end child loop.
    
    }   // end handleSelMethodPrefs().
      
    /**
     * Write the setting to the VDK's .ini file.
     * @param  inParameter  Name of the VDK setting.
     * @param  inValue      Value of that setting.
     */
    protected void doWriteSetting (String inParameter, String inValue)
    {
        writeSetting (inParameter, inValue);
    
    }   // end doWriteSetting().

    /**
     * Map the value retrieved from the preferences document to the actual value to output.
     * This is an override since many of the VDK preferences are calculated based on the
     * ACCLIP preference value, while some still remain simple lookups.
     * @param  inParam      The parameter of interest.  This is expressed using the technology's
     *                      vocabulary.
     * @param  inValue      The value from the ACCLIP as a String.
     * @return              The value to output, as a String.
     */
    protected String mapValue (String inParam, String inValue)
    {
        String result = null;       // return value.
        float slope;                // scratch.
        int vdkVal;                 // scratch.
                
        // Handle key width, height, and spacing.
        //        
        if (inParam.equals (VDKSettings.KEY_WIDTH_NAME))
            result = acclipSize2VdkSize (inValue, Percent2Pixels.WIDTH_FLAG, KEY_WIDTH_MIN, KEY_WIDTH_MAX);
        
        else if (inParam.equals (VDKSettings.KEY_HEIGHT_NAME))
            result = acclipSize2VdkSize (inValue, Percent2Pixels.HEIGHT_FLAG, KEY_HEIGHT_MIN, KEY_HEIGHT_MAX);
        
        else if (inParam.equals (VDKSettings.KEY_SPACING_NAME))
            result = acclipSize2VdkSize (inValue, Percent2Pixels.WIDTH_FLAG, KEY_SPACING_MIN, KEY_SPACING_MAX);
        
        else if (inParam.equals (VDKSettings.SWITCH_DELAY_NAME))
            result = calcVdkTimeVal (inValue, VDKSettings.SWITCH_DELAY_INCREMENT, VDKSettings.SWITCH_DELAY_MAX, VDKSettings.SWITCH_DELAY_MIN, 0);

        else if (inParam.equals (VDKSettings.DWELL_TIME_NAME))
            result = calcVdkTimeVal (inValue, VDKSettings.DWELL_TIME_INCREMENT, VDKSettings.DWELL_TIME_MAX, VDKSettings.DWELL_TIME_MIN, VDKSettings.DWELL_TIME_BASE);

        // Auto scan speed uses the same increment and base time a dwell.
        //
        else if (inParam.equals (VDKSettings.AUTO_SCAN_SPEED_NAME))
            result = calcVdkTimeVal (inValue, VDKSettings.AUTO_SCAN_SPEED_INCREMENT, VDKSettings.AUTO_SCAN_SPEED_MAX, VDKSettings.AUTO_SCAN_REPEAT_MIN, VDKSettings.AUTO_SCAN_SPEED_BASE);

        else if (inParam.equals (VDKSettings.AUTO_SCAN_INIT_DELAY_NAME))
            result = calcVdkTimeVal (inValue, VDKSettings.AUTO_SCAN_INIT_DELAY_INCREMENT, VDKSettings.AUTO_SCAN_INIT_DELAY_MAX, VDKSettings.AUTO_SCAN_INIT_DELAY_MIN, 0);

        else if (inParam.equals (VDKSettings.AUTO_SCAN_SWITCH_DELAY_NAME))
            result = calcVdkTimeVal (inValue, VDKSettings.AUTO_SCAN_SWITCH_DELAY_INCREMENT, VDKSettings.AUTO_SCAN_SWITCH_DELAY_MAX, VDKSettings.AUTO_SCAN_SWITCH_DELAY_MIN, 0);

        else if (inParam.equals (VDKSettings.INVERSE_SCAN_SPEED_NAME))
            result = calcVdkTimeVal (inValue, VDKSettings.AUTO_SCAN_SPEED_INCREMENT, VDKSettings.INVERSE_SCAN_SPEED_MAX, VDKSettings.INVERSE_SCAN_SPEED_MIN, VDKSettings.AUTO_SCAN_SPEED_BASE);
        
        else if (inParam.equals (VDKSettings.INVERSE_SCAN_SWITCH_DELAY_NAME))
            result = calcVdkTimeVal (inValue, VDKSettings.INVERSE_SCAN_SWITCH_DELAY_INCREMENT, VDKSettings.INVERSE_SCAN_SWITCH_DELAY_MAX, VDKSettings.INVERSE_SCAN_SWITCH_DELAY_MIN, 0);
        
        else if (inParam.equals (VDKSettings.DIRECTED_SCAN_SPEED_NAME))
            result = calcVdkTimeVal (inValue, VDKSettings.AUTO_SCAN_SPEED_INCREMENT, VDKSettings.DIRECTED_SCAN_SPEED_MAX, VDKSettings.DIRECTED_SCAN_SPEED_MIN, VDKSettings.AUTO_SCAN_SPEED_BASE);
        
        else if (inParam.equals (VDKSettings.DIRECTED_SCAN_SWITCH_DELAY_NAME))
            result = calcVdkTimeVal (inValue, VDKSettings.AUTO_SCAN_SWITCH_DELAY_INCREMENT, VDKSettings.DIRECTED_SCAN_SWITCH_DELAY_MAX, VDKSettings.DIRECTED_SCAN_SWITCH_DELAY_MIN, 0);
        
        // Repeat cycles is an identity map, with the exception that the VDK maximum repeat value is seven.
        // Thus, if <inValue> is greater than seven, it is mapped to seven.
        //
        else if (inParam.equals (VDKSettings.AUTO_SCAN_REPEAT_NAME))
        {
            result = inValue;   // optimism.
            
            if (inValue.equals ("infinity"))
                result = Integer.toString (AUTO_SCAN_REPEAT_MAX);
            else
            {
                int inValueInt = Integer.parseInt (inValue);
                if (inValueInt > AUTO_SCAN_REPEAT_MAX)
                    result = Integer.toString (inValueInt);
            }
        }
                
        // All other handled by lookup tables.
        //
        else
            result = super.mapValue (inParam, inValue);
        
        ConfigManager.logDebugStatement ("For (" + inParam + "," + inValue + "), result is '" + result + "'");
        return result;
    
    }   // end mapValue().
    
    /**
     * Utility to convert an ACCLIP key size (width, height, or spacing) to a value that
     * the VDK can use.  The ACCLIP sizes are given as percentages of screen width or
     * screen height.  The return value is a String representation of an integer within
     * the range that the VDK handles.
     * @param   inPercent           The ACCLIP size as a percentage.
     * @param   inHeightWidthFlag   One of <code>Percent2Pixels.WIDTH_FLAG</code> or
     *                              <code>Percent2Pixels.HEIGHT_FLAG</code>.
     * @param   inMinVdkVal         The minimum value that the VDK handles.
     * @param   inMaxVdkVal         The maximum value that the VDK handles.
     * @return                      The VDK size value as a String.
     * @see #mapValue
     * @see Percent2Pixels#WIDTH_FLAG.
     * @see Percent2Pixels#HEIGHT_FLAG
     */
    private String acclipSize2VdkSize (String inPercent, int inHeightWidthFlag, int inMinVdkVal, int inMaxVdkVal)
    {
        // Convert <inPercent> to pixels.
        //
        float percentage = Float.parseFloat (inPercent);
        int pixels = Percent2Pixels.convert2Pixels (percentage, inHeightWidthFlag);
        
        // Min/max
        //
        if (pixels < inMinVdkVal)
            pixels = inMinVdkVal;
            
        else if (pixels > inMaxVdkVal)
            pixels = inMaxVdkVal;   
        
        // Done.
        //         
        return Integer.toString (pixels);
    
    }   // end acclipSize2VdkSize().

    /**
     * Utility method to convert a floating point ACCLIP time preference value to something
     * the VDK understands.  The units of the ACCLIP values are seconds.
     * @param   inAccLipVal     String that represents a the number of secconds
     *                          for some preference.  It is assumed to be a string
     *                          representation of a float.
     * @param   inVdkIncrement  Given the range of integer values that the VDK expects,
     *                          this number is the increment that each step in that
     *                          range, in milliseconds.
     * @param   inVdkMax        An int that represents the maximum of the VDK range
     *                          of values.  This is <em>not</em> in milliseconds.
     * @param   inVdkMin        An int that represents the minimum of the VDK range
     *                          of values.  This is <em>not</em> in milliseconds.
     * @param   inVdkBase       An int that represents a base value for the VDK
     *                          setting.  This is given in msec.  Note that this can be zero.
     * @return                  The value appropriately "scaled" for the VDK.  The
     *                          return value is a String.
     * @see #mapValue
     */                       
    public String calcVdkTimeVal (String inAccLipVal, int inVdkIncrement, int inVdkMax, int inVdkMin, int inVdkBase)
    {
        String result = null;       // Return value.
        
        // Convert <inAccLipVal> to a floating point number in msec.
        // Then calcuate the "real" VDK value.
        //
        float accLipMillis = Float.parseFloat (inAccLipVal) * 1000.0f;
        int vdkActual = (int) ((accLipMillis - ((float) inVdkBase)) / ((float) inVdkIncrement));
        
        // Check for exceeding the VDK minimum or maximum.
        //
        if (vdkActual < inVdkMin)
            vdkActual = inVdkMin;
            
        else if (vdkActual > inVdkMax)
            vdkActual = inVdkMax;
        
        return (Integer.toString (vdkActual));
    
    }   // end calcVdkTimeVal().
    
    /**
     * Launch the VDK, and record the process created.
     */
    public void doLaunch()
    {
        // Generate the command.  Start with the location.
        //
        try
        {
            String command = getControlHub().get3rdPartyExecutable (getAppID());
            ConfigManager.logDebugStatement ("'" + command + "'");
            setProcess (Runtime.getRuntime().exec (command));
        }

        catch (IOException ioe)
        {
            ConfigManager.logException(ioe);
        }

    }  // end doLaunch().

    /**
     * Write a settings file with just the default settings.
     */
    public void writeDefaultSettings()
    {
        if (theLocalOutput != null)
        {
            writeSetting (KEY_WIDTH_NAME, KEY_WIDTH_DEFAULT);
            writeSetting (KEY_HEIGHT_NAME, KEY_HEIGHT_DEFAULT);
            writeSetting (KEY_SPACING_NAME, KEY_SPACING_DEFAULT);
            writeSetting (KEY_SOUND_NAME, KEY_SOUND_DEFAULT);
            writeSetting (ALPHA_LAYOUT_NAME, ALPHA_LAYOUT_DEFAULT);
            writeSetting (SELECTION_METHOD_NAME, SELECTION_METHOD_DEFAULT);
            writeSetting (SWITCH_DELAY_NAME, SWITCH_DELAY_DEFAULT);

            writeSetting (DWELL_TIME_NAME, DWELL_TIME_DEFAULT);
            writeSetting (AUTO_SCAN_SPEED_NAME, AUTO_SCAN_SPEED_DEFAULT);
            writeSetting (AUTO_SCAN_INIT_DELAY_NAME, AUTO_SCAN_INIT_DELAY_DEFAULT);
            writeSetting (AUTO_SCAN_SWITCH_DELAY_NAME, AUTO_SCAN_SWITCH_DELAY_DEFAULT);
            writeSetting (AUTO_SCAN_REPEAT_NAME, AUTO_SCAN_REPEAT_DEFAULT);
            writeSetting (INVERSE_SCAN_SPEED_NAME, INVERSE_SCAN_SPEED_DEFAULT);
            writeSetting (INVERSE_SCAN_SWITCH_DELAY_NAME, INVERSE_SCAN_SWITCH_DELAY_DEFAULT);

            writeSetting (INPUT_TYPE_NAME, INPUT_TYPE_DEFAULT);
            writeUnusedDefaults();
            theLocalOutput.flush();
        }

    }  // end writeDefaultSettings().

    /**
     * Writes the settings that are currently unused in the smart card demo.  These are
     * simply default values.
     */
    private void writeUnusedDefaults()
    {
        writeSetting (WORD_PRED_NAME, WORD_PRED_DEFAULT);
        writeSetting (ADD_WORDS_NAME, ADD_WORDS_DEFAULT);
        writeSetting (NUM_PREDS_NAME, NUM_PREDS_DEFAULT);
        writeSetting (ADD_WORD_LENGTH_NAME, ADD_WORD_LENGTH_DEFAULT);
        writeSetting (EDIT_WORDSET_NAME, EDIT_WORDSET_DEFAULT);
        writeSetting (AUTO_POSITION_NAME, AUTO_POSITION_DEFAULT);
        writeSetting (SCAN_DIRECTION_NAME, SCAN_DIRECTION_DEFAULT);
        writeSetting (PORT_ADDRESS_NAME, PORT_ADDRESS_NAME_DEFAULT);

        // For the keyboard centre, use the centre of the screen width, and the bottom of the
        // screen.
        //
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        writeSetting (KEYBOARD_CENTRE_X_NAME, screenSize.width / 2);
        writeSetting (KEYBOARD_CENTRE_Y_NAME, screenSize.height);

    }  // end writeUnusedDefaults().
    
    /**
     * When shutting down the VDK, remove any ".ini" file that was created by doSettings().
     * This is to reset the VDK's settings back to their original values -- in this case, 
     * back to "factory" settings.
     */
    public void kill()
    {
        // Let the super class shut down the VDK.
        //
        super.kill();
        
        // Remove the ini file.
        //
        String dirSep = System.getProperty ("file.separator");
        String iniPath = null;
        try
        {
            iniPath = getControlHub().getHomeDirectory() + dirSep + getControlHub().get3rdPartyIni (getAppID());
            File iniFile = new File (iniPath);
            if (iniFile.exists())
                iniFile.delete();
        }
        
        // Can't get path to ini file...log it.
        //
        catch (MissingResourceException mre)
        {
            ConfigManager.logException (mre);
        }
                       
    }   // end kill().

    /**
     * Nested class for the onscreen keyboard settings of the VDK (note that the VDK is only
     * an onscreen keybaord).  The settings are stored as a table of ParameterState objects.
     */
    private static class VDKonscreenKeyboardSettings extends SettingsBundle
    {
        /**
         * Record the fact that these settings are of type "onscreenKeyboard".
         */
        public VDKonscreenKeyboardSettings()
        {
            super ("onscreenKeyboard");
        
        }   // end VDKonscreenKeyboardSettings().
        
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table.  The left side is an element name from the ACCLIP.  The right side
         * is the name of the VDK setting, whether the VDK requires that setting, and its default
         * value (as specified by the VDK).
         */
        final Object[][] contents = {
        
            // ACCLIP allows for internal and external alpha layouts.  VDK supports only internal.
            //
            { "alphaLayoutInternal", new ParameterState (ALPHA_LAYOUT_NAME, true, new Integer (ALPHA_LAYOUT_QWERTY)) },
            
            // Key sizes.
            //
            { "keyWidth", new ParameterState (KEY_WIDTH_NAME, true, new Integer (KEY_WIDTH_DEFAULT)) },
            { "keyHeight", new ParameterState (KEY_HEIGHT_NAME, true, new Integer (KEY_HEIGHT_DEFAULT)) },
            { "keySpacing", new ParameterState (KEY_SPACING_NAME, true, new Integer (KEY_SPACING_DEFAULT)) },
            
            // Selection methods:  first point-and-click, and its sub-settings.  The "must-write-as-default-selection-method" flag
            // is intially true.  If the selection method is later discovered to be other than point and click, this "must-write.."
            // flag is set to false.  See handleSelMethodPrefs().
            //
            { ACCLIP_POINT_CLICK_NAME, new ParameterState (SELECTION_METHOD_NAME, true, new Integer (SELECTION_METHOD_DIRECT)) },
            { "switchDelay", new ParameterState (SWITCH_DELAY_NAME, true, new Integer (SWITCH_DELAY_DEFAULT)) },
 
            // Selection methods:  first point-and-dwell, and its sub-settings.
            //
            { "pointAndDwell", new ParameterState (SELECTION_METHOD_NAME, false, new Integer (SELECTION_METHOD_DWELL)) },
            { "dwellTime", new ParameterState (DWELL_TIME_NAME, true, new Integer (DWELL_TIME_DEFAULT)) },

            // Selection methods:  auto scanning.
            //
            { "autoScanning", new ParameterState (SELECTION_METHOD_NAME, false, new Integer (SELECTION_METHOD_AUTO)) },
            { "scanSpeed",  new ParameterState (AUTO_SCAN_SPEED_NAME, true, new Integer (AUTO_SCAN_SPEED_DEFAULT)) },
            { "scanSwitchDelay", new ParameterState (AUTO_SCAN_SWITCH_DELAY_NAME, true, new Integer (AUTO_SCAN_SWITCH_DELAY_DEFAULT)) },
            { "autoScanInitDelay", new ParameterState (AUTO_SCAN_INIT_DELAY_NAME, true, new Integer (AUTO_SCAN_INIT_DELAY_DEFAULT)) },
            { "autoScanRepeat", new ParameterState (AUTO_SCAN_REPEAT_NAME, true, new Integer (AUTO_SCAN_REPEAT_DEFAULT)) },

            // Selection methods: inverse scanning.  Since you can't have the same key twice in the table, use the constants
            // for inverse scan speed and switch delay as keys here (the ACCLIP uses "scanSpeed" and "scanSwitchDelay" for auto,
            // inverse, and directed scanning).  See handleInverseScanning().
            //
            { "inverseScanning", new ParameterState (SELECTION_METHOD_NAME, false, new Integer (SELECTION_METHOD_INVERSE)) },
            { INVERSE_SCAN_SPEED_NAME, new ParameterState (INVERSE_SCAN_SPEED_NAME, true, new Integer (INVERSE_SCAN_SPEED_DEFAULT)) },
            { INVERSE_SCAN_SWITCH_DELAY_NAME, new ParameterState (INVERSE_SCAN_SWITCH_DELAY_NAME, true, new Integer (INVERSE_SCAN_SWITCH_DELAY_DEFAULT)) },
                        
            // Selection methods: directed scanning.  Since you can't have the same key twice in the table, use the constants
            // for inverse scan speed and switch delay as keys here (the ACCLIP uses "scanSpeed" and "scanSwitchDelay" for auto
            // inverse, and directed scanning).  See handleDirectedScanning().
            //
            { "directedScanning", new ParameterState (SELECTION_METHOD_NAME, false, new Integer (SELECTION_METHOD_DIRECTED)) },
            { DIRECTED_SCAN_SPEED_NAME, new ParameterState (DIRECTED_SCAN_SPEED_NAME, true, new Integer (DIRECTED_SCAN_SPEED_DEFAULT)) },
            { DIRECTED_SCAN_SWITCH_DELAY_NAME, new ParameterState (DIRECTED_SCAN_SWITCH_DELAY_NAME, true, new Integer (DIRECTED_SCAN_SWITCH_DELAY_DEFAULT)) },
                        
            // And the rest...
            //
            { "sound", new ParameterState (KEY_SOUND_NAME, true, KEY_SOUND_DEFAULT) },
            { "switchType", new ParameterState (INPUT_TYPE_NAME, true, new Integer (INPUT_TYPE_MOUSE)) }

        };

    }  // end nested class VDKonscreenKeyboardSettings.
    
    /**
     * Nested class for mapping sound on/off to TRUE/FALSE.
     */
    private static class SoundMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<pref value>,<VDK value>})
         */
        final Object[][] contents = {
            { "true", "TRUE" },
            { "false", "FALSE" }
        };

    }  // end nested class SoundMap.

    /**
     * Nested class for mapping keyboard layout to .ini values.
     */
    private static class LayoutMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
        * The lookup table ({<pref value>,<VDK value>})
        */
        final Object[][] contents = {
            { "standard", "0" },
            { "sequential", "1" },
            { "frequency", "2" }
        };

    }  // end nested class LayoutMap.

    /**
     * Nested class for mapping selection method to .ini values.
     */
    private static class SelectionMethodMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
        * The lookup table ({<pref value>,<VDK value>})
        */
        final Object[][] contents = {
            { "pointAndClick", "0" },
            { "pointAndDwell", "1" },
            { "autoScanning", "2" },
            { "inverseScanning", "4" },
            { "directedScanning", "3" },
        };

    }  // end nested class SelectionMethodMap.

    /**
     * Nested class for mapping devices to .ini values.
     */
    private static class InputTypeMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
        * The lookup table ({<pref value>,<VDK value>})
        */
        final Object[][] contents = {
            { "mouse", "0" },
            { "serial", "1" },
            { "game", "2" },
            { "usb", "0" },         // default to mouse (?).
            { "firewire", "0" },    // default to mouse (?).
            { "infrared", "0" },    // default to mouse (?).
            { "bluetooth", "0" }    // default to mouse (?).
        };

    }  // end nested class InputTypeMap.

    /**
     * Nested class for mapping prefs values to our Ereader values maps.
     */
    private static class ValueMapChooser extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<param for .ini>,<our map>})
         */
        final Object[][] contents = {
            { VDKSettings.KEY_SOUND_NAME, new SoundMap() },
            { VDKSettings.ALPHA_LAYOUT_NAME, new LayoutMap() },
            { VDKSettings.SELECTION_METHOD_NAME, new SelectionMethodMap() },
            { VDKSettings.INPUT_TYPE_NAME, new InputTypeMap() },
        };

    }  // end nested class ValueMapChooser.

}  // end class VDKSettings.

