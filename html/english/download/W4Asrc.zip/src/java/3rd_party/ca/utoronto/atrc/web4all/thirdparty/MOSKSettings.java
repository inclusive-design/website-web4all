/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

/*
 * File:            MOSKSettings.java
 *
 * Synoposis:       package ca.utoronto.atrc.web4all.thirdparty;
 */
 
 package ca.utoronto.atrc.web4all.thirdparty;

import java.io.*;
import java.util.*;

import org.w3c.dom.*;

import ca.utoronto.atrc.web4all.*;
import ca.utoronto.atrc.web4all.configuration.*;

/**
 * Writes out settings for MOSK.
 *
 * Notes:
 * - This plug-in uses a modified version of the "MOSK V109 Opt3 Demo" available
 *   from Madentec. The demo was modified to eliminate the GUI and replace it with
 *   command line options.
 *
 * @version $Id: MOSKSettings.java,v 1.1 2006/03/28 16:38:56 stasia Exp $
 * @author Anastasia Cheetham
 */
public class MOSKSettings extends AbstractSetterLauncher
{

    /**
     * The argument index map.
     */
    private final static MOSKControllerArgsIndexMap ARGS_INDEX_MAP = new MOSKControllerArgsIndexMap();

    /*
     * Keys into the FontColourSetup argument index map
     */
    public final static int     MOSKCONTROLLER_NUM_ARGS        = 2;
    public final static String  MOSKCONTROLLER_SOUND           = "sound";
    public final static String  MOSKCONTROLLER_DWELL           = "pointAndDwell";
    public final static String	MOSKCONTROLLER_SOUND_DEFAULT   = "true";
    public final static String	MOSKCONTROLLER_DWELL_DEFAULT   = "false";

    /**
     * The array of default positional parameters to the Windows setter executable.
     */
    private final static String[] DEFAULT_ARGS = {
        MOSKCONTROLLER_SOUND_DEFAULT, MOSKCONTROLLER_DWELL_DEFAULT
    };

    /**
     * The key to the backup <code>.ini</code> file property. This location will be
     * use to back up the existing MOSK settings.
     */
    private final static String BACKUP_INI    = "backup.ini";

    /**
     * The ACCLIP technologies and their preferences that this MOSK SetterLauncher handles.
     */
    private final static SettingsBundle PARAMS_HANDLED[] = {
        new MOSKControllerSettings()
    };
    
    /**
     * The output file (".ini") itself.
     */
    private PrintWriter theLocalOutput;

    /**
     * Constructor -- no argument.
     */
    public MOSKSettings()
    {
        super();
        theLocalOutput = null;
		
    }  // end MOSKSettings().

    /**
     * Class specific initialization.
     */
    protected void init() {
        setUpParameters (MOSKSettings.PARAMS_HANDLED, null);
        createArgsArray(MOSKCONTROLLER_NUM_ARGS);
        setArgsArray (new String[DEFAULT_ARGS.length]);
        setArgsIndexMap (ARGS_INDEX_MAP);
	} // end init()


    /**
     * Launch the MOSK.  <code>doSettings()</code> will
     * be called first to configure the technology prior to launching it.
     * @see #doSettings(Vector,ControlHub)
     */
    public void doLaunch() {
        // Generate the command.
        //
        try
        {
         	// Start with the location.
			StringBuffer command = new StringBuffer(getControlHub().get3rdPartyExecutable (getAppID()));
			command.append(" show");
			
            // Next, the parameters.
            //
            String[] argsArray = getArgsArray();
            for (int i=0; i<argsArray.length; i++)
                command.append(" " + argsArray[i]);
  
            ConfigManager.logDebugStatement ("'" + command.toString() + "'");
            setProcess (Runtime.getRuntime().exec (command.toString()));
        }

        catch (IOException ioe)
        {
            ConfigManager.logException(ioe);
        }
	} // end doLaunch()

	public void kill() {

		// We must ask the external program to close the MOSK
		//
        try
        {
         	// Start with the location.
			StringBuffer command = new StringBuffer(getControlHub().get3rdPartyExecutable (getAppID()));
			command.append(" close");
			
            ConfigManager.logDebugStatement ("'" + command.toString() + "'");
            setProcess (Runtime.getRuntime().exec (command.toString()));
        }

        catch (IOException ioe)
        {
            ConfigManager.logException(ioe);
        }
		
        // Remove the ini file.
        //
        String dirSep = System.getProperty ("file.separator");
        String iniPath = null;
        try
        {
            iniPath = getControlHub().getHomeDirectory() + dirSep + getControlHub().get3rdPartyIni (getAppID());
            File iniFile = new File (iniPath);
            if (iniFile.exists())
                iniFile.delete();
        }
        
        // Can't get path to ini file...log it.
        //
        catch (MissingResourceException mre)
        {
            ConfigManager.logException (mre);
        }
                       
	} // end kill()

    /**
     * Configure the MOSK based on the given ACCLIP preferences.
     * The preferences are given as a list of AccLipInfoPackage objects.  Each AccLipInfoPackage
     * is identified as a specific kind of technology (e.g., a screen reader), and contains
     * a set of generic and specific settings for that technology.  The type and settings
     * use the vocabulary of the ACCLIP schema.
     * @param       inAccLipInfoPackages    A Vector of AccLipInfoPackage instances.
     * @param       inControlHub            The ControlHub object that contains information about the technology
     *                                      such as the location of an ".ini" file and the path to the
     *                                      executable.
     * @return                              A flag indicating whether this SetterLauncher launches
     *                                      a browser.
     * @see AccLipInfoPackage
     * @see ControlHub
     */
    public boolean doSettings (Vector inAccLipInfoPackages, ControlHub inControlHub) {

        // Get the name of the ACCLIP Element that is for onscreen keyboards.  This is the only
        // technology type that "MOSKSettings" handles.
        //
        String onscreenKeyboardElName = inControlHub.getPrefElementName (Web4AllConstants.ONSCREEN_KEYBOARD);
        
        // Loop thru the ACCLIP info looking for <onscreenKeyboardElName>.
        //
        for (int i = 0; i < inAccLipInfoPackages.size(); i++)
        {
            // Skip any AccLipInfoPackage that is not for the "onscreenKeyboard" type.
            //
            AccLipInfoPackage anAccLipInfo = (AccLipInfoPackage) inAccLipInfoPackages.elementAt (i);
            if (anAccLipInfo.getAppType().equals (onscreenKeyboardElName) == false)
                continue;

            // Record the parent Element in the ACCLIP that contains both the generic settings and
            // specific settings.  Record, also, the ControlHub instance.  Get the application name
            // from <anAccLipInfo>'s specific preferences container. Finally create the output file.
            //
            Element prefsParentElement = (Element) anAccLipInfo.getGenericPrefs().getParentNode();
            setAppSettings (prefsParentElement);
            setControlHub (inControlHub);
            setAppID (anAccLipInfo.getSpecificPrefs());
            theLocalOutput = createOutput (getControlHub().getHomeDirectory(), getControlHub().get3rdPartyIni (getAppID()), false);

            // Machinery intialized: start processing the preferences.
            // this process will write desired settings out to the ini file cleared above
            //
            if (prefsParentElement != null)
            {
                // Clear the <theParamsWritten> array.
                //
                clearParamsWritten (onscreenKeyboardElName);

                // (Re)Initialize the argument collector to default values.
                //
                String[] args = getArgsArray();
                System.arraycopy (DEFAULT_ARGS, 0, args, 0, args.length);
                
                // Loop thru the generic preferences within <prefsParentElement>.
                //
                loopThruGenerics (onscreenKeyboardElName, anAccLipInfo.getGenericPrefs());

                // Now, go through the <MOSKSettings.PARAMS_WRITTEN>, and for each one that is not written,
                // write its default.
                //
                handleUnwrittenParams (onscreenKeyboardElName);

                // Close the output, the ".ini" file is done.
                //
                closeOutput();
			}
		}

		return false;  // the MOSK does not launch a browser
	} // end doSettings()


    /**
     * Write the setting to the MOSK .ini file.
     *
     * @param  inParameter  Name of the MOSK setting.
     * @param  inValue      Value of that setting.
     */
    protected void doWriteSetting (String inParameter, String inValue) {
		
		addArgToArray(inParameter, inValue);
	} // end doWriteSetting()
	
    /**
     * Given a technology type and a preference for that type, determine if it is one that
     * we handle.  If so, write out its value.  This override is to take into account the
     * hiearchical nature of the keyboard layout and selection method settings.
     * @param   inTechType      The type of technology this preference is for, as taken from the
     *                          ACCLIP. If it is not "onscreenKeyboard", this does nothing.
     * @param   inPref          The preferences Element that represent a single MOSK setting.
     * @param   isGeneric       Is <code>inPref</code> from the default section of the preferences?
     * @see #handleLayoutPrefs
     * @see #handleSelMethodPrefs
     */
    protected void handlePref (String inTechType, Element inPref, boolean isGeneric)
    {
        // Map <inPref> to a MOSK parameter, and see if that parameter is either layout or
        // selection method.  Dispatch to other methods as appropriate.
        //
        ParameterState paramState = findParameter (inTechType, inPref.getTagName(), true);
        if (paramState != null)
        {
            if (paramState.getParamName() == MOSKCONTROLLER_DWELL)
                handlePointAndDwellPref (inTechType, inPref, paramState);
            
            // Nothing special -- let the super class handle it.
            //
            else
                super.handlePref (inTechType, inPref, isGeneric);
        }
 
    }  // end handlePref().
    
    /**
     * Handle the "point-and-dwell" sub-tree from the ACCLIP preferences.
     * @param   inTechType      The type for technology from the ACCLIP.
     * @param   inPref          The selection method container element from the ACCLIP document.
     * @param   inParamState    The ParameterState found for <code>inPref</code>.
     * @see #handlePref
     */
    protected void handlePointAndDwellPref (String inTechType, Element inPref, ParameterState inParamState)
	{
            String techParanmName = inParamState.getParamName();
            doWriteSetting (techParanmName, "true");
            inParamState.setSetState (true);
            ConfigManager.logDebugStatement ("wrote " + techParanmName);
	}
	
    /**
     * Map the value retrieved from the preferences document to the parameter's value.
     * @param  inParam      The parameter of interest.  This is expressed using the technology's
     *                      vocabulary.
     * @param  inValue      The value from the ACCLIP.
     * @return              The value to of the parameter, as a String.
     * @see #linearCalcTechVal(String,float,float)
     */
    protected String mapValue (String inParam, String inValue)
    {
        String result = new String();

        if ((inValue == null) || (inValue.equals("false")))
        {
            result = "false";
            ConfigManager.logDebugStatement ("For (" + inParam + "," + inValue + "), result is '" + result + "'");
        } else {
            result = "true";
            ConfigManager.logDebugStatement ("For (" + inParam + "," + inValue + "), result is '" + result + "'");
        }

        return result;
    
    }   // end mapValue().
    
    /**
     * Nested class defining the argument index map for passing arguments to MOSKController.
     */
    private static class MOSKControllerArgsIndexMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<pref value>,<MOSK value>})
         */
        final Object[][] contents = {
            { MOSKCONTROLLER_SOUND, new Integer(0) },
            { MOSKCONTROLLER_DWELL, new Integer(1) },
        };
    }   // end nested class MOSKControllerArgsIndexMap

    /**
     * Nested class for the onscreen keyboard settings of MOSK.
     * The settings are stored as a table of ParameterState objects.
     */
    private static class MOSKControllerSettings extends SettingsBundle
    {
        /**
         * Record the fact that these settings are of type "onscreenKeyboard".
         */
        public MOSKControllerSettings()
        {
            super ("onscreenKeyboard");
        
        }   // end MOSKControllerSettings().
        
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table.  The left side is an element name from the ACCLIP.  The right side
         * is the name of the MOSKController setting, whether the MOSKController requires that setting, and its default
         * value (as specified by MOSK).
         */
        final Object[][] contents = {
        
            { "sound", new ParameterState (MOSKCONTROLLER_SOUND, true, MOSKCONTROLLER_SOUND_DEFAULT) },
            { "pointAndDwell", new ParameterState (MOSKCONTROLLER_DWELL, true, MOSKCONTROLLER_DWELL_DEFAULT) },
        };

    }  // end nested class MOSKControllerSettings.


} // end class MOSKSettings
