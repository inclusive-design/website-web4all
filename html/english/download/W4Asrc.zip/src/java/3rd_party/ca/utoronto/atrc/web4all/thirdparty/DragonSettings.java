/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

/*
 * File:            DragonSettings.java
 *
 * Synoposis:       package ca.utoronto.atrc.web4all.thirdparty;
 */
 
 package ca.utoronto.atrc.web4all.thirdparty;

import java.io.*;
import java.util.*;

import org.w3c.dom.*;
import org.apache.xerces.util.DOMUtil;

import ca.utoronto.atrc.web4all.*;
import ca.utoronto.atrc.web4all.configuration.*;

/**
 * Writes out settings for Dragon Naturally Speaking.
 *
 * Notes:
 * - This plug-in works with Dragon Naturally Speaking version 8
 * - This plug-in assumes the existence of a Naturally Speaking user called "TEST"
 *   and that Naturally Speaking will launch using that user.
 *
 * @version $Id: DragonSettings.java,v 1.1 2006/03/28 16:38:10 stasia Exp $
 * @author Anastasia Cheetham
 */
public class DragonSettings extends AbstractSetterLauncher
{

    /**
     * The value map chooser.
     */
    private final static ValueMapChooser VAL_MAP_CHOOSER = new ValueMapChooser();
    
    /**
     * The element name for the voice recognition command and control settings.
     */
	final static String COMMAND_CONTROL_NAME = "commandControl";

    /**
	 * The Dragon setting name associated with the ACCLIP vocabulary preference
     */
	final static String VOCABULARY_NAME = "Disable NLP Support";

    /**
	 * The default value for the Dragon vocabulary setting
     */
	final static String	VOCABULARY_DEFAULT = "0";

    /**
	 * The Dragon setting name associated with the ACCLIP feedback preference
     */
	final static String FEEDBACK_NAME = "enx Beep on Phrase Finish";

    /**
	 * The default value for the Dragon feedback setting
     */
	final static String FEEDBACK_DEFAULT = "1";
	
    /**
     * The key to the backup <code>.ini</code> file property. This location will be
     * use to back up the existing Dragon settings.
     */
    private final static String BACKUP_INI    = "backup.ini";

    /**
     * The ACCLIP technologies and their preferences that this Dragon SetterLauncher handles.
     */
    private final static SettingsBundle PARAMS_HANDLED[] = {
        new DragonSettings.DragonVoiceRecognitionSettings(),
    };
    
    /**
     * The output file (".ini") itself.
     */
    private PrintWriter theLocalOutput;

	/**
	 * The heading to use within the output ".ini" file.
	 */
	private final static String INI_HEADING = "[Options]";
	
    /**
     * Constructor -- no argument.
     */
    public DragonSettings()
    {
        super();
        theLocalOutput = null;
		
    }  // end DragonSettings().

    /**
     * Class specific initialization.
     */
    protected void init() {
        setUpParameters (PARAMS_HANDLED, VAL_MAP_CHOOSER);
	} // end init()

    /**
     * Launch Dragon Naturally Speaking.  <code>doSettings()</code> will
     * be called first to configure the technology prior to launching it.
     * @see #doSettings(Vector,ControlHub)
     */
    public void doLaunch() {
        // Generate the command.  Start with the location.
        //
        try
        {
            String command = getControlHub().get3rdPartyExecutable (getAppID());
            ConfigManager.logDebugStatement ("'" + command + "'");
            setProcess (Runtime.getRuntime().exec (command));
        }

        catch (IOException ioe)
        {
            ConfigManager.logException(ioe);
        }
	} // end doLaunch()

    /**
     * Kill the technology and clean up any files.
     */
	public void kill() {
	
        // Let the super class shut down Dragon.
        //
        super.kill();
        
        // Restore the settings file to the state it was before we configured.
        //
		restoreLocalOutput();

        // Remove the ini file.
        //
        String dirSep = System.getProperty ("file.separator");
        String iniPath = null;
        try
        {
            iniPath = getControlHub().getHomeDirectory() + dirSep + getControlHub().get3rdPartyIni (getAppID());
            File iniFile = new File (iniPath);
            if (iniFile.exists())
                iniFile.delete();
        }
        
        // Can't get path to ini file...log it.
        //
        catch (MissingResourceException mre)
        {
            ConfigManager.logException (mre);
        }
                       
	} // end kill()

    /**
     * Configure Dragon based on the given ACCLIP preferences.
     * The preferences are given as a list of AccLipInfoPackage objects.  Each AccLipInfoPackage
     * is identified as a specific kind of technology (e.g., a screen reader), and contains
     * a set of generic and specific settings for that technology.  The type and settings
     * use the vocabulary of the ACCLIP schema.
     * @param       inAccLipInfoPackages    A Vector of AccLipInfoPackage instances.
     * @param       inControlHub            The ControlHub object that contains information about the technology
     *                                      such as the location of an ".ini" file and the path to the
     *                                      executable.
     * @return                              A flag indicating whether this SetterLauncher launches
     *                                      a browser.
     * @see AccLipInfoPackage
     * @see ControlHub
     */
    public boolean doSettings (Vector inAccLipInfoPackages, ControlHub inControlHub) {

        // Get the name of the ACCLIP Element that is for voice recognition systems.
        // This is the only technology type that "DragonSettings" handles.
        //
        String voiceRecognitionElName = inControlHub.getPrefElementName (Web4AllConstants.VOICE_REC);
        
        // Loop thru the ACCLIP info looking for <voiceRecognitionElName>.
        //
        for (int i = 0; i < inAccLipInfoPackages.size(); i++)
        {
            // Skip any AccLipInfoPackage that is not for the "voiceRecognition" type.
            //
            AccLipInfoPackage anAccLipInfo = (AccLipInfoPackage) inAccLipInfoPackages.elementAt (i);
            if (anAccLipInfo.getAppType().equals (voiceRecognitionElName) == false)
                continue;

            // Record the parent Element in the ACCLIP that contains both the generic settings and
            // specific settings.  Record, also, the ControlHub instance.  Get the application name
            // from <anAccLipInfo>'s specific preferences container. Finally create the output file.
            //
            Element prefsParentElement = (Element) anAccLipInfo.getGenericPrefs().getParentNode();
            setAppSettings (prefsParentElement);
            setControlHub (inControlHub);
            setAppID (anAccLipInfo.getSpecificPrefs());

            backupLocalOutput();
            theLocalOutput = createOutput (getControlHub().get3rdPartyIni (getAppID()), false);

            // Machinery intialized: start processing the preferences.
            // this process will write desired settings out to the ini file cleared above
            //
            if (prefsParentElement != null)
            {
                // Clear the <theParamsWritten> array.
                //
                clearParamsWritten (voiceRecognitionElName);

                // Loop thru the generic preferences within <prefsParentElement>.
                //
                loopThruGenerics (voiceRecognitionElName, anAccLipInfo.getGenericPrefs());

                // Now, go through the <DragonSettings.PARAMS_WRITTEN>, and for each one that is not written,
                // write its default.
                //
                handleUnwrittenParams (voiceRecognitionElName);

                // Close the output, the ".ini" file is done.
                //
                closeOutput();
			}
		}

		// now that desired settings are written out to the ini file,
		// append the defaults
		appendDefaultSettings();

		return false; // Dragon does not launch a browser
		
	} // end doSettings()

    /**
     * Given a technology type and a preference for that type, determine if it is one that
     * we handle.  If so, write out its value.  This override is to take into account the
     * hierarchical nature of the voice recognition settings.
     * @param   inTechType      The type of technology this preference is for, as taken from the
     *                          ACCLIP. If it is not "voiceRec", this does nothing.
     * @param   inPref          The preferences Element that represent a single Dragon setting.
     * @param   isGeneric       Is <code>inPref</code> from the default section of the preferences?
     */
    protected void handlePref (String inTechType, Element inPref, boolean isGeneric)
    {
        // Map <inPref> to a Dragon parameter, and see if that parameter is <commandControl>.
        // Dispatch to other methods as appropriate.
        //
        ParameterState paramState = findParameter (inTechType, inPref.getTagName(), true );
        if (paramState != null)
        {
            if (paramState.getParamName() == COMMAND_CONTROL_NAME)
                handleCommandControlPrefs (inTechType, inPref, paramState);
            
            // Nothing special -- let the super class handle it.
            //
            else
                super.handlePref (inTechType, inPref, isGeneric);
        }
 
    }  // end handlePref().
    
    /**
     * Handle the "commandControl" sub-tree from the ACCLIP preferences.
     * @param   inTechType      The type for technology from the ACCLIP.
     * @param   inPref          The selection method container element from the ACCLIP document.
     * @param   inParamState    The ParameterState found for <code>inPref</code>.
     * @see #handlePref
     */
    private void handleCommandControlPrefs (String inTechType, Element inPref, ParameterState inParamState)
    {
        // <inPref> is a container element that contains the settings for the selection
        // method that <inPref> names.  Loop thru those settings.
        //
        Element aChild = DOMUtil.getFirstChildElement (inPref);
        while (aChild != null)
        {
            String prefName = aChild.getNodeName();
	        String value = getValueValue ((Element) aChild);
            if ((prefName == Web4AllConstants.VR_GENERIC_FEEDBACK) || (prefName == Web4AllConstants.VR_GENERIC_VOCABULARY))
            {
	            ParameterState paramState = findParameter (inTechType, prefName, true);
	            if (paramState != null)
	            {
	                String paramName = paramState.getParamName();
	                ConfigManager.logDebugStatement (paramName);
	                String paramValue = mapValue (paramName, value);
	                doWriteSetting (paramName, paramValue);
	                paramState.setSetState (true);
	                ConfigManager.logDebugStatement ("wrote " + paramName);
	            }
	            else
	                ConfigManager.logDebugStatement ("don't handle '" + prefName + "'");
			}
			else
                super.handlePref (inTechType, aChild, true);
            
            // Get next child.
            //
            aChild = DOMUtil.getNextSiblingElement (aChild);
        
        }   // end child loop.
                        
    } // end handleCommandControlPrefs()
    
    /**
     * Write the setting to the Dragon .ini file.
     *
     * @param  inParameter  Name of the Dragon setting.
     * @param  inValue      Value of that setting.
     */
    protected void doWriteSetting (String inParameter, String inValue) {
		writeSetting(INI_HEADING, inParameter, inValue);
	} // end doWriteSetting()
	
    /**
     * Write the given paramater and its value, preceded by the given heading.
     * It is assumed that the output is valid; that is,
     * that <code>createOutputFile()</code> was called at some point prior to this method.
     *
     * @param  inHeading    String representing the heading to write.
     * @param  inParameter  String representing the parameter to write.
     * @param  inValue      String representing the value of <code>inParameter</code>.
     */
    protected void writeSetting (String inHeading, String inParameter, String inValue)
    {
        if ((inHeading != null) && (inParameter != null) &&(inValue != null))
        {
            theLocalOutput.println (inHeading);
 			writeSetting(inParameter, inValue);
        }

    }  // writeSetting (String, String, String).

	/**
	 * Create a backup of the current Dragon settings file, which will be restored after
	 * the system is reset.
	 *
     * @see #backupLocalOutput
     * @see #restoreLocalOutput
     * @see #appendDefaultSettings
	 */
	private void backupLocalOutput() {
        try
        {
            // Build the command... first the command itself.
            //
            String dirSep = System.getProperty ("file.separator");
            StringBuffer command = new StringBuffer ("cmd.exe /C copy \"");
            command.append(getControlHub().get3rdPartyIni (getAppID()));
            command.append("\" \"");
	        String backupIniFile = getControlHub().get3rdPartyProperties (getAppID()).getString (BACKUP_INI);
            command.append(getControlHub().getHomeDirectory()).append(dirSep).append(backupIniFile);
            command.append("\"");
            
            ConfigManager.logDebugStatement ("Command:  '" + command.toString() + "'");
            Process bkpProcess = Runtime.getRuntime().exec (command.toString());
            handleProcessIStreams (bkpProcess, true);
            bkpProcess.waitFor();
            ConfigManager.logDebugStatement ("Command completed.");
        }
        catch(IOException ioe)
        {
            ConfigManager.logException(ioe);
        }
        catch (InterruptedException ie)
        {
            ConfigManager.logException(ie);
        }
	} // end backupLocalOutput()
	
	/**
	 * Append the copied default settings to the output file.
	 *
     * @see #backupLocalOutput
	 */
	private void appendDefaultSettings() {
        try
        {
            // Build the command... first the command itself.
            //
            String dirSep = System.getProperty ("file.separator");
	        String backupIniFile = getControlHub().get3rdPartyProperties (getAppID()).getString (BACKUP_INI);
            String localOutputFile = getControlHub().get3rdPartyIni (getAppID());
            StringBuffer command = new StringBuffer ("cmd.exe /C type \""+backupIniFile+"\" >> \""+localOutputFile+"\"");
            
            ConfigManager.logDebugStatement ("Command:  '" + command.toString() + "'");
            Process appendProcess = Runtime.getRuntime().exec (command.toString());
            handleProcessIStreams (appendProcess, true);
            appendProcess.waitFor();
            ConfigManager.logDebugStatement ("Command completed.");
        }
        catch(IOException ioe)
        {
            ConfigManager.logException(ioe);
        }
        catch (InterruptedException ie)
        {
            ConfigManager.logException(ie);
        }
	} // end appendDefaultSettings
	
    /**
     * Write the backup copy of the ini file out to the Dragon ini file.
     * This should reset to Dragon to the backed up configuration.
     *
     * @see #backupLocalOutput
     */
    protected void restoreLocalOutput()
    {
        try
        {
            // Build the command... first the command itself.
            //
            String dirSep = System.getProperty ("file.separator");
            StringBuffer command = new StringBuffer ("cmd.exe /C copy \"");
	        String backupIniFile = getControlHub().get3rdPartyProperties (getAppID()).getString (BACKUP_INI);
            command.append(getControlHub().getHomeDirectory()).append(dirSep).append(backupIniFile);
			command.append("\" \"");
            command.append(getControlHub().get3rdPartyIni (getAppID()));
            command.append("\"");
            
            ConfigManager.logDebugStatement ("Command:  '" + command.toString() + "'");
            Process restoreProcess = Runtime.getRuntime().exec (command.toString());
            handleProcessIStreams (restoreProcess, true);
            restoreProcess.waitFor();
            ConfigManager.logDebugStatement ("Command completed.");
        }
        catch(IOException ioe)
        {
            ConfigManager.logException(ioe);
        }
        catch (InterruptedException ie)
        {
            ConfigManager.logException(ie);
        }
   }    // end reseLocalOutpu()
    
    /**
     * Nested class for the voice recognition settings of Dragon.
     * The settings are stored as a table of ParameterState objects.
     */
    private static class DragonVoiceRecognitionSettings extends SettingsBundle
    {
        /**
         * Record the fact that these settings are of type "voiceRecognition".
         */
        public DragonVoiceRecognitionSettings()
        {
            super ("voiceRecognition");
        
        }   // end DragonDwellSettings().
        
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table.  The left side is an element name from the ACCLIP.  The right side
         * is the name of the Dragon setting, whether Dragon requires that setting, and its default
         * value (as specified by Dragon).
         */
        final Object[][] contents = {
        
            { "commandControl", new ParameterState (COMMAND_CONTROL_NAME, false, null) },
            { "vocabulary", new ParameterState (VOCABULARY_NAME, false, new String (VOCABULARY_DEFAULT)) },
            { "feedback", new ParameterState (FEEDBACK_NAME, false, new Boolean (FEEDBACK_DEFAULT)) },
		};
	} // end inner class DragonVoiceRecognitionSettings
	
    /**
     * Nested class for mapping prefs values to our Dragon values maps.
     */
    private static class ValueMapChooser extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<param for .ini>,<our map>})
         */
        final Object[][] contents = {
            { FEEDBACK_NAME, new FeedbackMap() },
            { VOCABULARY_NAME, new VocabularyMap() },
        };

    }  // end nested class ValueMapChooser.

    /**
     * Nested class for mapping feedback settings to .ini values.
     */
    private static class FeedbackMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
        * The lookup table ({<pref value>,<Dragon value>})
        */
        final Object[][] contents = {
            { "true", "1" },
            { "false", "0" },
        };

    }  // end nested class FeedbackMap.

    /**
     * Nested class for mapping vocabulary settings to .ini values.
     */
    private static class VocabularyMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
        * The lookup table ({<pref value>,<Dragon value>})
        */
        final Object[][] contents = {
            { "context", "1" },
            { "natural", "0" },
        };

    }  // end nested class VocabularyMap.


} // end class DragonSettings
