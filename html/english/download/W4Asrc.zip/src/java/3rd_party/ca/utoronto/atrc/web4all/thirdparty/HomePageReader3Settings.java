/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            HomePageReader3Settings.java
 *
 * Synoposis:       package ca.utoronto.atrc.web4all.thirdparty;
 * 
]*/

package ca.utoronto.atrc.web4all.thirdparty;

import java.io.*;
import java.lang.Math;
import java.util.*;

import org.w3c.dom.*;

import ca.utoronto.atrc.web4all.*;
import ca.utoronto.atrc.web4all.configuration.*;

/**
 * Class that writes out the textual "HomePageReader3.ini" file, calls the windows app to use
 * that ini to change the Windows registry, and then launches HomePageReader.
 *
 * @version $Id: HomePageReader3Settings.java,v 1.10 2006/03/28 22:07:54 clown Exp $
 * @author  Anastasia Cheetham
 * @author  Joseph Scheuhammer
 */

public class HomePageReader3Settings extends AbstractSetterLauncher
{
    /*
     * Values for accessing the pitch map.
     */
    public final static String  PITCH_NAME          = "pitch";
    public final static String[]    PITCH_KEYS      = {"9","10","11","12","36","37","46","47"}; 
    public final static String[]    PITCH_DEFAULT   =  {"1","1","1","1","1","1","1","1"};   // male adult

    public final static String  LINK_NAME                  = "link";
    public final static String[]    LINK_STRINGS_DEFAULT   = {"funk-2.mid:string","funk-2.mid:string",":string",":string","0","2","0","2"};

    // Speak text keys are string keys
    public final static String[]    LINK_SPEAK_TEXT_KEYS    = {"13", "16"};
    public final static String[]    LINK_SPEAK_TEXT_VALS_ENGLISH    = {"link:string","link:string"};
    public final static String[]    LINK_SPEAK_TEXT_VALS_FRENCH    = {"lien:string","lien:string"};

    // Sound effect keys are string keys
    public final static String[]    LINK_SOUND_EFFECT_KEYS  = {"5", "6"};
    public final static String[]    LINK_SOUND_EFFECT_VALS  = {"Funk-2.mid:string","Funk-2.mid:string"};

    // Different voice keys are int keys
    public final static String[]    LINK_DIFF_VOICE_KEYS    = {"26","27","31","32"};
    public final static String[]    LINK_DIFF_VOICE_VALS    = {"0","1","0","1"};    // default=female adult

    public final static String[]    LINK_NONE_KEYS    = {"5", "6", "13", "16"};
    public final static String[]    LINK_NONE_VALS    = {":string",":string",":string",":string"};

    public final static String  VOLUME_NAME         = "volume";
    public final static String  VOLUME_KEY          = "8";
    public final static String  VOLUME_DEFAULT      = "16383";  // index into map

    public final static String  SPEECH_RATE_NAME            = "speechRate";
    public final static int     SPEECH_RATE_DEFAULT         = 180;
    public final static String  SPEECH_RATE_KEY             = "7";
    public final static int     SPEECH_RATE_MIN             = 70;
    public final static int     SPEECH_RATE_MAX             = 700;
    
    /**
     * Internal array for recording the pitch settings.
     * Link settings must use this information.
     */
    private String[]    thePitchSettings    = PITCH_DEFAULT;  // initialize to the pitch defaults

    /**
     * The Registry Console executable path key.
     */
    private final static String REGISTRY_EXE    = "registry.exec";
    
    /**
     * The output file (".ini") itself.
     */
    private PrintWriter theLocalOutput;

    /**
     * The Registry Console executable path.
     */
    private String theRegistryConsoleExec = null;
    
    /**
     * The key to the integer registry key property
     */
    private final static String REGISTRY_INT        = "registrykey.int";

    /**
     * The key to the string registry key property
     */
    private final static String REGISTRY_STRING     = "registrykey.string";

    /**
     * Flag indicating whether or not the pitch settings have been processed.
     * If a different voice is desired for link presentation, that must
     * be done after setting the pitch.
     */
    private boolean pitchProcessed = false;
    
    /**
     * Flag indicating whether or not a different voice is desired for link
     * presentation.
     */
    private boolean diffVoiceWanted = false;

    /**
     * Flag indicating whether or not the link settings have been processed.
     * The link settings must be processed AFTER the pitch settings.
     */
    private boolean diffVoiceProcessed = false;
    
    /**
     * The ACCLIP technologies and their preferences that this VDK SetterLauncher handles.
     */
    private final static SettingsBundle PARAMS_HANDLED[] = {
        new HomePageReader3Settings.HPRSettings()
    };
    
    /**
     * The value map chooser.
     */
    private final static HomePageReader3Settings.ValueMapChooser VALUE_MAP_CHOOSER = new HomePageReader3Settings.ValueMapChooser();

    /**
     * The HPR-specific local properties.
     */
    private ResourceBundle theLocalProperties;

    /**
     * Record of the link technology type input. Setting of link preferences must be
     * carried out after the pitch settings, so if they are encountered first, the values
     * must be recorded for later use.
     */
    private String savedLinkTechType = null;

    /**
     * Record of the link preferencea. Setting of link preferences must be
     * carried out after the pitch settings, so if they are encountered first, the values
     * must be recorded for later use.
     */
    private Element savedLinkPrefElement = null;

    /**
     * Default constructor.
     */
    public HomePageReader3Settings()
    {
        super();
        
    }  // end HomePageReader3Settings().

    /**
     * Class specific initialization.
     */
    protected void init()
    {
        // Initialize the parameters.
        //
        setUpParameters (HomePageReader3Settings.PARAMS_HANDLED, HomePageReader3Settings.VALUE_MAP_CHOOSER);
        theRegistryConsoleExec = null;
        createReadProcessIStreams();
    
    }   // end init().

    /**
     * Create the ".ini" from the given DOM sub-tree.
     *
     * @param   inAccLipInfoPackages    A Vector of AccLipInfoPackage objects that contain
     *                                  preferences for different types of technologies.  This
     *                                  handles only the "screenEnhance" type.
     * @param   inControlHub            The ControlHub that contains information about the application
     * @return                      <code>true</code> indicating that this intends to launch a browser.
     */
    public boolean doSettings (Vector inAccLipInfoPackages, ControlHub inControlHub)
    {
        // Get the name of the ACCLIP Element that is for screen readers.  This is the only
        // technology type that "HomePageReader3Settings" handles.
        //
        String screenReaderElName = inControlHub.getPrefElementName (Web4AllConstants.SCREEN_READER);
        
        // Loop thru the ACCLIP info looking for <screenReaderElName>.
        //
        for (int i = 0; i < inAccLipInfoPackages.size(); i++)
        {
            // Skip any AccLipInfoPackage that is not for the "screenReader" type.
            //
            AccLipInfoPackage anAccLipInfo = (AccLipInfoPackage) inAccLipInfoPackages.elementAt (i);
            if (anAccLipInfo.getAppType().equals (screenReaderElName) == false)
                continue;
        
            // Record the parent Element in the ACCLIP that contains both the generic settings and
            // specific settings.  Record, also, the ControlHub instance.  Get the application name
            // from <anAccLipInfo>'s specific preferences container. Finally create the output file.
            //
            Element prefsParentElement = (Element) anAccLipInfo.getGenericPrefs().getParentNode();
            setAppSettings (prefsParentElement);
            setControlHub (inControlHub);
            setAppID (anAccLipInfo.getSpecificPrefs());
            theLocalOutput = createOutput (getControlHub().get3rdPartyIni (getAppID()));
            theLocalProperties = getControlHub().get3rdPartyProperties (getAppID());

            // Start processing the preferences.
            //
            if (prefsParentElement != null)
            {
                // Clear the <theParamsWritten> array.
                //
                clearParamsWritten (screenReaderElName);

                // Loop thru the generic preferences within <prefsParentElement>.
                //
                loopThruGenerics (screenReaderElName, anAccLipInfo.getGenericPrefs());


                // If necessary, handle the 'differnt voice' link settings now
                //
                if (!diffVoiceProcessed)
                {
                    if (diffVoiceWanted)
                        handleDifferentVoice(savedLinkTechType, savedLinkPrefElement);
                    else
                    {
                        // want voice setting to be explicitly the same
                        String iniHeader = getControlHub().get3rdPartyProperties (getAppID()).getString (HomePageReader3Settings.REGISTRY_INT);
                        theLocalOutput.println (iniHeader);
                        for (i=0; i<LINK_DIFF_VOICE_KEYS.length; i++)
                        {
                            doWriteSetting (LINK_DIFF_VOICE_KEYS[i], PITCH_DEFAULT[i]);
                        }
                    }
                }
                    
                // Now, go through the <VDKSettings.PARAMS_WRITTEN>, and for each one that is not written,
                // write its default.
                //
                handleUnwrittenParams (screenReaderElName);


                // Close the output files.
                //
                closeOutput();

                // call the process that sets writes the values to the registry.
                writeToRegistry();
            }

        }

        return true;        // we do launch a browser.
        
    }  // end doSettings().

    /**
     * Given a technology type and a preference for that type, determine if it is one that
     * we handle.  If so, write out its value.  This override is to take into account the
     * multiple values that must be written out for pitch and link settings.
     * @param   inTechType      The type of technology this preference is for, as taken from the
     *                          ACCLIP. If it is not "screenReader", this does nothing.
     * @param   inPref          The preferences Element that represent a single screen reader setting.
     * @param   isGeneric       Is <code>inPref</code> from the default section of the preferences?
     */
    protected void handlePref (String inTechType, Element inPref, boolean isGeneric)
    {
        // Get the attributes, and look to see if it is one we handle.
        //
        String prefName = inPref.getTagName();
        
        // Dispatch to methods specific to the settings
        //
        if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.SR_GENERIC_PITCH)))
        {
            handlePrefArray (inTechType, inPref);
            pitchProcessed = true;
        }
        else if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.SR_GENERIC_LINK)) )
            handleLinkPref (inTechType, inPref);

        else if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.SR_GENERIC_SPEECH_RATE)) )
            handleSpeechRatePref (inTechType, inPref);

        // Nothing special -- let the super class handle it through a value map.
        //
        else
            super.handlePref (inTechType, inPref, isGeneric);

    }  // end handlePref().
    
    /**
     * Method to handle an array of settings mapped to a single preference. 
     * @param   inTechType      The type of technology this preference is for, as taken from the
     *                          ACCLIP. If it is not "screenReader", this does nothing.
     * @param   inPref          The preferences Element that represent a single screen reader setting.
     */
    protected void handlePrefArray (String inTechType, Element inPref)
    {
        // Get the attributes, and look to see if it is one we handle.
        //
        String prefName = inPref.getTagName();
        ConfigManager.logDebugStatement (prefName);

        // Look for <inTechType> in the parameters handles.  If found, write out the setting.
        //
        ParameterState techParamState = findParameter (inTechType, prefName, true);
        if (techParamState != null)
        {
            // Knowing that these arrays are for integer values only,
            // write out an appropriate registry key header first
            //
            String iniHeaderInt = getControlHub().get3rdPartyProperties (getAppID()).getString (HomePageReader3Settings.REGISTRY_INT);
            theLocalOutput.println (iniHeaderInt);

            String techParamName = techParamState.getParamName();
            ConfigManager.logDebugStatement (techParamName);
            String value = getValueValue (inPref);
            String[] realValues = mapValueArray (techParamName, value);
            String[] keys = getArrayKeys(techParamName, value);
            int c = getArrayCount(techParamName, value);
            for (int i=0; i<c; i++)
            {
                doWriteSetting (keys[i], realValues[i]);
                
                if (prefName.equals("pitch"))
                    // record the desired pitch settings for use by the link settings
                    thePitchSettings[i] = realValues[i];
            }
            techParamState.setSetState (true);
            ConfigManager.logDebugStatement ("wrote " + techParamName);
        }
        else
        {
            ConfigManager.logDebugStatement ("'" + inPref + "' not handled");
        }

    }   // end handlePrefArray()
    
    /**
     * @param   inTechType      The type of technology this preference is for, as taken from the
     *                          ACCLIP. If it is not "onscreenKeyboard", this does nothing.
     * @param   inPref          The preferences Element that represent a single VDK setting.
     */
    protected void handleLinkPref (String inTechType, Element inPref)
    {
        // A link pref other than different voice is handled just as any other
        // pref array
        String linktype = getValueValue(inPref);
        
        if (linktype.equals("differentVoice"))
        {
            handleDifferentVoice(inTechType, inPref);
            return;
        }
        else
        {
            handlePrefKeyValMap(inTechType, inPref);
            return;
        }
    }   // end handleLinkPref()
    
    /**
     * @param   inTechType      The type of technology this preference is for, as taken from the
     *                          ACCLIP. If it is not "onscreenKeyboard", this does nothing.
     * @param   inPref          The preferences Element that represent a single VDK setting.
     */
    protected void handleDifferentVoice(String inTechType, Element inPref)
    {
           
        // if we haven't processed the pitch yet, we can't set the
        // link voice to be different, so we will postpone it.
        if (!pitchProcessed)
        {
            // set aside necessary information to process the link settings later
            savedLinkTechType = inTechType;
            savedLinkPrefElement = inPref;
            diffVoiceWanted = true;
            return;
        }
    
        // Get the attributes, and look to see if it is one we handle.
        //
        String prefName = inPref.getTagName();
        ConfigManager.logDebugStatement (prefName);

        // Look for <inTechType> in the parameters handles.  If found, write out the setting.
        //
        ParameterState techParamState = findParameter (inTechType, prefName, true);
        if (techParamState != null)
        {
            String techParamName = techParamState.getParamName();
            ConfigManager.logDebugStatement (techParamName);

            // Knowing that these arrays are integers only,
            // write out an appropriate registry key header first
            //
            String iniHeaderInt = getControlHub().get3rdPartyProperties (getAppID()).getString (HomePageReader3Settings.REGISTRY_INT);
            theLocalOutput.println (iniHeaderInt);

            String[] keys = LINK_DIFF_VOICE_KEYS;
            int i, x;
            for (i=0; i<keys.length; i++)
            {
                x = Integer.parseInt(thePitchSettings[i]);
                x = (x+1)%2;
                doWriteSetting (keys[i], Integer.toString(x));
            }
            
            techParamState.setSetState (true);
            ConfigManager.logDebugStatement ("wrote " + techParamName);
        }        
        diffVoiceProcessed = true;
    }   // end handleDifferentVoice()
    
    /**
     * Method to handle an array of settings mapped to a single preference. 
     * @param   inTechType      The type of technology this preference is for, as taken from the
     *                          ACCLIP. If it is not "screenReader", this does nothing.
     * @param   inPref          The preferences Element that represent a single screen reader setting.
     */
    protected void handlePrefKeyValMap (String inTechType, Element inPref)
    {
        // Get the attributes, and look to see if it is one we handle.
        //
        String prefName = inPref.getTagName();
        ConfigManager.logDebugStatement (prefName);
        // Look for <inTechType> in the parameters handles.  If found, write out the setting.
        //
        ParameterState techParamState = findParameter (inTechType, prefName, true);
        if (techParamState != null)
        {
            // Knowing that these arrays are for integer values only,
            // write out an appropriate registry key header first
            //
            String iniHeaderString = getControlHub().get3rdPartyProperties (getAppID()).getString (HomePageReader3Settings.REGISTRY_STRING);
            theLocalOutput.println (iniHeaderString);

            String techParamName = techParamState.getParamName();
            ConfigManager.logDebugStatement (techParamName);
            String value = getValueValue (inPref);
			// the 'speak the word "link"' preference must be locale
			// specific
			if (prefName.equals("link")) {
			    if(value.equals("speakLink")) {
					Locale loc = getControlHub().getLocale();
					value = value.concat(loc.toString());
			    }
			}
            KeyValMap valmap = mapValues(techParamName, value);
            
            String[] keys = valmap.keys();
            String[] realValues =valmap.vals();
            for (int i=0; i<keys.length; i++)
                doWriteSetting (keys[i], realValues[i]);

            techParamState.setSetState (true);
            ConfigManager.logDebugStatement ("wrote " + techParamName);
        }
        else
        {
            ConfigManager.logDebugStatement ("'" + inPref + "' not handled");
        }

    }   // end handlePrefKeyValMap()
    
    /**
     * Method to handle a Home Page Reader speech rate setting. The value in the ACCLIP preferences
     * is to be written out exactly - no mapping is to be carried out.
     * @param   inTechType      The type of technology this preference is for, as taken from the
     *                          ACCLIP. If it is not "screenReader", this does nothing.
     * @param   inPref          The preferences Element that represent a single screen reader setting.
     */
    protected void handleSpeechRatePref (String inTechType, Element inPref)
    {
        // Get the attributes, and look to see if it is one we handle.
        //
        String prefName = inPref.getTagName();
        ConfigManager.logDebugStatement (prefName);

        // Look for <inTechType> in the parameters handles.  If found, write out the setting.
        //
        ParameterState techParamState = findParameter (inTechType, prefName, true);
        if (techParamState != null)
        {
            // Knowing that these arrays are for integer values only,
            // write out an appropriate registry key header first
            //
            String iniHeaderInt = getControlHub().get3rdPartyProperties (getAppID()).getString (HomePageReader3Settings.REGISTRY_INT);
            theLocalOutput.println (iniHeaderInt);

            String techParamName = techParamState.getParamName();
            ConfigManager.logDebugStatement (techParamName);
            String value = getValueValue (inPref);
            
            // the speech rate setting is absolute, but the Web4All range is larger
            // than what HPR can handle. Check against the boundaries, and clip if necessary
            value = checkHPRSpeechRate(value);            
            doWriteSetting (techParamName, value);
            
            techParamState.setSetState (true);
            ConfigManager.logDebugStatement ("wrote " + techParamName);
        }
        else
        {
            ConfigManager.logDebugStatement ("'" + inPref + "' not handled");
        }
    }   // end handleSpeechRatePref()
    
    /**
     * When shutting down Home Page Reader, reset the registry setting to factory defaults
     */
    public void kill()
    {
        int i;
        // Let the super class shut down Home Page Reader.
        //
        super.kill();
        
        // Write the defaults out to the temporary ini file.
        //
        theLocalOutput = createOutput (getControlHub().get3rdPartyIni (getAppID()));
        
        // header for integer settings
        String iniHeader = getControlHub().get3rdPartyProperties (getAppID()).getString (HomePageReader3Settings.REGISTRY_INT);
        theLocalOutput.println (iniHeader);

        // default pitch
        for (i=0; i<PITCH_KEYS.length; i++)
        {
            doWriteSetting (PITCH_KEYS[i], PITCH_DEFAULT[i]);
        }

        //default volume
        doWriteSetting (HomePageReader3Settings.VOLUME_KEY, VOLUME_DEFAULT);
        
        //default link presentation is different voice, set the integers
        for (i=0; i<LINK_DIFF_VOICE_KEYS.length; i++)
        {
            doWriteSetting (LINK_DIFF_VOICE_KEYS[i], LINK_DIFF_VOICE_VALS[i]);
        }
        
        
        // header for string settings
        iniHeader = getControlHub().get3rdPartyProperties (getAppID()).getString (HomePageReader3Settings.REGISTRY_STRING);
        theLocalOutput.println (iniHeader);

        //default link presentation is different voice, disable the other settings

        // first,the 'speak link'
        for (i=0; i<LINK_SPEAK_TEXT_KEYS.length; i++)
            doWriteSetting (LINK_SPEAK_TEXT_KEYS[i], LINK_NONE_VALS[i]);
            
        // next, the 'sound effect'
        for (i=0; i<LINK_SOUND_EFFECT_KEYS.length; i++)
            doWriteSetting (LINK_SOUND_EFFECT_KEYS[i], LINK_NONE_VALS[i]);

        // Write the values to the registry.
        //
        closeOutput();
        writeToRegistry();
                       
    }   // end kill().

    /**
     * @param   inRate  A string representing the desired speech rate
     * @return          A string representing the final speech rate. Values
     *                  less than 70 will be replace with 70, and values greater
     *                  than 700 will be replaced with 700.
     */
    private String checkHPRSpeechRate(String inRate)
    {
        String newRate = inRate;

        int rate = Integer.parseInt(inRate);
        if (rate < SPEECH_RATE_MIN)
            newRate = String.valueOf(SPEECH_RATE_MIN);
        else if (rate > SPEECH_RATE_MAX)
            newRate = String.valueOf(SPEECH_RATE_MAX);

        return newRate;
    }   // end checkHPRSpeechRate()
    
    /**
     * Map the value retrieved from the preferences document to the parameter's value.
     * @param  inParam      The parameter of interest.  This is expressed using the technology's
     *                      vocabulary.
     * @param  inValue      The value from the ACCLIP.
     * @return              The value to of the parameter, as a String.
     * @see #linearCalcTechVal(String,float,float)
     */
    protected KeyValMap mapValues (String inParam, String inValue)
    {
        KeyValMap result = null;

        // Choose a value map.
        //
        if (HomePageReader3Settings.VALUE_MAP_CHOOSER != null)
        {
            // Choose a value map.
            //
            ResourceBundle valueMap = (ResourceBundle) HomePageReader3Settings.VALUE_MAP_CHOOSER.getObject (inParam);
            if (valueMap != null)
            {
                result = (KeyValMap)valueMap.getObject (inValue);
                ConfigManager.logDebugStatement ("For (" + inParam + "," + inValue + "), result is '" + result + "'");
            }
        }
        return result;
    
    }   // end mapValues().

    /**
     * Map the value retrieved from the preferences document to the parameter's value.
     * This special case handles an array of values as the return value. It also converts
     * a pitch value (from 0.0 to 1.0) into an array for table lookup.
     * @param  inParam      The parameter of interest.  This is expressed using the technology's
     *                      vocabulary.
     * @param  inValue      The value from the ACCLIP.
     * @return              The values of the parameter, as an array of Strings.
     */
    protected String[] mapValueArray (String inParam, String inValue)
    {
        String[] result = null;

        // Choose a value map.
        //
        if (VALUE_MAP_CHOOSER != null)
        {
            // Choose a value map.
            //
            ResourceBundle valueMap = (ResourceBundle) VALUE_MAP_CHOOSER.getObject (inParam);
            if (valueMap != null)
            {
                if (inParam == HomePageReader3Settings.PITCH_NAME)
                {
                    // convert the string float between 0.0 and 1.0 to an int between 0 and 10
                    int iValue = (int)(Float.parseFloat (inValue)*10.0);
                    result = (String [])valueMap.getObject (String.valueOf(iValue));
                }
                else
                {
                    result = (String [])valueMap.getObject (inValue);
                }
                ConfigManager.logDebugStatement ("Got result for (" + inParam + "," + inValue + ")");
           }
        }
        return result;
    
    }   // end mapValueArray().

    /**
     * Retrieve an array of registry keys associated with the value map for the given paramter.
     * @param  inParam      The parameter of interest.  This is expressed using the technology's
     *                      vocabulary.
     * @param  inValue      The value from the ACCLIP.
     * @return              The keys for the parameters, as an array of Strings.
     */
    protected String[] getArrayKeys (String inParam, String inValue)
    {
        String[] result = null;

        // Choose a value map.
        //
        if (VALUE_MAP_CHOOSER != null)
        {
            // Choose a value map.
            //
            MapWithKeys valueMap = (MapWithKeys) VALUE_MAP_CHOOSER.getObject (inParam);
            if (valueMap != null)
            {
                result = (String [])valueMap.getArrayKeys();
                ConfigManager.logDebugStatement ("Got keys for (" + inParam + "," + inValue + ")");
            }
        }
        return result;
    
    }   // end getArrayKeys().

    /**
     * Retrieve a count of the number of registry values associated with the value map
     * for the given paramter.
     * @param  inParam      The parameter of interest.  This is expressed using the technology's
     *                      vocabulary.
     * @param  inValue      The value from the ACCLIP.
     * @return              An integer number indicating the number of values.
     */
    protected int getArrayCount (String inParam, String inValue)
    {
        int result = 0;

        // Choose a value map.
        //
        if (VALUE_MAP_CHOOSER != null)
        {
            // Choose a value map.
            //
            MapWithKeys valueMap = (MapWithKeys) VALUE_MAP_CHOOSER.getObject (inParam);
            if (valueMap != null)
            {
                result = valueMap.getValCount();
                ConfigManager.logDebugStatement ("Got key count for (" + inParam + "," + inValue + ")");
            }
        }
        return result;
    
    }   // end getArrayKeys().

    /**
     * Method for effectively "writing" the setting. For HomePageReader, the key-value
     * pairs are written out to the .ini file.
     * @param  inProperty   String representing the parameter to write.
     * @param  inValue      String representing the value of <code>inProperty</code>.
     */
    protected void doWriteSetting (String inProperty, String inValue)
    {
        writeSetting (inProperty, inValue);
    }

    /**
     * Launch HomePageReader, and record the process created.
     */
    public void doLaunch()
    {
        // Launch HomePageReader.  Start with the location.
        //
        try
        {
            String command = getControlHub().get3rdPartyExecutable (getAppID());
            ConfigManager.logDebugStatement ("'" + command.toString() + "'");
            setProcess (Runtime.getRuntime().exec (command.toString() + " " + getControlHub().getGlobalProperty(Web4AllPropNames.LAUNCH_URL)));
        }
        
        catch (IOException ioe)
        {
            ConfigManager.logException(ioe);
        }

    }  // end doLaunch().

     /**
     * Method for writing the final settings to the registry. Invokes the RegistryConsole
     * utility to process the .ini file created by doSettings();
     * @see #doSettings(Vector, ControlHub)
     */
    protected void writeToRegistry()
    {
        boolean success = initLocalProps();
        
        // If we got the local properties, try to get <theRegistryExec>.
        //
        if (success) {
            try {
                // build the registry console command
                String dirSep = System.getProperty ("file.separator");
                StringBuffer command = new StringBuffer (getControlHub().getHomeDirectory());
                theRegistryConsoleExec = getLocalProperty (HomePageReader3Settings.REGISTRY_EXE);
                System.out.println ("HomePageReader3Settings.writeToRegistry():  <theRegistryExec> is '" + (theRegistryConsoleExec == null ? "null" : theRegistryConsoleExec) + "'");
                command.append (dirSep).append (theRegistryConsoleExec);
                
                // append the ini file name
                command.append (" \""); // space double-quote.
                command.append (getControlHub().getHomeDirectory()).append (dirSep).append (getControlHub().get3rdPartyIni (getAppID()));
                command.append ("\"");  // double-quote.
                
                // now run the process
                Process registryConsole = Runtime.getRuntime().exec (command.toString());
                try
                {
                    handleProcessIStreams (registryConsole, true);
                    registryConsole.waitFor();
                }
                catch (InterruptedException ie)
                {
                    ConfigManager.logException(ie);
                }
            }
            catch (MissingResourceException mre) {
                System.out.println ("HomePageReader3Settings.writeToRegistry():  can't get local properties");
                ConfigManager.logException (mre);
            }
            catch (IOException ioe) {
                System.out.println ("HomePageReader3Settings.writeToRegistry():  can't run registry console");
                ConfigManager.logException (ioe);
            }
        }

    }   // end setLocalData().

    /**
     * Utility to convert a floating point ACCLIP preference value to a parameter value.   This
     * performs a linear transformation.
     * @param   inAccLipVal     Floating point value from the ACCLIP.
     * @param   inConst         A float that represents the constant multiplier.
     * @param   inFactor        A float that represents the factor of the exponent.
     * @return                  A float that represents the parameter's value.
     * @see #mapValue(String,String)
     */
    public float expCalcTechVal (String inAccLipVal, float inConst, float inFactor)
    {
        // Convert <inAccLipVal> to a float.
        //
        float accLipVal = Float.parseFloat (inAccLipVal);
        int iValue = (int)(accLipVal*10.0);
        
        // Compute and return value.
        //
        return (inConst * (float)Math.exp(inFactor * iValue));
    
    }   // end linearCalcTechVal().
            
   /**
     * Nested class to map the ACCLIP preference name to the HomePageReader settings.
     * The settings are stored as a table of ParameterState objects.
     */
    private static class HPRSettings extends SettingsBundle
    {
        /**
         * Record the fact that these settings are of type "screenReader".
         */
        public HPRSettings()
        {
            super ("screenReader");
        
        }   // end HPRSettings().
        
        public Object[][] getContents()
        {
            return contents;
        }
        
        /**
         * The lookup table.  The left side is an element name from the ACCLIP.  The right side
         * is the name of the HPR setting, whether the application requires that setting, and its default
         * value.
         */
        final Object[][] contents = {
        
            { LINK_NAME, new ParameterState (LINK_NAME, true, LINK_STRINGS_DEFAULT) },
            { SPEECH_RATE_NAME, new ParameterState (SPEECH_RATE_KEY, true, new Integer(SPEECH_RATE_DEFAULT)) },
            { PITCH_NAME, new ParameterState (PITCH_NAME, true, PITCH_DEFAULT) },
            { VOLUME_NAME, new ParameterState (VOLUME_KEY, true, VOLUME_DEFAULT) }
        
        };
        
    }  // end nested class HPRSettings.

    /**
     * Nested class for mapping prefs values to the HomePageReader values maps.
     */
    private static class ValueMapChooser extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table (ACCLIP name, our map})
         */
        final Object[][] contents = {
            { HomePageReader3Settings.LINK_NAME,  new LinkMap() },
            { HomePageReader3Settings.PITCH_NAME,  new PitchMap() },
            { HomePageReader3Settings.VOLUME_NAME,  new VolumeMap() },
            { HomePageReader3Settings.VOLUME_KEY,  new VolumeMap() },
        };

    }  // end inner class ValueMapChooser.

    /**
     * Interface to define methods added to ListResourceBundle to handle
     * values that are arrays of strings.
     */
    private interface MapWithKeys
    {
        /**
         * Get count of number of strings in the lookup table objects
         */
        public int getValCount();

        /**
         * Get array of registry keys which map to the settings in the object table
         */
        public String[] getArrayKeys();
        
    }   // end interface MapWithKeys
    
    /**
     * Nested class for mapping link presentation prefs to HPR registry settings.
     */
    private static class LinkMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table.
         */
        final Object[][] contents = {
            { "differentVoice",  new KeyValMap(LINK_DIFF_VOICE_KEYS, LINK_DIFF_VOICE_VALS) },
            { "speakLink",  new KeyValMap(LINK_SPEAK_TEXT_KEYS, LINK_SPEAK_TEXT_VALS_ENGLISH) },
            { "speakLinken",  new KeyValMap(LINK_SPEAK_TEXT_KEYS, LINK_SPEAK_TEXT_VALS_ENGLISH) },
            { "speakLinken_CA",  new KeyValMap(LINK_SPEAK_TEXT_KEYS, LINK_SPEAK_TEXT_VALS_ENGLISH) },
            { "speakLinken_US",  new KeyValMap(LINK_SPEAK_TEXT_KEYS, LINK_SPEAK_TEXT_VALS_ENGLISH) },
            { "speakLinken_GB",  new KeyValMap(LINK_SPEAK_TEXT_KEYS, LINK_SPEAK_TEXT_VALS_ENGLISH) },
            { "speakLinken_SE",  new KeyValMap(LINK_SPEAK_TEXT_KEYS, LINK_SPEAK_TEXT_VALS_ENGLISH) },
            { "speakLinken_AU",  new KeyValMap(LINK_SPEAK_TEXT_KEYS, LINK_SPEAK_TEXT_VALS_ENGLISH) },
            { "speakLinkfr",  new KeyValMap(LINK_SPEAK_TEXT_KEYS, LINK_SPEAK_TEXT_VALS_FRENCH) },
            { "speakLinkfr_CA",  new KeyValMap(LINK_SPEAK_TEXT_KEYS, LINK_SPEAK_TEXT_VALS_FRENCH) },
            { "speakLinkfr_FR",  new KeyValMap(LINK_SPEAK_TEXT_KEYS, LINK_SPEAK_TEXT_VALS_FRENCH) },
            { "speakLinkfr_BE",  new KeyValMap(LINK_SPEAK_TEXT_KEYS, LINK_SPEAK_TEXT_VALS_FRENCH) },
            { "soundEffect",  new KeyValMap(LINK_SOUND_EFFECT_KEYS, LINK_SOUND_EFFECT_VALS) },
            { "none", new KeyValMap(LINK_NONE_KEYS, LINK_NONE_VALS) },
            { "default", new KeyValMap(LINK_SOUND_EFFECT_KEYS, LINK_SOUND_EFFECT_VALS) },
        };


    }  // end inner class LinkMap.
    
    /**
     * Inner class for mapping prefs pitch values to HomePageReader's.
     */
    private static class PitchMap extends ListResourceBundle implements MapWithKeys
    {
        private final static int ValCount = 8;
        public final static String[]    PITCH_KEYS      = {"9","10","11","12","36","37","46","47"}; 
        
        /**
         * Get count of number of strings in the lookup table objects
         */
        public int getValCount()
        {
            return ValCount;
        }
        
        /**
         * Get array of registry keys which map to the settings in the object table
         */
        public String[] getArrayKeys()
        {
            return PITCH_KEYS;
        }
        
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }
    
        /**
         * The lookup table ({<value from prefs, converted to integer>,<HomePageReader values>})
         */
        final Object[][] contents = {
            { "0",  new String[] {"1","2","1","2","1","2","1","2"} },
            { "1",  new String[] {"1","2","1","2","1","2","1","2"} },   // male, senior
            { "2",  new String[] {"1","2","1","2","1","2","1","2"} },
            
            { "3",  new String[] {"1","1","1","1","1","1","1","1"} },   // male, adult
            { "4",  new String[] {"1","1","1","1","1","1","1","1"} },
            
            { "5",  new String[] {"0","2","0","2","0","2","0","2"} },   // female, senior
            { "6",  new String[] {"0","2","0","2","0","2","0","2"} },
            
            { "7",  new String[] {"0","1","0","1","0","1","0","1"} },   // female, adult
            { "8",  new String[] {"0","1","0","1","0","1","0","1"} },
            
            { "9",  new String[] {"0","0","0","0","0","0","0","0"} },   // female, child
            { "10", new String[] {"0","0","0","0","0","0","0","0"} },
            { "default", PITCH_DEFAULT }
        };
    
    }  // end inner class PitchMap.
    
    /**
     * Inner class for mapping prefs volume values to HomePageReader's.
     */
    private static class VolumeMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<value from prefs, converted to integer>,<HomePageReader value>})
         */
        final Object[][] contents = {
            { "0", "127" },
            { "1", "127" },
            { "2", "255" },
            { "3", "511" },
            { "4", "1023" },
            { "5", "2047" },
            { "6", "4095" },
            { "7", "8191" },
            { "8", "16383" },
            { "9", "32767" },
            { "10", "65535" },
            { "0.0", "127" },
            { "0.1", "127" },
            { "0.2", "255" },
            { "0.3", "511" },
            { "0.4", "1023" },
            { "0.5", "2047" },
            { "0.6", "4095" },
            { "0.7", "8191" },
            { "0.8", "16383" },
            { "0.9", "32767" },
            { "1.0", "65535" },
            { "default", VOLUME_DEFAULT }
        };

    }  // end inner class VolumeMap.

    /**
     * Inner class for encapsulating registry key-value pairs
     */
    private static class KeyValMap
    {
        private String[] theKeys;
        private String[] theVals;
        
        // constructor
        public KeyValMap(String[] inKeys, String[] inVals)
        {
            theKeys = inKeys;
            theVals = inVals;
        }   // end constructor
        
        // accessors
        public String[] keys() {return theKeys;}
        public String[] vals() {return theVals;}

    }   // end inner class KeyValPair
    
}   // end class HomePageReader3Settings



