/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            WinKeyboardSettings.java
 *
 * Synoposis:       package ca.utoronto.atrc.web4all.thirdparty;
 *
]*/

package ca.utoronto.atrc.web4all.thirdparty;

import java.io.*;
import java.util.*;
import org.w3c.dom.*;
import org.apache.xerces.util.DOMUtil;

import ca.utoronto.atrc.web4all.*;
import ca.utoronto.atrc.web4all.configuration.*;

/**
 * Class that configures some of the Windows keyboard "control panel" settings.  This
 * handles sticky keys, repeat keys, and slow keys.
 *
 * @version $Id: WinKeyboardSettings.java,v 1.9 2006/03/28 22:07:54 clown Exp $
 * @author Joseph Scheuhammer
 */
    
public class WinKeyboardSettings extends AbstractSetterLauncher
{
    /**
     * Sticky key settings.
     */
    public final static String  STICKY_NAME             = "stickyKeys";
    public final static String  STICKY_DEFAULT          = "0"; // = off
    
    /**
     * Repeat key settings.
     */
    public final static String  REPEAT_NAME             = "repeatKeys";
    public final static String  REPEAT_DEFAULT          = "0"; // = off
    public final static String  AUTO_DELAY_NAME         = "autoRepeatDelay";
    public final static String  AUTO_DELAY_DEFAULT      = "250";
    public final static int     AUTO_DELAY_DEFAULT_INT  = 250;
    public final static String  AUTO_RATE_NAME          = "autoRepeatRate";
    public final static String  AUTO_RATE_DEFAULT       = "300";
    public final static int     AUTO_RATE_DEFAULT_INT   = 300;

    /**
     * Slow key settings.
     */
    public final static String  SLOW_NAME            = "slowKeys";
    public final static String  SLOW_DEFAULT         = "500";
    public final static int     SLOW_DEFAULT_INT     = 500;
    public final static int     SLOW_OFF_INT         = 0;
    public final static String  SLOW_INTERVAL_NAME   = "slowKeysInterval";

	/**
	 * Debounce settings.
	 */
	public final static String	DEBOUNCE_NAME			= "debounce";
    public final static String  DEBOUNCE_DEFAULT        = "500";
    public final static int     DEBOUNCE_DEFAULT_INT    = 500;      // msec
    public final static int     DEBOUNCE_MIN_INT        = 500;      // msec
    public final static int     DEBOUNCE_MAX_INT        = 2000;     // msec
    public final static int     DEBOUNCE_OFF_INT        = 0;
    public final static String  DEBOUNCE_INTERVAL_NAME  = "debounceInterval";
	
    /**
     * The ACCLIP to parameter names map array.
     */
    private final static SettingsBundle PARAMS_HANDLED[] = {
        new WinKeyboardSettings.KeyboardSettings()
    };

    /**
     * The value map chooser.
     */
    private final static WinKeyboardSettings.ValueMapChooser VALUE_MAP_CHOOSER = new WinKeyboardSettings.ValueMapChooser();

    /**
     * The array of default command line arguments.
     */
    private final static String DEFAULT_ARGS[] = {
        STICKY_DEFAULT, REPEAT_DEFAULT, AUTO_DELAY_DEFAULT, AUTO_RATE_DEFAULT, SLOW_DEFAULT, DEBOUNCE_DEFAULT
    };

    /**
     * Lookup table for mapping Keyboard settings to their position in the command line argument.
     */
    private final static WinKeyboardSettings.ArgIndexMap ARG_INDICES = new WinKeyboardSettings.ArgIndexMap();

    /**
     * The executable for making changes to the Windows keyboard registry.
     */
    private String theWinKeysExec;

    /**
     * Constructor -- no argument.
     */
    public WinKeyboardSettings()
    {
        super();    

    }  // end WinKeyboardSettings().

    /**
     * Class specific initialization -- override to avoid creating the output file, and allocate the positional
     * parameter array.
     */
    protected void init()
    {
        setUpParameters (WinKeyboardSettings.PARAMS_HANDLED, WinKeyboardSettings.VALUE_MAP_CHOOSER);
        setArgsArray (new String[WinKeyboardSettings.DEFAULT_ARGS.length]);
        setArgsIndexMap (WinKeyboardSettings.ARG_INDICES);
        theWinKeysExec = null;
        createReadProcessIStreams();
    
    }   // end init().

    /**
     * Translate the ACCLIP preferences for keyboard enchancements to the corresponding Windows
     * keyboard settings.  The keyboard settings are placed in a command line argument array,
     * and the command line utility is called with those arguments to install the settings.
     * @param   inAccLipInfoPackages    A Vector of AccLipInfoPackage objects that contain
     *                                  preferences for different types of technologies.  This
     *                                  handles only the "keyboardEnhanced" type.
     * @param   inControlHub            The ControlHub instance that contains information about the location
     *                                  of the command line utility.
     * @return                          <code>false</code> indicating that this does not launch a browser.
     */
    public boolean doSettings (Vector inAccLipInfoPackages, ControlHub inControlHub)
    {
        // Get the name of the ACCLIP Element that is for keyboard enhancements.  This is the only
        // technology type that <this> handles.
        //
        String keyboardEnchanceElName = inControlHub.getPrefElementName (Web4AllConstants.KEYBOARD_ENHANCED);

        // Loop thru the ACCLIP info looking for <keyboardEnchanceElName>.
        //
        for (int i = 0; i < inAccLipInfoPackages.size(); i++)
        {
            // Skip any AccLipInfoPackage that is not for the "keyboardEnhanced" type.
            //
            AccLipInfoPackage anAccLipInfo = (AccLipInfoPackage) inAccLipInfoPackages.elementAt (i);
            if (anAccLipInfo.getAppType().equals (keyboardEnchanceElName) == false)
                continue;

            // Record the parent Element in the ACCLIP that contains both the generic settings and
            // specific settings.  Record, also, the ControlHub instance.  Get the application name
            // from <anAccLipInfo>'s specific preferences container.
            //
            Element prefsParentElement = (Element) anAccLipInfo.getGenericPrefs().getParentNode();
            setAppSettings (prefsParentElement);
            setControlHub (inControlHub);
            setAppID (anAccLipInfo.getSpecificPrefs());

            // Get our local properties.
            //
            boolean worked = setLocalData();
                
            // Machinery intialized: start processing the preferences.
            //
            if ((prefsParentElement != null) && worked)
            {           
                // (Re)Initialize the argument collector to default values.
                //
                String[] args = getArgsArray();
                System.arraycopy (WinKeyboardSettings.DEFAULT_ARGS, 0, args, 0, args.length);
                
                // Loop thru the children of <inPrefs>, looking for values.
                //
                loopThruGenerics (keyboardEnchanceElName, anAccLipInfo.getGenericPrefs());

                // Call the utility that installs the settings.
                //
                try
                {
                    // First, the command.
                    //
                    StringBuffer command = new StringBuffer (theWinKeysExec);
                    command.append (" ");       // space.
                    
                    // Now the arguments
                    //
                    for (int j = 0; j < args.length; j++)
                    {
                        command.append (args[j]);
                        command.append (" ");   // space.
                    }
                    
                    ConfigManager.logDebugStatement ("Command:  '" + command.toString() + "'");
                    Process nativeSetup = Runtime.getRuntime().exec (command.toString());
                    try
                    {
                        handleProcessIStreams (nativeSetup, true);
                        nativeSetup.waitFor();
                    }
                    catch (InterruptedException ie)
                    {
                        ConfigManager.logException(ie);
                    }
                }
                catch (IOException ioe)
                {
                    ConfigManager.logException(ioe);
                }
            }
        }
        return false;       // we do not launch a browser.

    }  // end doSettings().

    /**
     * Given a technology type and a preference for that type, determine if it is one that
     * we handle.  If so, write out its value.  This override is to take into account the
     * heirarchical nature of the keyboard preferences.
     * @param   inTechType      The type of technology this preference is for, as taken from the
     *                          ACCLIP. If it is not "keyboardEnhanced", this does nothing.
     * @param   inPref          The preferences Element that represent a single keyboard setting.
     * @param   isGeneric       Is <code>inPref</code> from the generic section of the preferences?
     * @param #handleContainer
     */
    protected void handlePref (String inTechType, Element inPref, boolean isGeneric)
    {
        // Get the attributes, and look to see if it is one we handle.
        //
        String prefName = inPref.getTagName();
        
        // Dispatch to the repeat keys method if <prefName> is "repeatKeys", and slow keys method if
        // "slowKeys".
        //
        if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.KE_GENERIC_REPEAT)))
            handleContainer (inTechType, inPref, WinKeyboardSettings.REPEAT_NAME);
        
        else if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.KE_GENERIC_SLOW)))
            handleContainer (inTechType, inPref, WinKeyboardSettings.SLOW_NAME);

        else if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.KE_GENERIC_DEBOUNCE)))
            handleContainer (inTechType, inPref, WinKeyboardSettings.DEBOUNCE_NAME);
                
        // Nothing special -- let the super class handle it.
        //
        else
            super.handlePref (inTechType, inPref, isGeneric);

    }  // end handlePref().
   
    /**
     * Handles the "repeatKeys" and "slowKeys" container elements in the ACCLIP.
     * @param    inTechType      The type of technology this handles. This should be "keyboardEnhanced".
     * @param    inPref          The container element from the ACCLIP.
     * @param    inContainerType One of REPEAT_KEYS or SLOW_KEYS.
     * @see #handlePref
     * @see #REPEAT_KEYS
     * @see #SLOW_KEYS
     */
    private void handleContainer (String inTechType, Element inPref, String inContainerType)
    {
        // Check <inContainerType>.  For repeat keys, the boolean to indicate that repeat keys is on/off
        // is written to the args array.
        //
        if (inContainerType == WinKeyboardSettings.REPEAT_NAME)
            super.handlePref (inTechType, inPref, true /* generic pref */);
        
        // For the case where slow keys or debounce is off, <inPref> contains nothing, and the actual
        // value to output is the relevant "off" value.
        //
        else if ((inContainerType == WinKeyboardSettings.SLOW_NAME) || (inContainerType == WinKeyboardSettings.DEBOUNCE_NAME))
        {
            // Set up parmeter name and the "off" value for slow keys vs. debounce.
            //
            String paramName;
            Integer offValue;
            if (inContainerType == WinKeyboardSettings.SLOW_NAME)
            {
                paramName = WinKeyboardSettings.SLOW_INTERVAL_NAME;
                offValue = new Integer (WinKeyboardSettings.SLOW_OFF_INT);
            }
            else
            {
                paramName = WinKeyboardSettings.DEBOUNCE_INTERVAL_NAME;
                offValue = new Integer (WinKeyboardSettings.DEBOUNCE_OFF_INT);
            }
            
            // If the preference is off, set according to the <offValue>.
            //
            String onOff = getValueValue (inPref);
            if (onOff.equals ("false"))
            {
                ParameterState paramState = findParameter (inTechType, paramName, true /* generic pref */);
                paramState.setDefaultValue (offValue);
                doWriteSetting (paramState.getParamName(), paramState.getDefaultValue().toString());
                paramState.setSetState (true);
                ConfigManager.logDebugStatement ("For (" + paramState.getParamName() + "," + onOff + "), result is '" + paramState.getDefaultValue().toString() + "'");
            }
        }
            
        // Loop through any children of <inPref>.
        //
        Element aChild = DOMUtil.getFirstChildElement (inPref);
        while (aChild != null)
        {
            String childName = aChild.getNodeName();
                        
            // The AbstractSettingLauncher handles this case.
            //
            super.handlePref (inTechType, aChild, true);    // "true" means generic pref.
            aChild = DOMUtil.getNextSiblingElement (aChild);
         }        
  
   }    // end handleContainer().
    
    /**
     * Map the value retrieved from the preferences document to the actual value to output.
     * This is an override since most of the keyboard settings are linear transforms based on the
     * ACCLIP preference value, while some still remain simple lookups.
     * @param  inParam      The parameter of interest.  This is expressed using the technology's
     *                      vocabulary.
     * @param  inValue      The value from the ACCLIP as a String.
     * @return              The value to output, as a String.
     */
    protected String mapValue (String inParam, String inValue)
    {
        String result = null;       // return value.
        
        // Handle auto delay as a straight linear transform.
        //        
        if (inParam.equals (WinKeyboardSettings.AUTO_DELAY_NAME))
        {
            // Two linear transforms depending on whether <inValue> is less than 0.5.
            //
            float accVal = Float.parseFloat (inValue);
            int techVal = -1;
            if (accVal < 0.5)
                techVal = (int) linearCalcTechVal (inValue, 1400.0f, 300.0f);
            else
                techVal = (int) linearCalcTechVal (inValue, 2000.0f, 0.0f);
            
            techVal = ( techVal < 0 ? WinKeyboardSettings.AUTO_DELAY_DEFAULT_INT : techVal );
            result = Integer.toString (techVal);
        }
        
        // Handle auto rate as a straight linear transform.
        //        
        else if (inParam.equals (WinKeyboardSettings.AUTO_RATE_NAME))
        {
            // Two linear transforms depending on whether <inValue> is less than 0.5.
            //
            float accVal = Float.parseFloat (inValue);
            int techVal = -1;
            if (accVal < 0.5)
                techVal = (int) linearCalcTechVal (inValue, 800.0f, 300.0f);
            else
                techVal = (int) linearCalcTechVal (inValue, 2600.0f, -600.0f);
            
            techVal = ( techVal < 0 ? WinKeyboardSettings.AUTO_RATE_DEFAULT_INT : techVal );
            result = Integer.toString (techVal);
        }
        
        // Handle slow keys as a straight linear transform.
        //        
        else if (inParam.equals (WinKeyboardSettings.SLOW_NAME))
        {
            // Two linear transforms depending on whether <inValue> is less than 0.5.
            //
            float accVal = Float.parseFloat (inValue);
            int techVal = -1;
            if (accVal < 0.5)
                techVal = (int) linearCalcTechVal (inValue, 800.0f, 300.0f);
            else
                techVal = (int) linearCalcTechVal (inValue, 2600.0f, -600.0f);
            
            techVal = ( techVal < 0 ? WinKeyboardSettings.SLOW_DEFAULT_INT : techVal );
            result = Integer.toString (techVal);
        }
        
        // Handle debounce as a straight linear transform (range 0mm to 5000ms, instead, though).
        //        
        else if (inParam.equals (WinKeyboardSettings.DEBOUNCE_NAME))
        {
            // Acclip value is in seconds, and need to output msec.  Also, range in Acclip is [0,5] secconds
            // whereas Windows range is [500,2000] msec. (DEBOUNCE_MIN_INT and DEBOUNCE_MAX_INT).
            //
            float accVal = Float.parseFloat (inValue);
            int techVal =  (int) (accVal * 1000.0f);
            if (techVal < DEBOUNCE_MIN_INT)
                techVal = DEBOUNCE_MIN_INT;
            else if (techVal > DEBOUNCE_MAX_INT)
                techVal = DEBOUNCE_MAX_INT;

            result = Integer.toString (techVal);
        }
        
        // All other handled by lookup tables.
        //
        else
            result = super.mapValue (inParam, inValue);

        ConfigManager.logDebugStatement ("For (" + inParam + "," + inValue + "), result is '" + result + "'");
        return result;
            
    }   // end mapValue().
    
    /**
     * Write the setting to the command line argument array.
     * @param  inParameter  String representing the keyboard parameter of interest.
     * @param  inValue      String representing that setting's ACCLIP value.
     */
    protected void doWriteSetting (String inParameter, String inValue)
    {
        addArgToArray (inParameter, inValue);
    
    }   // end doWriteSetting().
    
    /**
     * Method for acquiring the executable to call to modify the Windows keyboard settings.
     * @return            Did this method successfully get all those properties (boolean)?
     */
    protected boolean setLocalData()
    {
        boolean success = false;
        
        // Try to get <theWinKeysExec>.
        //
        try
        {
            theWinKeysExec = getControlHub().get3rdPartyExecutable (getAppID());
            ConfigManager.logDebugStatement ("WinKeyboardSettings.setLocalData():  <theWinKeysExec> is '" + (theWinKeysExec == null ? "null" : theWinKeysExec) + "'");
            success = true;
        }
        catch (MissingResourceException mre)
        {
            ConfigManager.logDebugStatement ("WinKeyboardSettings.setLocalData():  can't get local properties");
            ConfigManager.logException (mre);
            theWinKeysExec = null;
            success = false;
        }
        
        return success;
    
    }   // end setLocalData().

    /**
     * This SetterLauncher does not actually launch anything.  No-op implementation.
     */
    public void doLaunch()
    {
    
    }   // end doLaunch().
    
    /**
     * "Kill" the process created by <code>doLaunch()</code>.  Since nothing is actually launched, we take
     * this opportunity to reset the keyboard back to default values.
     */
    public void kill()
    {
        // Don't do anything if there is no command to execute.
        //
        if (theWinKeysExec != null)
        {
            try
            {
                // Run the command.
                //
                ConfigManager.logDebugStatement ("Command:  '" + theWinKeysExec + "'");
                Process nativeSetup = Runtime.getRuntime().exec (theWinKeysExec);
                try
                {
                    handleProcessIStreams (nativeSetup, true);
                    nativeSetup.waitFor();
                }
                catch (InterruptedException ie)
                {
                    ConfigManager.logException(ie);
                }
            }
            catch (IOException ioe)
            {
                ConfigManager.logException(ioe);
            }
        }

    }  // end kill().

    /**
     * Nested class to map the ACCLIP preference name to the Windows keyboard settings.
     */
    private static class KeyboardSettings extends SettingsBundle
    {
        /**
         * Record the fact that these settings are of type "alternativePointing".
         */
        public KeyboardSettings()
        {
            super ("keyboardEnhanced");
        
        }   // end KeyboardSettings().
        
        public Object[][] getContents()
        {
            return contents;
        }
        
        /**
         * The lookup table.  The left side is an element name from the ACCLIP.  The right side
         * is the name of the windows keyboard parameter, whether the setting is required, and its
         * default value.
         */
        final Object[][] contents = {
            
            // Sticky keys.
            //
            { STICKY_NAME, new ParameterState (WinKeyboardSettings.STICKY_NAME, true, new Integer (WinKeyboardSettings.STICKY_DEFAULT)) },
            
            // Repeat keys.  Note that <repeatKeys> is a container element for <autoRepeatDelay> and <autoRepeatRate>.
            //
            { REPEAT_NAME, new ParameterState (WinKeyboardSettings.REPEAT_NAME, true, new Integer (WinKeyboardSettings.REPEAT_DEFAULT)) },
            { AUTO_DELAY_NAME, new ParameterState (WinKeyboardSettings.AUTO_DELAY_NAME, true, new Integer (WinKeyboardSettings.AUTO_DELAY_DEFAULT)) },
            { AUTO_RATE_NAME, new ParameterState (WinKeyboardSettings.AUTO_RATE_NAME, true, new Integer (WinKeyboardSettings.AUTO_RATE_DEFAULT)) },
            
            // Slow keys.  Note that <slowKeys> is a container element for <slowKeysInterval>.  The former is
            // a boolean, and is *not* written.  The latter is the slow keys value, and *that* is what is written.
            //
            { SLOW_INTERVAL_NAME, new ParameterState (WinKeyboardSettings.SLOW_NAME, true, new Integer (WinKeyboardSettings.SLOW_DEFAULT)) },
        
            // Debounce.  Note that <debounce> is a container element for <debounceInterval>.  The former is
            // a boolean, and is *not* written.  The latter is the debounce interval, and *that* is what is written.
            //
            { DEBOUNCE_INTERVAL_NAME, new ParameterState (WinKeyboardSettings.DEBOUNCE_NAME, true, new Integer (WinKeyboardSettings.DEBOUNCE_DEFAULT)) }
        
        };
        
    }  // end nested class KeyboardSettings.
     
    /**
     * Inner class for mapping yes/no prefs to Windows registry values.
     */
    private static class YesNoMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<value from prefs>,<windows value>})
         */
        final Object[][] contents = {
            { "true", "1" },
            { "false", "0" }
        };

    }  // end inner class YesNoMap.

    /**
     * Nested class for mapping prefs values to the Windows values maps.
     */
    private static class ValueMapChooser extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<value uid from once corp>,<our map>})
         */
        final Object[][] contents = {
            { WinKeyboardSettings.STICKY_NAME,  new YesNoMap() },
            { WinKeyboardSettings.REPEAT_NAME,  new YesNoMap() },
        };

    }  // end inner class ValueMapChooser.

    /**
     * Nested class for mapping KeyboardSettings to their position in the command line argument.
     */
    private static class ArgIndexMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table (keyboard setting, argument index})
         */
        final Object[][] contents = {
            { WinKeyboardSettings.STICKY_NAME, new Integer (0) },
            { WinKeyboardSettings.REPEAT_NAME, new Integer (1) },
            { WinKeyboardSettings.AUTO_DELAY_NAME, new Integer (2) },
            { WinKeyboardSettings.AUTO_RATE_NAME, new Integer (3) },
            { WinKeyboardSettings.SLOW_NAME, new Integer (4) },
            { WinKeyboardSettings.DEBOUNCE_NAME, new Integer (5) }
        };

    }  // end inner class ArgIndexMap.
        
}   // end class WinKeyboardSettings.

