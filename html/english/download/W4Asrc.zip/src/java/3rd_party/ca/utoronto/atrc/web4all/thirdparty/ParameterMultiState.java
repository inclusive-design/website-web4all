/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 *
 * File:        ParameterMultiState.java
 *
 * Synoposis:   package ca.utoronto.atrc.web4all.thirdparty;
 *
]*/

package ca.utoronto.atrc.web4all.thirdparty;

import java.util.ListResourceBundle;
import ca.utoronto.atrc.web4all.configuration.ParameterState;

/**
 * Stores state information about a specific third party technology parameter, or setting. 
 * States stored include whether the parameter has been set, whether the third party technolgy
 * requires that the parameter be set, and, if required, but not set, the setting's
 * default value.
 *
 * @author  Anastasia Cheetham
 * @version $Id: ParameterMultiState.java,v 1.2 2006/03/28 22:07:54 clown Exp $
 */
public class ParameterMultiState extends ParameterState
{
    /**
    /*
     * Indices into the contents array
     */
    public static int   INI = 0;
    public static int   CSS = 1;
    public static int   FCS = 2;

    /*
     *
     */
    private ParameterMultiState.ParameterStateChooser ParamStateChooser = new ParameterMultiState.ParameterStateChooser();
     
     /**
      * Intialize the state object given a parameter name, whether it is required, and its
      * default value.  The "set" state is initialized to <code>false</code>.
      * @param  inParamName     The technology specific name of the parameter.  This is
      *                         not a preference name from the ACCLIP, but the third
      *                         party technology's corresponding name.
      * @param  inRequiredFlag  Is this parameter required by the third party technology?
      * @param  inDefaultValue  If it is required, this is the default value if it can't
      *                         be set via the ACCLIP document.
      */
     public ParameterMultiState (String inParamName, boolean inRequiredFlag, Object inDefaultValue,
                                  ParameterState inIniState, ParameterState inCssState, ParameterState inFcsState)
     {
        super(inParamName, inRequiredFlag, inDefaultValue);
        ParamStateChooser.getContents()[INI][1] = inIniState;
        ParamStateChooser.getContents()[CSS][1] = inCssState;
        ParamStateChooser.getContents()[FCS][1] = inFcsState;
     
     }  // end ParameterState().
 
     
    /**
     * Retrieve the third party technology specific name of this parameter.
     * @param   inKey   the type of output requested - must be one of "ini", "css", or "fcs"
     * @return    The parameter name.
     */
    public String getParamName(String inKey)
    {
        ParameterState pState = (ParameterState)ParamStateChooser.getObject(inKey);
        if (pState != null)
            return pState.getParamName();
        else
            return null;
    
    }   // end getParamName().
    
    /**
     * Nested class for mapping prefs values to our Ereader values maps.
     */
    private static class ParameterStateChooser extends ListResourceBundle
    {

        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<param for .ini>,<our map>})
         */
        final Object[][] contents = {
            { "ini", null },
            { "css", null },
            { "fcs", null/*new ParameterState(null, false, null)*/ },


        };

    }  // end nested class ParameterStateChooser.
    
}   // end class ParameterMultiState.
