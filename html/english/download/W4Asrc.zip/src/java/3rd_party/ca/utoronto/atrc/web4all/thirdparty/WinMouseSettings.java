/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            WinMouseSettings.java
 *
 * Synoposis:       package ca.utoronto.atrc.web4all.thirdparty;
 *
]*/

package ca.utoronto.atrc.web4all.thirdparty;

import java.io.*;
import java.util.*;
import org.w3c.dom.*;

import ca.utoronto.atrc.web4all.*;
import ca.utoronto.atrc.web4all.configuration.*;

/**
 * Class that configures Windows mouse speed and acceleration based on user's preferences.
 *
 * @version $Id: WinMouseSettings.java,v 1.6 2006/03/28 22:07:54 clown Exp $
 * @author Joseph Scheuhammer
 */
public class WinMouseSettings extends AbstractSetterLauncher
{
    /**
     * The speed parameter.
     */
    public final static String SPEED_NAME       =   "SPEED";

    /**
     * The acceleration parameter.
     */
    public final static String ACCEL_NAME       =   "ACCEL";
    
    /**
     * The default cursor speed, in msec.
     */
    public final static String SPEED_DEFAULT    =   "60";
    
    /**
     * The default cursor acceleration, in msec.
     */
    public final static String ACCEL_DEFAULT    =   "5000";

    /**
     * Slope for linear transform of speed less than an ACCLIP value of 0.5.
     */
    private final static float SPEED_SLOPE1    = 110.0f;
    
    /**
     * Intercept for linear transform of speed less than an ACCLIP value of 0.5.
     */
    private final static float SPEED_CEPT1     = 10.0f;

    /**
     * Slope for linear transform of speed less than an ACCLIP value of 0.9.
     */
    private final static float SPEED_SLOPE2    = 600.0f;
    
    /**
     * Intercept for linear transform of speed less than an ACCLIP value of 0.9.
     */
    private final static float SPEED_CEPT2     = 64.0f;

    /**
     * Slope for linear transform of speed less than an ACCLIP value of 1.0.
     */
    private final static float SPEED_SLOPE3    = 560.0f;
    
    /**
     * Intercept for linear transform of speed less than an ACCLIP value of 1.0
     */
    private final static float SPEED_CEPT3     = 304.0f;

    /**
     * Slope for linear transform of speed and acceleration.
     */
    private final static float ACCEL_SLOPE    = -4000.0f;
    
    /**
     * Intercept for linear transform of speed and acceleration.
     */
    private final static float ACCEL_CEPT     = 5000.0f;
    
    /**
     * The parameter names that we actually look for in the profile.  These are mouse pointer
     * speed and acceleration
     */
    private final static SettingsBundle PARAMS_HANDLED[] = {
        new WinMouseSettings.MousekeysSettings()
    };

    /**
     * The value map chooser.
     */
    private final static WinMouseSettings.ValueMapChooser VALUE_MAP_CHOOSER = new WinMouseSettings.ValueMapChooser();

    /**
     * The array of default positional parameters to the Windows setter executable.
     */
    private final static String[] DEFAULT_ARGS = {
        WinMouseSettings.SPEED_DEFAULT, WinMouseSettings.ACCEL_DEFAULT
    };

    /**
     * Lookup table for mapping Mousekeys settings to their position in the command line argument.
     */
    private final static WinMouseSettings.ArgIndexMap ARG_INDICES = new WinMouseSettings.ArgIndexMap();

    /**
     * The executable for making changes to the Windows "mouse keys" registry.
     */
    private String theMouseKeysExec;

    /**
     * Constructor -- no argument.
     */
    public WinMouseSettings()
    {
        super();    

    }  // end WinMouseSettings().

    /**
     * Class specific initialization -- override to avoid creating the output file, and allocate the positional
     * parameter array.
     */
    protected void init()
    {
        setUpParameters (WinMouseSettings.PARAMS_HANDLED, WinMouseSettings.VALUE_MAP_CHOOSER);
        setArgsArray (new String[WinMouseSettings.DEFAULT_ARGS.length]);
        setArgsIndexMap (WinMouseSettings.ARG_INDICES);
        theMouseKeysExec = null;
        createReadProcessIStreams();
        
    }   // end init().

    /**
     * Translate the ACCLIP preferences for alternative pointing device to the values that Mousekeys
     * understands, "outputting" them to a String array.  Then execute the command line utility
     * with that array as its command line arguments.  The command line utility sets the appropriate
     * Mousekeys parameters with the desired values.
     * @param   inAccLipInfoPackages    A Vector of AccLipInfoPackage objects that contain
     *                                  preferences for different types of technologies.  This
     *                                  handles only the "mouseEmulation" type.
     * @param   inControlHub            The ControlHub instance that contains information about the location
     *                                  of the command line utility.
     * @return                          <code>false</code> indicating that this does not launch a browser.
     */
    public boolean doSettings (Vector inAccLipInfoPackages, ControlHub inControlHub)
    {

        // Get the name of the ACCLIP Element that is for mouse emulating devices.  This is the only
        // technology type that "WinMouseSettings" handles.
        //
        String mouseEmulationElName = inControlHub.getPrefElementName (Web4AllConstants.MOUSE_EMULATION);

        // Loop thru the ACCLIP info looking for <altPointingElName>.
        //
        for (int i = 0; i < inAccLipInfoPackages.size(); i++)
        {
            // Skip any AccLipInfoPackage that is not for the "mouseEmulation" type.
            //
            AccLipInfoPackage anAccLipInfo = (AccLipInfoPackage) inAccLipInfoPackages.elementAt (i);
            if (anAccLipInfo.getAppType().equals (mouseEmulationElName) == false)
                continue;

            // Record the parent Element in the ACCLIP that contains both the generic settings and
            // specific settings.  Record, also, the ControlHub instance.  Get the application name
            // from <anAccLipInfo>'s specific preferences container.
            //
            Element prefsParentElement = (Element) anAccLipInfo.getGenericPrefs().getParentNode();
            setAppSettings (prefsParentElement);
            setControlHub (inControlHub);
            setAppID (anAccLipInfo.getSpecificPrefs());

            // Get our local properties.
            //
            boolean worked = setLocalData();

            // Machinery intialized: start processing the preferences.
            //
            if ((prefsParentElement != null) && worked)
            {           
                // (Re)Initialize the argument collector to default values.
                //
                String[] args = getArgsArray();
                System.arraycopy (WinMouseSettings.DEFAULT_ARGS, 0, args, 0, args.length);
                
                // Loop thru the children of <inPrefs>, looking for values.
                //
                loopThruGenerics (mouseEmulationElName, anAccLipInfo.getGenericPrefs());

                // Call the utility that passes the settings to Mouseworks..
                //
                try
                {
                    // First, the command.
                    //
                    StringBuffer command = new StringBuffer (theMouseKeysExec);
                    command.append (" ");       // space.
                    
                    // Now the arguments
                    //
                    for (int j = 0; j < args.length; j++)
                    {
                        command.append (args[j]);
                        command.append (" ");   // space.
                    }
 //                   command.append (DONT_WRITE);
                    
                    ConfigManager.logDebugStatement ("Command:  '" + command.toString() + "'");
                    Process nativeSetup = Runtime.getRuntime().exec (command.toString());
                    try
                    {
                        handleProcessIStreams (nativeSetup, true);
                        nativeSetup.waitFor();
                    }
                    catch (InterruptedException ie)
                    {
                        ConfigManager.logException(ie);
                    }
                }
                catch (IOException ioe)
                {
                    ConfigManager.logException(ioe);
                }
            }
        }
        return false;       // we do not launch a browser.

    }  // end doSettings().

    /**
     * Given a technology type and a preference for that type, determine if it is one that
     * we handle.  If so, write out its value.  This override is to take into account the
     * heirarchical nature of the relative pointing settings.
     * @param   inTechType      The type of technology this preference is for, as taken from the
     *                          ACCLIP. If it is not "mouseEmulation", this does nothing.
     * @param   inPref          The preferences Element that represent a single trackball setting.
     * @param   isGeneric       Is <code>inPref</code> from the generic section of the preferences?
     */
    protected void handlePref (String inTechType, Element inPref, boolean isGeneric)
    {
        // Get the attributes, and look to see if it is one we handle.
        //
        String prefName = inPref.getTagName();
        
        // If "deviceType" do nothing (we only support keypad).
        //
        if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.ME_GENERIC_DEVICE)))
			return;
        // Nothing special -- let the super class handle it.
        //
        else
            super.handlePref (inTechType, inPref, isGeneric);

    }  // end handlePref().

    /**
     * Map the value retrieved from the preferences document to the actual value to output.
     * This is an override since many of the Mousekey preferences are calculated based on the
     * ACCLIP preference value, while some still remain simple lookups.
     * @param  inParam      The parameter of interest.  This is expressed using the technology's
     *                      vocabulary.
     * @param  inValue      The value from the ACCLIP as a String.
     * @return              The value to output, as a String.
     */
    protected String mapValue (String inParam, String inValue)
    {
        String result = null;       // return value.
        
        // Handle speed. The slope varies on the value.
        //        
        if ( inParam.equals (WinMouseSettings.SPEED_NAME) ) {

            float accLipVal = Float.parseFloat (inValue);

			if (accLipVal < 0.5f) {
				int techVal = (int) linearCalcTechVal (inValue, WinMouseSettings.SPEED_SLOPE1, WinMouseSettings.SPEED_CEPT1);
				result = Integer.toString (techVal);
			}
			else if (accLipVal < 0.9f) {
				String modVal = String.valueOf(accLipVal - 0.5f);
				int techVal = (int) linearCalcTechVal (modVal, WinMouseSettings.SPEED_SLOPE2, WinMouseSettings.SPEED_CEPT2);
				result = Integer.toString (techVal);
			}
			else {
				String modVal = String.valueOf(accLipVal - 0.9f);
				int techVal = (int) linearCalcTechVal (modVal, WinMouseSettings.SPEED_SLOPE3, WinMouseSettings.SPEED_CEPT3);
				result = Integer.toString (techVal);
			}
        }

		// Handle accelleration as a straight linear transform.
		//
        else if (inParam.equals (WinMouseSettings.ACCEL_NAME)) {
            int techVal = (int) linearCalcTechVal (inValue, WinMouseSettings.ACCEL_SLOPE, WinMouseSettings.ACCEL_CEPT);
            result = Integer.toString (techVal);
		}
                
        // All other handled by lookup tables.
        //
        else
            result = super.mapValue (inParam, inValue);

        return result;
            
    }   // end mapValue().

    /**
     * Write the setting to the command line argument array.
     * @param  inParameter  String representing the Mousekeys setting of interest.
     * @param  inValue      String representing that setting's value.
     */
    protected void doWriteSetting (String inParameter, String inValue)
    {
        addArgToArray (inParameter, inValue);
    
    }   // end doWriteSetting().


    /**
     * Method for acquiring the executable to call to modify the Windows mouse-keys settings.
     * @return            Did this method successfully get all those properties (boolean)?
     */
    protected boolean setLocalData()
    {
        boolean success = false;
        
        // Try to get <theMouseKeysExec>.
        //
        try
        {
            theMouseKeysExec = getControlHub().get3rdPartyExecutable (getAppID());
            ConfigManager.logDebugStatement ("WinKeyboardSettings.setLocalData():  <theMouseKeysExec> is '" + (theMouseKeysExec == null ? "null" : theMouseKeysExec) + "'");
            success = true;
        }
        catch (MissingResourceException mre)
        {
            ConfigManager.logDebugStatement ("WinKeyboardSettings.setLocalData():  can't get local properties");
            ConfigManager.logException (mre);
            theMouseKeysExec = null;
            success = false;
        }
        
        return success;
    
    }   // end setLocalData().
    
    /**
     * This SetterLauncher does not actually launch anything.  No-op implementation.
     */
    public void doLaunch()
    {
    
    }   // end doLaunch().

    /**
     * "Kill" the process created by <code>doLaunch()</code>.  Since nothing is actually launched, we take
     * this opportunity to reset the keyboard back to default values.
     */
    public void kill()
    {
        // Don't do anything if there is no command to execute.
        //
        if (theMouseKeysExec != null)
        {
            try
            {
                // Run the command.
                //
                ConfigManager.logDebugStatement ("Command:  '" + theMouseKeysExec + "'");
                Process nativeSetup = Runtime.getRuntime().exec (theMouseKeysExec);
                try
                {
                    handleProcessIStreams (nativeSetup, true);
                    nativeSetup.waitFor();
                }
                catch (InterruptedException ie)
                {
                    ConfigManager.logException(ie);
                }
            }
            catch (IOException ioe)
            {
                ConfigManager.logException(ioe);
            }
        }

    }  // end kill().

    /**
     * Nested class to map the ACCLIP preference name to the Windows mouse-keys settings.
     * The settings are stored as a table of ParameterState objects.
     */
    private static class MousekeysSettings extends SettingsBundle
    {
        /**
         * Record the fact that these settings are of type "alternativePointing".
         */
        public MousekeysSettings()
        {
            super ("mouseEmulation");
        
        } 
        
        public Object[][] getContents()
        {
            return contents;
        }
        
        final Object[][] contents = {
        
            { "speed", new ParameterState (WinMouseSettings.SPEED_NAME, true, new Integer (SPEED_DEFAULT)) },
            { "acceleration", new ParameterState (WinMouseSettings.ACCEL_NAME, true, new Integer (ACCEL_DEFAULT)) },
            
        };
        
    }  // end nested class MouseworksSettings.

    /**
     * Inner class for mapping Windows mouse keyboard parameters to the ones in the preferences.
     */
    private class ParamMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<ereader name>,<prefs element>})
         */
        final Object[][] contents = {
            { WinMouseSettings.SPEED_NAME,  Web4AllConstants.ME_GENERIC_SPEED },
            { WinMouseSettings.ACCEL_NAME,  Web4AllConstants.ME_GENERIC_ACCEL }
        };

    }  // end inner class ParamMap.


    /**
     * Inner class for mapping prefs values to the Windows values maps.
     */
    private static class ValueMapChooser extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<value uid from once corp>,<our map>})
         */
        final Object[][] contents = {};

    }  // end inner class ValueMapChooser.

    /**
     * Nested class for mapping Mousework settings to its position in the command line argument.
     */
    private static class ArgIndexMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table (Mousework setting, argument index})
         */
        final Object[][] contents = {
            { WinMouseSettings.SPEED_NAME, new Integer (0) },
            { WinMouseSettings.ACCEL_NAME, new Integer (1) },
        };

    }  // end inner class ArgIndexMap.

}   // end class WinMouseSettings.

