/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

/*
 * File:            ZoomTextSettings.java
 *
 * Synoposis:       package ca.utoronto.atrc.web4all.thirdparty;
 */
 
 package ca.utoronto.atrc.web4all.thirdparty;

import java.io.*;
import java.util.*;

import org.w3c.dom.*;

import ca.utoronto.atrc.web4all.*;
import ca.utoronto.atrc.web4all.configuration.*;

/**
 * Writes out ini settings for ZoomText.
 *
 * @version $Id: ZoomTextSettings.java,v 1.1 2006/03/28 16:39:14 stasia Exp $
 * @author Anastasia Cheetham
 */
public class ZoomTextSettings extends AbstractSetterLauncher
{

    /**
	 * The setting name associated with the ACCLIP magnification preference
     */
	final static String MAGNIFICATION_NAME = "magnification";

    /**
	 * The default value for the magnification
     */
	final static String MAG_DEFAULT = "1.5";
	

    /**
     * The key to the backup <code>.ini</code> file property. This location will be
     * use to back up the existing ZoomText settings.
     */
    private final static String BACKUP_INI    = "backup.ini";

    /**
     * The key to the settings file location property.
     */
    private final static String SETTINGS_FOLDER	= "ZoomText.zxc.dir";

    /**
     * The key to the settings file name property.
     */
    private final static String SETTINGS_FILE	= "ZoomText.zxc.file";

    /**
     * The ACCLIP technologies and their preferences that this ZoomText SetterLauncher handles.
     */
    private final static SettingsBundle PARAMS_HANDLED[] = {
        new ZoomTextSettings.ZoomTextMagnifierSettings()
    };
    
    /**
     * The output file (".ini") itself.
     */
    private PrintWriter theLocalOutput;

    /**
     * Constructor -- no argument.
     */
    public ZoomTextSettings()
    {
        super();
        theLocalOutput = null;
		
    }  // end ZoomTextSettings().

    /**
     * Class specific initialization.
     */
    protected void init() {
        setUpParameters (ZoomTextSettings.PARAMS_HANDLED, null);
	} // end init()

    /**
     * Launch ZoomText.  <code>doSettings()</code> should
     * be called first to configure the technology prior to launching it.
     * @see #doSettings(Vector,ControlHub)
     */
    public void doLaunch() {
        // Generate the command.  Start with the location.
        //
        try
        {
            String command = getControlHub().get3rdPartyExecutable (getAppID());
            ConfigManager.logDebugStatement ("'" + command + "'");
            setProcess (Runtime.getRuntime().exec (command));
        }

        catch (IOException ioe)
        {
            ConfigManager.logException(ioe);
        }
	} // end doLaunch()

	/**
	 * TODO: add note about the fact that killing currently doesn't work
	 */
	public void kill() {
        // Let the super class shut down ZoomText.
        //
        super.kill();
        
        // Restore the settings file to the state it was before we configured.
        //
		restoreLocalOutput();

        // Remove the ini file.
        //
        String dirSep = System.getProperty ("file.separator");
        String iniPath = null;
        try
        {
            iniPath = getControlHub().getHomeDirectory() + dirSep + getControlHub().get3rdPartyIni (getAppID());
            File iniFile = new File (iniPath);
            if (iniFile.exists())
                iniFile.delete();
        }
        
        // Can't get path to ini file...log it.
        //
        catch (MissingResourceException mre)
        {
            ConfigManager.logException (mre);
        }
                       
	} // end kill()

    /**
     * Configure ZoomText based on the given ACCLIP preferences.
     * The preferences are given as a list of AccLipInfoPackage objects.  Each AccLipInfoPackage
     * is identified as a specific kind of technology (e.g., a screen reader), and contains
     * a set of generic and specific settings for that technology.  The type and settings
     * use the vocabulary of the ACCLIP schema.
     * @param       inAccLipInfoPackages    A Vector of AccLipInfoPackage instances.
     * @param       inControlHub            The ControlHub object that contains information about the technology
     *                                      such as the location of an ".ini" file and the path to the
     *                                      executable.
     * @return                              A flag indicating whether this SetterLauncher launches
     *                                      a browser.
     * @see AccLipInfoPackage
     * @see ControlHub
     */
    public boolean doSettings (Vector inAccLipInfoPackages, ControlHub inControlHub) {

        // Get the name of the ACCLIP Element that is for screen magnifiers.  This is the only
        // technology type that "ZoomTextSettings" handles.
        //
        String magnifierElName = inControlHub.getPrefElementName (Web4AllConstants.SCREEN_ENHANCE);
        
        // Loop thru the ACCLIP info looking for <magnifierElName>.
        //
        for (int i = 0; i < inAccLipInfoPackages.size(); i++)
        {
            // Skip any AccLipInfoPackage that is not for the "magnifier" type.
            //
            AccLipInfoPackage anAccLipInfo = (AccLipInfoPackage) inAccLipInfoPackages.elementAt (i);
            if (anAccLipInfo.getAppType().equals (magnifierElName) == false)
                continue;

            // Record the parent Element in the ACCLIP that contains both the generic settings and
            // specific settings.  Record, also, the ControlHub instance.  Get the application name
            // from <anAccLipInfo>'s specific preferences container. Finally create the output file.
            //
            Element prefsParentElement = (Element) anAccLipInfo.getGenericPrefs().getParentNode();
            setAppSettings (prefsParentElement);
            setControlHub (inControlHub);
            setAppID (anAccLipInfo.getSpecificPrefs());

            backupLocalOutput();
            // the createOutput() will recreate the ini file, but empty
            theLocalOutput = createOutput (getUserSettingsFile());

            // Machinery intialized: start processing the preferences.
            // this process will write desired settings out to the ini file cleared above
            //
            if (prefsParentElement != null)
            {
                // Clear the <theParamsWritten> array.
                //
                clearParamsWritten (magnifierElName);

                // Loop thru the generic preferences within <prefsParentElement>.
                //
                loopThruGenerics (magnifierElName, anAccLipInfo.getGenericPrefs());

                // Now, go through the <ZoomTextSettings.PARAMS_WRITTEN>, and for each one that is not written,
                // write its default.
                //
                handleUnwrittenParams (magnifierElName);

                // Close the output, the ".ini" file is done.
                //
                closeOutput();
			}
		}

		// now that desired settings are written out to the ini file,
		// append the defaults
		appendDefaultSettings();

		return false;
	} // end doSettings()

    /**
     *
     */
    protected void doWriteSetting (String inParameter, String inValue) {
		
		if (inParameter.equals(MAGNIFICATION_NAME)) {
			writeSetting("[PRIMARY]", "magPower", inValue);
			writeSetting("[STATIC 1]", "magPower", inValue);
		}
		else {
			writeSetting(inParameter, inValue);
		}
	} // end doWriteSetting()
	
    protected void writeSetting (String inHeading)
    {
        if (inHeading != null)
        {
            theLocalOutput.println (inHeading);
        }

    }  // writeSetting (String).

    protected void writeSetting (String inHeading, String inParameter, String inValue)
    {
        if ((inHeading != null) && (inParameter != null) &&(inValue != null))
        {
            theLocalOutput.println (inHeading);
            writeSetting (inParameter, inValue);
        }

    }  // writeSetting (String, String, String).

	/**
	 * Append the copied default settings to the output file.
	 *
     * @see #backupLocalOutput
	 */
	private void appendDefaultSettings() {
        try
        {
            // Build the command... first the command itself.
            //
            String dirSep = System.getProperty ("file.separator");
	        String backupIniFile = getControlHub().get3rdPartyProperties (getAppID()).getString (BACKUP_INI);
            String localOutputFile = getUserSettingsFile();
            StringBuffer command = new StringBuffer ("cmd.exe /C type \""+backupIniFile+"\" >> \""+localOutputFile+"\"");
            
            ConfigManager.logDebugStatement ("Command:  '" + command.toString() + "'");
            Process appendProcess = Runtime.getRuntime().exec (command.toString());
            handleProcessIStreams (appendProcess, true);
            appendProcess.waitFor();
            ConfigManager.logDebugStatement ("Command completed.");
        }
        catch(IOException ioe)
        {
            ConfigManager.logException(ioe);
        }
        catch (InterruptedException ie)
        {
            ConfigManager.logException(ie);
        }
	} // end appendDefaultSettings
	
	/**
	 * Create a backup of the current ZoomText settings file, which will be restored after
	 * the system is reset.
	 *
     * @see #backupLocalOutput
     * @see #restoreLocalOutput
     * @see #appendDefaultSettings
	 */
	private void backupLocalOutput() {
        try
        {
            // Build the command... first the command itself.
            //
            String dirSep = System.getProperty ("file.separator");
            StringBuffer command = new StringBuffer ("cmd.exe /C copy \"");
            command.append(getUserSettingsFile());
            command.append("\" \"");
	        String backupIniFile = getControlHub().get3rdPartyProperties (getAppID()).getString (BACKUP_INI);
            command.append(getControlHub().getHomeDirectory()).append(dirSep).append(backupIniFile);
            command.append("\"");
            
            ConfigManager.logDebugStatement ("Command:  '" + command.toString() + "'");
            Process bkpProcess = Runtime.getRuntime().exec (command.toString());
            handleProcessIStreams (bkpProcess, true);
            bkpProcess.waitFor();
            ConfigManager.logDebugStatement ("Command completed.");
        }
        catch(IOException ioe)
        {
            ConfigManager.logException(ioe);
        }
        catch (InterruptedException ie)
        {
            ConfigManager.logException(ie);
        }
	} // end backupLocalOutput()
	
	/**
	 * Construct the path to the user settings file based on the current user name
	 */
	private String getUserSettingsFile() {
        StringBuffer userSettingsFile = new StringBuffer(getControlHub().get3rdPartyProperties (getAppID()).getString (SETTINGS_FOLDER));
		userSettingsFile.append(System.getProperty ("user.name"));
		userSettingsFile.append(getControlHub().get3rdPartyProperties (getAppID()).getString (SETTINGS_FILE));			
		ConfigManager.logDebugStatement("user settings file is "+userSettingsFile);
		
		return userSettingsFile.toString();
	} // end getUserSettingsFile()
	
    /**
     * Write the backup copy of the ini file out to the ZoomText settings file.
     * This should reset to ZoomText to the backed up configuration.
     *
     * @see #backupLocalOutput
     */
    protected void restoreLocalOutput()
    {
        try
        {
            // Build the command... first the command itself.
            //
            String dirSep = System.getProperty ("file.separator");
            StringBuffer command = new StringBuffer ("cmd.exe /C copy \"");
	        String backupIniFile = getControlHub().get3rdPartyProperties (getAppID()).getString (BACKUP_INI);
            command.append(getControlHub().getHomeDirectory()).append(dirSep).append(backupIniFile);
			command.append("\" \"");
            command.append(getUserSettingsFile());
            command.append("\"");
            
            ConfigManager.logDebugStatement ("Command:  '" + command.toString() + "'");
            Process restoreProcess = Runtime.getRuntime().exec (command.toString());
            handleProcessIStreams (restoreProcess, true);
            restoreProcess.waitFor();
            ConfigManager.logDebugStatement ("Command completed.");
        }
        catch(IOException ioe)
        {
            ConfigManager.logException(ioe);
        }
        catch (InterruptedException ie)
        {
            ConfigManager.logException(ie);
        }
   }    // end reseLocalOutpu()
    
    /**
     * Map the value retrieved from the preferences document to the actual value to output.
     * This is an override since the magnification must be calculated.
     * @param  inParam      The parameter of interest.  This is expressed using the technology's
     *                      vocabulary.
     * @param  inValue      The value from the ACCLIP as a String.
     * @return              The value to output, as a String.
     */
    protected String mapValue (String inParam, String inValue)
    {
        String result = null;

        // Choose a value map.
        //
		if (inParam.equals(MAGNIFICATION_NAME)) {
			float fResult = linearCalcTechVal (inValue, (float)100.0, (float)0.0);
			result = Float.toString((int)fResult);
		}
		
        else {
			super.mapValue(inParam, inValue);
        }
        return result;
    
    }   // end mapValue().

    /**
     * Nested class for the magnifier settings of ZoomText.
     * The settings are stored as a table of ParameterState objects.
     */
    private static class ZoomTextMagnifierSettings extends SettingsBundle
    {
        /**
         * Record the fact that these settings are of type "screenEnhance".
         */
        public ZoomTextMagnifierSettings()
        {
            super ("screenEnhance");
        
        }   // end ZoomTextMagnifierSettings().
        
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table.  The left side is an element name from the ACCLIP.  The right side
         * is the name of the ZoomText setting, whether ZoomText requires that setting, and its default
         * value (as specified by ZoomText).
         */
        final Object[][] contents = {
        
            { "magnification", new ParameterState (MAGNIFICATION_NAME, true, new Integer (MAG_DEFAULT)) },
		};
	} // end inner class ZoomTextMagnifierSettings
	

} // end class ZoomTextSettings
