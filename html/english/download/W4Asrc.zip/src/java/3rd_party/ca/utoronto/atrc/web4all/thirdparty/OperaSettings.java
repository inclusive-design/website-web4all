/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * 
 * File:            OperaSettings.java
 *
 * Synoposis:       package ca.utoronto.atrc.web4all.thirdparty;
 * 
]*/

package ca.utoronto.atrc.web4all.thirdparty;

import java.awt.Color;
import java.io.*;
import java.util.*;

import org.w3c.dom.*;
import org.apache.xerces.util.DOMUtil;

import ca.utoronto.atrc.web4all.*;
import ca.utoronto.atrc.web4all.configuration.*;


/**
 * Class that writes out the textual "Opera.ini" file and the user's
 * css file, and then launches Opera.
 *
 * @version $Id: OperaSettings.java,v 1.20 2006/03/28 22:07:54 clown Exp $
 * @author  Anastasia Cheetham
 * @author  Joseph Scheuhammer
 */

public class OperaSettings extends AbstractSetterLauncher
{

    public final static String  GENERIC_FACE_NAME_INI       = "FaceName";
    public final static String  GENERIC_FACE_SANSSERIF      = "Arial";
    public final static String  GENERIC_FACE_SERIF          = "Times";
    public final static String  GENERIC_FACE_MONOSPACE      = "Courier";
    public final static String  GENERIC_FACE_CURSIVE        = "Comic Sans MS";
    public final static String  GENERIC_FACE_FANTASY        = "??";
    public final static String  GENERIC_FACE_DEFAULT        = GENERIC_FACE_SANSSERIF;
    
    public final static String  GENERIC_FACE_NAME_CSS       = "font-family: ";
    public final static String  GENERIC_FACE_CSS_SERIF      = "serif";
    public final static String  GENERIC_FACE_CSS_SANSSERIF  = "sans-serif";
    public final static String  GENERIC_FACE_CSS_MONOSPACE  = "monospace";
    public final static String  GENERIC_FACE_CSS_CURSIVE    = "cursive";
    public final static String  GENERIC_FACE_CSS_FANTASY    = "fantasy";
    public final static String  GENERIC_FACE_CSS_DEFAULT    = GENERIC_FACE_CSS_SANSSERIF;
    
    public final static String  GENERIC_FACE_NAME_FCS       = "GenericFace";
    public final static String  GENERIC_FACE_FCS_SERIF      = "Times";
    public final static String  GENERIC_FACE_FCS_SANSSERIF  = "Arial";
    public final static String  GENERIC_FACE_FCS_MONOSPACE  = "Courier";
    public final static String  GENERIC_FACE_FCS_CURSIVE    = "Comic Sans MS";
    public final static String  GENERIC_FACE_FCS_FANTASY    = "??";
    public final static String  GENERIC_FACE_FCS_DEFAULT    = GENERIC_FACE_FCS_SANSSERIF;
    
    public final static String  FONT_NAME_NAME              = "FontName";
    public final static String  FONT_NAME_DEFAULT           = GENERIC_FACE_SANSSERIF;

    public final static String  FONT_SIZE_NAME              = "FontSize";
    public final static int     FONT_SIZE_DEFAULT           = 12;
    public final static String  FONT_SIZE_NAME_INI          = "Height";
    public final static String  FONT_SIZE_NAME_CSS          = "font-size: ";
    public final static String  FONT_SIZE_NAME_FCS          = "FontSize";

    public final static String  FOREGROUND_COLOR_NAME       = "ForegroundColor";
    public final static String  FOREGROUND_COLOR_DEFAULT    = "00000000";   // white
    public final static String  BACKGROUND_COLOR_NAME       = "BackgroundColor";
    public final static String  BACKGROUND_COLOR_DEFAULT    = "00ffffff";   // black
    public final static String  INVERT_COLORS_NAME          = "InvertColors";
    public final static String  INVERT_COLORS_DEFAULT       = "0";
    public final static String  HIGHLIGHT_COLOR_NAME        = "BackgroundColor";
    public final static String  HIGHLIGHT_COLOR_DEFAULT      = "000a246a";   // dark blue

    public final static String  CURSOR_COLOR_WHITE    = "1";
    public final static String  CURSOR_COLOR_BLACK    = "0";
    public final static String  CURSOR_SIZE_STANDARD  = "1";
    public final static String  CURSOR_SIZE_LARGE     = "2";
    public final static String  CURSOR_SIZE_XLARGE    = "3";
	public final static String	CURSOR_TRAILS_DEFAULT = "0";
	public final static float	CURSOR_TRAILS_MAX     = (float)10.0;

    public final static String  MAG_NAME    = "Scale";
    public final static String  MAG_DEFAULT = "100";

    /*
     * Keys into the FontColourSetup argument index map
     */
    public final static int     FCS_NUM_ARGS        = 8;
    public final static String  FCS_FONTSIZE        = "fontSize";
    public final static String  FCS_FONTFACE        = "fontFace";
    public final static String  FCS_FG_COLOUR       = "fgColour";
    public final static String  FCS_BG_COLOUR       = "bgCcolour";
//    public final static String  FCS_INVERT          = "invertColorChoice";
    public final static String  FCS_HILIGHT_COLOUR  = "hilightCcolour";
    public final static String  FCS_CURSORCOLOUR    = "cursorColour";
    public final static String  FCS_CURSORSIZE      = "cursorSize";
    public final static String  FCS_CURSORTRAILS    = "cursorTrails";
     
    /*
     * Various header strings necessary for the Opera.ini file
     */
    public final static String  USER_PREFS_HEADING           = "\n[User Prefs]\nLanguage File=";
    public final static String  LANG_USER_HEADING           = "\n[User Prefs]\nLanguage File=";
    public final static String  FONT_USER_HEADING           = "\n[User Prefs]\nUseWindowsDefaultUISettings=0";
    public final static String  CSS_USER_HEADING            = "\n[User Prefs]\nLocal CSS File=";
    public final static String  MAG_USER_HEADING            = "\n[User Prefs]\nScale=";
    public final static String  FONT_UI_HEADING             = "\n[FONT.UI]";
    public final static String  FONT_UIDIS_HEADING          = "\n[FONT.UIDIS]";
    public final static String  COLOR_UI_HEADING            = "\n[COLOR.UI]";
    public final static String  COLOR_UIDIS_HEADING         = "\n[COLOR.UIDis]";
    public final static String  COLOR_UIBG_HEADING          = "\n[COLOR.UIBG]";
    public final static String  COLOR_UIBUTTONBG_HEADING    = "\n[COLOR.UIBUTTONBG]";
    public final static String  COLOR_KEY_RED               = "\nRED=";
    public final static String  COLOR_KEY_GREEN             = "\nGREEN=";
    public final static String  COLOR_KEY_BLUE              = "\nBLUE=";
    public final static String  DEFAULTS_STANDARD           = "<standard>";
    public final static String  DOCUMENT_MODE_HEADING       = "\n[Document Mode]";
    public final static String  USER_MODE_HEADING       	= "\n[User Mode]";
    public final static String  USER_MODE_SETTING 			= "\nAuthor CSS=1\nAuthor Font and Colors=1\nUser CSS=1\nUser Font and Colors=1\nUser Link Settings=1\nTables=1";


    // Added by David W.
    public final static String  HOME_URL_USER_HEADING      = "\n[User Prefs]\nHome URL=";

    
    public final static String  CSS_FONT_FAMILY         = "font-family: ";
    public final static String  CSS_FONT_SIZE           = "font-size: ";
    public final static String  CSS_FONT_COLOR          = "color: ";
    public final static String  CSS_BKG_COLOR           = "background-color: ";
    public final static String  CSS_HEADING1            = "h1";
    public final static String  CSS_HEADING2            = "h2";
    public final static String  CSS_HEADING3            = "h3";
    public final static String  CSS_HEADING4            = "h4";
    public final static String  CSS_HEADING5            = "h5";
    public final static String  CSS_HEADING6            = "h6";
    public final static String  CSS_LINK                = "a";
    public final static String  CSS_TEXT                = "text: ";
    public final static String  CSS_UNDERLINE           = "underline";
    public final static String  CSS_STAR                = "*";
    public final static String  CSS_BODY_OPENING        = "body { background-image: none ! important; ";
    public final static String  CSS_BODY		        = "body";
    public final static String  CSS_BKG_IMAGE           = "background-image:";
    public final static String  CSS_NONE                = "none ";
    public final static String  CSS_SEP                 = " ! important;";
    public final static String  CSS_OPENING             = " { ";
    public final static String  CSS_CLOSING             = " }";
    public final static String  CSS_FONT_FAMILY_S       = "serif";
    public final static String  CSS_FONT_FAMILY_SS      = "sans-serif";
    public final static String  CSS_FONT_FAMILY_M       = "monospace";
    public final static String  CSS_FONT_FAMILY_C       = "cursive";
    public final static String  CSS_FONT_FAMILY_F       = "fantasy";
    public final static String  CSS_FONT_SIZE_UNITS     = "pt ";
    public final static String  CSS_PERCENT             = "% ";

    /**
     * The key to the default <code>.ini</code> file property. This file contains
     * defaults that must be written out to the output <code>.ini</code> file.
     */
    private final static String DEFAULTS_INI    = "defaults.ini";

    /**
     * The key to the backup <code>.ini</code> file property. This location will be
     * use to back up the existing Opera settings.
     */
    private final static String BACKUP_INI    = "backup.ini";

    /**
     * The key to the font colour executable property.
     */
    private final static String FONT_EXE        = "font.exec";

    /**
     * The language file name to output to the <code>.ini</code> file.
     */
    private String theLanguageFile;
    
    /**
     * The key to the language file path property.
     */
    private final static String LANGFILE_PATH       = "langfile.path";

    /**
     * The key to the language file extension property.
     */
    private final static String LANGFILE_EXT        = "langfile.ext";

    /**
     * The ACCLIP technologies and their preferences that this VDK SetterLauncher handles.
     */
    private final static SettingsBundle PARAMS_HANDLED[] = {
        new OperaSettings.OperaScreenEnhancementSettings()
    };
    
    /**
     * Flag indicating whether or not to invert fg and bg colours.
     */
    private boolean theInvertFlag = false;

    /**
     * The output file (".ini") itself.
     */
    private PrintWriter theLocalOutput;

    /**
     * The css output file (".css").
     */
    private PrintWriter theLocalCssOutput;

    /**
     * The Opera-specific local properties.
     */
    private ResourceBundle theLocalProperties;

    /**
     * The value map chooser.
     */
    private final static OperaSettings.ValueMapChooser VAL_MAP_CHOOSER = new OperaSettings.ValueMapChooser();
    
    /**
     * The argument index map.
     */
    private final static OperaSettings.FCSArgsIndexMap ARGS_INDEX_MAP = new OperaSettings.FCSArgsIndexMap();

    /**
     * Constructor -- no argument; calls super().
     */
    public OperaSettings()
    {
        super();
    }  // end OperaSettings().

    /**
     * Class specific initialization.
     */
    protected void init()
    {
        // Initialize the parameters.
        //
        setUpParameters (OperaSettings.PARAMS_HANDLED, OperaSettings.VAL_MAP_CHOOSER);
        createArgsArray(FCS_NUM_ARGS);
        setArgsIndexMap (OperaSettings.ARGS_INDEX_MAP);
        createReadProcessIStreams();
        theLanguageFile = new String();

    }   // end init().

    /**
     * Create the output file.
     * @param       inHomeDir   A String naming the home directory relative to the directory we
     *                          are running in, "or", the full path to the directory containing
     *                          the file (see parameter <code>useSubDir</code> below).
     * @param       inFileName  A String naming the file.
     * @param       useSubDir   A boolean to indicate whether <code>inHomeDir</code> is a sub-folder
     *                          of the one the ConfigManager is in, or a full path to some other
     *                          directory.
     * @return                  A FileWriter for the file.  <code>null</code> if something went
     *                          wrong.
     * @see #init.
     */
    protected PrintWriter createCssOutput (String inHomeDir, String inFileName, boolean useSubDir)
    {
        PrintWriter cssWriter = null;
        
        // Create a full path to the file in question, as a String.
        //
        String dirSep = System.getProperty ("file.separator");
        String fullPath = null;

        // Get the ConfigManager directory and create the file in that folder.
        //
        if (useSubDir)
            fullPath = ConfigManager.getHomeDir() + dirSep + inHomeDir + dirSep + inFileName;
        
        // Assume that <inHomeDir> is a full path, and create the file in that folder.
        //
        else
            fullPath = inHomeDir + dirSep + inFileName;
        
        // Let the general case method do the rest.
        //
        PrintWriter printWriter = null;

        // Clean up any old output.
        //
        if (theLocalCssOutput != null)
        {
            theLocalCssOutput.flush();
            theLocalCssOutput.close();
            theLocalCssOutput = null;
        }

        // Create the file, and its PrintWriter.
        //
        try
        {
            File aFile = new File (fullPath);
            if (aFile != null)
                cssWriter = new PrintWriter (new FileWriter (aFile));
        }

        catch (IOException ioe)
        {
            ConfigManager.logException(ioe);
            printWriter = null;
        }

        // Assign the (new) output file.
        //
        theLocalCssOutput = cssWriter;
        return theLocalCssOutput;

    }  // end createOutput (String inHomeDir, String inFileName, boolean useSubDir).

    /**
     * Flush and close the current CSS output file -- release the resources.
     */
    protected void closeCssOutput()
    {
        if (theLocalCssOutput != null)
        {
            theLocalCssOutput.flush();
            theLocalCssOutput.close();
            theLocalCssOutput = null;
        }

    }  // end closeCssOutput().

    /**
     * Configure Opera based on the given ACCLIP preferences.
     * @param   inAccLipInfoPackages    A Vector of AccLipInfoPackage objects that contain
     *                                  preferences for different types of technologies.  This
     *                                  handles only the "screenEnhance" type.
     * @param   inControlHub            The ControlHub that contains information about the application
     * @return                          A flag to indicate whether this SetterLauncher will
     *                                  attempt to launch a browser.
     */
    public boolean doSettings (Vector inAccLipInfoPackages, ControlHub inControlHub)
    {
        // Get the name of the ACCLIP Element that is for screen enhancers.  This is the only
        // technology type that "OperaSettings" handles.
        //
        String screenEnhancerElName = inControlHub.getPrefElementName (Web4AllConstants.SCREEN_ENHANCE);
        
        // Loop thru the ACCLIP info looking for <screenEnhancerElName>.
        //
        for (int i = 0; i < inAccLipInfoPackages.size(); i++)
        {
            // Skip any AccLipInfoPackage that is not for the "screenEnhancer" type.
            //
            AccLipInfoPackage anAccLipInfo = (AccLipInfoPackage) inAccLipInfoPackages.elementAt (i);
            if (anAccLipInfo.getAppType().equals (screenEnhancerElName) == false)
                continue;
        
            // Record the parent Element in the ACCLIP that contains both the generic settings and
            // specific settings.  Record, also, the ControlHub instance.  Get the application name
            // from <anAccLipInfo>'s specific preferences container. Finally create the output file.
            //
            Element prefsParentElement = (Element) anAccLipInfo.getGenericPrefs().getParentNode();
            setAppSettings (prefsParentElement);
            setControlHub (inControlHub);
            setAppID (anAccLipInfo.getSpecificPrefs());

            // handle locale
            theLanguageFile = findLanguageFile(inControlHub.getLocale());
            if (theLanguageFile == null)
                theLanguageFile = DEFAULTS_STANDARD;

            backupLocalOutput();
            theLocalOutput = createOutput (getControlHub().get3rdPartyIni (getAppID()), true);
            theLocalProperties = getControlHub().get3rdPartyProperties (getAppID());
            theLocalCssOutput = createCssOutput (ConfigManager.getHomeDir(), theLocalProperties.getString("user.css"), false);

            // Start processing the preferences.
            //
            if (prefsParentElement != null)
            {
                // Clear the <theParamsWritten> array.
                //
                clearParamsWritten (screenEnhancerElName);

                // write out the language setting
                theLocalOutput.print (LANG_USER_HEADING);
                theLocalOutput.println(theLanguageFile);

                // write out the pointer to the css file, relative to the home directory
                theLocalOutput.println(CSS_USER_HEADING + getControlHub().getHomeDirectory() + System.getProperty ("file.separator") + theLocalProperties.getString("user.css"));

				// set Opera flags so that it pays attention to the css file
                theLocalOutput.println(USER_MODE_HEADING);
                theLocalOutput.println(USER_MODE_SETTING);
				
                // Specify the Default Startup URL - Added by David W.
                try
                {
                    theLocalOutput.println(HOME_URL_USER_HEADING + getControlHub().getGlobalProperty(Web4AllPropNames.LAUNCH_URL));
                }
                catch (MissingResourceException mre)
                {
                    ConfigManager.logException (mre);
                }

                // Before looping through the generic preferences, extract the generic
                // invertColors preference, so that the information is available
                // when processing the colour preferences
                //
                getInvertColorPrefs(screenEnhancerElName, anAccLipInfo.getGenericPrefs());
                
                // Loop thru the generic preferences within <prefsParentElement>.
                // This calls handlePref() which will call the indivisual preference handlers
                // as appropriate
                //
                loopThruGenerics (screenEnhancerElName, anAccLipInfo.getGenericPrefs());

                // Now, go through the <OperaSettings.PARAMS_WRITTEN>, and for each one that is not written,
                // write its default.
                //
                handleUnwrittenParams (screenEnhancerElName);

                // Close the output files.
                //
                closeOutput();
                closeCssOutput();

                // call the process that sets the system font and colours.
                setSystemSettings();
            }
        }
        
        return true;        // we do launch a browser.
    }  // end doSettings().

	/**
	 * Create a backup of the current Opera.ini file, which will be restored after
	 * the system is reset.
	 */
	private void backupLocalOutput() {
        try
        {
            // Build the command... first the command itself.
            //
            String dirSep = System.getProperty ("file.separator");
            StringBuffer command = new StringBuffer ("cmd.exe /C copy \"");
            command.append(getControlHub().get3rdPartyIni (getAppID()));
            command.append("\" \"");
	        String backupIniFile = getControlHub().get3rdPartyProperties (getAppID()).getString (OperaSettings.BACKUP_INI);
            command.append(getControlHub().getHomeDirectory()).append(dirSep).append(backupIniFile);
            command.append("\"");
            
            ConfigManager.logDebugStatement ("Command:  '" + command.toString() + "'");
            Process bkpProcess = Runtime.getRuntime().exec (command.toString());
            handleProcessIStreams (bkpProcess, true);
            bkpProcess.waitFor();
            ConfigManager.logDebugStatement ("Command completed.");
        }
        catch(IOException ioe)
        {
            ConfigManager.logException(ioe);
        }
        catch (InterruptedException ie)
        {
            ConfigManager.logException(ie);
        }
	} // end backupLocalOutput()
	
    /**
     * Finds a language file based on the current locale.
     * @param   inLocale    The current Locale.
     * @return  A string containing the full path of the language file, or null if
     *          not found.
     */
    protected String findLanguageFile(Locale inLocale)
    { 
        String dirName = getControlHub().get3rdPartyProperties (getAppID()).getString (OperaSettings.LANGFILE_PATH);
        String ext = getControlHub().get3rdPartyProperties (getAppID()).getString (OperaSettings.LANGFILE_EXT);

        String lng = inLocale.getDisplayLanguage(Locale.ENGLISH).toLowerCase();

        String fName = new String(dirName+lng+ext);

        File f = new File(fName);
        if (f.exists())
            return fName;
        else
            return null;
    }   // end findLanguageFile()
    
    /**
     * Extract and record the colour inversion preference.
     * @param   inTechType              The type of technology the given generic preferences are for
     *                                  expressed in the ACCLIP's vocabulary (e.g. "screenReader").
     * @param   inGenericContainer      The parent generic Element, (e.g. "screenReaderGeneric").
     * @see #handlePref(String,Element,boolean)
     */
    protected void getInvertColorPrefs (String inTechType, Element inGenericContainer)
    {
        if (inGenericContainer != null)
        {
            // Get the immediate children of <inGenericContainer>, go through them, matching
            // against <theParamsHandled>.  If that setting is declared in the children,
            // write it out.
            //
            String elName = getControlHub().getPrefElementName (Web4AllConstants.SE_GENERIC_INVERT_COLOURS);
            Element aChild = DOMUtil.getFirstChildElement (inGenericContainer, elName);
            if (aChild != null)
            {
                String childName = aChild.getNodeName();
                ConfigManager.logDebugStatement ("For '" + inTechType + "' *generic* pref '" + childName + "'");
                handleInvertColoursPrefs (inTechType, aChild);
                ConfigManager.logDebugStatement ("");   // new line.
            }
        }
    
    }   // end  getInvertColorPrefs().

    /**
     * Given a technology type and a preference for that type, determine if it is one that
     * we handle.  If so, write out its value.  This override is to take into account the
     * hiearchical nature of the keyboard layout and selection method settings.
     * @param   inTechType      The type of technology this preference is for, as taken from the
     *                          ACCLIP. If it is not "onscreenKeyboard", this does nothing.
     * @param   inPref          The preferences Element that represent a single VDK setting.
     * @param   isGeneric       Is <code>inPref</code> from the default section of the preferences?
     */
    protected void handlePref (String inTechType, Element inPref, boolean isGeneric)
    {
        // Get the attributes, and look to see if it is one we handle.
        //
        String prefName = inPref.getTagName();
        
        // Dispatch to appropriate methods
        //
        
        // Font Face
        if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.SE_GENERIC_FONT_FACE)))
            handleFontFacePrefs (inTechType, inPref);

        // Generic Font Face        
        else if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.SE_GENERIC_GENERIC_FACE)) )
            handleGenericFacePrefs (inTechType, inPref);
        
        // Generic Font Size
        else if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.SE_GENERIC_FONT_SIZE)) )
            handleFontSizePrefs (inTechType, inPref);
        
        // Generic Foreground Colour
        else if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.SE_GENERIC_FG_COLOUR)) )
            handleFgColourPrefs (inTechType, inPref);
        
        // Generic Background Colour
        else if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.SE_GENERIC_BG_COLOUR)) )
            handleBgColourPrefs (inTechType, inPref);

		// Invert Colours
        else if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.SE_GENERIC_INVERT_COLOURS)) )
            handleInvertColoursPrefs (inTechType, inPref);

		// Generic Highlight Colour
        else if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.SE_GENERIC_HI_COLOUR)) )
            handleHilightColourPrefs (inTechType, inPref);
        
        // Generic Cursor Colour
        else if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.SE_GENERIC_CURSOR_COLOUR)) )
            handleCursorColourPrefs (inTechType, inPref);
        
        // Generic Cursor Size
		else if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.SE_GENERIC_CURSOR_SIZE)) )
            handleCursorSizePrefs (inTechType, inPref);

        // Generic Cursor Size
		else if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.SE_GENERIC_CURSOR_TRAILS)) )
            handleCursorTrailsPrefs (inTechType, inPref);

		// Generic Magnification Factor
		// Note: this preference should be handled by a screen magnifier, so we ignore it
        else if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.SE_GENERIC_MAGNIFICATION)) )
			;
			
// we are currently ignoring this preference        
//        else if (prefName.equals (getControlHub().getPrefElementName (Web4AllConstants.SE_GENERIC_FONT_NAME)) )
//            handleFontNamePrefs (inTechType, inPref);
        
        // Nothing special -- let the super class handle it through a value map.
        //
        else
            super.handlePref (inTechType, inPref, isGeneric);

    }  // end handlePref().
    
    /**
     * Handle the "font face" sub-tree from the ACCLIP preferences.
     * @param   inTechType  The type for technology from the ACCLIP.  This SetterLauncher
     *                      handles only "onscreenKeyboard".
     * @param   inPref      The font face preference from the ACCLIP document.
     * #see handlePref
     */
    private void handleFontFacePrefs (String inTechType, Element inPref)
    {
        // Loop thru the children of <inPref> and process them via this.handlePref().
        //
        Element aChild = DOMUtil.getFirstChildElement (inPref);
        while (aChild != null)
        {
            String childName = aChild.getNodeName();
            handlePref (inTechType, aChild, true);    // "true" means generic pref.            
            aChild = DOMUtil.getNextSiblingElement (aChild);
       } 
        
    }   // end handleFontFacePrefs()
    
    /**
     * Handle the "generic font face" sub-tree from the ACCLIP preferences.
     * @param   inTechType  The type for technology from the ACCLIP.  This SetterLauncher
     *                      handles only "onscreenKeyboard".
     * @param   inPref      The font face preference from the ACCLIP document.
     * #see handlePref
     */
    private void handleGenericFacePrefs (String inTechType, Element inPref)
    {
        String value = null;
        String realValue = null;
        ParameterMultiState techParamMultiState = null;
        
        String prefName = inPref.getTagName();
        ConfigManager.logDebugStatement (prefName);

        // do the equivalent of doWriteSetting(), but for Opera,
        // which requires a bunch of stuff:
        

        techParamMultiState = (ParameterMultiState)findParameter (inTechType, prefName, true);
        if (techParamMultiState != null)
        {
            String techParamIniName = techParamMultiState.getParamName("ini");
            String techParamCssName = techParamMultiState.getParamName("css");
            String techParamFcsName = techParamMultiState.getParamName("fcs");
            ConfigManager.logDebugStatement (techParamIniName);
            value = getValueValue (inPref);

            realValue = mapValue (techParamFcsName, value);
            addArgToArray(techParamFcsName, realValue);

            realValue = mapValue (techParamIniName, value);
			writeFontSetting(techParamIniName, realValue);
			
            realValue = mapValue (techParamCssName, value);
            writeCssSetting(techParamCssName, realValue);
			// Opera does not properly inherit styles applied to the body tag, so
			// we must specify heading font face directly
            writeCssSetting(CSS_HEADING1, CSS_FONT_FAMILY, realValue);
            writeCssSetting(CSS_HEADING2, CSS_FONT_FAMILY, realValue);
            writeCssSetting(CSS_HEADING3, CSS_FONT_FAMILY, realValue);
            writeCssSetting(CSS_HEADING4, CSS_FONT_FAMILY, realValue);
            writeCssSetting(CSS_HEADING5, CSS_FONT_FAMILY, realValue);
            writeCssSetting(CSS_HEADING6, CSS_FONT_FAMILY, realValue);
            writeCssSetting(CSS_LINK, CSS_FONT_FAMILY, realValue);

            techParamMultiState.setSetState (true);
            ConfigManager.logDebugStatement ("wrote " + techParamIniName);
        }
        else
        {
            ConfigManager.logDebugStatement ("'" + inPref + "' not handled");
        }
    }   // end handleGenericFacePrefs()
    

    /**
     * Handle the "font size" sub-tree from the ACCLIP preferences.
     * @param   inTechType  The type for technology from the ACCLIP.  This SetterLauncher
     *                      handles only "onscreenKeyboard".
     * @param   inPref      The font face preference from the ACCLIP document.
     * #see handlePref
     */
    private void handleFontSizePrefs (String inTechType, Element inPref)
    {
        String techParamName = null;
        String value = null;
        String realValue = null;
        ParameterState techParamState = null;
        
        String prefName = inPref.getTagName();
        ConfigManager.logDebugStatement (prefName);

        // do the equivalent of doWriteSetting(), but for Opera,
        // which requires a bunch of stuff:
        
        techParamState = findParameter (inTechType, prefName, true);
        if (techParamState != null)
        {
            techParamName = techParamState.getParamName();
            ConfigManager.logDebugStatement (techParamName);
            value = getValueValue (inPref);
            
	        // To affect the Opera menus, we must configure system paramaters
	        // through the FontColourSetup utility
            realValue = new String("-"+pointsToIniHeight(value));
            writeFontSetting(techParamName, realValue);
            addArgToArray(FCS_FONTSIZE, realValue);

			// font size of the page being viewed should be handled by
			// a user stylesheet, but Opera is not properly configuring
			// headings using this method, so instead we will
			// use the magnification factor for this.

			int intVal = Integer.parseInt(value);
			double pctVal = (double)intVal/12.0*100.0;
			realValue= String.valueOf(pctVal);
            writeMagnificationSetting(MAG_NAME, realValue);

            techParamState.setSetState (true);
            ConfigManager.logDebugStatement ("wrote " + MAG_NAME);
        }
        else
        {
            ConfigManager.logDebugStatement ("'" + inPref + "' not handled (FontColourSetup)");
        }
        
    }   // end handleFontSizePrefs()
    
    /**
     * Handle the "foreground colour" sub-tree from the ACCLIP preferences.
     * @param   inTechType  The type for technology from the ACCLIP.  This SetterLauncher
     *                      handles only "onscreenKeyboard".
     * @param   inPref      The font face preference from the ACCLIP document.
     * #see handlePref
     */
    private void handleFgColourPrefs (String inTechType, Element inPref)
    {
        String techParamName = null;
        String value = null;
        String realValue = null;
        ParameterState techParamState = null;
        
        String prefName = inPref.getTagName();
        ConfigManager.logDebugStatement (prefName);

        // do the equivalent of doWriteSetting(), but for Opera,
        // which requires a bunch of stuff:
        
        techParamState = findParameter (inTechType, prefName, true);
        if (techParamState != null)
        {
            techParamName = techParamState.getParamName();
            ConfigManager.logDebugStatement (techParamName);
            value = getValueValue (inPref);
            
			// we check the invert flag, because if it is set, the specified 
			// "foreground" colour must be applied to the background.
            if (theInvertFlag)
            {
				// To affect the Opera menus, we must configure system paramaters
				// through the FontColourSetup utility
				realValue = colorToFcsColor(value);
                addArgToArray(FCS_BG_COLOUR, realValue);

				// To affect the Opera toolbar buttons, we must configure Opera
				// through the Opera.ini file
                realValue = colorToIniColor(value);
                writeBGColourSetting(techParamName, realValue);

				// To affect the web page content, we must write the colour preference
				// to the style sheet used by Opera
                realValue = colorToCssColor(value);
                writeCssSetting(CSS_BKG_COLOR, realValue);
                writeCssSetting(CSS_STAR, CSS_BKG_COLOR, realValue);
            }
            else
            {
				// To affect the Opera menus, we must configure system paramaters
				// through the FontColourSetup utility
                realValue = colorToFcsColor(value);
                addArgToArray(FCS_FG_COLOUR, realValue);

				// To affect the Opera toolbar buttons, we must configure Opera
				// through the Opera.ini file
                realValue = colorToIniColor(value);
                writeFGColourSetting(techParamName, realValue);

				// To affect the web page content, we must write the colour preference
				// to the style sheet used by Opera
                realValue = colorToCssColor(value);
                writeCssSetting(CSS_FONT_COLOR, realValue);
				// Opera does not properly inherit styles applied to the body tag, so
				// we must specify heading and link font colours directly
                writeCssSetting(CSS_STAR, CSS_FONT_COLOR, realValue);
                writeCssSetting(CSS_HEADING1, CSS_FONT_COLOR, realValue);
                writeCssSetting(CSS_HEADING2, CSS_FONT_COLOR, realValue);
                writeCssSetting(CSS_HEADING3, CSS_FONT_COLOR, realValue);
                writeCssSetting(CSS_HEADING4, CSS_FONT_COLOR, realValue);
                writeCssSetting(CSS_HEADING5, CSS_FONT_COLOR, realValue);
                writeCssSetting(CSS_HEADING6, CSS_FONT_COLOR, realValue);
                writeCssSetting(CSS_LINK, CSS_FONT_COLOR, realValue);
                writeCssSetting(CSS_LINK, CSS_TEXT, CSS_UNDERLINE);
            }

            ConfigManager.logDebugStatement ("wrote " + techParamName);
        }
        else
        {
            ConfigManager.logDebugStatement ("'" + inPref + "' not handled (FontColourSetup)");
        }

    }   // end handleFgColourPrefs()
    
    /**
     * Handle the "background colour" sub-tree from the ACCLIP preferences.
     * @param   inTechType  The type for technology from the ACCLIP.  This SetterLauncher
     *                      handles only "onscreenKeyboard".
     * @param   inPref      The font face preference from the ACCLIP document.
     * #see handlePref
     */
    private void handleBgColourPrefs (String inTechType, Element inPref)
    {
        String techParamName = null;
        String value = null;
        String realValue = null;
        ParameterState techParamState = null;
        
        String prefName = inPref.getTagName();
        ConfigManager.logDebugStatement (prefName);

        // do the equivalent of doWriteSetting(), but for Opera,
        // which requires a bunch of stuff:
        
        techParamState = findParameter (inTechType, prefName, true);
        if (techParamState != null)
        {
            techParamName = techParamState.getParamName();
            ConfigManager.logDebugStatement (techParamName);
            value = getValueValue (inPref);
            
			// we check the invert flag, because if it is set, the specified 
			// "background" colour must be applied to the foreground.
            if (theInvertFlag)
            {
		        // To affect the Opera menus, we must configure system paramaters
		        // through the FontColourSetup utility
                realValue = colorToFcsColor(value);
                addArgToArray(FCS_FG_COLOUR, realValue);

				// To affect the Opera toolbar buttons, we must configure Opera
				// through the Opera.ini file
                realValue = colorToIniColor(value);
                writeFGColourSetting(techParamName, realValue);

 				// To affect the web page content, we must write the colour preference
				// to the style sheet used by Opera
				realValue = colorToCssColor(value);
                writeCssSetting(CSS_FONT_COLOR, realValue);
				// Opera does not properly inherit styles applied to the body tag, so
				// we must specify heading and link font colours directly
                writeCssSetting(CSS_STAR, CSS_FONT_COLOR, realValue);
                writeCssSetting(CSS_HEADING1, CSS_FONT_COLOR, realValue);
                writeCssSetting(CSS_HEADING2, CSS_FONT_COLOR, realValue);
                writeCssSetting(CSS_HEADING3, CSS_FONT_COLOR, realValue);
                writeCssSetting(CSS_HEADING4, CSS_FONT_COLOR, realValue);
                writeCssSetting(CSS_HEADING5, CSS_FONT_COLOR, realValue);
                writeCssSetting(CSS_HEADING6, CSS_FONT_COLOR, realValue);
                writeCssSetting(CSS_LINK, CSS_FONT_COLOR, realValue);
                writeCssSetting(CSS_LINK, CSS_TEXT, CSS_UNDERLINE);
            }
            else
            {
		        // To affect the Opera menus, we must configure system paramaters
		        // through the FontColourSetup utility
                realValue = colorToFcsColor(value);
                addArgToArray(FCS_BG_COLOUR, realValue);

				// To affect the Opera toolbar buttons, we must configure Opera
				// through the Opera.ini file
                realValue = colorToIniColor(value);
                writeBGColourSetting(techParamName, realValue);

				// To affect the web page content, we must write the colour preference
				// to the style sheet used by Opera
                realValue = colorToCssColor(value);
                writeCssSetting(CSS_BKG_COLOR, realValue);
                writeCssSetting(CSS_STAR, CSS_BKG_COLOR, realValue);
            }

            techParamState.setSetState (true);
            ConfigManager.logDebugStatement ("wrote " + techParamName);
        }
        else
        {
            ConfigManager.logDebugStatement ("'" + inPref + "' not handled (FontColourSetup)");
        }
        
    }   // end handleBgColourPrefs()
    
    /**
     * Handle the "invert color choice" sub-tree from the ACCLIP preferences.
     * @param   inTechType  The type for technology from the ACCLIP.
     * @param   inPref      The colour inversion preference from the ACCLIP document.
     * #see handlePref
     */
    private void handleInvertColoursPrefs (String inTechType, Element inPref)
    {
        String techParamName = null;
        String value = null;
        String realValue = null;
        ParameterState techParamState = null;
        
        String prefName = inPref.getTagName();
        ConfigManager.logDebugStatement (prefName);

		// make note of the preference.
		// The information will be used later when processing
		// the actual colour preferences
        techParamState = findParameter (inTechType, prefName, true);
        if (techParamState != null)
        {
            techParamName = techParamState.getParamName();
            ConfigManager.logDebugStatement (techParamName);
            value = getValueValue (inPref);
  
            if (value.equals("true"))
                theInvertFlag = true;
            else
                theInvertFlag = false;
                          
            techParamState.setSetState (true);
            ConfigManager.logDebugStatement ("wrote " + techParamName);
        }
        else
        {
            ConfigManager.logDebugStatement ("'" + inPref + "' not handled (FontColourSetup)");
        }

    }   // end handleInvertColoursPrefs()
    
    /**
     * Handle the "hilight colour" sub-tree from the ACCLIP preferences.
     * @param   inTechType  The type for technology from the ACCLIP.
     * @param   inPref      The highlight colour preference from the ACCLIP document.
     * #see handlePref
     */
    private void handleHilightColourPrefs (String inTechType, Element inPref)
    {
        String techParamName = null;
        String value = null;
        String realValue = null;
        ParameterState techParamState = null;
        
        String prefName = inPref.getTagName();
        ConfigManager.logDebugStatement (prefName);

        // do the equivalent of doWriteSetting(), but for Opera,
        // which requires a bunch of stuff:
        
        techParamState = findParameter (inTechType, prefName, true);
        if (techParamState != null)
        {
            techParamName = techParamState.getParamName();
            ConfigManager.logDebugStatement (techParamName);
            value = getValueValue (inPref);
            
	        // To affect the Opera menus, we must configure system paramaters
	        // through the FontColourSetup utility
            realValue = colorToFcsColor(value);
            addArgToArray(FCS_HILIGHT_COLOUR, realValue);

            // note that Opera itself cannot do any highlighting, so
            // this setting doesn't need to be written to the Opera ini
            // or css files
            
            techParamState.setSetState (true);
            ConfigManager.logDebugStatement ("wrote " + techParamName);
        }
        else
        {
            ConfigManager.logDebugStatement ("'" + inPref + "' not handled (FontColourSetup)");
        }

    }   // end handleHilightColourPrefs()
    
    /**
     * Handle the "cursor colour" sub-tree from the ACCLIP preferences.
     * @param   inTechType  The type for technology from the ACCLIP.  This SetterLauncher
     *                      handles only "onscreenKeyboard".
     * @param   inPref      The font face preference from the ACCLIP document.
     * #see handlePref
     */
    private void handleCursorColourPrefs (String inTechType, Element inPref)
    {
        String techParamName = null;
        String value = null;
        String realValue = null;
        ParameterState techParamState = null;
        
        String prefName = inPref.getTagName();
        ConfigManager.logDebugStatement (prefName);

        // do the equivalent of doWriteSetting(), but for Opera,
        // which requires a bunch of stuff:
        
        techParamState = findParameter (inTechType, prefName, true);
        if (techParamState != null)
        {
            techParamName = techParamState.getParamName();
            ConfigManager.logDebugStatement (techParamName);
            value = getValueValue (inPref);
            
	        // To affect the cursor colour, we must configure system paramaters
	        // through the FontColourSetup utility
            realValue = colorToCursorColor(value);
            addArgToArray(FCS_CURSORCOLOUR, realValue);

            techParamState.setSetState (true);
            ConfigManager.logDebugStatement ("wrote " + techParamName);
        }
        else
        {
            ConfigManager.logDebugStatement ("'" + inPref + "' not handled (FontColourSetup)");
        }
    }   // end handleCursorColourPrefs()
    
    /**
     * Handle the "cursor size" sub-tree from the ACCLIP preferences.
     * @param   inTechType  The type for technology from the ACCLIP.  This SetterLauncher
     *                      handles only "onscreenKeyboard".
     * @param   inPref      The font face preference from the ACCLIP document.
     * #see handlePref
     */
    private void handleCursorSizePrefs (String inTechType, Element inPref)
    {
        String techParamName = null;
        String value = null;
        String realValue = null;
        ParameterState techParamState = null;
        
        String prefName = inPref.getTagName();
        ConfigManager.logDebugStatement (prefName);

        // do the equivalent of doWriteSetting(), but for Opera,
        // which requires a bunch of stuff:
        
        techParamState = findParameter (inTechType, prefName, true);
        if (techParamState != null)
        {
            techParamName = techParamState.getParamName();
            ConfigManager.logDebugStatement (techParamName);
            value = getValueValue (inPref);
            
	        // To affect the cursor size, we must configure system paramaters
	        // through the FontColourSetup utility
            realValue = sizeToCursorSize(value);
            addArgToArray(FCS_CURSORSIZE, realValue);

            techParamState.setSetState (true);
            ConfigManager.logDebugStatement ("wrote " + techParamName);
        }
        else
        {
            ConfigManager.logDebugStatement ("'" + inPref + "' not handled (FontColourSetup)");
        }
    }   // end handleCursorSizePrefs()
    
    /**
     * Handle the "cursor trails" sub-tree from the ACCLIP preferences.
     * @param   inTechType  The type for technology from the ACCLIP.  This SetterLauncher
     *                      handles only "onscreenKeyboard".
     * @param   inPref      The font face preference from the ACCLIP document.
     * #see handlePref
     */
    private void handleCursorTrailsPrefs (String inTechType, Element inPref)
    {
        String techParamName = null;
        String value = null;
        String realValue = null;
        ParameterState techParamState = null;
        
        String prefName = inPref.getTagName();
        ConfigManager.logDebugStatement (prefName);

        // do the equivalent of doWriteSetting(), but for Opera,
        // which requires a bunch of stuff:
        
        techParamState = findParameter (inTechType, prefName, true);
        if (techParamState != null)
        {
            techParamName = techParamState.getParamName();
            ConfigManager.logDebugStatement (techParamName);
            value = getValueValue (inPref);
            
	        // To affect the cursor size, we must configure system paramaters
	        // through the FontColourSetup utility
            realValue = Float.toString((int)linearCalcTechVal (value, CURSOR_TRAILS_MAX, (float)0.0));
            addArgToArray(FCS_CURSORTRAILS, realValue);

            techParamState.setSetState (true);
            ConfigManager.logDebugStatement ("wrote " + techParamName);
        }
        else
        {
            ConfigManager.logDebugStatement ("'" + inPref + "' not handled (FontColourSetup)");
        }
    }   // end handleCursorTrailsPrefs()
    
    /**
     * Handle the "magnification" sub-tree from the ACCLIP preferences.
     * @param   inTechType  The type for technology from the ACCLIP.
     * @param   inPref      The magnification preference from the ACCLIP document.
     * #see handlePref
     */
    private void handleMagnificationPrefs (String inTechType, Element inPref)
    {
        String techParamName = null;
        String value = null;
        String realValue = null;
        ParameterState techParamState = null;
        
        String prefName = inPref.getTagName();
        ConfigManager.logDebugStatement (prefName);

        // do the equivalent of doWriteSetting(), but for Opera,
        // which requires a bunch of stuff:
        
        techParamState = findParameter (inTechType, prefName, true);
        if (techParamState != null)
        {
            techParamName = techParamState.getParamName();
            ConfigManager.logDebugStatement (techParamName);
            value = getValueValue (inPref);
            
            realValue = scaleToPercent(value);
            writeMagnificationSetting(techParamName, realValue);

            techParamState.setSetState (true);
            ConfigManager.logDebugStatement ("wrote " + techParamName);
        }
        else
        {
            ConfigManager.logDebugStatement ("'" + inPref + "' not handled (FontColourSetup)");
        }

    }   // end handleMagnificationPrefs()
    
    /**
     * Write a settings to Opera's .ini file. Note that in many cases, this method
     * is not used, since a setting is often written to two different keys, and to
     * the css file.
     * @param  inProperty   Name of the Opera setting.
     * @param  inValue      Value of that setting.
     */
    protected void doWriteSetting (String inProperty, String inValue)
    {
        writeSetting (inProperty, inValue);
    }


    /**
     * Write the given setting (property/value pair), where the value is a String.
     * For Opera settings, this value must be written out twice, under different
     * section headings.
     * <p> Note that this assumes the output stream is valid (non-null).
     *
     * @param  inProperty   String representing the parameter to write.
     * @param  inValue      String representing the value of <code>inProperty</code>.
     */
    protected void writeMagnificationSetting (String inProperty, String inValue)
    {
        if ((inProperty != null) && (inValue != null))
        {
            // the user heading must be output to tell opera to use the
            // subsequent user settings (as opposed to system settings)
            theLocalOutput.println(MAG_USER_HEADING);
            super.writeSetting(inProperty, inValue);
        }

    }  // writeMagnificationtSetting (String, String).

    /**
     * Write the given setting (property/value pair), where the value is a String.
     * For Opera settings, this value must be written out twice, under different
     * section headings.
     * <p> Note that this assumes the output stream is valid (non-null).
     *
     * @param  inProperty   String representing the parameter to write.
     * @param  inValue      String representing the value of <code>inProperty</code>.
     */
    protected void writeFontSetting (String inProperty, String inValue)
    {
        if ((inProperty != null) && (inValue != null))
        {
            // the user heading must be output to tell opera to use the
            // subsequent user settings (as opposed to system settings)
            theLocalOutput.println(FONT_USER_HEADING);
            
            theLocalOutput.println(FONT_UI_HEADING);
            super.writeSetting(inProperty, inValue);
            theLocalOutput.println(FONT_UIDIS_HEADING);
            super.writeSetting(inProperty, inValue);
        }

    }  // writeFontSetting (String, String).

    /**
     * Write the given setting (property/value pair), where the value is a String.
     * For Opera settings, this value must be written out twice, under different
     * section headings.
     * <p> Note that this assumes the output stream is valid (non-null).
     *
     * @param  inProperty   String representing the parameter to write.
     * @param  inValue      String representing the value of <code>inProperty</code>.
     */
    protected void writeFGColourSetting (String inProperty, String inValue)
    {
        if ((inProperty != null) && (inValue != null))
        {
            // the user heading must be output to tell opera to use the
            // subsequent user settings (as opposed to system settings)
            theLocalOutput.println(FONT_USER_HEADING);
            
            theLocalOutput.print(COLOR_UI_HEADING);
            theLocalOutput.println(inValue);
            theLocalOutput.print(COLOR_UIDIS_HEADING);
            theLocalOutput.println(inValue);
        }

    }  // writeFGColourSetting (String, String).

    /**
     * Write the given setting (property/value pair), where the value is a String.
     * For Opera settings, this value must be written out twice, under different
     * section headings.
     * <p> Note that this assumes the output stream is valid (non-null).
     *
     * @param  inProperty   String representing the parameter to write.
     * @param  inValue      String representing the value of <code>inProperty</code>.
     */
    protected void writeBGColourSetting (String inProperty, String inValue)
    {
        if ((inProperty != null) && (inValue != null))
        {
            // the user heading must be output to tell opera to use the
            // subsequent user settings (as opposed to system settings)
            theLocalOutput.println(FONT_USER_HEADING);
            
            theLocalOutput.print(COLOR_UIBG_HEADING);
            theLocalOutput.println(inValue);
            theLocalOutput.print(COLOR_UIBUTTONBG_HEADING);
            theLocalOutput.println(inValue);
        }

    }  // writeBGColourSetting (String, String).

     /**
     * Write the given setting (property/value pair), where the value is a String.  Note that
     * this assumes the output stream is valid (non-null).
     *
     * @param  inProperty   String representing the parameter to write.
     * @param  inValue      String representing the value of <code>inProperty</code>.
     */
    protected void writeCssSetting (String inProperty, String inValue)
    {
        if ((inProperty != null) && (inValue != null))
        {
            theLocalCssOutput.print (CSS_BODY_OPENING);
            theLocalCssOutput.print (inProperty);
            theLocalCssOutput.print (inValue);
            theLocalCssOutput.print (CSS_SEP);
            theLocalCssOutput.println (CSS_CLOSING);
        }

    }  // end writeSetting (String, String).

     /**
     * Write the given setting (property/value pair), where the value is a String.  Note that
     * this assumes the output stream is valid (non-null).
     *
     * @param  inElement   	String representing the element to style.
     * @param  inProperty   String representing the parameter to write.
     * @param  inValue      String representing the value of <code>inProperty</code>.
     */
    protected void writeCssSetting (String inElement, String inProperty, String inValue)
    {
        if ((inProperty != null) && (inValue != null))
        {
            theLocalCssOutput.print (inElement);
            theLocalCssOutput.print (CSS_OPENING);
            theLocalCssOutput.print (inProperty);
            theLocalCssOutput.print (inValue);
            theLocalCssOutput.print (CSS_SEP);
            theLocalCssOutput.println (CSS_CLOSING);
        }

    }  // end writeSetting (String, String).

     /**
     * Write the given setting (property/value pair) to the Ini output file with
     * the given section heading.  Note that
     * this assumes the output stream is valid (non-null).
     *
     * @param  inIniHeading String representing the section heading to write out.
     * @param  inProperty   String representing the parameter to write.
     * @param  inValue      String representing the value of <code>inProperty</code>.
     */
	protected void writeIniSetting (String inIniHeading, String inProperty, String inValue) {
        if ((inProperty != null) && (inValue != null))
        {
            theLocalOutput.print (inIniHeading);
			writeSetting(inProperty, inValue);
        }
	} // end writeIniSetting (String, String, String).
	
    /**
     * Copy the contents of the default ini file into the output ini file.
     */
    public void writeDefaultSettings()
    {
        // Fill the <code>.ini</code> file with the contents of the default file
        //
        String dirSep = System.getProperty ("file.separator");
        String defIniFile = getControlHub().get3rdPartyProperties (getAppID()).getString (OperaSettings.DEFAULTS_INI);
        File defaultIniFile = new File (getControlHub().getHomeDirectory() + dirSep + defIniFile);

        try
        {
            BufferedReader aReader = new BufferedReader (new FileReader (defaultIniFile));
            
            // write out the defaults found in the defaults file
            while (true)
            {
                String aLine = aReader.readLine();
                if (aLine != null)
                    theLocalOutput.println(aLine);
                else
                    break;
            }
            
        }
        catch (FileNotFoundException fnf)
        {
            ConfigManager.logException(fnf);
        }
        catch (IOException ioe)
        {
            ConfigManager.logException(ioe);
        }
    }   // end writeDefaultSettings()
    
   /**
     * This method is called to launch the technology.  <code>doSettings()</code> should
     * be called first to configure the technology before launching it.
     * @see #doSettings
     */
    public void doLaunch()
    {
        // Launch Opera.  Start with the location.
        //
        try
        {
            String command = getControlHub().get3rdPartyExecutable (getAppID());
            ConfigManager.logDebugStatement ("'" + command.toString() + "'");
            setProcess (Runtime.getRuntime().exec (command.toString()));
        }
        
        catch (IOException ioe)
        {
            ConfigManager.logException(ioe);
        }
    }   // end doLaunch()

    /**
     * After killing Opera, reset the .ini file to default, and reset the system settings.
     */
    public void kill()
    {
        super.kill();
    
        // reset Opera to default
        resetOperaIni();

        // reset the system appearance to default
        resetSystemSettings();  
    
    }   // end kill().

    /**
     * Write the backup copy of the ini file out to the Opera ini file.
     * This should reset to Opera to the backed up configuration.
     */
    protected void resetOperaIni()
    {
        try
        {
            // Build the command... first the command itself.
            //
            String dirSep = System.getProperty ("file.separator");
            StringBuffer command = new StringBuffer ("cmd.exe /C copy \"");
	        String backupIniFile = getControlHub().get3rdPartyProperties (getAppID()).getString (OperaSettings.BACKUP_INI);
            command.append(getControlHub().getHomeDirectory()).append(dirSep).append(backupIniFile);
			command.append("\" \"");
            command.append(getControlHub().get3rdPartyIni (getAppID()));
            command.append("\"");
            
            ConfigManager.logDebugStatement ("Command:  '" + command.toString() + "'");
            Process bkpProcess = Runtime.getRuntime().exec (command.toString());
            handleProcessIStreams (bkpProcess, true);
            bkpProcess.waitFor();
            ConfigManager.logDebugStatement ("Command completed.");
        }
        catch(IOException ioe)
        {
            ConfigManager.logException(ioe);
        }
        catch (InterruptedException ie)
        {
            ConfigManager.logException(ie);
        }
   }    // end resetOperaIni()
    
    /**
     * Run the utility which sets the system font and colours.
     */
    void setSystemSettings()
    {
        try
        {
            // Build the command... first the command itself.
            //
            String dirSep = System.getProperty ("file.separator");
            StringBuffer command = new StringBuffer (getControlHub().getHomeDirectory());
            String fontExe = getControlHub().get3rdPartyProperties (getAppID()).getString (OperaSettings.FONT_EXE);
            command.append (dirSep).append (fontExe);
    
            // Next, the parameters.
            //
            String[] argsArray = getArgsArray();
            for (int i=0; i<argsArray.length; i++)
                command.append(" " + argsArray[i]);
    
            ConfigManager.logDebugStatement ("Command:  '" + command.toString() + "'");
            Process winConfigProcess = Runtime.getRuntime().exec (command.toString());
            handleProcessIStreams (winConfigProcess, true);
            winConfigProcess.waitFor();
            ConfigManager.logDebugStatement ("Command completed.");
        }
        catch(IOException ioe)
        {
            ConfigManager.logException(ioe);
        }
        catch (InterruptedException ie)
        {
            ConfigManager.logException(ie);
        }
    }   // end setSystemSettings()
    
    /**
     * Run the utility which sets the system font and colours, but with no parameters.
     * This should reset to the system to a default setup.
     */
    void resetSystemSettings()
    {
        try
        {
            // Build the command... first the command itself.
            //
            String dirSep = System.getProperty ("file.separator");
            StringBuffer command = new StringBuffer (getControlHub().getHomeDirectory());
            String fontExe = getControlHub().get3rdPartyProperties (getAppID()).getString (OperaSettings.FONT_EXE);
            command.append (dirSep).append (fontExe);
    
            // no parameters - this will reset to system defaults

            ConfigManager.logDebugStatement ("Command:  '" + command.toString() + "'");
            Process winConfigProcess = Runtime.getRuntime().exec (command.toString());
            handleProcessIStreams (winConfigProcess, true);
            winConfigProcess.waitFor();
            ConfigManager.logDebugStatement ("Command completed.");
        }
        catch(IOException ioe)
        {
            ConfigManager.logException(ioe);
        }
        catch (InterruptedException ie)
        {
            ConfigManager.logException(ie);
        }
    }   // end resetSystemSettings()
    
    /**
     * Convert a string representing an ACCLIP colour to a format suitable for CSS
     * @param   inACCLIPColor   an ACCLIP-compliant colour value
     * @return                  a CSS-compatible colour value
     */
    private String colorToCssColor(String inACCLIPColor)
    {
        String result = new String("#"+inACCLIPColor.substring(0,6));
        return result;
    }   // end colorToCssColor()
    
    /**
     * Convert a string representing an ACCLIP colour to a format suitable for the Opera
     * .ini file, which consist of three key-value pairs of the form "RED=255".
     * @param   inACCLIPColor   an ACCLIP-compliant colour value, "RRGGBBAA"
     * @return                  a colour value suitable for the Opera .ini file. This String
     *							is actually in the form of three property/value pairs,
     *							"Red=rrr\nGreen=ggg\nBlue=bbb"
     */
    private String colorToIniColor(String inACCLIPColor)
    {
        String strColor = new String("0x"+inACCLIPColor.substring(0,6));
        Color c = Color.decode(strColor);
        int red = c.getRed();
        int green = c.getGreen();
        int blue = c.getBlue();
        String result = new String(COLOR_KEY_RED+red+COLOR_KEY_GREEN+green+COLOR_KEY_BLUE+blue);
        return result;
    }   // end colorToIniColor()
    
    /**
     * Convert a string representing an ACCLIP colour to a format suitable for use
     * as a parameter the the FontColourSetup utility, which is an integer representing
     * an number of the form 0x00BBGGRR.
     * @param   inACCLIPColor   an ACCLIP-compliant colour value, "RRGGBBAA"
     * @return                  a FontColourSetup-compatible colour value
     */
    private String colorToFcsColor(String inACCLIPColor)
    {
        String red = inACCLIPColor.substring(0,2);
        String green = inACCLIPColor.substring(2,4);
        String blue = inACCLIPColor.substring(4,6);
        String colourStr = new String(blue+green+red);
        int colourInt = Integer.parseInt(colourStr, 16);
        String result = String.valueOf(colourInt);
        return result;
    }   // end colorToFcsColor()
    
    /**
     * Convert a string representing an ACCLIP colour to a format suitable for
     * setting the system cursor colour. In this version of the plug-in, only black
     * or white cursors are available, so this method chooses one of these colours based
     * on the brightness of the input colour.
     * @param   inACCLIPColor   an ACCLIP-compliant colour value, "RRGGBBAA"
     * @return                  A String representing either black or white
     */
    private String colorToCursorColor(String inACCLIPColor)
    {
        String result = CURSOR_COLOR_WHITE;
        
        String strColor = new String("0x"+inACCLIPColor.substring(0,6));
        Color c = Color.decode(strColor);
        
        // use the brightness to choose either black or white
        // (which is all that our Windows utilities provide
        //
/*
        // convert the input colour into HSB format
        String strColor = new String("0x"+inACCLIPColor.substring(2));
        Color c = Color.decode(strColor);
        float hsbvalues[] = {0, 0, 0};
        Color.RGBtoHSB(c.getRed(), c.getGreen(), c.getBlue(), hsbvalues);
//        float brightness = hsbvalues[2];
*/            
        
        float brightness = (c.getRed()*299 + c.getGreen()*587 + c.getBlue()*114)/1000;
        if (brightness > 255/2)    // brightness is a number from 0 to 100
            result = CURSOR_COLOR_WHITE;
        else
            result = CURSOR_COLOR_BLACK;
        return result;
    }   // end colorToCursorColor()
    

    /**
     * Convert a string representing an ACCLIP cursor size (a float between 0.0 and
     * 1.0) into a setting suitable for setting the system cursor size.
     * @param   inACCLIPCursorSize  A string representation of a float between 0.0 and
     *                              1.0 indicating a desired cursor size
     * @return                  A String one of three cursor sizes, suitable for use
     *                          with the FontColourSetup utility
     */
    private String sizeToCursorSize(String inACCLIPCursorSize)
    {
        String result = CURSOR_SIZE_LARGE;
        
        float size = Float.parseFloat(inACCLIPCursorSize);
        
        if (size < 0.33)
            result = CURSOR_SIZE_STANDARD;
        else if (size > 0.67)
            result = CURSOR_SIZE_XLARGE;        

        return result;
    }   // end sizeToCursorSize()
    
    /**
     *
     * @param   inPointsString  a String point value
     * @return      an integer representing the desired font size suitable for
     *              use with the FontColourSetup utility
     */
    private int pointsToIniHeight(String inPointsString)
    {
        int points = Integer.parseInt(inPointsString);
        double doublePoints = (double)points;
        double height = doublePoints * 96.0 / 72.0;
        int intHeight = (int)height;
        return (int)height;
    }   // end pointsToIniHeight()


    /**
     *
     * @param   inScale  a String scale factor, representing an integer from 1 to 20
     * @return      an integer representing equivalent percentage, where a scale of
     *              1 corresponds to 100%
     */
    private String scaleToPercent(String inScale)
    {
        int scale = Integer.parseInt(inScale);
        int percent = scale * 100;
        String percentString = String.valueOf(percent);
        return percentString;
    }   // end scaleToPercent()



    /**
     * Nested class mapping ACCLIP generic face values to Opera-specific values for the .ini file.
     */
    private static class GenericFaceMapIni extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<pref value>,<Opera value>})
         */
        final Object[][] contents = {
            { "serif", GENERIC_FACE_SERIF },
            { "sansSerif", GENERIC_FACE_SANSSERIF },
            { "monospaced", GENERIC_FACE_MONOSPACE },
            { "cursive", GENERIC_FACE_CURSIVE },
            { "fantasy", GENERIC_FACE_FANTASY }
        };
    }   // end nested class GenericFaceMapIni

    /**
     * Nested class mapping ACCLIP generic face values to Opera-specific values for the .css file.
     */
    private static class GenericFaceMapCss extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<pref value>,<CSS value>})
         */
        final Object[][] contents = {
            { "serif", CSS_FONT_FAMILY_S },
            { "sansSerif", CSS_FONT_FAMILY_SS },
            { "monospaced", CSS_FONT_FAMILY_M },
            { "cursive", CSS_FONT_FAMILY_C },
            { "fantasy", CSS_FONT_FAMILY_F },
        };
    }   // end nested class GenericFaceMapCss

    /**
     * Nested class mapping ACCLIP generic face values to FontColourSetup parameter values.
     */
    private static class GenericFaceMapFCS extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<pref value>,<FontColourSetup value>})
         */
        final Object[][] contents = {
            { "serif", GENERIC_FACE_FCS_SERIF },
            { "sansSerif", GENERIC_FACE_FCS_SANSSERIF },
            { "monospaced", GENERIC_FACE_FCS_MONOSPACE },
            { "cursive", "cursive"/*GENERIC_FACE_CURSIVE*/ },
            { "fantasy", GENERIC_FACE_FANTASY }
        };
    }   // end nested class GenericFaceMapFCS

    /**
     * Nested class for mapping prefs values to our Ereader values maps.
     */
    private static class ValueMapChooser extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<param for .ini>,<our map>})
         */
        final Object[][] contents = {
            { OperaSettings.GENERIC_FACE_NAME_INI, new GenericFaceMapIni() },
            { OperaSettings.GENERIC_FACE_NAME_CSS, new GenericFaceMapCss() },
            { OperaSettings.GENERIC_FACE_NAME_FCS, new GenericFaceMapFCS() },


        };

    }  // end nested class ValueMapChooser.

    /**
     * Nested class for the screen enhancement settings of Opera.
     * The settings are stored as a table of ParameterState objects.
     */
    private static class OperaScreenEnhancementSettings extends SettingsBundle
    {
        /**
         * Record the fact that these settings are of type "onscreenKeyboard".
         */
        public OperaScreenEnhancementSettings()
        {
            super ("screenEnhance");
        
        }   // end VDKonscreenKeyboardSettings().
        
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table.  The left side is an element name from the ACCLIP.  The right side
         * is the name of the Opera setting, whether the Opera requires that setting, and its default
         * value (as specified by Opera).
         */
        final Object[][] contents = {
        
            { "genericFace", new ParameterMultiState ("genericFace", true, GENERIC_FACE_DEFAULT,
                new ParameterState (GENERIC_FACE_NAME_INI, true, GENERIC_FACE_DEFAULT),
                new ParameterState (GENERIC_FACE_NAME_CSS, true, GENERIC_FACE_CSS_DEFAULT),
                new ParameterState (GENERIC_FACE_NAME_FCS, true, GENERIC_FACE_FCS_DEFAULT) )
             },
            
            { "fontSize", new ParameterState (FONT_SIZE_NAME_INI, true, new Integer (FONT_SIZE_DEFAULT)) },

            { "foregroundColor", new ParameterState (FOREGROUND_COLOR_NAME, true, FOREGROUND_COLOR_DEFAULT) },
            { "backgroundColor", new ParameterState (BACKGROUND_COLOR_NAME, true, BACKGROUND_COLOR_DEFAULT) },
            { "invertedColorChoice", new ParameterState (INVERT_COLORS_NAME, true, new Integer (INVERT_COLORS_DEFAULT)) },
            { "highlightColor", new ParameterState (HIGHLIGHT_COLOR_NAME, true, HIGHLIGHT_COLOR_DEFAULT) },

            { "cursorColor", new ParameterState (FCS_CURSORCOLOUR, true, CURSOR_COLOR_WHITE) },
            { "cursorSize", new ParameterState (FCS_CURSORSIZE, true, CURSOR_SIZE_STANDARD) },
            { "cursorTrails", new ParameterState (FCS_CURSORTRAILS, true, CURSOR_TRAILS_DEFAULT) },

            { "magnification", new ParameterState (MAG_NAME, true, new Integer (MAG_DEFAULT)) },
        };

    }  // end nested class VDKonscreenKeyboardSettings.

    /**
     * Nested class defining the argument index map for passing arguments to FontColourSetup.
     */
    private static class FCSArgsIndexMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<pref value>,<Opera value>})
         */
        final Object[][] contents = {
            { FCS_FONTSIZE, new Integer(0) },
            { GENERIC_FACE_NAME_FCS, new Integer(1) },
            { FCS_FG_COLOUR, new Integer(2) },
            { FCS_BG_COLOUR, new Integer(3) },
            { FCS_HILIGHT_COLOUR, new Integer(4) },
            { FCS_CURSORCOLOUR, new Integer(5) },
            { FCS_CURSORSIZE, new Integer(6) },
            { FCS_CURSORTRAILS, new Integer(7) },
        };
    }   // end nested class FCSArgsIndexMap

}  // end class OperaSettings.


