/*[
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 * File:            EReaderSettings.java
 *
 * Synoposis:       package ca.utoronto.atrc.web4all.thirdparty;
 * 
]*/

package ca.utoronto.atrc.web4all.thirdparty;

import java.io.*;
import java.util.*;

import org.w3c.dom.*;

import ca.utoronto.atrc.web4all.*;
import ca.utoronto.atrc.web4all.configuration.*;

/**
 * This settings object is for CAST E-Reader -- for learning disability, using TTS and
 * highlighting.
 *
 * @version $Id: EReaderSettings.java,v 1.8 2006/03/28 22:07:54 clown Exp $
 * @author Anastasia Cheetham
 * @author Joseph Scheuhammer.
 */
    
public class EReaderSettings extends AbstractSetterLauncher
{
    /**
     * Speech rate ACCLIP element name.
     */
    private final static String SPEECH_RATE_NAME     = "speechRate";
    
    /**
     * Speech rate default value.
     */
    private final static String SPEECH_RATE_DEFAULT     = "160";
    
    /**
     * Pitch ACCLIP element name.
     */
    private final static String PITCH_NAME     = "pitch";
    
    /**
     * Speech rate default value.
     */
    private final static String PITCH_DEFAULT     = "145";
    
    /**
     * Volume ACCLIP element name.
     */
    private final static String VOLUME_NAME     = "volume";
    
    /**
     * Speech rate default value.
     */
    private final static String VOLUME_DEFAULT     = "50";
    
    /**
     * Highlight ACCLIP element name.
     */
    private final static String HIGHLIGHT_NAME     = "highlight";
    
    /**
     * Highlight default value.
     */
    private final static String HIGHLIGHT_DEFAULT     = "word";
    
    /**
     * Speak alt text ACCLIP element name.
     */
    private final static String SPEAK_ALT_TEXT_NAME     = "speakAltText";
    
    /**
     * Speak alt text default value.
     */
    private final static String SPEAK_ALT_TEXT_DEFAULT     = "true";
    
    /**
     * "Speak when tabbing" ACCLIP element name.
     */
    private final static String SPEAK_WHEN_TABBING_NAME     = "speakWhenTabbing";
    
    /**
     * "Speak when tabbing" default value.
     */
    private final static String SPEAK_WHEN_TABBING_DEFAULT     = "true";
    
    /**
     * Reading unit ACCLIP element name.
     */
//    private final static String READING_UNIT_NAME     = "readingUnit";
    
    /**
     * Reading unit default value.
     */
//    private final static String READING_UNIT_DEFAULT     = "??";
    
    /**
     * Higlight parameter (either words or sentences) eReader registry key name.
     */
    private final static String  HILIGHT                = "BrowsWordHi";
    
    /**
     * Alt text parameter eReader registry key name.
     */
    private final static String  ALT_TEXT               = "GetAltText";
    
    /**
     * Speak links eReader registry key name.
     */
    private final static String  SPEAK_LINKS            = "SpeakLinks";
    
    /**
     * Voice pitch eReader registry key name.
     */
    private final static String  VOICE_PITCH            = "Pitch";
    
    /**
     * Voice speed eReader registry key name.
     */
    private final static String  VOICE_RATE             = "Speed";
    private final static int  VOICE_RATE_MIN            = 30;
    private final static int  VOICE_RATE_MAX            = 510;
    
    /**
     * Voice volume eReader registry key name.
     */
    private final static String  VOICE_VOLUME           = "Volume";
    
    /**
     * Reading unit eReader registry key name.
     */
//    private final static String  READING_UNIT           = "????";
    

    /**
     * The slope of the linear transform for a pitch less than an ACCLIP value of
     * or equal to 5.0.
     */
    private final static float PITCH_SLOPEen     =  170.0f;
    private final static float PITCH_SLOPEfr     =  382.0f;
    
    /**
     * The intercept of the linear transform for a pitch less than an ACCLIP value of
     * or equal to 5.0.
     */
    private final static float PITCH_CEPTen      =  56.0f;
    private final static float PITCH_CEPTfr      =  40.0f;
    
    /**
     * The slope of the linear transform for volume.
     */
    private final static float VOLUME_SLOPE     =  99.0f;
    
    /**
     * The intercept of the linear transform for volume.
     */
    private final static float VOLUME_CEPT      =  1.0f;
    
    /**
     * The eReader-specific local properties.
     */
    private ResourceBundle theLocalProperties;

    /**
     * Local copy of the file to write.
     */
    private PrintWriter theLocalOutput;

    /**
     * The Registry Console executable path key.
     */
    private final static String REGISTRY_EXE    = "registry.exec";
    
    /**
     * The Registry Console executable path.
     */
    private String theRegistryConsoleExec = null;
    
    /**
     * The key to the integer registry key property
     */
    private final static String REGISTRY_HEADER        = "registrykey.main";

    /**
     * The key to the string registry key property
     */
    private final static String REGISTRY_HEADER_VOICE     = "registrykey.special";

    /**
     * The ACCLIP technologies and their preferences that this eReader SetterLauncher handles.
     */
    private final static SettingsBundle PARAMS_HANDLED[] = {
        new EReaderSettings.ERSettings()
    };
    
    /**
     * The value map chooser.
     */
    private final static EReaderSettings.ValueMapChooser VALUE_MAP_CHOOSER = new EReaderSettings.ValueMapChooser();

    /**
     * Constructor -- no argument; calls super().
     */
    public EReaderSettings()
    {
        super();

    }  // end EReaderSettings().

    /**
     * Class specific initialization -- override as necessary.
     */
    protected void init()
    {
        // Initialize the parameters.  Note that there are no default settings.
        //
        setUpParameters (EReaderSettings.PARAMS_HANDLED, EReaderSettings.VALUE_MAP_CHOOSER);
        theRegistryConsoleExec = null;
        createReadProcessIStreams();
           
    }   // end init().

    /**
     * Create the ".ini" from the given DOM sub-tree.
     *
     * @param   inAccLipInfoPackages    A Vector of AccLipInfoPackage objects that contain
     *                                  preferences for different types of technologies.  This
     *                                  handles only the "textReaderHightlight" type.
     * @param   inControlHub            The ControlHub that contains information about the application
     * @return                      <code>true</code> indicating that this intends to launch a browser.
     */
    public boolean doSettings (Vector inAccLipInfoPackages, ControlHub inControlHub)
    {
        // Get the name of the ACCLIP Element that is for text reader/highlighter.  This is the only
        // technology type that "eReader" handles.
        //
        String textReadingHighlightElName = inControlHub.getPrefElementName (Web4AllConstants.TEXT_READING_HIGHLITE);
        
        // Loop thru the ACCLIP info looking for <textReadingHighlightElName>.
        //
        for (int i = 0; i < inAccLipInfoPackages.size(); i++)
        {
            // Skip any AccLipInfoPackage that is not for the "text reader/highlighter" type.
            //
            AccLipInfoPackage anAccLipInfo = (AccLipInfoPackage) inAccLipInfoPackages.elementAt (i);
            if (anAccLipInfo.getAppType().equals (textReadingHighlightElName) == false)
                continue;
        
            // Record the parent Element in the ACCLIP that contains both the generic settings and
            // specific settings.  Record, also, the ControlHub instance.  Get the application name
            // from <anAccLipInfo>'s specific preferences container. Finally create the output file.
            //
            Element prefsParentElement = (Element) anAccLipInfo.getGenericPrefs().getParentNode();
            setAppSettings (prefsParentElement);
            setControlHub (inControlHub);
            setAppID (anAccLipInfo.getSpecificPrefs());
            theLocalProperties = getControlHub().get3rdPartyProperties (getAppID());
			theLocalOutput = createOutput (ConfigManager.getHomeDir(), getControlHub().get3rdPartyIni (getAppID()), false);

            // Start processing the preferences.
            //
            if (prefsParentElement != null)
            {
                // Clear the <theParamsWritten> array.
                //
                clearParamsWritten (textReadingHighlightElName);

                // Loop thru the generic preferences within <prefsParentElement>.
                //
                loopThruGenerics (textReadingHighlightElName, anAccLipInfo.getGenericPrefs());


                // Now, go through the <EReaderSettings.PARAMS_WRITTEN>, and for each one that is not written,
                // write its default.
                //
                handleUnwrittenParams (textReadingHighlightElName);


                // Close the output files.
                //
                closeOutput();

                // call the process that sets writes the values to the registry.
                writeToRegistry();
            }

        }
        return true;        // we do launch a browser.

    }  // end doSettings().

    /**
     * Map the value retrieved from the preferences document to the actual value to output.
     * This is an override since many of the eReader preferences are calculated based on the
     * ACCLIP preference value, while some still remain simple lookups.
     * @param  inParam      The parameter of interest.  This is expressed using the technology's
     *                      vocabulary.
     * @param  inValue      The value from the ACCLIP as a String.
     * @return              The value to output, as a String.
     */
    protected String mapValue (String inParam, String inValue)
    {
        String result = null;       // return value.
        
        // Speech rate requires no transformation.
        //        
        if ( inParam.equals (EReaderSettings.VOICE_RATE))
        {
            result = checkSpeechRate(inValue);
        }
        
        // Handle volume as a straight linear scaling.
        //        
        else if ( inParam.equals (EReaderSettings.VOICE_VOLUME) )
        {
            int techVal = (int) linearCalcTechVal (inValue, EReaderSettings.VOLUME_SLOPE, EReaderSettings.VOLUME_CEPT);
            result = Integer.toString (techVal);
        }
        
        // Handle pitch.  The slope of the transfromation is different for ACCLIP
        // values less than or equal to 5.0.
        //
        else if (inParam.equals (EReaderSettings.VOICE_PITCH))
        {
			Locale loc = getControlHub().getLocale();
			int techVal;
			if ((loc.toString()).matches("en") || (loc.toString()).matches("en_\\w\\w")) {
            	techVal = (int) linearCalcTechVal (inValue, EReaderSettings.PITCH_SLOPEen, EReaderSettings.PITCH_CEPTen);
			} else {
            	techVal = (int) linearCalcTechVal (inValue, EReaderSettings.PITCH_SLOPEfr, EReaderSettings.PITCH_CEPTfr);
			}
            result = Integer.toString (techVal);
        }
        
        // All other handled by lookup tables.
        //
        else
            result = super.mapValue (inParam, inValue);

        ConfigManager.logDebugStatement ("For (" + inParam + "," + inValue + "), result is '" + result + "'");
        return result;
            
    }   // end mapValue().
    
    /**
     * @param   inRate  A string representing the desired speech rate
     * @return          A string representing the final speech rate. Values
     *                  less than the minimum or greater than the maximum
     *                  will be clipped.
     */
    private String checkSpeechRate(String inRate)
    {
        String newRate = inRate;

        int rate = Integer.parseInt(inRate);
        if (rate < VOICE_RATE_MIN)
            newRate = String.valueOf(VOICE_RATE_MIN);
        else if (rate > VOICE_RATE_MAX)
            newRate = String.valueOf(VOICE_RATE_MAX);

        return newRate;
    }   // end checkSpeechRate()
    
    /**
     * Method for effectively "writing" the setting.
     * This override outputs an appropriate registry key ahead of the setting.
     * @param  inProperty   String representing the parameter to write.
     * @param  inValue      String representing the value of <code>inProperty</code>.
     * @see #writeSetting, #addSettingToArgs
     */
    protected void doWriteSetting (String inProperty, String inValue)
    {
        String iniHeaderInt = null;
        
        if (inProperty.equals(VOICE_PITCH) || inProperty.equals(VOICE_RATE) || inProperty.equals(VOICE_VOLUME))    
            iniHeaderInt = getControlHub().get3rdPartyProperties (getAppID()).getString (EReaderSettings.REGISTRY_HEADER_VOICE);
        else if (inProperty.equals(HILIGHT) || inProperty.equals(ALT_TEXT) || inProperty.equals(SPEAK_LINKS))    
            iniHeaderInt = getControlHub().get3rdPartyProperties (getAppID()).getString (EReaderSettings.REGISTRY_HEADER);
        else
            // unrecognized property
            return;
            
        theLocalOutput.println (iniHeaderInt);
        writeSetting (inProperty, inValue);
    }   // end doWriteSetting()

    /**
     * Launch eReader, and record the process created.
     */
    public void doLaunch()
    {
        // Launch eReader.  Start with the location.
        //
        try
        {
            String command = getControlHub().get3rdPartyExecutable (getAppID());
            ConfigManager.logDebugStatement ("'" + command.toString() + "'");
            setProcess (Runtime.getRuntime().exec (command.toString() + " -sp " + getControlHub().getGlobalProperty(Web4AllPropNames.LAUNCH_URL)));
        }
        
        catch (IOException ioe)
        {
            ConfigManager.logException(ioe);
        }

    }  // end doLaunch().

     /**
     * Method for writing the final settings to the registry. Invokes the RegistryConsole
     * utility to process the .ini file created by doSettings();
     * @see #doSettings(Vector, ControlHub)
     */
    protected void writeToRegistry()
    {
        boolean success = initLocalProps();
        
        // If we got the local properties, try to get <theRegistryExec>.
        //
        if (success) {
            try {
                // build the registry console command
                String dirSep = System.getProperty ("file.separator");
                StringBuffer command = new StringBuffer (getControlHub().getHomeDirectory());
                theRegistryConsoleExec = getLocalProperty (EReaderSettings.REGISTRY_EXE);
                System.out.println ("EReaderSettings.writeToRegistry():  <theRegistryExec> is '" + (theRegistryConsoleExec == null ? "null" : theRegistryConsoleExec) + "'");
                command.append (dirSep).append (theRegistryConsoleExec);
                
                // append the ini file name
                command.append (" \""); // space double-quote.
                command.append (getControlHub().getHomeDirectory()).append (dirSep).append (getControlHub().get3rdPartyIni (getAppID()));
                command.append ("\"");  // double-quote.
                
                // now run the process
                Process registryConsole = Runtime.getRuntime().exec (command.toString());
                try
                {
                    handleProcessIStreams (registryConsole, true);
                    registryConsole.waitFor();
                }
                catch (InterruptedException ie)
                {
                    ConfigManager.logException(ie);
                }
            }
            catch (MissingResourceException mre) {
                System.out.println ("EReaderSettings.writeToRegistry():  can't get local properties");
                ConfigManager.logException (mre);
            }
            catch (IOException ioe) {
                System.out.println ("EReaderSettings.writeToRegistry():  can't run registry console");
                ConfigManager.logException (ioe);
            }
        }

    }   // end setLocalData().

   /**
     * Nested class to map the ACCLIP preference name to the HomePageReader settings.
     * The settings are stored as a table of ParameterState objects.
     */
    private static class ERSettings extends SettingsBundle
    {
        /**
         * Record the fact that these settings are of type "textReadingHighlight".
         */
        public ERSettings()
        {
            super ("textReadingHighlight");
        
        }   // end ERSettings().
        
        public Object[][] getContents()
        {
            return contents;
        }
        
        /**
         * The lookup table.  The left side is an element name from the ACCLIP.  The right side
         * is the name of the eReader setting, whether the application requires that setting, and its default
         * value.
         */
        final Object[][] contents = {
        
            { SPEECH_RATE_NAME, new ParameterState (VOICE_RATE, true, SPEECH_RATE_DEFAULT) },
            { PITCH_NAME, new ParameterState (VOICE_PITCH, true, PITCH_DEFAULT) },
            { VOLUME_NAME, new ParameterState (VOICE_VOLUME, true, VOLUME_DEFAULT) },
            { HIGHLIGHT_NAME, new ParameterState (HILIGHT, true, HIGHLIGHT_DEFAULT) },
            { SPEAK_ALT_TEXT_NAME, new ParameterState (ALT_TEXT, true, SPEAK_ALT_TEXT_DEFAULT) },
            { SPEAK_WHEN_TABBING_NAME, new ParameterState (SPEAK_LINKS, true, SPEAK_WHEN_TABBING_DEFAULT) },
//            { READING_UNIT_NAME, new ParameterState (READING_UNIT, true, READING_UNIT_DEFAULT) },
        
        };
        
    }  // end nested class ERSettings.

    /**
     * Nested class for mapping prefs values to the HomePageReader values maps.
     */
    private static class ValueMapChooser extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table (ACCLIP name, our map})
         */
        final Object[][] contents = {
            { EReaderSettings.ALT_TEXT,  new TrueFalseMap() },
            { EReaderSettings.SPEAK_LINKS,  new TrueFalseMap() },
            { EReaderSettings.HILIGHT,  new HilightMap() },
        };

    }  // end inner class ValueMapChooser.

    /**
     * Inner class for mapping prefs higlight values to EReader's.
     */
    private static class HilightMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<value from prefs>,<ereader value>})
         */
        final Object[][] contents = {
            { "word", "1" },
            { "sentence", "0" },
            { "line", "0" },
            { "paragraph", "0" },
        };

    }  // end inner class HilightMap.
    
    /**
     * Inner class for mapping prefs "true"/"false" values to EReader's.
     */
    private static class TrueFalseMap extends ListResourceBundle
    {
        /**
         * Get the lookup table.
         */
        public Object[][] getContents()
        {
            return contents;
        }

        /**
         * The lookup table ({<value from prefs>,<ereader value>})
         */
        final Object[][] contents = {
            { "true",  "1" },
            { "false", "0" }
        };

    }  // end inner class TrueFalseMap.
    
    
}   // end class EReaderSettings.

