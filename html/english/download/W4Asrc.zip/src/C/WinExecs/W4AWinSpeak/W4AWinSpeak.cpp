/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 * 
 *
 * File:            W4AWinSpeak.cpp 
 *
 * JNI implementation for native French and English MSAPI voice access
 *
 * DTB - March 2006 - created (in a rush).
 *
 */

#include "stdafx.h"
#include "W4AWinSpeak.h"

#include <sapi.h>
#include <sphelper.h>

/* VC++ stuff */
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#ifdef cplusplus
extern "C" {
#endif

/* jni header */
#include "ca_utoronto_atrc_web4all_tts_SimpleSpeech.h"

/* jni implementation */
#define BOTHVOICES 0
#define ENGLISHONLY 1
#define FRENCHONLY 2
#define NOVOICES 3

#define MAXSPEAKTEXT 1000
#define ENGLISH 0
#define FRENCH 1

struct {
	ISpVoice* pCurrentVoice;
	ISpVoice* pEnglishVoice;
	ISpVoice* pFrenchVoice;
	WCHAR theString[MAXSPEAKTEXT];
	int language;
	BOOL haveEnglish;
	BOOL haveFrench;
	int systemStatus;
} global;


/*
 * Class:     ca_utoronto_atrc_web4all_tts_SimpleSpeech
 * Method:    initialize
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_ca_utoronto_atrc_web4all_tts_SimpleSpeech_initialize
  (JNIEnv *env, jobject o)
{
	HRESULT hr;
	jint returncode = NOVOICES;

	ISpObjectToken* pToken = NULL;

	/* intialize global variables */
	global.pCurrentVoice = NULL;
	global.pEnglishVoice = NULL;
	global.pFrenchVoice = NULL;
	global.theString[0] = '\0';
	global.language = ENGLISH;
	global.haveEnglish = FALSE;
	global.haveFrench = FALSE;
	global.systemStatus = 3;

	hr = CoCreateInstance(CLSID_SpVoice, NULL, CLSCTX_ALL, IID_ISpVoice, (void **)&global.pEnglishVoice);
	if( SUCCEEDED( hr ) )
	{
		hr = SpFindBestToken(SPCAT_VOICES, L"Language=409",
			L"Gender=Female", &pToken);
		if( SUCCEEDED( hr ) ) {
			hr = global.pEnglishVoice->SetVoice(pToken);
			if ( SUCCEEDED( hr ) ) {
				global.haveEnglish = TRUE;
				global.pEnglishVoice->Speak( L"", SPF_ASYNC, NULL); /* "use it or lose it" - not sure why*/
			}
		}

	}

	hr = CoCreateInstance(CLSID_SpVoice, NULL, CLSCTX_ALL, IID_ISpVoice, (void **)&global.pFrenchVoice);
	if( SUCCEEDED( hr ) )
	{
		hr = SpFindBestToken(SPCAT_VOICES, L"Language=40C",
			L"Gender=Female", &pToken);
		if( SUCCEEDED( hr ) ) {
			hr = global.pFrenchVoice->SetVoice(pToken);
			if ( SUCCEEDED( hr ) ) {
				global.haveFrench = TRUE;
				global.pFrenchVoice->Speak( L"", SPF_ASYNC, NULL); /* again, "use it or lose it" */
			}
		}
	}

	if (global.haveEnglish && global.haveFrench) {
		global.pCurrentVoice = global.pEnglishVoice;
		returncode = BOTHVOICES;
	}
	else if (global.haveEnglish && !global.haveFrench) {
		global.pCurrentVoice = global.pEnglishVoice;
		returncode = ENGLISHONLY;
	}
	else if (!global.haveEnglish && global.haveFrench) {
		global.pCurrentVoice = global.pFrenchVoice;
		returncode = FRENCHONLY;
	}
	else {
		returncode = NOVOICES;
	}

	wcscpy( global.theString, L"Hi" );
	global.systemStatus = (int) returncode;

	return returncode;
}


/*
 * Class:     ca_utoronto_atrc_web4all_tts_SimpleSpeech
 * Method:    french
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_ca_utoronto_atrc_web4all_tts_SimpleSpeech_french
  (JNIEnv *env, jobject o)
{
	if (!(global.systemStatus == ENGLISHONLY)) {
		global.pCurrentVoice = global.pFrenchVoice;
	}

	return (jint) 0;
}

/*
 * Class:     ca_utoronto_atrc_web4all_tts_SimpleSpeech
 * Method:    english
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_ca_utoronto_atrc_web4all_tts_SimpleSpeech_english
  (JNIEnv *env, jobject o)
{
	if (!(global.systemStatus == FRENCHONLY)) {
		global.pCurrentVoice = global.pEnglishVoice;
	}

	return (jint) 0;
}

/*
 * Class:     ca_utoronto_atrc_web4all_tts_SimpleSpeech
 * Method:    say
 * Signature: (Ljava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_ca_utoronto_atrc_web4all_tts_SimpleSpeech_say
  (JNIEnv *env, jobject o, jstring s)
{
	HRESULT hr;

	const jchar* jcstr = env->GetStringCritical(s, JNI_FALSE);
	BSTR bstr = ::SysAllocStringLen(jcstr, env->GetStringLength(s));
	hr = global.pCurrentVoice->Speak( bstr, SPF_ASYNC | SPF_PURGEBEFORESPEAK, NULL);
	env->ReleaseStringCritical(s, jcstr);
	::SysFreeString(bstr);

    return hr;
}

/*
 * Class:     ca_utoronto_atrc_web4all_tts_SimpleSpeech
 * Method:    silence
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_ca_utoronto_atrc_web4all_tts_SimpleSpeech_silence
  (JNIEnv *env, jobject o)
{
	if (!(global.systemStatus == NOVOICES)) {
		global.pCurrentVoice->Speak( L"", SPF_ASYNC | SPF_PURGEBEFORESPEAK, NULL);
	}
	return (jint) 0;
}


#ifdef cplusplus
} /* extern C */
#endif


/* VC++ stuff */


//
//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

/////////////////////////////////////////////////////////////////////////////
// CW4AWinSpeakApp

BEGIN_MESSAGE_MAP(CW4AWinSpeakApp, CWinApp)
	//{{AFX_MSG_MAP(CW4AWinSpeakApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CW4AWinSpeakApp construction

CW4AWinSpeakApp::CW4AWinSpeakApp()
{
	CoInitialize(NULL);
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CW4AWinSpeakApp object
CW4AWinSpeakApp theApp;

BOOL CW4AWinSpeakApp::InitInstance()
{
	CWinApp::InitInstance();


	return TRUE;
}

CW4AWinSpeakApp::ExitInstance()
{
	CWinApp::ExitInstance();

    CoUninitialize();

	return TRUE;
}

