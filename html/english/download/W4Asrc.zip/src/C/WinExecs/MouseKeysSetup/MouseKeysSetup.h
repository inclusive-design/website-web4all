/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */


#if !defined(AFX_MOUSEKEYSSETUP_H__B872E608_0A31_11D4_8580_00C04F49F155__INCLUDED_)
#define AFX_MOUSEKEYSSETUP_H__B872E608_0A31_11D4_8580_00C04F49F155__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"

int	inSpeed;
int	inAcceleration;

#define	SPEED_MIN		10
#define	SPEED_MAX		360
#define	SPEED_MEDIUM	64
#define	SPEED_DEFAULT	60

#define	ACCEL_MIN		5000
#define	ACCEL_MAX		1000
#define	ACCEL_MEDIUM	3000
#define	ACCEL_DEFAULT	5000

bool reset;

#endif // !defined(AFX_MOUSEKEYSSETUP_H__B872E608_0A31_11D4_8580_00C04F49F155__INCLUDED_)
