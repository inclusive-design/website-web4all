/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

// MouseKeysSetup.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "MouseKeysSetup.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;

/////////////////////////////////////////////////////////////////////////////
// OutputErrMsg
/////////////////////////////////////////////////////////////////////////////
void OutputErrMsg()
{

	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		(LPTSTR) &lpMsgBuf,
		0,
		NULL 
	);
	cout << _T("     *** Error Message: ");
	cout << _T((char *)lpMsgBuf) << endl;
}

/////////////////////////////////////////////////////////////////////////////
// SetupMouseKeys
/////////////////////////////////////////////////////////////////////////////
int SetupMouseKeys()
{
	MOUSEKEYS mk;
	mk.cbSize = sizeof(mk);
	mk.dwFlags = MKF_AVAILABLE |
				 MKF_MOUSEKEYSON |
				 MKF_MODIFIERS |
				 MKF_INDICATOR;
	mk.iMaxSpeed = inSpeed;
	mk.iTimeToMaxSpeed = inAcceleration;
	if (!SystemParametersInfo(SPI_SETMOUSEKEYS,
								sizeof(MOUSEKEYS), (PVOID)&mk,
								SPIF_UPDATEINIFILE|SPIF_SENDCHANGE))
	{
		OutputErrMsg();
		return -1;
	}

	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// DisableMouseKeys
/////////////////////////////////////////////////////////////////////////////
int DisableMouseKeys()
{
	MOUSEKEYS mk;
	mk.cbSize = sizeof(mk);
	mk.dwFlags = MKF_AVAILABLE |
				 MKF_MODIFIERS |
				 MKF_INDICATOR;
	mk.iMaxSpeed = SPEED_DEFAULT;
	mk.iTimeToMaxSpeed = ACCEL_DEFAULT;
	if (!SystemParametersInfo(SPI_SETMOUSEKEYS,
								sizeof(MOUSEKEYS), (PVOID)&mk,
								SPIF_UPDATEINIFILE|SPIF_SENDCHANGE))
	{
		OutputErrMsg();
		return -1;
	}

	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// OutputSyntaxHelp
/////////////////////////////////////////////////////////////////////////////
void OutputSyntaxHelp()
{
	cout << _T ("MouseKeysSetup sets MouseKeys features.") << endl;
	cout << _T ("Syntax: MouseKeysSetup <speed> <acceleration>") << endl;
}

/////////////////////////////////////////////////////////////////////////////
// ProcessCommandLine
/////////////////////////////////////////////////////////////////////////////
int ProcessCommandLine(int argc, char argv[][20])
{
	if (argc == 1)	// no parameters, setting to defaults
	{
		inSpeed			= SPEED_DEFAULT;
		inAcceleration	= ACCEL_DEFAULT;
		
		reset = true;
	}
	else if (argc == 3)
	{
		inSpeed			= atoi(argv[1]);
		inAcceleration	= atoi(argv[2]);
	}
	else
	{
		OutputSyntaxHelp();
		return 1;
	}

	return 0;
}


/////////////////////////////////////////////////////////////////////////////
// WinMain
/////////////////////////////////////////////////////////////////////////////
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	char seps[] = " ";
	char* token;
	char argv[10][20];	// assume less than 10 integer arguments for our purposes.
	token = strtok(lpCmdLine, seps);
	int argc = 1;
	while (token != NULL)
	{
		strcpy(argv[argc++], token);
        token = strtok( NULL, seps );
    }

	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		return 1;
	}

	reset = false;

	if (ProcessCommandLine(argc, argv))
		return 1;

	if (reset)
	{
		cout << _T("Setting mousekey configuration to default...") << endl;
		if (DisableMouseKeys() != 0)
		{
			cerr << _T("Error configuring mousekeys") << endl;
			return 1;
		}
		cout << _T("... configuration complete.") << endl;
		return 0;
	}


	cout << _T("Setting mousekey configuration...") << endl;
	if (SetupMouseKeys() != 0)
	{
		cerr << _T("Error configuring mousekeys.") << endl;
		return 1;
	}
	cout << _T("... configuration complete.") << endl;
	return nRetCode;
}


