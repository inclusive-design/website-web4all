/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

// RegistryConsole.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "RegistryConsole.h"
#include "iostream.h"
#include "shellapi.h"


/////////////////////////////////////////////////////////////////////////////
// OutputErrMsg
/////////////////////////////////////////////////////////////////////////////
void OutputErrMsg()
{

	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		(LPTSTR) &lpMsgBuf,
		0,
		NULL 
	);
	cout << _T("     *** Error Message: ");
	cout << _T((char *)lpMsgBuf) << endl;
}

/////////////////////////////////////////////////////////////////////////////
// HandleKeyValue
// Handle a key/value line by extracting the key and value, and writing
// to the currently open subkey
/////////////////////////////////////////////////////////////////////////////
void HandleKeyValue(CString KeyValue)
{
	int count = KeyValue.Find ('=');
	if (count != -1)
	{
		CString settingString = KeyValue.Left (count);
		settingString.TrimRight();
		CString valueString = KeyValue.Right (KeyValue.GetLength() - count - 1);
		valueString.TrimLeft();
		if (valueString.Right(STRINGFLAGLEN) == STRINGFLAG)
		{
			// handle a string parameter
			// strip off the flag
			valueString = valueString.Left(valueString.GetLength()-STRINGFLAGLEN);
			char valString[40];
			memset(valString,0,40);
			strcpy(valString,valueString.GetBuffer(valueString.GetLength()));
			if (hOpenKey != NULL)
			{
				RegSetValueEx (hOpenKey, settingString, NULL, REG_SZ , 
								(LPBYTE)&valString, valueString.GetLength());

			}
		}
		else
		{
			// handle an int parameter
			int value = atoi (valueString);
			if (hOpenKey != NULL)
			{
				RegSetValueEx (hOpenKey, settingString, NULL, REG_DWORD , 
								(LPBYTE)&value, sizeof(value));
			}
		}
	}
}


/////////////////////////////////////////////////////////////////////////////
// GetEreaderCurrentVoice
// Highly specialized routine to determine the "Current Voice" setting for
// eReader.
// This method assumes that the eReader settings are in the typical key 
// location in the registry
/////////////////////////////////////////////////////////////////////////////
BOOL GetEreaderCurrentVoice(LPBYTE currentVoice)
{
	// this string makes assumptions!!!
	CString defUserKey = "Software\\CAST\\eReader\\DefaultUser";

	// try to open the eReader default user key
	if (RegOpenKeyEx (HKEY_CURRENT_USER, 
					defUserKey, 
					NULL, 
					KEY_ALL_ACCESS, 
					&hOpenKey) != ERROR_SUCCESS)
	{
		cout << _T ("Error: unable to get default user key\n") << endl;
		return false;
	}

	// extract the "Current Voice" data value
    TCHAR szCurrVoice[100];
    DWORD dwBufLen = sizeof(szCurrVoice);
    if (RegQueryValueEx(hOpenKey,
                    TEXT("Current Voice"),
                    NULL,
                    NULL,
                    (LPBYTE)szCurrVoice,
                    &dwBufLen) != ERROR_SUCCESS)
	{
		cout << _T ("Error: unable to determine current voice data \n") << endl;
		return false;
	}

	strcpy((char *)currentVoice, szCurrVoice);
	return true;
}

/////////////////////////////////////////////////////////////////////////////
// HandleEreaderSpecial
// Handle the special case header used for eReader voice settings.
// These settings must be applied to the current voice, which is unknown
// until runtime, and therefor can't be encoded into the ini file
/////////////////////////////////////////////////////////////////////////////
void HandleEreaderSpecial(CString SubKey)
{
	CString newSubKey;

	cout << _T("RegistryConsole: handling Ereader voice settings") << endl;;
	// strip off the flag
	SubKey = SubKey.Left(SubKey.GetLength()-EREADERSPECIALFLAGLEN);

	// open the given subkey
	if (RegOpenKeyEx (HKEY_CURRENT_USER, 
					SubKey, 
					NULL, 
					KEY_ALL_ACCESS, 
					&hOpenKey) != ERROR_SUCCESS)
	{
		cout << _T ("Error: Subkey does not exist!\n") << endl;
		OutputErrMsg();
		hOpenKey = NULL;
		return;
	}

	cout << _T("RegistryConsole: determining current voice...") << endl;
	// look inside the given subkey for the classid of the current voice

	// get the current voice so that we can direct the settings appropriately
	TCHAR currVoice[100];
	memset (currVoice, 0, sizeof(currVoice));
	GetEreaderCurrentVoice((LPBYTE)currVoice);

	// construct the new subkey for the current voice
	newSubKey = SubKey + currVoice;
	cout << _T("RegistryConsole: opening subkey for voice...") << endl;

	// open this new subkey
	if (RegOpenKeyEx (HKEY_CURRENT_USER, 
					newSubKey, 
					NULL, 
					KEY_ALL_ACCESS, 
					&hOpenKey) != ERROR_SUCCESS)
	{
		cout << _T ("Warning: Key not in registry!\n") << endl;
		OutputErrMsg();

		// key is not in registry yet, so create it
		DWORD DispositionBuffer;
		if (RegCreateKeyEx (HKEY_CURRENT_USER,
						newSubKey, 
						NULL, 
						NULL, // address of class string 
						REG_OPTION_NON_VOLATILE,
						KEY_ALL_ACCESS ,
						NULL,
						&hOpenKey,
						&DispositionBuffer) != ERROR_SUCCESS)
		{
			cout << _T ("Error: Can't create subkey!\n") << endl;
			OutputErrMsg();
			hOpenKey = NULL;
		}
	}

	cout << _T("RegistryConsole: subkey opened.") << endl;
}

/////////////////////////////////////////////////////////////////////////////
// HandleHeader
// Handle a header line by extracting the subkey and opening the appropriate
// it, first closing any subkey which might already be open
/////////////////////////////////////////////////////////////////////////////
void HandleHeader(CString Header)
{
	CString subKey;

	// if a key is already open, close it
	if (hOpenKey != NULL)
	{
		RegCloseKey (hOpenKey);
	}

	// strip off the square brackets
	subKey = Header.Mid(1, Header.GetLength()-2);

	// the eReader voice settings rely on the class id of the current
	// voice, which is unknown before runtime, and can therefore NOT be
	// recorded in the .ini file.
	// A special flag is used to indicate whether or not the subkey must
	// be determined by examining the contents of the registry
	if (subKey.Right(EREADERSPECIALFLAGLEN) == EREADERSPECIALFLAG)
	{
		HandleEreaderSpecial(subKey);
		return;
	}

	// try to open the new key
	if (RegOpenKeyEx (HKEY_CURRENT_USER, 
					subKey, 
					NULL, 
					KEY_ALL_ACCESS, 
					&hOpenKey) != ERROR_SUCCESS)
	{
		cout << _T ("Warning: Key not in registry!\n") << endl;

		// key is not in registry yet, so create it
		DWORD DispositionBuffer;
		if (RegCreateKeyEx (HKEY_CURRENT_USER,
						subKey, 
						NULL, 
						NULL, // address of class string 
						REG_OPTION_NON_VOLATILE,
						KEY_ALL_ACCESS ,
						NULL,
						&hOpenKey,
						&DispositionBuffer) != ERROR_SUCCESS)
		{
			cout << _T ("Error: Can't create subkey!\n") << endl;
			OutputErrMsg();
			hOpenKey = NULL;
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// WinMain
/////////////////////////////////////////////////////////////////////////////
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	cout << _T("Registry console started.") << endl;

	int nRetCode = 0;

	CString fileName = lpCmdLine;	// assumes only thing on commandline is filename
	// strip off any surrounding quotes
	if (fileName[0] == '\"')
		fileName.Remove('\"');
	else if (fileName[0] == '\'')
		fileName.Remove('\'');

	FILE* pFile = fopen (fileName, "rt");
	if (pFile == NULL)
	{
		cout << _T ("Can't open file: ");
		cout << _T (fileName) << endl;
		return 0;
	}

	cout << _T ("Writing registry settings from ");
	cout << _T (fileName) << endl;
	TCHAR line[501];
	hOpenKey = NULL;

	// read in the file contents and process
	while (fgets (line, 500, pFile) != NULL)
	{
		CString stringLine = line;
		stringLine.TrimLeft();
		stringLine.TrimRight();

		if (stringLine.IsEmpty() == FALSE)
		{
			CString registrySubkey;
			// if this line is a header line, pass to HandleHeader
			if (stringLine.GetAt(0) == '[')
			{
				HandleHeader(stringLine);
			}
			else
			{
				// if this is not a header, then a subkey should already be open
				if (hOpenKey == NULL)
				{
					CString message = "Setting does not occur within a section: ";
					message += stringLine;
					cout << _T (message) << endl;
				}
				else
				{
					HandleKeyValue(stringLine);
				}
			}
		}
	}

	if (hOpenKey != NULL)
	{
		RegFlushKey (hOpenKey);
		RegCloseKey (hOpenKey);
	}

	fclose (pFile);

	return 0;

}

