#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include <string.h>
#include "iostream.h"
#include "resource.h"

#include "mosk.h"
#include "prototype.h"

HINSTANCE	g_hInst = NULL;
HWND		g_hWnd = NULL;
LPTSTR		g_stringCommand = NULL;

void commandOsk (void);
void processSettings (LPSTR);

int WINAPI _tWinMain (HINSTANCE hInstance,
   HINSTANCE hPrevInstance, LPTSTR lpszCmdLine, int nCmdShow)
{
	g_hInst = hInstance;
	g_stringCommand = lpszCmdLine;

	// is our app already running?
	g_hWnd = FindWindow (NULL, "W4A Keyboard");
	if (g_hWnd != NULL){
		// yes, our app is running
//		MessageBox (hWnd, "We're already running!", "message", MB_OK);

		// modify the OSK
		commandOsk();
	}
	else { // our app is not running yet
		// create our dialog (during creation it will display the OSK)
		DialogBox(hInstance, MAKEINTRESOURCE(IDD_TEST), NULL, TestProc);
	}

	return(0);
}

LRESULT CALLBACK TestProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	long x = 0,y = 0;
	g_hWnd = hDlg;
	SetClassLong(hDlg, GCL_HICON, (long)LoadIcon (g_hInst, MAKEINTRESOURCE(IDI_SDK)));
	switch (message)
	{
		case WM_INITDIALOG:
			// display the OSK
			if(!MOSK_IsOpen())
			{	
				MOSK_Init(hDlg,"");
				Sleep (5000);
				MOSK_Show(SW_SHOW);
			}
			
			// set a timer that will hide our dialog
			SetTimer(hDlg,666,10,(TIMERPROC) NULL);     

			return FALSE;
			break;

		case WM_TIMER:
			// stop the timer
			KillTimer(hDlg, 666);

			// hide our dialog
			ShowWindow (hDlg, SW_HIDE); 

			// modify the OSK
			commandOsk();
			break;

		case WM_COMMAND:
			switch(wParam)
			{
				case IDCANCEL:
				case IDEXIT:
					EndDialog(hDlg, LOWORD(wParam));
					return TRUE;
				
				case IDC_OPEN_MOSK:
					if(!MOSK_Show(SW_SHOW))
						SendErrorMessage(g_hWnd,IDS_CANNOT_OPEN_KEYBOARD);
					break;

				case IDC_CLOSE_MOSK:
					if(!MOSK_Close())
						SendErrorMessage(g_hWnd,IDS_ERROR_CLOSING_KEYBOARD);
					break;

				case IDC_VISIBLE:
					 MOSK_Toggle_Visible();
					break;

				default:
					break;
			 }
		break;
	}
    return FALSE;
}

// modify the OSK
void commandOsk ()
{
	if (g_stringCommand != NULL){
		if (strcmp (g_stringCommand, "close") == 0){
			MOSK_Close();

			// close the running app??
			PostMessage (g_hWnd, WM_COMMAND, IDCANCEL, IDCANCEL);
		}
		else if (strncmp (g_stringCommand, "show", 4) == 0){
			MOSK_Show(SW_SHOW);
			processSettings(g_stringCommand);
		}
	}

}

void processSettings(LPSTR lpCmdLine)
{
	char strSound[20];
	char strDwell[20];
	
	char seps[] = " ";
	char* token;
	char argv[5][20];
	int argc = 1;
	token = strtok(lpCmdLine, seps);
	while (token != NULL)
	{
		strcpy(argv[argc++], token);
        token = strtok( NULL, seps );
    }
	strcpy (strSound, argv[2]);
	strcpy (strDwell, argv[3]);

	if (strcmp (strSound, "true") == 0){
		if (MOSK_Get_Sound() == FALSE) {
			MOSK_Toggle_Sound();
		}
	} else {//if {strcmp (strSound, "false") == 0) {
		if (MOSK_Get_Sound() == TRUE) {
			MOSK_Toggle_Sound();
		}
	}

	if (strcmp (strDwell, "true") == 0){
		if (MOSK_Get_Dwell() == FALSE) {
			MOSK_Toggle_Dwell();
		}
	} else {//if {strcmp (strDwell, "false") == 0) {
		if (MOSK_Get_Dwell() == TRUE) {
			MOSK_Toggle_Dwell();
		}
	}

}
