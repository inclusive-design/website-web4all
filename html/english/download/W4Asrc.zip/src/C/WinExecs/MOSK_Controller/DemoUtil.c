#define STRICT

#include <windows.h>
#include <stdio.h> 
#include <stdarg.h>
#include "resource.h"
#include "ProtoType.h"
#include "mosk.h"



/**************************************************************************/
/*  FUNCTION:   DebugMsg(const TCHAR, ...) 
/*  PURPOSE:    Prints formatted output to the debugger ala printf.
/*  PARAMETERS:
/*      *pFmt   - string with the necessary formatting codes
/*      ...     - arguments being embedded in the pFmt string.
/*  RETURN VALUE:
/*      Returns number of bytes written or -1 if buffer is too small
/*  COMMENTS:
/*      Calling this function should be just like calling printf.  The only
/*      difference is this function outputs to the debugger instead of STDOUT.
/*  Author: Jason Dutton
/**************************************************************************/
int DM( const TCHAR *pFmt, ...)
{
    int i;
    const int iMsgSize = 512;
    va_list pArgs;
    char szMsg[512];

    // outputs formatted string to debugger
    // returns count of bytes written or -1 if buffer size is too small

    va_start( pArgs, pFmt );
    #ifdef UNICODE
        i = _vsnwprintf(szMsg, iMsgSize+1, pFmt, pArgs);
    #else
        i = _vsnprintf(szMsg, iMsgSize+1, pFmt, pArgs);
    #endif
    va_end( pArgs );
    OutputDebugString( szMsg );
    return( i );
}


/*************************************************************************/
// Info message box
// Given : a string
/*************************************************************************/
void SendInfoMessage_str(HWND hwnd,TCHAR *str)
{	

	TCHAR title[]="MOSK - Message";

	MessageBox(hwnd, str, title, MB_ICONINFORMATION | MB_OK | MB_SYSTEMMODAL);

}
/**************************************************************************/
// Give out information  IDOK
// Given : a resource id
/**************************************************************************/
void SendInfoMessage(HWND hwnd,UINT ids_string)
{	
	TCHAR str[256]="";
	TCHAR title[]="MOSK - Message";

	LoadString(g_hInst, ids_string, (LPTSTR)&str, 256);
	MessageBox(hwnd, str, title, MB_ICONINFORMATION | MB_OK | MB_SYSTEMMODAL);
}
/**************************************************************************/
/* SendErrorMessage  - error msg  IDOK                                    */
/**************************************************************************/
void SendErrorMessage(HWND hwnd,UINT ids_string)
{	
	TCHAR str[256]="";
	TCHAR title[]="MOSK - Error";

	LoadString(g_hInst, ids_string, (LPTSTR)&str, 256);
	MessageBox(hwnd, str, title, MB_ICONHAND | MB_OK | MB_SYSTEMMODAL);
}// SendErrorMessage

/**************************************************************************/
/* SendAttentionMessage  - Attention type of msg Return: IDYES IDNO		  */
/**************************************************************************/
int SendAttentionMessage(HWND hwnd,char *msg)
{	
	TCHAR title[]="MOSK - ATTENTION!";
	return(MessageBox(hwnd, msg, title, MB_ICONQUESTION | MB_YESNO | MB_SYSTEMMODAL));
}
/**************************************************************************/
// Yes , No , Cancel
/**************************************************************************/
int SaveChangesMessage(HWND hwnd, char *msg)
{

	TCHAR title[]="MOSK - ATTENTION!";

	return(MessageBox(hwnd, msg, title, MB_ICONQUESTION | MB_YESNOCANCEL | MB_SYSTEMMODAL));
}
/***************************************************************************/
int OkCancelMsg(HWND hwnd,TCHAR *msg)
{
	TCHAR title[]="MOSK - ATTENTION!";
	return(MessageBox(hwnd, msg, title, MB_ICONQUESTION | MB_OKCANCEL | MB_SYSTEMMODAL));
}



/**************************************************************/
DWORD WhatPlatform(void)
{  OSVERSIONINFO	osverinfo;

	osverinfo.dwOSVersionInfoSize = (DWORD)sizeof(OSVERSIONINFO);
	GetVersionEx(&osverinfo);

	
	return osverinfo.dwPlatformId;

}
/**************************************************************/
HFONT ChangeFont(void)
{	LOGFONT  logfont;
	HFONT hFont=NULL;        // Handle of the selected font

		logfont.lfHeight= -11;
		logfont.lfWidth= 0;
		logfont.lfEscapement= 0;
		logfont.lfOrientation= 0;
		logfont.lfWeight= 400;
		logfont.lfItalic= '\xFF';
		logfont.lfUnderline= '\0';
		logfont.lfStrikeOut= '\0';
		logfont.lfCharSet= '\0';
		logfont.lfOutPrecision= '\x03';
		logfont.lfClipPrecision= '\x02';
		logfont.lfQuality= '\x01';
		logfont.lfPitchAndFamily= '\x12';
		lstrcpy(logfont.lfFaceName, "Times New Roman");
		hFont = CreateFontIndirect(&logfont);
		return hFont;
}

/**************************************************************************/
/*  FUNCTION:	GetAppPath()
/*  PURPOSE:    Returns the applications path 
/*	PARAM'S:    LPSTR - FName, name of the file
/*  RETURNS:    BOOL - TRUE if successful.			
/*  COMMENTS:
/*		This function will aquire the applications path based on the module 
/*		handle. It will append the path to the file name and return TRUE if
/*		all went well.
/*
/*  Jason Dutton 05-30-00 
/**************************************************************************/
BOOL GetAppPath(LPSTR lpsFName)
{	
	TCHAR path[MAX_PATH]="";
	int i, len;

	if(GetModuleFileName(GetModuleHandle(NULL), path, MAX_PATH) != 0)
	{	
		len = lstrlen(path);
		
		//Remove the current application's name
		for(i=len; i > 0; i--)
			if(path[i] == '\\')
			{	path[i+1] = '\0';
				break;
			}
		DM("Path - %s\n",path);
		//put the path together with the file name
		lstrcat(path, lpsFName);
		//copy back to backupfilename
		lstrcpy(lpsFName, path);
		return TRUE;
	
	}else
		return FALSE;
}

void Wait(long delay)
{
	//Wait is measured in milliseconds eg. 1000 = 1sec.
	unsigned long dwtimeout;

	dwtimeout = GetTickCount() + delay;
	while(GetTickCount() < dwtimeout);
}

