//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Demo.rc
//
#define IDEXIT                          1
#define Version                         1
#define IDS_CANNOTCREATEDLG             4
#define IDS_REGISTRY_DAMAGE             5
#define IDS_REGISTRY_ACCESS_ERROR       6
#define IDS_MEMORY_LIMITED              7
#define IDS_SECURITY_FAILURE            8
#define IDS_CANNOT_REGISTER             9
#define IDS_NO_MOUSE                    10
#define IDS_CANNOT_SWITCH_LANG          11
#define IDS_CANNOT_CREATE_KB            12
#define IDS_CANNOT_CREATE_KEY           13
#define IDS_CANNOT_LOAD_ICON            14
#define IDS_SETTING_DAMAGE              18
#define IDS_CANNOT_OPEN_KEYBOARD        26
#define IDS_ERROR_CLOSING_KEYBOARD      27
#define IDS_TITLE                       28
#define IDS_KBD_NOT_LOADED              29
#define IDS_CAPTION_NULL                30
#define IDS_PREVINST_EXIST              31
#define IDS_ERROR_SAVING_COLORS         32
#define IDS_ERROR_GETTING_COLORS        33
#define IDB_MADENTEC_LOGO               101
#define IDC_OPEN_MOSK                   200
#define IDC_CLOSE_MOSK                  201
#define IDC_SET_POS                     202
#define IDC_SET_SIZE                    203
#define IDC_XPOS                        204
#define IDC_YPOS                        205
#define IDC_WIDTH                       206
#define IDD_ABOUT                       207
#define IDC_HEIGHT                      207
#define IDD_TEST                        208
#define IDC_GET_POS                     208
#define IDC_GET_SIZE                    209
#define IDC_VISIBLE                     210
#define IDI_SDK                         211
#define IDC_CAPTION                     211
#define IDC_HIDETOPMENU                 212
#define IDC_3DKEYS                      213
#define IDC_ONTOP                       214
#define IDC_SOUND                       215
#define IDC_INIT                        216
#define IDC_STANDARD                    224
#define IDC_ENHANCED                    225
#define IDC_85_ENGLISH                  226
#define IDC_101_ENGLISH                 227
#define IDC_102_EUROPEAN                228
#define IDC_106_JAPANESE                229
#define IDC_101_BLOCK                   230
#define IDC_NUMBER_PAD                  231
#define IDC_REFRESH                     232
#define IDC_FONTS                       233
#define IDC_COLORS                      234
#define IDD_SELECT_COLORS               291
#define IDC_SETCAPTION                  1000
#define IDC_DWELL_SELECT                1001
#define CHK_USE_CUSTOM_COLORS           1084
#define LBL_KBD_BGR                     1179
#define LBL_KBD_SEL                     1180
#define LBL_KBD_LED                     1183
#define LBL_3DKEY_SHADOW                1184
#define LBL_3DKEY_HIGHLIGHT             1185
#define BTN_DEFAULT                     1187
#define LBL_CHARKEY_FACE                1188
#define LBL_CHARKEY_TEXT                1189
#define BTN_KBD_BGR                     1192
#define BTN_KBD_SEL                     1193
#define BTN_KBD_LED                     1194
#define FRM_KBD_BGR                     1195
#define BTN_3DKEY_SHADOW                1196
#define BTN_3DKEY_HIGHLIGHT             1197
#define FRM_KBD_LED                     1199
#define FRM_3DKEY_SHADOW                1200
#define BTN_CHARKEY_FACE                1201
#define BTN_CHARKEY_TEXT                1202
#define LBL_MODKEY_FACE                 1204
#define FRM_MODKEY_FACE                 1205
#define BTN_MODKEY_FACE                 1206
#define LBL_MODKEY_TEXT                 1207
#define BTN_MODKEY_TEXT                 1208
#define FRM_3DKEY_HIGHLIGHT             1209
#define FRM_KBD_SEL                     1210
#define LBL_DEADKEY_FACE                1211
#define FRM_DEADKEY_FACE                1212
#define BTN_DEADKEY_FACE                1213
#define LBL_DEADKEY_TEXT                1214
#define BTN_DEADKEY_TEXT                1215
#define BTN_OK                          1216
#define PNL_KEYBOARD_COLORS             1217
#define PNL_CHARACTER_KEY_COLORS        1218
#define PNL_MODIFIER_KEY_COLORS         1219
#define PNL_DEADKEY_COLORS              1220
#define FRM_CHARKEY_TEXT                1221
#define FRM_MODKEY_TEXT                 1222
#define FRM_DEADKEY_TEXT                1223
#define BTN_CANCEL                      1224
#define FRM_CHARKEY_FACE                1226

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
