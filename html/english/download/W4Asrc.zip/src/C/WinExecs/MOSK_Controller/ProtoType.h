//DemoProc.c
LRESULT CALLBACK Demo_MainWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK AboutProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK TestProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
void SetAccessAll(HWND hDlg, BOOL bEnable);
void SetPrefs(HWND hDlg);
BOOL ChooseNewFont(HWND hWnd, LOGFONT *LogFont);


//Utilities
BOOL GetAppPath(LPSTR lpsFName);
void SendInfoMessage_str(HWND hwnd,TCHAR *str);
void SendInfoMessage(HWND hwnd,UINT ids_string);
void SendErrorMessage(HWND hwnd,UINT ids_string);
int SendAttentionMessage(HWND hwnd,char *msg);
int SaveChangesMessage(HWND hwnd, char *msg);
int OkCancelMsg(HWND hwnd,TCHAR *msg);
DWORD WhatPlatform(void);
int DM( const TCHAR *pFmt, ...);
void Wait(long delay);

//DLG_SelectColors.c
int SelectColorsDlgFunc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
BOOL WINAPI SelectColorsDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
BOOL DrawControlBitmap(LPDRAWITEMSTRUCT lpDrawItem, char *pBitmapName, BOOL bStretch);
void SetSystemColors();					  ;
void On_EnableControls(HWND hdwnd, BOOL bState);
void CancelColorSelect();
void SaveCurrentColors();
void ChangeColors();
COLORREF SelectColor(COLORREF color, HWND hDlg);
