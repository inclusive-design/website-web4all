//////////////////////////////////////////////////////////////////////////////
//  MODULE:     mosk.h
//  PURPOSE:    Header file for MOSK SDK.
//  PLATFORMS:  Windows 95, Windows NT
//  COMMENTS:
//////////////////////////////////////////////////////////////////////////////


#define DllImport __declspec(dllimport)

//Custom message for MOSK
#define WM_EXTERNALCMD_FONT				4500
#define WM_EXTERNALCMD_COLOR			4501

#define IDM_101_LAYOUT                  40008
#define IDM_102_LAYOUT                  40009
#define IDM_106_LAYOUT                  40010
#define IDM_HIDE_TOP_MENU               40041
#define IDM_STANDARD_KBD                40101
#define IDM_ENHANCED_KBD                40102
#define IDM_85KEYS_ENGLISH				40103
#define IDM_101KEYS_ENGLISH             40104
#define IDM_101KEYS_BLOCK               40105
#define IDM_102KEYS_EUROPEAN            40106
#define IDM_106KEYS_JAPANESE            40107
#define IDM_NUMBER_PAD                  40108
#define IDM_3DKEYS                      40109
#define IDM_ALWAYSONTOP                 40111
#define IDM_USECLICKSOUND               40112
#define IDM_KEYBOARDVISIBLE             40121
#define IDM_FONTS                       40114

#define REG_ACCESS_ERROR				40011
#define REG_MEMORY_LIMITED_ERROR		40012
#define REG_SECURITY_ERROR				40013
#define REG_PREF_VERSION_ERROR			40014
#define REG_ERROR_SUCCESS				40015


#define KBD_STANDARD 0
#define KBD_ENHANCED 1
#define KBD_101KEYS  2
#define KBD_102KEYS	 3
#define KBD_BLOCK	 5
#define KBD_NUMPAD	 6
#define KBD_JAPANESE 7 
#define KBD_85KEYS	 8

typedef struct tagCOLORS
	{
	COLORREF	BackGrdColor; 		// Keyboard background color
	COLORREF	SelectRingColor;	// Selection ring color
	COLORREF    LEDColor; 			// Indicator LED color
	COLORREF    Key3DShadowColor;	// 3D Shadow color (on shadow side)
	COLORREF    Key3DHighlightColor;// 3D Hilight color (on light side)
	COLORREF	CharKeyTextColor;	// Normal Character key Text color
	COLORREF    CharKeyFaceColor; 	// Normal Character key Face color
	COLORREF    ModiKeyFaceColor;	// Modifier key Face color
	COLORREF    ModiKeyTextColor; 	// Modifier key Text color
	COLORREF	DeadKeyFaceColor; 	// Dead key Face color
	COLORREF	DeadKeyTextColor;	// Dead Key Text color
	BOOL		bCustomColor;	// Use Custom color flag
}TEMPCOLORS;

extern TEMPCOLORS   *tc;

DllImport BOOL MOSK_Toggle_Dwell();
DllImport BOOL MOSK_Get_Dwell();

DllImport BOOL MOSK_Init(HWND hwnd,LPSTR sSubDir);
DllImport BOOL MOSK_Show(BOOL State);
DllImport BOOL MOSK_Close();
DllImport BOOL MOSK_IsOpen();

DllImport BOOL MOSK_Toggle_Visible();
DllImport BOOL MOSK_Get_Visible();

DllImport BOOL MOSK_Toggle_3DKeys();
DllImport BOOL MOSK_Get_3DKeys();

DllImport BOOL MOSK_Toggle_OnTop();
DllImport BOOL MOSK_Get_OnTop();

DllImport BOOL MOSK_Toggle_Sound();
DllImport BOOL MOSK_Get_Sound();

DllImport BOOL MOSK_Toggle_HideTopMenu();
DllImport BOOL MOSK_Get_HideTopMenu();

DllImport int MOSK_Get_Type();
DllImport BOOL MOSK_Set_Type(int iType);

DllImport int MOSK_Get_Layout();
DllImport BOOL MOSK_Set_Layout(int iLayout);
DllImport BOOL MOSK_Change_Font();

DllImport BOOL MOSK_Get_Rect(RECT *rect);
DllImport BOOL MOSK_Set_Size(int x, int y);
DllImport BOOL MOSK_Set_Pos(int x, int y);
DllImport BOOL MOSK_SetCaption(LPSTR Caption);

DllImport LOGFONT MOSK_Get_Font();
DllImport BOOL MOSK_Set_Font(LOGFONT lf);

DllImport BOOL MOSK_Get_Colors(TEMPCOLORS *tc);
DllImport BOOL MOSK_Set_Colors(TEMPCOLORS *tc);

extern HINSTANCE	g_hInst;
extern HWND		g_hWnd;

