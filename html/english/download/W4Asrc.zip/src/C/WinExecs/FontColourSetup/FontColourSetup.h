/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

#if !defined(AFX_FONTCOLOURSETUP_H__6C0F2E7C_7352_4BAB_A7E9_B0BE867EE253__INCLUDED_)
#define AFX_FONTCOLOURSETUP_H__6C0F2E7C_7352_4BAB_A7E9_B0BE867EE253__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"

// definitions
#define COL_WINDEF		0
#define COL_WHITEBLACK	1
#define COL_BLACKWHITE	2
#define COL_YELLOWBLUE	3
#define COL_BLUEYELLOW	4
#define COL_BLUEWHITE	5

#define FONT_WINDEF	0
#define FONT_SMALL	1
#define FONT_MEDIUM	2
#define FONT_LARGE	3
#define FONT_XLARGE	4

#define FACE_WINDEF		0
#define FACE_SERIF		1
#define FACE_SANSSERIF	2
#define FACE_MONOSPACED	3

#define INVERT_NO	0
#define INVERT_YES	1

#define	RGB_WHITE	0x00FFFFFF	//0xbbggrr
#define	RGB_BLACK	0x00000000
#define	RGB_BLUE	0x00FF0000
#define	RGB_YELLOW	0x0000FFFF
#define RGB_DEFAULT	0x00C0C0C0
#define RGB_HILIGHT 0x6A240A

#define FONT_SETTING_SMALL		-19
#define FONT_SETTING_MEDIUM		-21
#define FONT_SETTING_LARGE		-24
#define FONT_SETTING_XLARGE		-27
#define FONT_SETTING_DEFAULT	-11
#define MENU_SETTING_DEFAULT	18

#define FACE_NAME_SERIF			"Times"
#define FACE_NAME_SANSSERIF		"MS Sans Serif"
#define FACE_NAME_MONOSPACED	"Courier"
#define FACE_NAME_CURSIVE		"Comic Sans MS"
#define FACE_NAME_FANTASY		"Western"
#define FACE_NAME_DEFAULT		FACE_NAME_SANSSERIF

#define FACE_TYPE_SERIF			"serif"
#define FACE_TYPE_SANSSERIF		"sansserif"
#define FACE_TYPE_MONOSPACED	"monospaced"
#define FACE_TYPE_CURSIVE		"cursive"
#define FACE_TYPE_FANTASY		"fantasy"

#define CURSOR_STD_WHITE	"c:\\windows\\cursors\\F_no.cur"
#define CURSOR_TRAILS_DISABLE	0

// OS major version codes
#define WIN98	4
#define WIN2K	5

// Globals extracted from command line
int iFontSize = FONT_SETTING_DEFAULT;
char strFontFace[20];
int iBgColour;
int iFgColour;
int iHilightColour;
int iCursorColour;
int iCursorSize;
int iCursorTrails;

// Cursors
#define OCR_NORMAL          32512
#define OCR_IBEAM           32513
#define OCR_WAIT            32514
#define OCR_CROSS           32515
#define OCR_UP              32516
#define OCR_SIZE            32640   /* OBSOLETE: use OCR_SIZEALL */
#define OCR_ICON            32641   /* OBSOLETE: use OCR_NORMAL */
#define OCR_SIZENWSE        32642
#define OCR_SIZENESW        32643
#define OCR_SIZEWE          32644
#define OCR_SIZENS          32645
#define OCR_SIZEALL         32646
#define OCR_ICOCUR          32647   /* OBSOLETE: use OIC_WINLOGO */
#define OCR_NO              32648
#define OCR_HAND            32649
#define OCR_APPSTARTING     32650

#define NUMCURSORS	3

#define BLACK_XLARGE	6
#define BLACK_LARGE		5
#define BLACK_STANDARD	4
#define WHITE_XLARGE	3
#define WHITE_LARGE		2
#define WHITE_STANDARD	1

#define CURSOR_WHITE	1
#define CURSOR_BLACK	0

#define CURSOR_STANDARD	1
#define CURSOR_LARGE	2
#define CURSOR_XLARGE	3

#define STD	1
#define	LG	2
#define	XLG	3
#define	WHT	1
#define	BLK	2

int cursorIds[NUMCURSORS] = { OCR_NORMAL,
                  OCR_WAIT,
				  OCR_APPSTARTING };

char cursors_white_standard_win98[NUMCURSORS][40] = {
				"\\cursors\\arrow_1.cur",
				"\\cursors\\busy_1.cur",
				"\\cursors\\wait_1.cur" };
char cursors_white_standard_win2k[NUMCURSORS][40] = {
				"\\cursors\\3dwarro.cur",
				"\\cursors\\busy_1.cur",
				"\\cursors\\wait_1.cur" };
char cursors_white_large[NUMCURSORS][40] = {
				"\\cursors\\arrow_M.cur",
				"\\cursors\\busy_M.cur",
				"\\cursors\\wait_M.cur" };
char cursors_white_xlarge[NUMCURSORS][40] = {
				"\\cursors\\arrow_L.cur",
				"\\cursors\\busy_L.cur",
				"\\cursors\\wait_L.cur" };
char cursors_black_standard[NUMCURSORS][40] = {
				"\\cursors\\arrow_r.cur",
				"\\cursors\\busy_r.cur",
				"\\cursors\\wait_r.cur" };
char cursors_black_large[NUMCURSORS][40] = {
				"\\cursors\\arrow_rm.cur",
				"\\cursors\\busy_rm.cur",
				"\\cursors\\wait_rm.cur" };
char cursors_black_xlarge[NUMCURSORS][40] = {
				"\\cursors\\arrow_rl.cur",
				"\\cursors\\busy_rl.cur",
				"\\cursors\\wait_rl.cur" };



#endif // !defined(AFX_FONTCOLOURSETUP_H__6C0F2E7C_7352_4BAB_A7E9_B0BE867EE253__INCLUDED_)
