/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

// FontColourSetup.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "FontColourSetup.h"
#include "iostream.h"
#include "Tlhelp32.h"


/////////////////////////////////////////////////////////////////////////////
// OutputMsg
/////////////////////////////////////////////////////////////////////////////
void OutputMsg(char *msg)
{
	SYSTEMTIME systemTime;
	char lpTimeStr[40];
	char lpDateStr[40];

	GetSystemTime((LPSYSTEMTIME) &systemTime);

	GetDateFormat(
		NULL,               // locale
		NULL,             // options
		&systemTime,  // date
		NULL,          // date format
		(LPTSTR) lpDateStr,          // formatted string buffer
		40                // size of buffer
	);

	GetTimeFormat(
		NULL,              // locale
		TIME_FORCE24HOURFORMAT,            // options
		&systemTime, // time
		"HH':'mm':'ss'",         // time format string
		(LPTSTR) lpTimeStr,         // formatted string buffer
		40               // size of string buffer
	);

//	cout << _T (lpDateStr);
//	cout << _T (" ");
	cout << _T (lpTimeStr);
	cout << _T (" FontColourSetup: ");
	cout << _T (msg) << endl;
}

/////////////////////////////////////////////////////////////////////////////
// OutputErrMsg
/////////////////////////////////////////////////////////////////////////////
void OutputErrMsg()
{
	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		(LPTSTR) &lpMsgBuf,
		0,
		NULL 
	);
	OutputMsg("Error Message: ");
	cout << _T("                   ");
	cout << _T((char *)lpMsgBuf);
}

/////////////////////////////////////////////////////////////////////////////
// OutputSyntaxHelp
/////////////////////////////////////////////////////////////////////////////
void OutputSyntaxHelp()
{
	OutputMsg ("FontColourSetup - sets Windows fonts and colours.");
	OutputMsg ("Syntax: FontColourSetup <fontSize> <fontFace> <fgColour> <bgColour> <cursorColour> <cursorSize> <cursorTrails>");
	OutputMsg ("        where");
	OutputMsg ("              <fontSize> is a negative integer representing a font size (according to Windows documentation)");
	OutputMsg ("              <fontFace> is a string font name, or one of \"serif\", \"sansserif\", \"monospaced\",");
	OutputMsg ("                               \"cursive\" or \"fantasy\".");
	OutputMsg ("              <fgColour> is an integer representing the foreground colour (based on 0xBBGGRR)");
	OutputMsg ("              <bgColour> is an integer representing the background colour (based on 0xBBGGRR)");
	OutputMsg ("              <hilightColour> is an integer representing the hilight colour (based on 0xBBGGRR)");
	OutputMsg ("              <cursorColour> is 1 for white, 0 for black");
	OutputMsg ("              <cursorSize> is 1, 2 or 3 for standard, large or extra-large");
	OutputMsg ("              <cursorTrails> is 0 for disabled, or 1-10 for length");
}

/////////////////////////////////////////////////////////////////////////////
// KillSmartCardProcess
/////////////////////////////////////////////////////////////////////////////
int KillSmartCardProcess(void)
{
	HANDLE snapshot;
	PROCESSENTRY32 pe;

	OutputMsg("Searching for offending card process");

	if ((int)(snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPALL, 0)) == -1)
	{
		OutputMsg(">>> failure getting process snapshot");
		return -1;
	}

	pe.dwSize = sizeof(pe);
	if (!Process32First(snapshot, &pe))
	{
		OutputMsg(">>> failure getting first process");
		DWORD rc = GetLastError();
		if (rc == ERROR_NO_MORE_FILES)
			OutputMsg("  no more file");
		return -1;
	}

	OutputMsg(pe.szExeFile);
	if (strstr(pe.szExeFile,"SCARDS32.EXE") != NULL)
	{
		OutputMsg("Found offending process, killing...");
		if (!TerminateProcess(OpenProcess(PROCESS_ALL_ACCESS,TRUE,pe.th32ProcessID), 0))
		{

			OutputMsg("       ===== termination failed");
			OutputErrMsg();
		}
		return 0;
	}

	while (Process32Next(snapshot, &pe))
	{
		OutputMsg(pe.szExeFile);
		if (strstr(pe.szExeFile,"SCARDS32.EXE") != NULL)
		{
			OutputMsg("Found offending process, killing...");
			if (!TerminateProcess(OpenProcess(PROCESS_ALL_ACCESS,TRUE,pe.th32ProcessID), 0))
			{
				OutputMsg("       ===== termination failed");
				OutputErrMsg();
			}
			return 0;
		}

	}
	OutputMsg("Offending card process not found, returning");
	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// ProcessCommandLine
/////////////////////////////////////////////////////////////////////////////
int ProcessCommandLine(int argc, char argv[][20])
{
	OutputMsg("Processing command line options");

	if (argc == 1)	// no parameters, setting to windows defaults
	{
		iFontSize = FONT_SETTING_DEFAULT;
		strcpy (strFontFace, FACE_NAME_DEFAULT);
		iFgColour = RGB_BLACK;
		iBgColour = RGB_DEFAULT;
		iHilightColour = RGB_HILIGHT;
		iCursorColour = CURSOR_WHITE;
		iCursorSize = CURSOR_STANDARD;
		iCursorTrails = CURSOR_TRAILS_DISABLE;
		
		// kill the offending smart card process
	//	KillSmartCardProcess();
		return 0;
	}

	else if (argc == 9)
	{
		// set to defaults for now
		iFontSize = atoi(argv[1]);
		strcpy (strFontFace, argv[2]);
		iFgColour = atoi(argv[3]);
		iBgColour = atoi(argv[4]);
		iHilightColour = atoi(argv[5]);
		iCursorColour = atoi(argv[6]);
		iCursorSize = atoi(argv[7]);
		iCursorTrails = atoi(argv[8]);

		return 0;
	}
	else
	{
		OutputSyntaxHelp();
		return -1;
	}	

}


/////////////////////////////////////////////////////////////////////////////
// ConfigureWindows
/////////////////////////////////////////////////////////////////////////////
int ConfigureWindows() 
{
	COLORREF fgColour;
	COLORREF bgColour;
	COLORREF hilightColour;

	OutputMsg("Configuring system fonts/colours");

	fgColour = iFgColour;
	bgColour = iBgColour;
	hilightColour = iHilightColour;

	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	OutputMsg("Configuring fonts: calling SystemParametersInfo(get info)");
	if (!SystemParametersInfo(SPI_GETNONCLIENTMETRICS,
								sizeof(NONCLIENTMETRICS), (PVOID)&ncm,
								NULL))
	{
		OutputMsg("=== Error configuring system fonts: SystemParametersInfo(get info) failed");
		OutputErrMsg();
		return 1;
	}
	OutputMsg("SystemParametersInfo(get info) completed successfully.");

	if (strcmp(strFontFace, FACE_TYPE_SERIF) == 0)
		strcpy(ncm.lfMenuFont.lfFaceName, FACE_NAME_SERIF);
	else if (strcmp(strFontFace, FACE_TYPE_SANSSERIF) == 0)
		strcpy(ncm.lfMenuFont.lfFaceName, FACE_NAME_SANSSERIF);
	else if (strcmp(strFontFace, FACE_TYPE_MONOSPACED) == 0)
		strcpy(ncm.lfMenuFont.lfFaceName, FACE_NAME_MONOSPACED);
	else if (strcmp(strFontFace, FACE_TYPE_CURSIVE) == 0)
		strcpy(ncm.lfMenuFont.lfFaceName, FACE_NAME_CURSIVE);
	else if (strcmp(strFontFace, FACE_TYPE_FANTASY) == 0)
		strcpy(ncm.lfMenuFont.lfFaceName, FACE_NAME_FANTASY);
	else
		strcpy(ncm.lfMenuFont.lfFaceName, strFontFace);

	ncm.lfMenuFont.lfHeight = iFontSize;
	ncm.iMenuHeight = iFontSize;
	OutputMsg("Configuring fonts: calling SystemParametersInfo(set info)");
	if (!SystemParametersInfo(SPI_SETNONCLIENTMETRICS,
								sizeof(NONCLIENTMETRICS), (PVOID)&ncm,
								NULL))
	{
		OutputMsg("=== Error configuring system fonts: SystemParametersInfo(set info) failed");
		OutputErrMsg();
		return 1;
	}
	OutputMsg("SystemParametersInfo(set info) completed successfully.");


	int cElements = 5;
	int elements[] = { COLOR_MENU, COLOR_MENUBAR, COLOR_MENUTEXT, COLOR_HIGHLIGHT, COLOR_MENUHILIGHT };
	COLORREF values[] = { bgColour, bgColour, fgColour, hilightColour, hilightColour  };

	OutputMsg("Configuring colours: calling SetSysColors(menus)");
	if (!SetSysColors(cElements, elements, values))
	{
		OutputMsg("=== Error configuring system colours: SetSysColors(menus) failed");
		OutputErrMsg();
		return 1;
	}
	OutputMsg("SetSysColors(menus) completed successfully.");

	OutputMsg("Configuring system fonts/colours completed successfully - returning.");
	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// ConfigureCursorTrails
/////////////////////////////////////////////////////////////////////////////
int ConfigureCursorTrails()
{
	int setting;

	if (iCursorTrails == CURSOR_TRAILS_DISABLE)
		setting = CURSOR_TRAILS_DISABLE;
	else
		setting = iCursorTrails;

	OutputMsg("Configuring cursor trails: calling SystemParametersInfo(set info)");
	if (!SystemParametersInfo(SPI_SETMOUSETRAILS,
								setting, NULL, 0))
	{
		OutputMsg("=== Error configuring cursor trails: SystemParametersInfo(set info) failed");
		OutputErrMsg();
		return 1;
	}
	OutputMsg("SystemParametersInfo(set info) completed successfully.");
}

/////////////////////////////////////////////////////////////////////////////
// ConfigureCursors
/////////////////////////////////////////////////////////////////////////////
int ConfigureCursors()
{
	char cursors[NUMCURSORS][40];
	int setting, i;

	OSVERSIONINFO versionInfo;
	versionInfo.dwOSVersionInfoSize = sizeof(versionInfo);

	if (!GetVersionEx(&versionInfo))
	{
		OutputMsg("=== Error determing OS version: GetVersionEx() failed");
		OutputErrMsg();
		return 1;
	}

	char sysdir[40];
	UINT sysdirrc;
	sysdirrc = GetWindowsDirectory(
		sysdir,  // buffer for system directory
		sizeof(sysdir)        // size of directory buffer
	);


	OutputMsg("Configuring system cursors");

	if ((iCursorColour == CURSOR_WHITE) && (iCursorSize == CURSOR_STANDARD))
		setting = WHITE_STANDARD;
	else if ((iCursorColour == CURSOR_WHITE) && (iCursorSize == CURSOR_LARGE))
		setting = WHITE_LARGE;
	else if ((iCursorColour == CURSOR_WHITE) && (iCursorSize == CURSOR_XLARGE))
		setting = WHITE_XLARGE;
	else if ((iCursorColour == CURSOR_BLACK) && (iCursorSize == CURSOR_STANDARD))
		setting = BLACK_STANDARD;
	else if ((iCursorColour == CURSOR_BLACK) && (iCursorSize == CURSOR_LARGE))
		setting = BLACK_LARGE;
	else if ((iCursorColour == CURSOR_BLACK) && (iCursorSize == CURSOR_XLARGE))
		setting = BLACK_XLARGE;
	else
		setting = WHITE_STANDARD;

	if (setting == WHITE_STANDARD)
	{
		// just reset to system defaults, and return
		if (SystemParametersInfo(SPI_SETCURSORS, 0, NULL, SPIF_SENDWININICHANGE) == 0)
		{
			OutputMsg("=== Error resetting cursors to default: SystemParametersInfo() failed:");
			OutputErrMsg();
			return 1;
		}
		return 0;
	}

	for (i=0; i<NUMCURSORS; i++)
		strcpy(cursors[i], sysdir);
	switch (setting)
	{
	case BLACK_XLARGE:
		for (i=0; i<NUMCURSORS; i++)
			strcat(cursors[i], cursors_black_xlarge[i]);
		break;
	case BLACK_LARGE:
		for (i=0; i<NUMCURSORS; i++)
			strcat(cursors[i], cursors_black_large[i]);
		break;
	case BLACK_STANDARD:
		for (i=0; i<NUMCURSORS; i++)
			strcat(cursors[i], cursors_black_standard[i]);
		break;
	case WHITE_XLARGE:
		for (i=0; i<NUMCURSORS; i++)
			strcat(cursors[i], cursors_white_xlarge[i]);
		break;
	case WHITE_LARGE:
		for (i=0; i<NUMCURSORS; i++)
			strcat(cursors[i], cursors_white_large[i]);
		break;
	case WHITE_STANDARD:	// special case
	default:
		if (versionInfo.dwMajorVersion == WIN98)
			for (i=0; i<NUMCURSORS; i++)
				strcat(cursors[i], cursors_white_standard_win98[i]);
		else if (versionInfo.dwMajorVersion == WIN2K)
			for (i=0; i<NUMCURSORS; i++)
				strcat(cursors[i], cursors_white_standard_win2k[i]);
		else 
			OutputMsg("=== Unrecognized operating system version - can't reset cursor to default");
		break;
	}

	// set the cursors
	HCURSOR hcur;
	DWORD id;       // system cursor identifier
	for (i=0; i<NUMCURSORS; i++)
	{
		hcur = LoadCursorFromFile(cursors[i]);
		if (hcur == NULL)
		{
			OutputMsg("=== Error loading cursors from file: LoadCursorFromFile() failed");
			OutputErrMsg();
			return 1;
		}
		id = cursorIds[i];
		OutputMsg("Configuring cursors: calling SetSysCursor()");
		if (!SetSystemCursor (hcur, id))
		{
			OutputMsg("=== Error configuring system cursors, SetSystemCursor() failed:");
			OutputErrMsg();
			return 1;
		}
		OutputMsg("SetSysCursor() completed successfully.");
	}

	OutputMsg("Configuring system cursors completed successfully - returning.");
	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// WinMain
/////////////////////////////////////////////////////////////////////////////
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	char seps[] = " ";
	char* token;
	char argv[10][20];	// assume less than 10 integer arguments for our purposes.
	token = strtok(lpCmdLine, seps);
	int argc = 1;
	while (token != NULL)
	{
		strcpy(argv[argc++], token);
        token = strtok( NULL, seps );
    }

	OutputMsg("starting");

	if (ProcessCommandLine(argc, argv))
		return 1;

	OutputMsg("Calling ConfigureWindows()");
	if (ConfigureWindows())
	{
		OutputMsg("=== Error configuring colours, exitting with error code");
		return -1;
	}
	OutputMsg("Returned from ConfigureWindows() successfully.");

	OutputMsg("Calling ConfigureCursors()");
	if (ConfigureCursors())
	{
		OutputMsg("=== Error configuring cursors, exitting with error code");
		return -1;
	}
	OutputMsg("Returned from ConfigureCursors() successfully.");

	OutputMsg("Calling ConfigureCursorTrails()");
	if (ConfigureCursorTrails())
	{
		OutputMsg("=== Error configuring cursor trails, exitting with error code");
		return -1;
	}
	OutputMsg("Returned from ConfigureCursorTrails() successfully.");

	OutputMsg("completed successfully, exitting.");

	return 0;

}
