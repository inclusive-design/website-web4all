/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

#include <stdio.h>
#include <process.h>
#include <windows.h>

/** 
 * File: start_web4AllPWM.c
 * Author: David Weinkauf
 * Version: $Revision: 1.2 $, $Date: 2006/03/27 16:27:17 $
 *
 * This is the Windows executable to launch the Web4All PWM WITHOUT A MS-DOS WINDOW.
 * It also dynamically adds all the third party JAR files to the CLASSPATH.
 * 
 * SPECIAL COMPILATION NOTE:
 * This program was designed to be compiled with the MINGW (Miniumal Gnu Tools for Windows) gcc compiler with 
 * the -mwindows option. The -mwindows argument deprecates the creation of unwanted MS-DOS windows in the
 * main program (it also links up necessary Windows libraries with your program - cool).
 * For example: gcc -o executable_name start_web4All.c -mwindows
 */

const char* SEPARATOR = ";";                       /* Windows separates files in the CLASSPATH with a semi-colon */
const char* JAR_WILD_CARD = "*.jar";               /* The wild card to retrieve every JAR file in the current directory */
const char* LAUNCHER_LOG = "launcher.log";         /* The name of the log file */
const char* THIRD_PARTY_FOLDER = "3rd_party";      /* The name of the third party directory */
const char* LIB_FOLDER = "lib";                    /* The name of the lib directory */
const char* W4A_MAIN = "ca.utoronto.atrc.web4all.Web4All"; /* The main class */

/**
 * prependJarsFromDir:
 *
 * @dir: the directory look for JAR files in
 * @path: the path to prepend JAR files to
 * @log: the log file
 *
 * Prepend the absolute path of JAR files found in @dir to @path.
 */
void prependJarsFromDir(const char *dir, char **path, FILE *log) {
  char *next_jar;                              /* The next JAR we add to the classpath */
  char *full_path_name;                        /* The full path name of the JAR file */
  char *current_directory;                     /* The current directory of the application */
  char *temp_path;
  WIN32_FIND_DATA FindFileData;                /* The struct to hold the JAR file data */
  HANDLE file_handle;                          /* The HANDLE used for searching for files */
  int cwd_length;
  int file_length;
  int cur_size;

  /* Set the current directory to the third party folder */
  fprintf(log, "Moving to the directory: %s......\n", dir);

  if (!SetCurrentDirectory(dir)) {
    fprintf(log, "%s directory not found.\n", dir);
    return;
  }

  cwd_length = GetCurrentDirectory(0, current_directory);
  current_directory = (char*) malloc((cwd_length + 1) * sizeof(char));
  if (current_directory == NULL) {
    fprintf(log, "Out of memory.\n");
    exit(1);
  }
    
  GetCurrentDirectory(cwd_length, current_directory);
  fprintf(log, "Current directory is %s\n", current_directory);
    
  /* Use a wild card (e.g. *.jar) to retrieve all JAR files in third party folder */
  fprintf(log, "JAR wild card: %s\n", JAR_WILD_CARD);
    
  /* Find the first JAR file in the third party folder */
  file_handle = FindFirstFile(JAR_WILD_CARD, &FindFileData);
    
  /* Check if we retrieved a valid HANDLE to the third party directory listing of files */
  if (file_handle == INVALID_HANDLE_VALUE) {
    fprintf (log, "Invalid File Handle. Get Last Error reports %d\n", GetLastError ());
    fprintf (log, "NO THIRD PARTY JARS FOUND!\n\n");
  } 
  else {
    fprintf (log, "The first JAR file found is %s\n", FindFileData.cFileName);
  }
    
  if (file_handle != INVALID_HANDLE_VALUE) {
    /* Add the JAR file to the classpath. Don't forget to separate with a semi-colon and to 
     * retrieve the full path name of the JAR file we are adding.
     */
    file_length = GetFullPathName(FindFileData.cFileName, 0, full_path_name, NULL);  
    full_path_name = (char*) malloc((file_length + 1) * sizeof(char));
    if (full_path_name == NULL) {
      fprintf(log, "Out of memory.\n");
      exit(1);
    }
      
    GetFullPathName(FindFileData.cFileName, file_length, full_path_name, NULL);
    
    cur_size = strlen(*path) + 1;
    temp_path = (char*) malloc(cur_size * sizeof(char));
    if (temp_path == NULL) {
      fprintf(log, "Out of memory.\n");
      exit(1);
    }
    strcpy(temp_path, *path);

    *path = (char*) realloc(*path, (strlen(*path) + file_length + 2 + 2) * sizeof(char));
    if (*path == NULL) {
      fprintf(log, "Out of memory.\n");
      exit(1);
    }

    memset(*path, 0, cur_size);
    strcat(*path, "\"");
    strcat(*path, full_path_name);
    strcat(*path, "\"");
    strcat(*path, SEPARATOR);
    strcat(*path, temp_path);

    free(temp_path);
          
    /* Loop through the remaining JAR files adding them to the classpath */
    while (FindNextFile(file_handle, &FindFileData)) {
      fprintf(log, "The next JAR file found is %s\n", FindFileData.cFileName);
	
      file_length = GetFullPathName(FindFileData.cFileName, 0, full_path_name, NULL);  
      full_path_name = (char*) malloc((file_length + 1) * sizeof(char));
      if (full_path_name == NULL) {
	fprintf(log, "Out of memory.\n");
	exit(1);
      }
	
      GetFullPathName(FindFileData.cFileName, file_length, full_path_name, NULL);

      cur_size = strlen(*path) + 1;
      temp_path = (char*) malloc(cur_size * sizeof(char));
      if (temp_path == NULL) {
	fprintf(log, "Out of memory.\n");
	exit(1);
      }
      strcpy(temp_path, *path);
	
      *path = (char*) realloc(*path, (strlen(*path) + file_length + 2 + 2) * sizeof(char));
      if (*path == NULL) {
	fprintf(log, "Out of memory.\n");
	exit(1);
      }
	
      memset(*path, 0, cur_size);
      strcat(*path, "\"");
      strcat(*path, full_path_name);
      strcat(*path, "\"");
      strcat(*path, SEPARATOR);
      strcat(*path, temp_path);

      free(temp_path);
    }
      
    /* Close the HANDLE */
    FindClose(file_handle);      

  }
  
  /* Move back up to the parent directory */
  fprintf(log, "Moving up to parent directory......\n");
  SetCurrentDirectory("..");
  cwd_length = GetCurrentDirectory(0, current_directory);
  current_directory = (char*) malloc((cwd_length + 1) * sizeof(char));
  if (current_directory == NULL) {
    fprintf(log, "Out of memory.\n");
    exit(1);
  }
  
  GetCurrentDirectory(cwd_length, current_directory);    
  fprintf(log, "Current directory is %s\n", current_directory);
  
}

/**
 * Check if Web-4-All is launched and return pointer to 
 * window if it is.
 */
HWND isWeb4AllLaunched() {

  HWND handle = NULL;

  handle = FindWindow(NULL, "Le Web pour tous | Web-4-All");
  if (handle == NULL)
    handle = FindWindow(NULL, "Web-4-All | Le Web pour tous");

  return handle;

}

/**
 * main:
 * 
 * Launches Web-4-All after dynamically generating the classpath from the lib and 3rd_party dirs.
 */
int main(int argc, char *argv[]) { 
  int ret;                                /* The return value of _spawnlp */
  char *classpath;                        /* Holds the CLASSPATH + THIRD_PARTY JARS */
  FILE *log;                              /* Log file */
  HWND window;                            /* Web-4-All window */ 


  /* If Web-4-All is launched, restore and focus its window. */
  if ( (window = isWeb4AllLaunched()) != NULL ) {
    ShowWindow(window, SW_RESTORE);
    SetForegroundWindow(window);
    exit(1);
  }

  /* Initialize classpath to NULL */
  classpath = (char*) malloc(sizeof(char));
  memset(classpath, 0, sizeof(char));

  /* Initialize the log file */
  log = fopen(LAUNCHER_LOG, "w");
  if (!log) {
    fprintf(stderr, "Could not open %s\n", LAUNCHER_LOG);
  }

  fprintf(log, "Web-4-All-PWM startup log.\n\n");

  /* Do not prepend JARs from the system CLASSPATH anymore
     b/c sometimes the system CLASSPATH is malformed and so
     Web-4-All chokes! */

  prependJarsFromDir(THIRD_PARTY_FOLDER, &classpath, log);
  prependJarsFromDir(LIB_FOLDER, &classpath, log);
 
  fprintf(log, "\nFinal CLASSPATH: %s\n\n", classpath);

  fprintf(log, "Main class: %s\n", W4A_MAIN);
  fprintf(log, "Spawning Web4All for the first time............\n");
  
  /* Flush the log before we call Web4All */
  fflush(log);

  /* No looping b/c this is only the PWM.*/
  ret = _spawnlp( _P_WAIT, "javaw.exe", "javaw.exe", "-cp", classpath, W4A_MAIN, NULL);	
  exit(ret);

}
