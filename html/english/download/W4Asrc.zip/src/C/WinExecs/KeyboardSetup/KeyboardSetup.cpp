/*
 * MIT Open Source Code License
 * 
 * Web-4-All
 * 
 * Copyright (c) 2006, University of Toronto. All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Adaptive Technology Resource Centre, University of Toronto
 * 130 St. George St., Toronto, Ontario, Canada
 * Telephone: (416) 978-4360
 */

// KeyboardSetup.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "KeyboardSetup.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;


/////////////////////////////////////////////////////////////////////////////
// OutputErrMsg
/////////////////////////////////////////////////////////////////////////////
void OutputErrMsg()
{

	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		(LPTSTR) &lpMsgBuf,
		0,
		NULL 
	);
	cout << _T("     *** Error Message: ");
	cout << _T((char *)lpMsgBuf) << endl;
}

/////////////////////////////////////////////////////////////////////////////
// SetupStickyKeys
/////////////////////////////////////////////////////////////////////////////
int SetupStickyKeys(BOOL inOnOff)
{
	int result = 0;
	STICKYKEYS sk;
	sk.cbSize = sizeof(sk);

	if (inOnOff)
	{
		cout << _T("    Turning sticky keys on...") << endl;
		sk.dwFlags = SKF_AVAILABLE |
					 SKF_STICKYKEYSON |
					 SKF_AUDIBLEFEEDBACK |
					 SKF_INDICATOR;
		if (!SystemParametersInfo(SPI_SETSTICKYKEYS,
									sizeof(STICKYKEYS), (PVOID)&sk,
									SPIF_UPDATEINIFILE|SPIF_SENDCHANGE))
		{
			OutputErrMsg();
			cerr << _T("        Error setting up Sticky Keys") << endl;
			result = -1;
		}
	}
	else
	{
		cout << _T("    Disabling sticky keys...") << endl;
		sk.dwFlags = SKF_AVAILABLE;
		if (!SystemParametersInfo(SPI_SETSTICKYKEYS,
									sizeof(STICKYKEYS), (PVOID)&sk,
									SPIF_UPDATEINIFILE|SPIF_SENDCHANGE))
		{
			OutputErrMsg();
			cerr << _T("        Error disabling Sticky Keys") << endl;
			result = -1;
		}

	}

	return result;
}


/////////////////////////////////////////////////////////////////////////////
// SetupDebounce
/////////////////////////////////////////////////////////////////////////////
void SetupDebounce(FILTERKEYS *inFK,BOOL inOnOff)
{

	if (inOnOff)
	{
		cout << _T("    Setting debounce interval...") << endl;
		// set appropriate flags to turn filter keys on
		inFK->dwFlags = FKF_AVAILABLE |
					 FKF_FILTERKEYSON |	// this will be off in default state
					 FKF_CLICKON |
					 FKF_INDICATOR;

		// set the debounce interval to the input value
		inFK->iBounceMSec = inDebounce;

		// set other settings to 0, as debounce overrides them
		inFK->iDelayMSec = 0;
		inFK->iWaitMSec = 0;
		inFK->iRepeatMSec = 0;
		
	}
	else
	{
		cout << _T("    Disabling debounce...") << endl;
		inFK->iBounceMSec = 0;

	}
	
}

/////////////////////////////////////////////////////////////////////////////
// SetupRepeatKeys
/////////////////////////////////////////////////////////////////////////////
void SetupRepeatKeys(FILTERKEYS *inFK, BOOL inOnOff)
{
	if (inOnOff)
	{
		cout << _T("    Setting repeat key values...") << endl;
		// set appropriate flags to turn repeat keys on
		inFK->dwFlags = FKF_AVAILABLE |
					 FKF_FILTERKEYSON |	// this will be off in default state
					 FKF_CLICKON |
					 FKF_INDICATOR;

		// set the delay and repeat for the slowing of keyboard rates
		inFK->iDelayMSec = inDelay;
		inFK->iRepeatMSec = inRate;

		// turn bounce keys off (otherwise it will override these settings)
		if (versionInfo.dwMajorVersion == WIN98)
			inFK->iBounceMSec = BOUNCE_DISABLE;
		else
			inFK->iBounceMSec = 0;

	}
	else
	{
		cout << _T("    Disabling repeat keys...") << endl;
		// set appropriate flags to turn repeat keys on
		inFK->iDelayMSec = 0;
		inFK->iWaitMSec = 0;

	}

}

/////////////////////////////////////////////////////////////////////////////
// SetupSlowKeys
/////////////////////////////////////////////////////////////////////////////
void SetupSlowKeys(FILTERKEYS *inFK, BOOL inOnOff)
{
	if (inOnOff)
	{
		cout << _T("    Setting slow key value...") << endl;
		inFK->dwFlags = FKF_AVAILABLE |
					 FKF_FILTERKEYSON |	// this will be off in default state
					 FKF_CLICKON |
					 FKF_INDICATOR;

		// set the slow keys value to the input value
		inFK->iWaitMSec = inSlowKeys;
		
		// turn bounce keys off (otherwise it will override these settings)
		if (versionInfo.dwMajorVersion == WIN98)
			inFK->iBounceMSec = BOUNCE_DISABLE;
		else
			inFK->iBounceMSec = 0;

	}
	else
	{
		cout << _T("    Disabling slow keys...") << endl;

		// set the slow keys value to the default
		inFK->iWaitMSec = 0;
		
		// set other values to ensure that slowkeys is off
		inFK->iDelayMSec = 0;

	}
}


/////////////////////////////////////////////////////////////////////////////
// ConfigureKeyboard
/////////////////////////////////////////////////////////////////////////////
int ConfigureKeyboard()
{
	int result = 0;
	FILTERKEYS fk;
	memset(&fk,0,sizeof(fk));
	fk.cbSize = sizeof(fk);


	cout << _T("Configuring Keyboard...") << endl;

	// get a copy of the current filter key values
	if (!SystemParametersInfo(SPI_GETFILTERKEYS,
								sizeof(FILTERKEYS), (PVOID)&fk,
								SPIF_UPDATEINIFILE|SPIF_SENDCHANGE))
	{
		OutputErrMsg();
		cerr << _T("  Error getting a copy of the FilterKeys info") << endl;
		result = -1;
	}

	// either enable or disable sticky keys
	if (inStickyKeys == 1)
	{
		if (SetupStickyKeys(true) != 0)
			result = -1;
	}
	else
		if (SetupStickyKeys(false) != 0)
			result = -1;



	// set the contents of the filterkeys data structure accordingly

	// either set up or disable key repeat
	if (inRepeat == 1)
		SetupRepeatKeys(&fk, true);

	else
		SetupRepeatKeys(&fk, false);

	// set the slow key rate
	if (inSlowKeys != 0)
		SetupSlowKeys(&fk, true);

	else
		SetupSlowKeys(&fk, false);

	// set the debounce interval
	// we do this last, because it overides
	// all other filterkeys settings
	if (inDebounce != 0)
		SetupDebounce(&fk, true);

	else
		SetupDebounce(&fk, false);

	// if the system is to be reset, then ensure all the appropriate
	// flags are turned off
	if (reset)
	{
		fk.dwFlags &= !FKF_AVAILABLE &
					 !FKF_FILTERKEYSON &	// this will be off in default state
					 !FKF_CLICKON &
					 !FKF_INDICATOR;
	}

	// set the settings
	if (!SystemParametersInfo(SPI_SETFILTERKEYS,
								sizeof(FILTERKEYS), (PVOID)&fk,
								SPIF_UPDATEINIFILE|SPIF_SENDCHANGE))
	{
		OutputErrMsg();
		cerr << _T("  Error resetting SlowKeys rate") << endl;
		result = -1;
	}


	cout << _T("...done configuring keyboard...") << endl;
	return result;
}

/////////////////////////////////////////////////////////////////////////////
// OutputSyntaxHelp
/////////////////////////////////////////////////////////////////////////////
void OutputSyntaxHelp()
{
	cout << _T ("KeyboardSetup sets keyboard accessibility features.") << endl;
	cout << _T ("Syntax: KeyboardSetup <stickykeys> <repeat> <delay> <rate> <slowkeys> <debounce>") << endl;
	cout << _T ("    where") << endl;
	cout << _T ("          <stickykeys> is 1 to enable sticky keys, 0 otherwise") << endl;
	cout << _T ("          <repeat>     is 1 to enable repeat key settings, 0 otherwise") << endl;
	cout << _T ("          <delay>      is the repeat delay in milliseconds") << endl;
	cout << _T ("          <rate>       is the repeat rate in milliseconds") << endl;
	cout << _T ("          <slowkeys>   is the slow key wait in milliseconds") << endl;
	cout << _T ("          <debounce>   is the debounce interval in milliseconds") << endl;

}

/////////////////////////////////////////////////////////////////////////////
// ProcessCommandLine
/////////////////////////////////////////////////////////////////////////////
int ProcessCommandLine(int argc, char argv[][20])

{
	cout << _T("Processing command line...") << endl;

	if (argc == 1)	// no parameters, setting to defaults
	{
		inStickyKeys = 0;
		inRepeat     = 0;
		inDelay      = 0;
		inRate       = 0;
		inSlowKeys   = 0;
		if (versionInfo.dwMajorVersion == WIN98)
			inDebounce = BOUNCE_DISABLE;	// bug in WIN98 - must set to enable to disable
		else
			inDebounce = 0;

		
		reset = true;
	}
	else if (argc == 2)
	{
		if (!strcmp(argv[1], "-?"))
		{
			OutputSyntaxHelp();
			return 0;
		}
		else
		{
			OutputSyntaxHelp();
			return -1;
		}
	}
	else if (argc == 7)
	{
		inStickyKeys	= atoi(argv[1]);
		inRepeat		= atoi(argv[2]);
		inDelay			= atoi(argv[3]);
		inRate			= atoi(argv[4]);
		inSlowKeys		= atoi(argv[5]);
		inDebounce		= atoi(argv[6]);
	}
	else
	{
		OutputSyntaxHelp();
		return -1;
	}

	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// WinMain
/////////////////////////////////////////////////////////////////////////////
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	int result = 0;

	char seps[] = " ";
	char* token;
	char argv[10][20];	// assume less than 10 integer arguments for our purposes.
	token = strtok(lpCmdLine, seps);
	int argc = 1;
	while (token != NULL)
	{
		strcpy(argv[argc++], token);
        token = strtok( NULL, seps );
    }


	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		return 1;
	}

	// determine the version
	versionInfo.dwOSVersionInfoSize = sizeof(versionInfo);
	if (!GetVersionEx(&versionInfo)) // version information
	{
		OutputErrMsg();
		cerr << _T("  Error determining operating system version") << endl;
		result = -1;
	}

	reset = false;

	if (ProcessCommandLine(argc, argv))
		return 1;

/*
	if (reset)
	{
		cout << _T("Setting keyboard configuration to default...") << endl;
		if (SetupStickyKeys(false) != 0)
			result = 1;
		if (SetupRepeatKeys(false) != 0)
			result = 1;
		if (SetupSlowKeys(false) != 0)
			result = 1;
		if (SetupDebounce(false) != 0)
			result = 1;
		cout << _T("... configuration complete.") << endl;
		return result;
	}
*/

	if (ConfigureKeyboard() != 0)
	{
		cerr << _T("  Error configuring keyboard.") << endl;
		return 1;
	}
	cout << _T("... configuration complete.") << endl;

	return 0;
}


